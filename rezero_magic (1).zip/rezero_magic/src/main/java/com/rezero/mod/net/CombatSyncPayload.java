package com.rezero.mod.net;

import com.rezero.mod.ReZeroMod;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Servidor -> cliente: técnicas aprendidas (máscara de bits), estamina atual e máxima. Só para mostrar na tela. */
public record CombatSyncPayload(int techniqueMask, int stamina, int maxStamina) implements CustomPayload {
	public static final CustomPayload.Id<CombatSyncPayload> ID =
			new CustomPayload.Id<>(Identifier.of(ReZeroMod.MOD_ID, "combat_sync"));

	public static final PacketCodec<RegistryByteBuf, CombatSyncPayload> CODEC = PacketCodec.tuple(
			PacketCodecs.VAR_INT, CombatSyncPayload::techniqueMask,
			PacketCodecs.VAR_INT, CombatSyncPayload::stamina,
			PacketCodecs.VAR_INT, CombatSyncPayload::maxStamina,
			CombatSyncPayload::new);

	@Override
	public CustomPayload.Id<? extends CustomPayload> getId() {
		return ID;
	}
}
