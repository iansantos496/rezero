package com.rezero.mod.net;

import com.rezero.mod.server.CombatService;
import com.rezero.mod.server.InscriptionService;
import com.rezero.mod.server.MagicGate;
import com.rezero.mod.server.ProtectionService;
import com.rezero.mod.server.RaceService;
import com.rezero.mod.server.SpellService;
import com.rezero.mod.server.SpiritService;
import com.rezero.mod.server.TrainingService;
import com.rezero.mod.server.TransformService;

import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;

/** Registro dos pacotes e dos receptores do SERVIDOR. Todo pedido do cliente passa pelo MagicGate. */
public final class ModNetworking {
	private ModNetworking() {}

	public static void registerCommon() {
		PayloadTypeRegistry.playC2S().register(ChooseAffinityPayload.ID, ChooseAffinityPayload.CODEC);
		PayloadTypeRegistry.playC2S().register(CastSpellPayload.ID, CastSpellPayload.CODEC);
		PayloadTypeRegistry.playC2S().register(InscribePayload.ID, InscribePayload.CODEC);
		PayloadTypeRegistry.playC2S().register(SelectTrainingPayload.ID, SelectTrainingPayload.CODEC);
		PayloadTypeRegistry.playS2C().register(TrainingSyncPayload.ID, TrainingSyncPayload.CODEC);
		PayloadTypeRegistry.playC2S().register(CombatActionPayload.ID, CombatActionPayload.CODEC);
		PayloadTypeRegistry.playS2C().register(CombatSyncPayload.ID, CombatSyncPayload.CODEC);
		PayloadTypeRegistry.playS2C().register(TechniqueCooldownPayload.ID, TechniqueCooldownPayload.CODEC);
		PayloadTypeRegistry.playC2S().register(SpiritActionPayload.ID, SpiritActionPayload.CODEC);
		PayloadTypeRegistry.playS2C().register(SpiritSyncPayload.ID, SpiritSyncPayload.CODEC);
		PayloadTypeRegistry.playC2S().register(ChooseRacePayload.ID, ChooseRacePayload.CODEC);
		PayloadTypeRegistry.playC2S().register(RaceActionPayload.ID, RaceActionPayload.CODEC);
		PayloadTypeRegistry.playS2C().register(RaceSyncPayload.ID, RaceSyncPayload.CODEC);
		PayloadTypeRegistry.playS2C().register(OpenRaceScreenPayload.ID, OpenRaceScreenPayload.CODEC);
		PayloadTypeRegistry.playC2S().register(ProtectionActionPayload.ID, ProtectionActionPayload.CODEC);
		PayloadTypeRegistry.playS2C().register(ProtectionSyncPayload.ID, ProtectionSyncPayload.CODEC);
		PayloadTypeRegistry.playC2S().register(TransformActionPayload.ID, TransformActionPayload.CODEC);
		PayloadTypeRegistry.playS2C().register(TransformSyncPayload.ID, TransformSyncPayload.CODEC);
		PayloadTypeRegistry.playS2C().register(OpenHubPayload.ID, OpenHubPayload.CODEC);
		PayloadTypeRegistry.playS2C().register(PlayerSyncPayload.ID, PlayerSyncPayload.CODEC);
		PayloadTypeRegistry.playS2C().register(OpenAffinityScreenPayload.ID, OpenAffinityScreenPayload.CODEC);
		PayloadTypeRegistry.playS2C().register(ManaSyncPayload.ID, ManaSyncPayload.CODEC);
		PayloadTypeRegistry.playS2C().register(CastStatePayload.ID, CastStatePayload.CODEC);

		ServerPlayNetworking.registerGlobalReceiver(ChooseAffinityPayload.ID, (payload, context) ->
				MagicGate.tryChooseAffinity(context.player(), payload.affinityId()));
		ServerPlayNetworking.registerGlobalReceiver(CastSpellPayload.ID, (payload, context) ->
				SpellService.requestCast(context.server(), context.player(), payload.spellId()));
		ServerPlayNetworking.registerGlobalReceiver(InscribePayload.ID, (payload, context) ->
				InscriptionService.request(context.server(), context.player(), payload.inscriptionId(), payload.remove() != 0));
		ServerPlayNetworking.registerGlobalReceiver(SelectTrainingPayload.ID, (payload, context) ->
				TrainingService.selectFocus(context.player(), payload.attributeId()));
		ServerPlayNetworking.registerGlobalReceiver(CombatActionPayload.ID, (payload, context) ->
				CombatService.request(context.server(), context.player(), payload.action(), payload.arg()));
		ServerPlayNetworking.registerGlobalReceiver(SpiritActionPayload.ID, (payload, context) ->
				SpiritService.request(context.server(), context.player(), payload.action()));
		ServerPlayNetworking.registerGlobalReceiver(ProtectionActionPayload.ID, (payload, context) ->
				ProtectionService.request(context.server(), context.player(), payload.action(), payload.arg()));
		ServerPlayNetworking.registerGlobalReceiver(TransformActionPayload.ID, (payload, context) ->
				TransformService.request(context.server(), context.player(), payload.action()));
		ServerPlayNetworking.registerGlobalReceiver(ChooseRacePayload.ID, (payload, context) ->
				RaceService.tryChoose(context.player(), payload.raceId()));
		ServerPlayNetworking.registerGlobalReceiver(RaceActionPayload.ID, (payload, context) ->
				RaceService.request(context.server(), context.player(), payload.action()));
	}
}
