package com.rezero.mod.net;

import com.rezero.mod.ReZeroMod;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Cliente -> servidor: "quero a raça X". É só um pedido; o servidor decide (escolha única). */
public record ChooseRacePayload(int raceId) implements CustomPayload {
	public static final CustomPayload.Id<ChooseRacePayload> ID =
			new CustomPayload.Id<>(Identifier.of(ReZeroMod.MOD_ID, "choose_race"));

	public static final PacketCodec<RegistryByteBuf, ChooseRacePayload> CODEC =
			PacketCodec.tuple(PacketCodecs.VAR_INT, ChooseRacePayload::raceId, ChooseRacePayload::new);

	@Override
	public CustomPayload.Id<? extends CustomPayload> getId() {
		return ID;
	}
}
