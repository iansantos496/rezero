package com.rezero.mod.core;

/**
 * Soma os bônus do equipamento (cajado na mão principal + acessório na mão secundária) com limites,
 * para que nenhuma combinação deixe a magia grátis ou instantânea. Código puro, testado fora do jogo.
 */
public final class EquipmentRules {
	/**
	 * Camada 1 (permanente): equipamento, vestes, marcas e treino somam e param nestes tetos.
	 * Camada 2 (situacional): espírito manifestado, raça e transformação ativa somam DEPOIS dos tetos da camada 1, para que um jogador com
	 * equipamento completo ainda sinta o ganho de uma transformação e a penalidade de uma raça (senão o teto engoliria os dois).
	 * Mesmo assim nada passa dos limites absolutos abaixo.
	 */
	public static final double MAX_POWER = 2.0;
	public static final double MIN_COST = 0.6;
	public static final double MIN_CAST = 0.6;
	public static final double MAX_REGEN = 2.0;
	public static final double MAX_POWER_ABS = 2.25;
	public static final double MIN_COST_ABS = 0.5;
	public static final double MIN_CAST_ABS = 0.5;
	public static final double MAX_REGEN_ABS = 2.5;

	private EquipmentRules() {}

	private static int level(int[] training, TrainingAttribute a) {
		return a.id() < training.length ? training[a.id()] : 0;
	}

	/** Qualquer argumento pode ser null (nada equipado ali). */
	public static CastModifiers combine(Catalyst staff, Charm charm) {
		return combine(staff, charm, null, null);
	}

	/**
	 * Tudo junto: cajado, acessório, vestes e marcas.
	 * @param robePieces peças vestidas de cada conjunto, indexadas por RobeSet.id() (null = nenhuma)
	 * @param marks marcas gravadas (null = nenhuma)
	 */
	public static CastModifiers combine(Catalyst staff, Charm charm, int[] robePieces, java.util.List<Inscription> marks) {
		return combine(staff, charm, robePieces, marks, null);
	}

	/**
	 * Tudo junto, mais o treinamento.
	 * @param training níveis dos atributos de treino indexados por TrainingAttribute.id() (null = nenhum)
	 */
	public static CastModifiers combine(Catalyst staff, Charm charm, int[] robePieces, java.util.List<Inscription> marks,
			int[] training) {
		return combine(staff, charm, robePieces, marks, training, 0);
	}

	/**
	 * Tudo junto, mais o espírito.
	 * @param spiritPowerPct bônus de potência do espírito manifestado (SpiritRules.powerPct), 0 se não há
	 */
	public static CastModifiers combine(Catalyst staff, Charm charm, int[] robePieces, java.util.List<Inscription> marks,
			int[] training, int spiritPowerPct) {
		return combine(staff, charm, robePieces, marks, training, spiritPowerPct, null);
	}

	/**
	 * Tudo junto, mais a raça.
	 * @param racial {potência%, redução de custo%, redução de carga%, regeneração%} (RaceRules.castPcts); null = nenhum
	 */
	public static CastModifiers combine(Catalyst staff, Charm charm, int[] robePieces, java.util.List<Inscription> marks,
			int[] training, int spiritPowerPct, int[] racial) {
		int power = 0;
		int cost = 0;
		int cast = 0;
		int regen = 0;
		if (training != null) {
			cast += TrainingModel.castReductionPct(level(training, TrainingAttribute.FOCUS));
			cost += TrainingModel.costReductionPct(level(training, TrainingAttribute.CONTROL));
			regen += TrainingModel.regenPct(level(training, TrainingAttribute.CONTROL));
		}
		if (robePieces != null) {
			for (RobeSet set : RobeSet.values()) {
				int n = set.id() < robePieces.length ? Math.max(0, Math.min(RobePiece.values().length, robePieces[set.id()])) : 0;
				power += set.piecePowerPct() * n;
				cost += set.pieceCostReductionPct() * n;
				cast += set.pieceCastReductionPct() * n;
				regen += set.pieceRegenPct() * n;
				if (n == RobePiece.values().length) {
					power += set.setPowerPct();
					cost += set.setCostReductionPct();
					cast += set.setCastReductionPct();
					regen += set.setRegenPct();
				}
			}
		}
		if (marks != null) {
			for (Inscription m : marks) {
				power += m.powerPct();
				cost += m.costReductionPct();
				cast += m.castReductionPct();
				regen += m.regenPct();
			}
		}
		if (staff != null) {
			power += staff.powerPct();
			cost += staff.costReductionPct();
			cast += staff.castReductionPct();
		}
		if (charm != null) {
			power += charm.powerPct();
			cost += charm.costReductionPct();
			cast += charm.castReductionPct();
			regen += charm.regenPct();
		}
		// camada 1: tetos permanentes
		double p1 = Math.min(MAX_POWER, 1.0 + power / 100.0);
		double c1 = Math.max(MIN_COST, 1.0 - cost / 100.0);
		double k1 = Math.max(MIN_CAST, 1.0 - cast / 100.0);
		double r1 = Math.min(MAX_REGEN, 1.0 + regen / 100.0);
		// camada 2: espírito, raça e forma ativa somam depois dos tetos, com limites absolutos
		int p2 = Math.max(0, spiritPowerPct);
		int c2 = 0;
		int k2 = 0;
		int r2 = 0;
		if (racial != null && racial.length >= 4) {
			p2 += racial[0];
			c2 += racial[1];
			k2 += racial[2];
			r2 += racial[3];
		}
		return new CastModifiers(
				Math.min(MAX_POWER_ABS, p1 + p2 / 100.0),
				Math.max(MIN_COST_ABS, c1 - c2 / 100.0),
				Math.max(MIN_CAST_ABS, k1 - k2 / 100.0),
				Math.min(MAX_REGEN_ABS, r1 + r2 / 100.0));
	}
}
