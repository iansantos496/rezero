package com.rezero.mod.core;

import java.util.List;

/**
 * Treinamento e evolução (Sistema 6), em código puro. ADAPTAÇÃO: nenhum número aqui vem da obra.
 * Cada atributo vai de 0 a 10. Sobe por USO (correr, lutar, conjurar) e por TREINO ATIVO no Poste de Treino,
 * que tem rendimento decrescente e fadiga. O teto dos atributos acompanha o nível dos canais de mana.
 */
public final class TrainingModel {
	public static final int MAX_LEVEL = 10;
	/** O XP de um atributo cabe em 10 bits no pacote de rede (o maior necessário é 310). */
	public static final int XP_BITS = 10;

	public static final int FATIGUE_MAX = 100;
	public static final int FATIGUE_PER_REP = 8;
	/** Depois de chegar a 100 de fadiga, só volta a treinar quando descer até aqui. */
	public static final int FATIGUE_RESUME = 40;
	/** A fadiga cai 1 ponto a cada 20 ticks (1 segundo). */
	public static final int FATIGUE_DECAY_TICKS = 20;
	public static final int BASE_REP_XP = 6;
	public static final int REP_COOLDOWN_TICKS = 10;
	/** Mínimo de comida para treinar (cada repetição também cansa o jogador). */
	public static final int MIN_FOOD = 6;
	public static final float REP_EXHAUSTION = 0.8f;
	public static final int OVERTRAIN_PENALTY_TICKS = 200;

	private TrainingModel() {}

	public static int clampLevel(int level) {
		return Math.max(0, Math.min(MAX_LEVEL, level));
	}

	/** XP para sair deste nível (0 no nível máximo): 40, 70, 100... 310. */
	public static int xpNeeded(int level) {
		int l = clampLevel(level);
		return l >= MAX_LEVEL ? 0 : 40 + 30 * l;
	}

	/** Teto dos atributos conforme o nível dos canais: 2 no nível 1, +1 a cada 2 níveis, até 10 (nível 16). */
	public static int levelCap(int channelLevel) {
		return Math.min(MAX_LEVEL, 2 + ChannelModel.clampLevel(channelLevel) / 2);
	}

	/**
	 * Aplica XP respeitando o teto. No teto o XP é descartado (não acumula).
	 * @return {novo nível, novo xp}
	 */
	public static int[] applyXp(int level, int xp, int gained, int cap) {
		int c = clampLevel(cap);
		int l = clampLevel(level);
		int x = Math.max(0, xp);
		if (l >= c) {
			return new int[] {l, 0};
		}
		x += Math.max(0, gained);
		while (l < c && l < MAX_LEVEL && x >= xpNeeded(l)) {
			x -= xpNeeded(l);
			l++;
		}
		if (l >= c) {
			x = 0;
		}
		return new int[] {l, x};
	}

	// ---- treino ativo ----

	/** Rendimento em %: 100% sem fadiga, cai 1 ponto por ponto de fadiga, mínimo 25%. */
	public static int yieldPct(int fatigue) {
		return Math.max(25, 100 - Math.max(0, Math.min(FATIGUE_MAX, fatigue)));
	}

	/** XP de uma repetição no Poste de Treino. */
	public static int repXp(int fatigue) {
		return Math.max(1, Math.round(BASE_REP_XP * yieldPct(fatigue) / 100.0f));
	}

	public static int fatigueAfterRep(int fatigue) {
		return Math.min(FATIGUE_MAX, Math.max(0, fatigue) + FATIGUE_PER_REP);
	}

	// ---- XP por uso ----

	/** XP de Foco por feitiço: 1 por 4 ticks de conjuração base (mínimo 1). */
	public static int focusXpForCast(int baseCastTicks) {
		return Math.max(1, baseCastTicks / 4);
	}

	/** XP de Controle de mana por feitiço: 1 por 4 pontos de mana gastos (mínimo 1). */
	public static int controlXpForMana(int spentMana) {
		return Math.max(1, spentMana / 4);
	}

	/** XP de Força por golpe corpo a corpo: o dano causado arredondado (mínimo 1). */
	public static int strengthXpForDamage(float damage) {
		return Math.max(1, Math.round(damage));
	}

	/** XP de Vigor por dano sofrido: o dano arredondado para cima (mínimo 1). */
	public static int vigorXpForDamage(float damage) {
		return Math.max(1, (int) Math.ceil(damage));
	}

	// ---- efeitos de cada atributo (nível 0..10) ----

	/** Vigor: +0,8 de vida máxima por nível (até +8 = 4 corações). */
	public static double maxHealthBonus(int vigor) {
		return 0.8 * clampLevel(vigor);
	}

	/** Força: +0,3 de dano de ataque por nível (até +3). */
	public static double attackBonus(int strength) {
		return 0.3 * clampLevel(strength);
	}

	/** Agilidade: +1,5% de velocidade de movimento por nível (até +15%), como fração (0.015 por nível). */
	public static double speedFraction(int agility) {
		return 0.015 * clampLevel(agility);
	}

	/** Foco: -2% no tempo de conjuração por nível (até -20%). */
	public static int castReductionPct(int focus) {
		return 2 * clampLevel(focus);
	}

	/** Controle: -1% no custo de mana por nível (até -10%). */
	public static int costReductionPct(int control) {
		return clampLevel(control);
	}

	/** Controle: +2% na regeneração de mana por nível (até +20%). */
	public static int regenPct(int control) {
		return 2 * clampLevel(control);
	}

	// ---- empacotamento para a rede ----

	/** 4 bits por atributo (0..10). */
	public static int packLevels(int[] levels) {
		int out = 0;
		for (int i = 0; i < TrainingAttribute.COUNT; i++) {
			int v = levels != null && i < levels.length ? clampLevel(levels[i]) : 0;
			out |= v << (4 * i);
		}
		return out;
	}

	public static int[] unpackLevels(int packed) {
		int[] out = new int[TrainingAttribute.COUNT];
		for (int i = 0; i < out.length; i++) {
			out[i] = clampLevel((packed >> (4 * i)) & 0xF);
		}
		return out;
	}

	/** Os atributos 0..2 ficam no primeiro inteiro e 3..4 no segundo (10 bits cada). */
	public static int packXpA(int[] xp) {
		return packXp(xp, 0, 3);
	}

	public static int packXpB(int[] xp) {
		return packXp(xp, 3, 2);
	}

	private static int packXp(int[] xp, int from, int count) {
		int out = 0;
		for (int i = 0; i < count; i++) {
			int idx = from + i;
			int v = xp != null && idx < xp.length ? Math.max(0, Math.min((1 << XP_BITS) - 1, xp[idx])) : 0;
			out |= v << (XP_BITS * i);
		}
		return out;
	}

	public static int[] unpackXp(int a, int b) {
		int mask = (1 << XP_BITS) - 1;
		return new int[] {a & mask, (a >> XP_BITS) & mask, (a >> (2 * XP_BITS)) & mask, b & mask, (b >> XP_BITS) & mask};
	}

	/** Deixa níveis e XP válidos (dados salvos corrompidos nunca produzem valores impossíveis). */
	public static int[] sanitizeLevels(List<Integer> raw) {
		int[] out = new int[TrainingAttribute.COUNT];
		for (int i = 0; i < out.length; i++) {
			out[i] = raw != null && i < raw.size() && raw.get(i) != null ? clampLevel(raw.get(i)) : 0;
		}
		return out;
	}

	public static int[] sanitizeXp(List<Integer> raw, int[] levels) {
		int[] out = new int[TrainingAttribute.COUNT];
		for (int i = 0; i < out.length; i++) {
			int v = raw != null && i < raw.size() && raw.get(i) != null ? Math.max(0, raw.get(i)) : 0;
			int needed = xpNeeded(levels[i]);
			out[i] = needed <= 0 ? 0 : Math.min(v, needed - 1);
		}
		return out;
	}
}
