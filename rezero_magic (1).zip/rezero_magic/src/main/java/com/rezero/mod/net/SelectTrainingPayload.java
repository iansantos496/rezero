package com.rezero.mod.net;

import com.rezero.mod.ReZeroMod;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Cliente -> servidor: "quero que o Poste de Treino exercite o atributo X". É só um pedido; o servidor valida o id. */
public record SelectTrainingPayload(int attributeId) implements CustomPayload {
	public static final CustomPayload.Id<SelectTrainingPayload> ID =
			new CustomPayload.Id<>(Identifier.of(ReZeroMod.MOD_ID, "select_training"));

	public static final PacketCodec<RegistryByteBuf, SelectTrainingPayload> CODEC = PacketCodec.tuple(
			PacketCodecs.VAR_INT, SelectTrainingPayload::attributeId,
			SelectTrainingPayload::new);

	@Override
	public CustomPayload.Id<? extends CustomPayload> getId() {
		return ID;
	}
}
