package com.rezero.mod.client;

import com.rezero.mod.core.Race;
import com.rezero.mod.core.RaceRules;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

/** HUD da habilidade racial (canto superior direito, abaixo do espírito). Só aparece para raças com transformação. */
public final class RaceHud {
	private RaceHud() {}

	public static void render(DrawContext context) {
		MinecraftClient client = MinecraftClient.getInstance();
		Race race = ClientPlayerData.race();
		if (client.player == null || client.options.hudHidden || !RaceRules.hasActive(race)) {
			return;
		}
		int x = client.getWindow().getScaledWidth() - 150;
		int y = 46;
		Text form = Text.translatable("race.rezero_magic." + race.key() + ".form");
		int formLeft = ClientPlayerData.raceFormLeft();
		int cd = ClientPlayerData.raceCooldownLeft();
		if (formLeft > 0) {
			context.drawTextWithShadow(client.textRenderer, Text.translatable("hud.rezero_magic.race_form_on", form,
					String.format("%.0f", formLeft / 20.0)), x, y, 0xFFFF9A6E);
		} else if (cd > 0) {
			context.drawTextWithShadow(client.textRenderer, Text.translatable("hud.rezero_magic.race_form_cd",
					ReZeroModClient.raceKeyName(), form, String.format("%.0f", cd / 20.0)), x, y, 0xFFAAAAAA);
		} else {
			context.drawTextWithShadow(client.textRenderer, Text.translatable("hud.rezero_magic.race_form_ready",
					ReZeroModClient.raceKeyName(), form), x, y, 0xFFFFFFFF);
		}
	}
}
