package com.rezero.mod.core;

/**
 * Raças jogáveis (Sistema 7). Só raças CITADAS na obra: humano, meio-elfo, demi-humano e oni.
 * Os ids são salvos no mundo: nunca reordene.
 */
public enum Race {
	HUMAN(0, "human"),
	HALF_ELF(1, "half_elf"),
	DEMI_HUMAN(2, "demi_human"),
	ONI(3, "oni");

	private final int id;
	private final String key;

	Race(int id, String key) {
		this.id = id;
		this.key = key;
	}

	public int id() {
		return id;
	}

	public String key() {
		return key;
	}

	/** @return a raça com esse id, ou null se o id for inválido (por exemplo, vindo de um pacote adulterado). */
	public static Race fromId(int id) {
		for (Race r : values()) {
			if (r.id == id) {
				return r;
			}
		}
		return null;
	}
}
