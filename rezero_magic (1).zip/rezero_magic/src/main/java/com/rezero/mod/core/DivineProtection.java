package com.rezero.mod.core;

/**
 * Proteções Divinas (Sistema 4). Os ids são salvos como bits no mundo: nunca reordene.
 * Nomes e ideias vêm da obra (Otapedia); condições de aquisição, números e limitações são ADAPTAÇÃO de jogo.
 */
public enum DivineProtection {
	SUN(0, "sun", 1, false),
	GATHERING_SPIRITS(1, "gathering_spirits", 1, false),
	EARTH_SPIRITS(2, "earth_spirits", 1, false),
	WIND_INDICATION(3, "wind_indication", 1, false),
	SWORD_SAINT(4, "sword_saint", 2, true);

	private final int id;
	private final String key;
	private final int slotCost;
	private final boolean epic;

	DivineProtection(int id, String key, int slotCost, boolean epic) {
		this.id = id;
		this.key = key;
		this.slotCost = slotCost;
		this.epic = epic;
	}

	public int id() {
		return id;
	}

	public String key() {
		return key;
	}

	/** Quantas das vagas da bênção ela ocupa. */
	public int slotCost() {
		return slotCost;
	}

	/** Épica = mais rara (ocupa mais vagas e tem a condição mais difícil); as demais são raras. */
	public boolean epic() {
		return epic;
	}

	public static DivineProtection fromId(int id) {
		for (DivineProtection p : values()) {
			if (p.id == id) {
				return p;
			}
		}
		return null;
	}
}
