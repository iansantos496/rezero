package com.rezero.mod.core;

/**
 * Definição de uma técnica de combate. Os ids são salvos (máscara de bits) e NUNCA devem mudar.
 * damagePct: % do dano base (atributo de ataque da arma, ou valor fixo para desarmado/arco); 0 = sem dano direto.
 * range: alcance em blocos. minLevel: nível mínimo do atributo de treino para aprender.
 * O custo em pontos de técnica é o próprio tier (1, 2 ou 3).
 */
public record TechniqueDef(
		int id,
		String key,
		CombatStyle style,
		int tier,
		int staminaCost,
		int cooldownTicks,
		int windupTicks,
		TrainingAttribute attribute,
		int minLevel,
		int damagePct,
		double range) {

	public int pointCost() {
		return tier;
	}
}
