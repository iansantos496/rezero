package com.rezero.mod.net;

import com.rezero.mod.ReZeroMod;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Cliente -> servidor: pedido para usar a habilidade racial (a transformação). O servidor confere raça, recarga e estado. */
public record RaceActionPayload(int action) implements CustomPayload {
	public static final CustomPayload.Id<RaceActionPayload> ID =
			new CustomPayload.Id<>(Identifier.of(ReZeroMod.MOD_ID, "race_action"));

	public static final PacketCodec<RegistryByteBuf, RaceActionPayload> CODEC =
			PacketCodec.tuple(PacketCodecs.VAR_INT, RaceActionPayload::action, RaceActionPayload::new);
	public static final int ACTIVATE = 0;

	@Override
	public CustomPayload.Id<? extends CustomPayload> getId() {
		return ID;
	}
}
