package com.rezero.mod.server;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.rezero.mod.core.CombatRules;
import com.rezero.mod.core.CombatStyle;
import com.rezero.mod.core.TechniqueDef;
import com.rezero.mod.core.Techniques;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

/**
 * O que cada uma das 15 técnicas FAZ. O dano base vem do ataque da arma na mão (incluindo o bônus de Força do treino);
 * desarmado e arco usam um valor fixo mais o bônus de Força. Tudo é adaptação de jogo.
 * Golpes em sequência no mesmo alvo precisam de intervalo maior que a invulnerabilidade dele (ver CombatRules.ECHO_DELAY_TICKS).
 */
final class CombatEffects {
	private CombatEffects() {}

	static void run(MinecraftServer server, ServerWorld world, ServerPlayerEntity p, TechniqueDef t) {
		double base = baseDamage(p, t.style());
		float dmg = (float) (base * t.damagePct() / 100.0);
		switch (t.id()) {
			case Techniques.SWORD_SWEEP -> {
				arcHit(world, p, t.range(), 60.0, dmg, 0.35, 0.2);
				sweepFx(world, p, 1.8);
				sound(world, p, SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, 1.0f, 1.0f);
			}
			case Techniques.SWORD_HEAVY -> {
				arcHit(world, p, t.range(), 30.0, dmg, 1.0, 0.35);
				sweepFx(world, p, 2.2);
				sound(world, p, SoundEvents.ENTITY_PLAYER_ATTACK_STRONG, 1.0f, 0.8f);
			}
			case Techniques.SWORD_RIPOSTE -> {
				CombatService.beginRiposte(p, dmg);
				world.spawnParticles(ParticleTypes.CRIT, p.getX(), p.getY() + 1.0, p.getZ(), 14, 0.5, 0.6, 0.5, 0.1);
				sound(world, p, SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME, 1.0f, 1.2f);
			}
			case Techniques.SPEAR_THRUST -> {
				List<LivingEntity> targets = inLine(world, p, t.range(), 0.6, 2);
				for (LivingEntity e : targets) {
					CombatService.techHurt(world, p, e, dmg);
					knock(p, e, 0.4, 0.15);
					hitEffect(world, e);
				}
				lineFx(world, p, t.range());
				sound(world, p, SoundEvents.ENTITY_PLAYER_ATTACK_STRONG, 0.9f, 1.3f);
			}
			case Techniques.SPEAR_LUNGE -> {
				Vec3d dir = CombatService.horizontalLook(p);
				CombatService.push(p, dir.x * 1.5, 0.15, dir.z * 1.5);
				world.spawnParticles(ParticleTypes.CLOUD, p.getX(), p.getY() + 0.3, p.getZ(), 12, 0.3, 0.1, 0.3, 0.06);
				// o golpe acontece no fim da investida
				CombatService.laterPlayer(4, p.getUuid(), (w, player) -> {
					arcHit(w, player, t.range(), 50.0, dmg, 0.8, 0.3);
					sound(w, player, SoundEvents.ENTITY_PLAYER_ATTACK_STRONG, 1.0f, 1.0f);
				});
			}
			case Techniques.SPEAR_WHIRL -> {
				for (LivingEntity e : inRadius(world, p, t.range())) {
					CombatService.techHurt(world, p, e, dmg);
					knock(p, e, 0.9, 0.3);
					hitEffect(world, e);
				}
				SpellEffects.ring(world, ParticleTypes.SWEEP_ATTACK, new Vec3d(p.getX(), p.getY() + 0.8, p.getZ()), t.range() * 0.7, 10);
				sound(world, p, SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, 1.0f, 0.7f);
			}
			case Techniques.DAGGER_FLURRY -> {
				LivingEntity target = nearest(world, p, t.range(), 45.0);
				if (target != null) {
					multiHit(world, p, target, dmg, 3);
				}
				sound(world, p, SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, 0.8f, 1.8f);
			}
			case Techniques.DAGGER_BACKSTAB -> {
				LivingEntity target = nearest(world, p, t.range(), 40.0);
				if (target != null) {
					boolean behind = Math.abs(MathHelper.wrapDegrees(target.getYaw() - p.getYaw())) < 60.0f;
					CombatService.techHurt(world, p, target, behind ? dmg * 2.0f : dmg);
					hitEffect(world, target);
					if (behind) {
						world.spawnParticles(ParticleTypes.CRIT, target.getX(), target.getBodyY(0.6), target.getZ(), 16, 0.3, 0.3, 0.3, 0.3);
					}
				}
				sound(world, p, SoundEvents.ENTITY_PLAYER_ATTACK_STRONG, 1.0f, 1.4f);
			}
			case Techniques.DAGGER_SHADOW -> {
				Vec3d dir = CombatService.horizontalLook(p);
				CombatService.push(p, dir.x * 1.6, 0.1, dir.z * 1.6);
				CombatService.beginInvulnerable(p, 6);
				p.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 60, 1));
				world.spawnParticles(ParticleTypes.LARGE_SMOKE, p.getX(), p.getY() + 0.5, p.getZ(), 16, 0.3, 0.4, 0.3, 0.02);
				sound(world, p, SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, 0.6f, 0.5f);
			}
			case Techniques.FIST_COMBO -> {
				LivingEntity target = nearest(world, p, t.range(), 50.0);
				if (target != null) {
					multiHit(world, p, target, dmg, 2);
				}
				sound(world, p, SoundEvents.ENTITY_PLAYER_ATTACK_STRONG, 0.8f, 1.5f);
			}
			case Techniques.FIST_SHOCKWAVE -> {
				arcHit(world, p, t.range(), 25.0, dmg, 1.5, 0.45);
				lineFx(world, p, t.range());
				sound(world, p, SoundEvents.ENTITY_PLAYER_ATTACK_STRONG, 1.0f, 0.6f);
			}
			case Techniques.FIST_GUARD -> {
				p.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, CombatRules.GUARD_STANCE_TICKS, 2));
				world.spawnParticles(ParticleTypes.CRIT, p.getX(), p.getY() + 1.0, p.getZ(), 16, 0.5, 0.7, 0.5, 0.1);
				sound(world, p, SoundEvents.ENTITY_PLAYER_ATTACK_STRONG, 0.9f, 0.6f);
			}
			case Techniques.BOW_PIERCE -> {
				for (LivingEntity e : inLine(world, p, t.range(), 0.4, 3)) {
					CombatService.techHurt(world, p, e, dmg);
					hitEffect(world, e);
				}
				lineFx(world, p, t.range());
				sound(world, p, SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, 1.0f, 1.9f);
			}
			case Techniques.BOW_VOLLEY -> {
				Map<LivingEntity, Integer> hits = new LinkedHashMap<>();
				int[] angles = {-20, -10, 0, 10, 20};
				for (int angle : angles) {
					Vec3d[] ray = rotatedRay(world, p, t.range(), angle);
					LivingEntity e = SpellEffects.findTarget(world, p, ray[0], ray[1], 0.4);
					SpellEffects.trail(world, ParticleTypes.CRIT, ray[0], ray[1]);
					if (e != null) {
						hits.merge(e, 1, Integer::sum);
					}
				}
				for (Map.Entry<LivingEntity, Integer> en : hits.entrySet()) {
					CombatService.techHurt(world, p, en.getKey(), dmg * en.getValue());
					hitEffect(world, en.getKey());
				}
				sound(world, p, SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, 1.0f, 1.6f);
			}
			case Techniques.BOW_SNARE -> {
				List<LivingEntity> targets = inLine(world, p, t.range(), 0.4, 1);
				for (LivingEntity e : targets) {
					CombatService.techHurt(world, p, e, dmg);
					e.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 80, 2));
					e.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 80, 0));
					hitEffect(world, e);
				}
				lineFx(world, p, t.range());
				sound(world, p, SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, 1.0f, 1.8f);
			}
			default -> {
				// id desconhecido: nada a fazer
			}
		}
	}

	/** Dano base: ataque da arma na mão, ou valor fixo (desarmado/arco) mais o bônus de Força do treino. */
	static double baseDamage(ServerPlayerEntity p, CombatStyle style) {
		double attack = p.getAttributeValue(EntityAttributes.ATTACK_DAMAGE);
		if (style == CombatStyle.UNARMED) {
			return CombatRules.UNARMED_BASE_DAMAGE + (attack - 1.0);
		}
		if (style == CombatStyle.BOW) {
			return CombatRules.BOW_BASE_DAMAGE + (attack - 1.0);
		}
		return attack;
	}

	// ------------------------------------------------------------------ seleção de alvos

	/** Criaturas à frente (setor horizontal), da mais próxima para a mais distante. */
	static List<LivingEntity> inArc(ServerWorld world, ServerPlayerEntity p, double range, double halfAngleDeg) {
		Vec3d look = CombatService.horizontalLook(p);
		double cos = Math.cos(Math.toRadians(halfAngleDeg));
		Box box = p.getBoundingBox().expand(range + 1.0);
		List<LivingEntity> out = new ArrayList<>();
		for (LivingEntity e : world.getEntitiesByClass(LivingEntity.class, box, x -> x != p && x.isAlive() && !x.isSpectator())) {
			double dx = e.getX() - p.getX();
			double dz = e.getZ() - p.getZ();
			double d = Math.sqrt(dx * dx + dz * dz);
			if (d > range + e.getWidth() / 2.0) {
				continue;
			}
			if (d > 0.01 && (dx / d * look.x + dz / d * look.z) < cos) {
				continue;
			}
			out.add(e);
		}
		out.sort((a, b) -> Double.compare(p.squaredDistanceTo(a), p.squaredDistanceTo(b)));
		return out;
	}

	static LivingEntity nearest(ServerWorld world, ServerPlayerEntity p, double range, double halfAngleDeg) {
		List<LivingEntity> list = inArc(world, p, range, halfAngleDeg);
		return list.isEmpty() ? null : list.get(0);
	}

	static List<LivingEntity> inRadius(ServerWorld world, ServerPlayerEntity p, double radius) {
		return inArc(world, p, radius, 180.0);
	}

	/** Criaturas na linha de visão (até o primeiro bloco), da mais próxima para a mais distante. */
	static List<LivingEntity> inLine(ServerWorld world, ServerPlayerEntity p, double range, double grow, int max) {
		Vec3d[] ray = SpellEffects.ray(world, p, (int) Math.ceil(range));
		return entitiesOnSegment(world, p, ray[0], ray[1], grow, max);
	}

	private static List<LivingEntity> entitiesOnSegment(ServerWorld world, ServerPlayerEntity p, Vec3d a, Vec3d b, double grow, int max) {
		Box search = new Box(a, b).expand(grow + 0.5);
		Map<LivingEntity, Double> found = new HashMap<>();
		for (LivingEntity e : world.getEntitiesByClass(LivingEntity.class, search, x -> x != p && x.isAlive() && !x.isSpectator())) {
			Optional<Vec3d> hit = e.getBoundingBox().expand(grow).raycast(a, b);
			if (hit.isPresent()) {
				found.put(e, a.squaredDistanceTo(hit.get()));
			}
		}
		List<LivingEntity> out = new ArrayList<>(found.keySet());
		out.sort((x, y) -> Double.compare(found.get(x), found.get(y)));
		return out.size() > max ? new ArrayList<>(out.subList(0, max)) : out;
	}

	/** Raio girado {@code angleDeg} graus na horizontal, parando no primeiro bloco. */
	private static Vec3d[] rotatedRay(ServerWorld world, ServerPlayerEntity p, double range, double angleDeg) {
		Vec3d[] straight = SpellEffects.ray(world, p, (int) Math.ceil(range));
		Vec3d eye = straight[0];
		Vec3d dir = p.getRotationVec(1.0f).rotateY((float) Math.toRadians(angleDeg));
		Vec3d far = eye.add(dir.multiply(range));
		RaycastContext ctx = new RaycastContext(eye, far,
				RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, p);
		BlockHitResult hit = world.raycast(ctx);
		Vec3d end = hit.getType() != HitResult.Type.MISS ? hit.getPos() : far;
		return new Vec3d[] {eye, end};
	}

	// ------------------------------------------------------------------ aplicação

	private static void arcHit(ServerWorld world, ServerPlayerEntity p, double range, double halfAngleDeg, float damage,
			double knockback, double up) {
		for (LivingEntity e : inArc(world, p, range, halfAngleDeg)) {
			CombatService.techHurt(world, p, e, damage);
			knock(p, e, knockback, up);
			hitEffect(world, e);
		}
	}

	/** {@code hits} golpes no mesmo alvo, o primeiro agora e os outros com intervalo maior que a invulnerabilidade dele. */
	private static void multiHit(ServerWorld world, ServerPlayerEntity p, LivingEntity target, float damage, int hits) {
		CombatService.techHurt(world, p, target, damage);
		hitEffect(world, target);
		for (int i = 1; i < hits; i++) {
			CombatService.hitLater(i * CombatRules.ECHO_DELAY_TICKS, p.getUuid(), target.getUuid(), damage);
		}
	}

	static void knock(ServerPlayerEntity from, LivingEntity e, double strength, double up) {
		double dx = e.getX() - from.getX();
		double dz = e.getZ() - from.getZ();
		double len = Math.sqrt(dx * dx + dz * dz);
		if (len > 0.01) {
			e.addVelocity(dx / len * strength, up, dz / len * strength);
		}
	}

	static void hitEffect(ServerWorld world, LivingEntity e) {
		world.spawnParticles(ParticleTypes.CRIT, e.getX(), e.getBodyY(0.5), e.getZ(), 6, 0.2, 0.25, 0.2, 0.2);
	}

	private static void sweepFx(ServerWorld world, ServerPlayerEntity p, double forward) {
		Vec3d look = CombatService.horizontalLook(p);
		world.spawnParticles(ParticleTypes.SWEEP_ATTACK, p.getX() + look.x * forward, p.getY() + 1.0, p.getZ() + look.z * forward,
				1, 0.0, 0.0, 0.0, 0.0);
	}

	private static void lineFx(ServerWorld world, ServerPlayerEntity p, double range) {
		Vec3d[] ray = SpellEffects.ray(world, p, (int) Math.ceil(range));
		SpellEffects.trail(world, ParticleTypes.CRIT, ray[0], ray[1]);
	}

	static void sound(ServerWorld world, ServerPlayerEntity p, SoundEvent s, float volume, float pitch) {
		world.playSound(null, p.getX(), p.getY(), p.getZ(), s, SoundCategory.PLAYERS, volume, pitch);
	}
}
