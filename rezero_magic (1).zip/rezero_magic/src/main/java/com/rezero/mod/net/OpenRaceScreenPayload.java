package com.rezero.mod.net;

import com.rezero.mod.ReZeroMod;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Servidor -> cliente: "abra a tela de escolha de raça" (afinidade já escolhida, raça ainda não). */
public record OpenRaceScreenPayload(int reason) implements CustomPayload {
	public static final CustomPayload.Id<OpenRaceScreenPayload> ID =
			new CustomPayload.Id<>(Identifier.of(ReZeroMod.MOD_ID, "open_race_screen"));

	public static final PacketCodec<RegistryByteBuf, OpenRaceScreenPayload> CODEC =
			PacketCodec.tuple(PacketCodecs.VAR_INT, OpenRaceScreenPayload::reason, OpenRaceScreenPayload::new);

	@Override
	public CustomPayload.Id<? extends CustomPayload> getId() {
		return ID;
	}
}
