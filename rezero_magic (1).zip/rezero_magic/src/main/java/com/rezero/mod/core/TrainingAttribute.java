package com.rezero.mod.core;

/**
 * Os 5 atributos de treino (Sistema 6). Os nomes são de jogo (adaptação); a obra não tem um sistema de atributos numéricos.
 * Os ids são salvos e enviados pela rede: NUNCA mudar a ordem.
 */
public enum TrainingAttribute {
	/** Resistência física: vida máxima. Treina correndo e sofrendo dano. */
	VIGOR(0, "vigor"),
	/** Força de ataque corpo a corpo. Treina causando dano corpo a corpo. */
	STRENGTH(1, "strength"),
	/** Velocidade de movimento. Treina pulando e percorrendo distância. */
	AGILITY(2, "agility"),
	/** Concentração: conjuração mais rápida. Treina conjurando. */
	FOCUS(3, "focus"),
	/** Controle de mana: custo menor e regeneração maior. Treina gastando mana. */
	CONTROL(4, "control");

	public static final int COUNT = 5;

	private final int id;
	private final String key;

	TrainingAttribute(int id, String key) {
		this.id = id;
		this.key = key;
	}

	public int id() {
		return id;
	}

	public String key() {
		return key;
	}

	/** @return o atributo com esse id, ou null (id vindo de pacote adulterado). */
	public static TrainingAttribute fromId(int id) {
		for (TrainingAttribute a : values()) {
			if (a.id == id) {
				return a;
			}
		}
		return null;
	}
}
