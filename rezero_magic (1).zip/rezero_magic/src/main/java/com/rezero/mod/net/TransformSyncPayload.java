package com.rezero.mod.net;

import com.rezero.mod.ReZeroMod;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Servidor -> cliente: forma ativa (0 = nenhuma, senão id + 1), tempo restante e recargas da Sintonia e do Último Fôlego (só exibição). */
public record TransformSyncPayload(int activePlus1, int leftTicks, int cooldownAttune, int cooldownStand) implements CustomPayload {
	public static final CustomPayload.Id<TransformSyncPayload> ID =
			new CustomPayload.Id<>(Identifier.of(ReZeroMod.MOD_ID, "transform_sync"));

	public static final PacketCodec<RegistryByteBuf, TransformSyncPayload> CODEC = PacketCodec.tuple(
			PacketCodecs.VAR_INT, TransformSyncPayload::activePlus1,
			PacketCodecs.VAR_INT, TransformSyncPayload::leftTicks,
			PacketCodecs.VAR_INT, TransformSyncPayload::cooldownAttune,
			PacketCodecs.VAR_INT, TransformSyncPayload::cooldownStand,
			TransformSyncPayload::new);

	@Override
	public CustomPayload.Id<? extends CustomPayload> getId() {
		return ID;
	}
}
