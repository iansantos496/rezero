package com.rezero.mod.net;

import com.rezero.mod.ReZeroMod;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/**
 * Servidor -> cliente: retrato do treinamento. Os níveis dos 5 atributos vêm empacotados em 4 bits cada
 * e o XP em 10 bits cada (TrainingModel.pack*), além do atributo em foco e da fadiga atual (0..100).
 * O cliente só usa isto para mostrar informação.
 */
public record TrainingSyncPayload(int levelsPack, int xpA, int xpB, int focus, int fatigue) implements CustomPayload {
	public static final CustomPayload.Id<TrainingSyncPayload> ID =
			new CustomPayload.Id<>(Identifier.of(ReZeroMod.MOD_ID, "training_sync"));

	public static final PacketCodec<RegistryByteBuf, TrainingSyncPayload> CODEC = PacketCodec.tuple(
			PacketCodecs.VAR_INT, TrainingSyncPayload::levelsPack,
			PacketCodecs.VAR_INT, TrainingSyncPayload::xpA,
			PacketCodecs.VAR_INT, TrainingSyncPayload::xpB,
			PacketCodecs.VAR_INT, TrainingSyncPayload::focus,
			PacketCodecs.VAR_INT, TrainingSyncPayload::fatigue,
			TrainingSyncPayload::new);

	@Override
	public CustomPayload.Id<? extends CustomPayload> getId() {
		return ID;
	}
}
