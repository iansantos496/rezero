package com.rezero.mod.core;

/**
 * Regras das Proteções Divinas (Sistema 4), em código puro e testado fora do jogo.
 *
 * CANON (Otapedia): Proteção Divina é uma bênção do mundo recebida AO NASCER; a maioria das pessoas nasce sem; só cerca de 1 em 1000 tem
 * uma considerada útil; é incompatível com Fator de Bruxa; pode ser perdida temporariamente se a ligação com o Od Laguna for cortada;
 * algumas têm restrições próprias (recarga, imobilidade). Exemplos citados: Indicação do Vento, Linguagem das Almas, Deus da Morte,
 * Clarividência, Reunião de Espíritos, Trissecção, Sol (mais forte de dia), Santo da Espada, Espíritos da Terra.
 * ADAPTAÇÃO: como o jogo precisa de condições EXPLÍCITAS e nada sorteado, a bênção "desperta" quando o jogador cumpre um marco e a recebe
 * por pedido. Há um limite de vagas (como a raridade na obra). Nenhuma é concedida sem critério. Sem Retorno por Morte nem equivalente.
 */
public final class ProtectionRules {
	/** Vagas de bênção por jogador. */
	public static final int MAX_SLOTS = 2;

	// Sol: de dia e a céu aberto, Força I renovada
	public static final int SUN_EFFECT_TICKS = 60;
	// Reunião de Espíritos: mais XP de vínculo
	public static final int GATHERING_BOND_XP_PCT = 50;
	// Espíritos da Terra: no chão e com a vida abaixo desta fração, regeneração
	public static final double EARTH_HEALTH_FRACTION = 0.6;
	public static final int EARTH_EFFECT_TICKS = 60;
	// Santo da Espada: técnicas de espada gastam menos estamina
	public static final int SWORD_STAMINA_REDUCTION_PCT = 25;
	// Indicação do Vento (ativa): revela criaturas hostis, mesmo invisíveis, por um tempo
	public static final int WIND_COST = 20;
	public static final int WIND_COOLDOWN_TICKS = 600;
	public static final double WIND_RANGE = 24.0;
	public static final int WIND_REVEAL_TICKS = 160;

	/** Marcos já medidos nos dados do jogador (servidor: dados salvos; cliente: espelho só para exibição). */
	public record Progress(Affinity affinity, int channelLevel, int[] training, int techniqueCount, int bondLevel, Race race) {}

	public enum ClaimResult { OK, UNKNOWN, ALREADY, NO_SLOTS, CONDITION }

	public enum ActiveResult { OK, NOT_OWNED, ON_COOLDOWN, NO_MANA }

	private ProtectionRules() {}

	private static int level(int[] training, TrainingAttribute a) {
		return training != null && a.id() < training.length ? training[a.id()] : 0;
	}

	/** Vínculo mínimo para a Reunião de Espíritos: 3 (2 para o meio-elfo, de aptidão espiritual — adaptação, ver RaceRules). */
	public static int gatheringBond(Race race) {
		return race == Race.HALF_ELF ? SpiritRules.ACTIVE_UNLOCK_BOND - 1 : SpiritRules.ACTIVE_UNLOCK_BOND;
	}

	/** A condição de aquisição desta proteção está cumprida? (Não considera vagas nem se já tem.) */
	public static boolean conditionMet(DivineProtection p, Progress g) {
		if (p == null || g == null) {
			return false;
		}
		return switch (p) {
			case SUN -> g.affinity() == Affinity.YANG && g.channelLevel() >= 8;
			case GATHERING_SPIRITS -> g.bondLevel() >= gatheringBond(g.race());
			case EARTH_SPIRITS -> g.affinity() == Affinity.EARTH && level(g.training(), TrainingAttribute.VIGOR) >= 5;
			case WIND_INDICATION -> g.affinity() == Affinity.WIND && g.channelLevel() >= 6
					&& level(g.training(), TrainingAttribute.AGILITY) >= 4;
			case SWORD_SAINT -> level(g.training(), TrainingAttribute.STRENGTH) >= 8 && g.techniqueCount() >= 6;
		};
	}

	public static int bit(DivineProtection p) {
		return 1 << p.id();
	}

	public static boolean has(int mask, DivineProtection p) {
		return p != null && (mask & bit(p)) != 0;
	}

	public static int slotsUsed(int mask) {
		int used = 0;
		for (DivineProtection p : DivineProtection.values()) {
			if (has(mask, p)) {
				used += p.slotCost();
			}
		}
		return used;
	}

	/** Máscara salva/recebida -> máscara segura: só bits válidos, e nunca além das vagas (na ordem dos ids). */
	public static int sanitizeMask(int mask) {
		int out = 0;
		int used = 0;
		for (DivineProtection p : DivineProtection.values()) {
			if (has(mask, p) && used + p.slotCost() <= MAX_SLOTS) {
				out |= bit(p);
				used += p.slotCost();
			}
		}
		return out;
	}

	public static ClaimResult checkClaim(int mask, DivineProtection p, Progress g) {
		if (p == null) {
			return ClaimResult.UNKNOWN;
		}
		if (has(mask, p)) {
			return ClaimResult.ALREADY;
		}
		if (slotsUsed(mask) + p.slotCost() > MAX_SLOTS) {
			return ClaimResult.NO_SLOTS;
		}
		if (!conditionMet(p, g)) {
			return ClaimResult.CONDITION;
		}
		return ClaimResult.OK;
	}

	// ---- efeitos ----

	/** Sol: só de dia e com o céu à vista. */
	public static boolean sunActive(boolean night, boolean skyVisible) {
		return !night && skyVisible;
	}

	/** Espíritos da Terra: com os pés no chão e a vida abaixo de 60%. */
	public static boolean earthActive(boolean onGround, double health, double maxHealth) {
		return onGround && maxHealth > 0.0 && health < maxHealth * EARTH_HEALTH_FRACTION;
	}

	/** XP de vínculo com a Reunião de Espíritos (arredonda para cima). */
	public static int bondXp(int mask, int xp) {
		if (xp <= 0) {
			return 0;
		}
		return has(mask, DivineProtection.GATHERING_SPIRITS) ? (xp * (100 + GATHERING_BOND_XP_PCT) + 99) / 100 : xp;
	}

	/** Redução (%) da estamina de uma técnica do estilo dado (Santo da Espada só reduz técnicas de espada). */
	public static int staminaReductionPct(int mask, CombatStyle style) {
		return has(mask, DivineProtection.SWORD_SAINT) && style == CombatStyle.SWORD ? SWORD_STAMINA_REDUCTION_PCT : 0;
	}

	/** Custo de estamina já reduzido (nunca menos de 1). */
	public static int effectiveStaminaCost(int baseCost, int reductionPct) {
		int pct = Math.max(0, Math.min(90, reductionPct));
		return Math.max(1, (baseCost * (100 - pct) + 50) / 100);
	}

	public static ActiveResult checkActive(int mask, int cooldownLeft, int mana) {
		if (!has(mask, DivineProtection.WIND_INDICATION)) {
			return ActiveResult.NOT_OWNED;
		}
		if (cooldownLeft > 0) {
			return ActiveResult.ON_COOLDOWN;
		}
		if (mana < WIND_COST) {
			return ActiveResult.NO_MANA;
		}
		return ActiveResult.OK;
	}
}
