package com.rezero.mod.net;

import com.rezero.mod.ReZeroMod;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/**
 * Servidor -> cliente: retrato do espírito. spiritId = elemento contratado (-1 = sem contrato); vínculo e XP;
 * manifestado (0/1); espírito selvagem por perto (0/1); recarga da habilidade ativa em ticks. Só para mostrar na tela.
 */
public record SpiritSyncPayload(int spiritId, int bondLevel, int bondXp, int summoned, int wisp, int cooldownTicks)
		implements CustomPayload {
	public static final CustomPayload.Id<SpiritSyncPayload> ID =
			new CustomPayload.Id<>(Identifier.of(ReZeroMod.MOD_ID, "spirit_sync"));

	public static final PacketCodec<RegistryByteBuf, SpiritSyncPayload> CODEC = PacketCodec.tuple(
			PacketCodecs.VAR_INT, SpiritSyncPayload::spiritId,
			PacketCodecs.VAR_INT, SpiritSyncPayload::bondLevel,
			PacketCodecs.VAR_INT, SpiritSyncPayload::bondXp,
			PacketCodecs.VAR_INT, SpiritSyncPayload::summoned,
			PacketCodecs.VAR_INT, SpiritSyncPayload::wisp,
			PacketCodecs.VAR_INT, SpiritSyncPayload::cooldownTicks,
			SpiritSyncPayload::new);

	@Override
	public CustomPayload.Id<? extends CustomPayload> getId() {
		return ID;
	}
}
