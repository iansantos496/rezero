package com.rezero.mod.client;

import java.util.ArrayList;
import java.util.List;

import com.rezero.mod.core.Affinity;
import com.rezero.mod.core.ChannelModel;
import com.rezero.mod.core.Inscription;
import com.rezero.mod.core.InscriptionRules;
import com.rezero.mod.core.SpellDef;
import com.rezero.mod.core.Spells;
import com.rezero.mod.core.ProtectionRules;
import com.rezero.mod.core.Race;
import com.rezero.mod.core.RaceRules;
import com.rezero.mod.core.SpiritRules;
import com.rezero.mod.core.Transformation;
import com.rezero.mod.core.TransformationRules;
import com.rezero.mod.core.Techniques;
import com.rezero.mod.core.TrainingAttribute;
import com.rezero.mod.core.TrainingModel;

/**
 * Cópia, no cliente, do último retrato enviado pelo servidor. SÓ para exibir informação.
 * Nunca use isto para decidir se um poder pode ser usado: quem decide é o servidor.
 */
public final class ClientPlayerData {
	private static volatile int affinityId = -1;
	private static volatile boolean affinityScreenRequested = false;
	private static volatile int channelLevel = 1;
	private static volatile int channelXp = 0;
	private static volatile int mana = 0;
	private static volatile boolean exhausted = false;
	private static volatile int marksMask = 0;
	private static volatile int pendingHubTab = -1;
	private static volatile int[] trainingLevels = new int[TrainingAttribute.COUNT];
	private static volatile int[] trainingXp = new int[TrainingAttribute.COUNT];
	private static volatile int trainingFocus = TrainingAttribute.STRENGTH.id();
	private static volatile int fatigue = 0;
	private static volatile int techniqueMask = 0;
	private static volatile int stamina = 0;
	private static volatile int maxStamina = 100;
	private static final long[] TECHNIQUE_CD_END = new long[Techniques.COUNT];
	private static long dodgeCdEnd = 0;
	private static volatile int spiritId = -1;
	private static volatile int bondLevel = 1;
	private static volatile int bondXp = 0;
	private static volatile boolean spiritSummoned = false;
	private static volatile boolean wispNearby = false;
	private static long spiritCdEnd = 0;
	private static volatile int raceId = -1;
	private static volatile boolean raceScreenRequested = false;
	private static long raceFormEnd = 0;
	private static long raceCdEnd = 0;
	private static volatile int protectionMask = 0;
	private static long protectionCdEnd = 0;
	private static volatile int transformActive = -1;
	private static long transformEnd = 0;
	private static long attuneCdEnd = 0;
	private static long standCdEnd = 0;

	private static int selectedSpellId = -1;
	/** Contador de ticks do cliente, usado para a recarga e a barra de conjuração na tela. */
	private static long clientTick = 0;
	private static int castingSpellId = -1;
	private static long castStart = 0;
	private static int castTotal = 0;
	private static final long[] COOLDOWN_END = new long[32];

	private ClientPlayerData() {}

	public static void update(int newAffinityId, int level, int xp, int newMarksMask) {
		affinityId = newAffinityId;
		marksMask = newMarksMask;
		channelLevel = ChannelModel.clampLevel(level);
		channelXp = Math.max(0, xp);
	}

	public static void updateMana(int newMana, boolean isExhausted) {
		mana = Math.max(0, newMana);
		exhausted = isExhausted;
	}

	public static void clear() {
		affinityId = -1;
		affinityScreenRequested = false;
		channelLevel = 1;
		channelXp = 0;
		mana = 0;
		exhausted = false;
		marksMask = 0;
		pendingHubTab = -1;
		trainingLevels = new int[TrainingAttribute.COUNT];
		trainingXp = new int[TrainingAttribute.COUNT];
		trainingFocus = TrainingAttribute.STRENGTH.id();
		fatigue = 0;
		techniqueMask = 0;
		stamina = 0;
		maxStamina = 100;
		java.util.Arrays.fill(TECHNIQUE_CD_END, 0L);
		dodgeCdEnd = 0;
		spiritId = -1;
		bondLevel = 1;
		bondXp = 0;
		spiritSummoned = false;
		wispNearby = false;
		spiritCdEnd = 0;
		raceId = -1;
		raceScreenRequested = false;
		raceFormEnd = 0;
		raceCdEnd = 0;
		protectionMask = 0;
		protectionCdEnd = 0;
		transformActive = -1;
		transformEnd = 0;
		attuneCdEnd = 0;
		standCdEnd = 0;
		selectedSpellId = -1;
		castingSpellId = -1;
		java.util.Arrays.fill(COOLDOWN_END, 0L);
	}

	public static void tick() {
		clientTick++;
		if (castingSpellId >= 0 && clientTick - castStart > castTotal + 20L) {
			castingSpellId = -1; // segurança: o servidor não avisou o fim
		}
	}

	/** @return a afinidade conhecida pelo cliente, ou null se o jogador ainda não escolheu. */
	public static Affinity affinity() {
		return Affinity.fromId(affinityId);
	}

	/** Marcas gravadas conhecidas pelo cliente (só para exibição). */
	public static List<Inscription> marks() {
		return InscriptionRules.fromMask(marksMask);
	}

	public static void updateTraining(int levelsPack, int xpA, int xpB, int focus, int newFatigue) {
		trainingLevels = TrainingModel.unpackLevels(levelsPack);
		trainingXp = TrainingModel.unpackXp(xpA, xpB);
		trainingFocus = TrainingAttribute.fromId(focus) == null ? TrainingAttribute.STRENGTH.id() : focus;
		fatigue = Math.max(0, Math.min(TrainingModel.FATIGUE_MAX, newFatigue));
	}

	public static void updateCombat(int mask, int newStamina, int newMax) {
		techniqueMask = mask;
		stamina = Math.max(0, newStamina);
		maxStamina = Math.max(1, newMax);
	}

	/** O servidor iniciou a recarga de uma técnica (id -1 = esquiva). */
	public static void onTechniqueCooldown(int techniqueId, int ticks) {
		if (techniqueId == -1) {
			dodgeCdEnd = clientTick + ticks;
		} else if (techniqueId >= 0 && techniqueId < TECHNIQUE_CD_END.length) {
			TECHNIQUE_CD_END[techniqueId] = clientTick + ticks;
		}
	}

	public static int techniqueCooldownLeft(int techniqueId) {
		if (techniqueId < 0 || techniqueId >= TECHNIQUE_CD_END.length) {
			return 0;
		}
		return (int) Math.max(0L, TECHNIQUE_CD_END[techniqueId] - clientTick);
	}

	public static void updateSpirit(int id, int bond, int xp, boolean summoned, boolean wisp, int cooldownTicks) {
		spiritId = id;
		bondLevel = SpiritRules.clampBond(bond);
		bondXp = Math.max(0, xp);
		spiritSummoned = summoned;
		wispNearby = wisp;
		spiritCdEnd = clientTick + Math.max(0, cooldownTicks);
	}

	public static void updateRace(int id, int formTicks, int cooldownTicks) {
		raceId = RaceRules.normalizeId(id);
		raceFormEnd = clientTick + Math.max(0, formTicks);
		raceCdEnd = clientTick + Math.max(0, cooldownTicks);
	}

	/** A raça escolhida, ou null (só exibição; o servidor é quem decide). */
	public static Race race() {
		return Race.fromId(raceId);
	}

	public static int raceFormLeft() {
		return (int) Math.max(0L, raceFormEnd - clientTick);
	}

	public static int raceCooldownLeft() {
		return (int) Math.max(0L, raceCdEnd - clientTick);
	}

	/** Efeitos da raça sobre a magia, os mesmos que o servidor aplica (só para mostrar números). */
	public static int[] racePcts() {
		return TransformationRules.sum(RaceRules.castPcts(race(), raceFormLeft() > 0),
				TransformationRules.castPcts(Transformation.fromId(transformFormLeft() > 0 ? transformActive : -1)));
	}

	public static void updateTransform(int activePlus1, int leftTicks, int cdAttune, int cdStand) {
		transformActive = activePlus1 - 1;
		transformEnd = clientTick + Math.max(0, leftTicks);
		attuneCdEnd = clientTick + Math.max(0, cdAttune);
		standCdEnd = clientTick + Math.max(0, cdStand);
	}

	/** Tempo restante da forma ativa deste sistema (Sintonia/Último Fôlego); 0 se não há. */
	public static int transformFormLeft() {
		return transformActive < 0 ? 0 : (int) Math.max(0L, transformEnd - clientTick);
	}

	/** Qual forma deste sistema está ativa, ou null. */
	public static Transformation transformActive() {
		return transformFormLeft() > 0 ? Transformation.fromId(transformActive) : null;
	}

	public static int transformCooldownLeft(Transformation t) {
		long end = t == Transformation.LAST_STAND ? standCdEnd : attuneCdEnd;
		return (int) Math.max(0L, end - clientTick);
	}

	/** A forma racial ativa agora (Forma Bestial/Oni), ou null. */
	public static Transformation racialActive() {
		if (raceFormLeft() <= 0) {
			return null;
		}
		Race r = race();
		return r == Race.ONI ? Transformation.ONI : r == Race.DEMI_HUMAN ? Transformation.BEAST : null;
	}

	/** Qualquer transformação ativa (racial ou não), para o efeito de tela. */
	public static Transformation anyTransformation() {
		Transformation t = transformActive();
		return t != null ? t : racialActive();
	}

	/** Contexto das condições como o cliente o conhece (o servidor refaz a conta ao receber o pedido). */
	public static TransformationRules.Context transformContext(Transformation t, net.minecraft.entity.player.PlayerEntity player) {
		return new TransformationRules.Context(anyTransformation() != null, transformCooldownLeft(t), channelLevel, mana,
				spirit() != null ? bondLevel : 0, spiritSummoned, player == null ? 0.0 : player.getHealth(),
				player == null ? 0.0 : player.getMaxHealth(), trainingLevels()[com.rezero.mod.core.TrainingAttribute.VIGOR.id()]);
	}

	public static void updateProtection(int mask, int cooldownTicks) {
		protectionMask = ProtectionRules.sanitizeMask(mask);
		protectionCdEnd = clientTick + Math.max(0, cooldownTicks);
	}

	/** Proteções Divinas recebidas (espelho do servidor, só para exibição). */
	public static int protectionMask() {
		return protectionMask;
	}

	public static int protectionCooldownLeft() {
		return (int) Math.max(0L, protectionCdEnd - clientTick);
	}

	/** Marcos do jogador como o cliente os conhece (o servidor refaz a conta ao receber o pedido). */
	public static ProtectionRules.Progress protectionProgress() {
		return new ProtectionRules.Progress(affinity(), channelLevel, trainingLevels(), Integer.bitCount(techniqueMask),
				spirit() != null ? bondLevel : 0, race());
	}

	public static void requestRaceScreen() {
		raceScreenRequested = true;
	}

	public static boolean raceScreenRequested() {
		return raceScreenRequested;
	}

	public static void clearRaceScreenRequest() {
		raceScreenRequested = false;
	}

	/** O elemento do espírito contratado, ou null se não há contrato (só exibição). */
	public static Affinity spirit() {
		return Affinity.fromId(spiritId);
	}

	public static int bondLevel() {
		return bondLevel;
	}

	public static int bondXp() {
		return bondXp;
	}

	public static boolean spiritSummoned() {
		return spiritSummoned;
	}

	public static boolean wispNearby() {
		return wispNearby;
	}

	public static int spiritCooldownLeft() {
		return (int) Math.max(0L, spiritCdEnd - clientTick);
	}

	/** Bônus de potência do espírito manifestado, o mesmo que o servidor aplica (só para mostrar números). */
	public static int spiritPowerPct() {
		return spiritSummoned && spirit() != null ? SpiritRules.powerPct(bondLevel) : 0;
	}

	public static int techniqueMask() {
		return techniqueMask;
	}

	public static int stamina() {
		return stamina;
	}

	public static int maxStamina() {
		return maxStamina;
	}

	/** Níveis de treino conhecidos pelo cliente (cópia; só para exibição). */
	public static int[] trainingLevels() {
		return trainingLevels.clone();
	}

	public static int trainingLevel(TrainingAttribute a) {
		return trainingLevels[a.id()];
	}

	public static int trainingXp(TrainingAttribute a) {
		return trainingXp[a.id()];
	}

	public static TrainingAttribute trainingFocus() {
		return TrainingAttribute.fromId(trainingFocus);
	}

	public static int fatigue() {
		return fatigue;
	}

	/** O servidor pediu para abrir o Hub numa aba (Mesa de Inscrição). */
	public static void requestHubTab(int tab) {
		pendingHubTab = tab;
	}

	/** @return a aba pedida (e limpa o pedido), ou -1. */
	public static int takeHubTabRequest() {
		int t = pendingHubTab;
		pendingHubTab = -1;
		return t;
	}

	public static int channelLevel() {
		return channelLevel;
	}

	public static int channelXp() {
		return channelXp;
	}

	public static int mana() {
		return mana;
	}

	public static int maxMana() {
		return ChannelModel.maxMana(channelLevel);
	}

	public static boolean exhausted() {
		return exhausted;
	}

	// ---- feitiços (somente exibição e escolha do que pedir ao servidor) ----

	/** Feitiços da afinidade já liberados pelo nível dos canais. */
	public static List<SpellDef> unlockedSpells() {
		List<SpellDef> out = new ArrayList<>();
		Affinity a = affinity();
		if (a == null) {
			return out;
		}
		for (SpellDef s : Spells.forAffinity(a)) {
			if (s.unlockLevel() <= channelLevel) {
				out.add(s);
			}
		}
		return out;
	}

	public static SpellDef selectedSpell() {
		List<SpellDef> list = unlockedSpells();
		if (list.isEmpty()) {
			return null;
		}
		for (SpellDef s : list) {
			if (s.id() == selectedSpellId) {
				return s;
			}
		}
		return list.get(0);
	}

	public static void cycleSpell(int direction) {
		List<SpellDef> list = unlockedSpells();
		SpellDef current = selectedSpell();
		if (list.isEmpty() || current == null) {
			return;
		}
		int idx = list.indexOf(current);
		int next = Math.floorMod(idx + direction, list.size());
		selectedSpellId = list.get(next).id();
	}

	public static void selectSpell(int id) {
		selectedSpellId = id;
	}

	public static void onCastState(int spellId, int castTicks, int cooldownTicks) {
		if (castTicks > 0) {
			castingSpellId = spellId;
			castStart = clientTick;
			castTotal = castTicks;
			return;
		}
		if (spellId == castingSpellId) {
			castingSpellId = -1;
		}
		if (cooldownTicks > 0 && spellId >= 0 && spellId < COOLDOWN_END.length) {
			COOLDOWN_END[spellId] = clientTick + cooldownTicks;
		}
	}

	/** @return de 0.0 a 1.0 o progresso da conjuração, ou -1 se não está conjurando. */
	public static float castProgress() {
		if (castingSpellId < 0 || castTotal <= 0) {
			return -1.0f;
		}
		return Math.min(1.0f, (clientTick - castStart) / (float) castTotal);
	}

	public static int castingSpellId() {
		return castingSpellId;
	}

	public static int cooldownLeft(int spellId) {
		if (spellId < 0 || spellId >= COOLDOWN_END.length) {
			return 0;
		}
		return (int) Math.max(0L, COOLDOWN_END[spellId] - clientTick);
	}

	// ---- tela de afinidade ----

	/** O servidor pediu a tela de afinidade; ela abre assim que o jogo estiver livre para isso. */
	public static void requestAffinityScreen() {
		affinityScreenRequested = true;
	}

	public static boolean affinityScreenRequested() {
		return affinityScreenRequested;
	}

	public static void clearAffinityScreenRequest() {
		affinityScreenRequested = false;
	}
}
