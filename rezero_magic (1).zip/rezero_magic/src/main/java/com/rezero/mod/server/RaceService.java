package com.rezero.mod.server;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import com.rezero.mod.ReZeroMod;
import com.rezero.mod.core.Race;
import com.rezero.mod.core.RaceRules;
import com.rezero.mod.core.TrainingAttribute;
import com.rezero.mod.data.PlayerDataStore;
import com.rezero.mod.data.PlayerMagicData;
import com.rezero.mod.net.OpenRaceScreenPayload;
import com.rezero.mod.net.RaceActionPayload;
import com.rezero.mod.net.RaceSyncPayload;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;

/**
 * Raças (Sistema 7) no servidor: escolha única, bônus passivos (vida, ataque, velocidade, XP, magia) e a habilidade ativa
 * dos demi-humanos (Forma Bestial) e dos oni (Forma Oni). As regras e números estão em RaceRules (testadas fora do jogo).
 * A transformação não é salva: ao entrar ou renascer ela volta desligada e a recarga zera.
 */
public final class RaceService {
	private static final int SYNC_PERIOD = 20;

	private static final class Runtime {
		int formLeft;
		int cooldown;
		boolean dirty;
	}

	private static final Map<UUID, Runtime> STATE = new HashMap<>();
	private static MinecraftServer server;

	private RaceService() {}

	public static void init() {
		ServerTickEvents.END_SERVER_TICK.register(RaceService::tick);
		ServerLifecycleEvents.SERVER_STARTED.register(started -> server = started);
		ServerLifecycleEvents.SERVER_STOPPED.register(stopped -> {
			server = null;
			STATE.clear();
		});
	}

	private static Runtime runtime(ServerPlayerEntity player) {
		return STATE.computeIfAbsent(player.getUuid(), k -> new Runtime());
	}

	/** Ao entrar ou renascer: forma desligada, recarga zerada, retrato enviado; pede a escolha se ainda não há raça. */
	public static void reset(ServerPlayerEntity player) {
		STATE.put(player.getUuid(), new Runtime());
		sync(player);
		promptIfNeeded(player);
	}

	/** Só depois de escolher a afinidade a tela de raça é pedida (uma coisa de cada vez). */
	public static void promptIfNeeded(ServerPlayerEntity player) {
		PlayerMagicData data = PlayerDataStore.get(player);
		if (data.affinity() != null && data.race() == null) {
			ServerPlayNetworking.send(player, new OpenRaceScreenPayload(0));
		}
	}

	// ------------------------------------------------------------------ consultas (servidor)

	public static Race raceOf(ServerPlayerEntity player) {
		return PlayerDataStore.get(player).race();
	}

	public static boolean formActive(ServerPlayerEntity player) {
		Runtime rt = STATE.get(player.getUuid());
		return rt != null && rt.formLeft > 0;
	}

	/** Efeitos da raça sobre a magia, para o cálculo do equipamento. */
	public static int[] castPcts(ServerPlayerEntity player) {
		return RaceRules.castPcts(raceOf(player), formActive(player));
	}

	/** Demi-humano transformado não conjura. */
	public static boolean blocksCasting(ServerPlayerEntity player) {
		return RaceRules.blocksCasting(raceOf(player), formActive(player));
	}

	public static void notifyNoCast(ServerPlayerEntity player) {
		message(player, "race.no_cast_form");
	}

	/** XP de treino já com o bônus da raça. */
	public static int trainingXp(ServerPlayerEntity player, TrainingAttribute attribute, int xp) {
		return RaceRules.trainingXp(raceOf(player), attribute, xp);
	}

	/** XP de vínculo com o espírito já com o bônus da raça. */
	public static int spiritBondXp(ServerPlayerEntity player, int xp) {
		return RaceRules.spiritBondXp(raceOf(player), xp);
	}

	// ------------------------------------------------------------------ escolha

	/** Pedido do cliente. Só aceita se o id for válido e o jogador já tiver afinidade e ainda não tiver raça. */
	public static boolean tryChoose(ServerPlayerEntity player, int raceId) {
		Race wanted = Race.fromId(raceId);
		PlayerMagicData data = PlayerDataStore.get(player);
		if (data.affinity() == null || !RaceRules.canChoose(data.race(), wanted)) {
			ReZeroMod.LOGGER.warn("Pedido de raça recusado para {} (id {}, atual {}).",
					player.getName().getString(), raceId, data.race());
			return false;
		}
		data.setRace(wanted);
		PlayerDataStore.save(player, data);
		TrainingService.refreshAttributes(player);
		sync(player);
		player.sendMessage(Text.translatable("message.rezero_magic.race.chosen",
				Text.translatable("race.rezero_magic." + wanted.key())), false);
		ReZeroMod.LOGGER.info("{} escolheu a raça {}.", player.getName().getString(), wanted.key());
		return true;
	}

	/** Comando de teste restrito (ver AdminCommands): apaga a raça e reabre a tela de escolha. */
	public static void adminReset(ServerPlayerEntity player) {
		PlayerMagicData data = PlayerDataStore.get(player);
		data.adminClearRace();
		PlayerDataStore.save(player, data);
		Runtime rt = runtime(player);
		rt.formLeft = 0;
		rt.cooldown = 0;
		TrainingService.refreshAttributes(player);
		sync(player);
		promptIfNeeded(player);
		ReZeroMod.LOGGER.warn("Raça de {} redefinida por comando administrativo.", player.getName().getString());
	}

	// ------------------------------------------------------------------ habilidade ativa

	public static void request(MinecraftServer current, ServerPlayerEntity player, int action) {
		if (!player.isAlive() || action != RaceActionPayload.ACTIVATE) {
			return;
		}
		if (TransformService.isActive(player)) {
			message(player, "transform.fail_other_active");
			return;
		}
		Race race = raceOf(player);
		Runtime rt = runtime(player);
		RaceRules.ActiveResult result = RaceRules.checkActive(race, rt.formLeft > 0, rt.cooldown);
		if (result != RaceRules.ActiveResult.OK) {
			message(player, "race.active_" + result.name().toLowerCase());
			return;
		}
		rt.formLeft = RaceRules.FORM_TICKS;
		rt.dirty = true;
		// transformado, o demi-humano age por instinto: a conjuração em andamento é cancelada
		SpellService.reset(player);
		player.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, RaceRules.FORM_TICKS, 0));
		if (race == Race.DEMI_HUMAN) {
			player.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, RaceRules.FORM_TICKS, 0));
		}
		ServerWorld world = WorldLookup.of(current, player);
		if (world != null) {
			world.spawnParticles(race == Race.ONI ? ParticleTypes.LARGE_SMOKE : ParticleTypes.POOF,
					player.getX(), player.getY() + 1.0, player.getZ(), 30, 0.6, 0.8, 0.6, 0.05);
			SpellEffects.sound(world, player.getX(), player.getY(), player.getZ(), SoundEvents.ENTITY_PLAYER_ATTACK_STRONG, 1.0f, 0.6f);
		}
		message(player, "race.form_start_" + race.key());
		sync(player);
	}

	private static void endForm(ServerPlayerEntity player, Runtime rt) {
		Race race = raceOf(player);
		rt.formLeft = 0;
		rt.cooldown = RaceRules.cooldownTicks(race);
		rt.dirty = true;
		if (race == Race.ONI) {
			// limitação da Forma Oni: exaustão depois da transformação
			player.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, RaceRules.ONI_EXHAUST_TICKS, 0));
			player.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, RaceRules.ONI_EXHAUST_TICKS, 0));
		}
		if (race != null) {
			message(player, "race.form_end_" + race.key());
		}
		sync(player);
	}

	private static void tick(MinecraftServer current) {
		boolean periodic = current.getTicks() % SYNC_PERIOD == 0;
		for (ServerPlayerEntity player : current.getPlayerManager().getPlayerList()) {
			Runtime rt = STATE.get(player.getUuid());
			if (rt == null || !player.isAlive()) {
				continue;
			}
			if (rt.formLeft > 0) {
				if (--rt.formLeft == 0) {
					endForm(player, rt);
					continue;
				}
				if (raceOf(player) == Race.ONI && current.getTicks() % 2 == 0) {
					ServerWorld hornWorld = WorldLookup.of(current, player);
					if (hornWorld != null) {
						spawnHorn(hornWorld, player);
					}
				}
				if (periodic) {
					ServerWorld world = WorldLookup.of(current, player);
					if (world != null) {
						world.spawnParticles(raceOf(player) == Race.ONI ? ParticleTypes.SMOKE : ParticleTypes.CRIT,
								player.getX(), player.getY() + 1.0, player.getZ(), 6, 0.4, 0.6, 0.4, 0.02);
					}
				}
			} else if (rt.cooldown > 0) {
				rt.cooldown--;
			}
			if (rt.dirty || (periodic && (rt.formLeft > 0 || rt.cooldown > 0))) {
				sync(player);
			}
		}
	}

	/**
	 * Chifre da Forma Oni (visual de jogo, original): uma ponta fina e brilhante em magenta acima da testa, feita de partículas.
	 * Maior que o chifre de referência: ~0,75 bloco de altura, mais denso na base e mais fino na ponta, com pulso de brilho.
	 */
	private static void spawnHorn(ServerWorld world, ServerPlayerEntity player) {
		double yaw = Math.toRadians(player.getYaw());
		double fx = -Math.sin(yaw);
		double fz = Math.cos(yaw);
		double baseX = player.getX() + fx * 0.22;
		double baseZ = player.getZ() + fz * 0.22;
		double baseY = player.getEyeY() + 0.15;
		boolean pulse = (player.age / 10) % 2 == 0;
		DustParticleEffect dust = new DustParticleEffect(pulse ? 0xFF3FE0 : 0xD020B8, pulse ? 1.1f : 0.9f);
		int points = 7;
		for (int i = 0; i < points; i++) {
			double t = i / (double) (points - 1);
			// levemente inclinado para trás na ponta, como um chifre curvo
			world.spawnParticles(dust, baseX - fx * 0.10 * t, baseY + 0.75 * t, baseZ - fz * 0.10 * t, 1, 0.0, 0.0, 0.0, 0.0);
		}
		world.spawnParticles(ParticleTypes.END_ROD, baseX - fx * 0.10, baseY + 0.78, baseZ - fz * 0.10, 1, 0.0, 0.0, 0.0, 0.0);
	}

	public static void sync(ServerPlayerEntity player) {
		PlayerMagicData data = PlayerDataStore.get(player);
		Runtime rt = runtime(player);
		rt.dirty = false;
		ServerPlayNetworking.send(player, new RaceSyncPayload(data.raceId(), rt.formLeft, rt.cooldown));
	}

	private static void message(ServerPlayerEntity player, String key) {
		player.sendMessage(Text.translatable("message.rezero_magic." + key), true);
	}
}
