package com.rezero.mod.content;

import com.rezero.mod.server.SpiritService;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.world.World;

/**
 * Pedra de Contrato: o item do ritual. Clique direito perto de um espírito selvagem tenta firmar o contrato;
 * o servidor confere afinidade, nível dos canais, contrato anterior e distância, e só então gasta a pedra.
 */
public class SpiritContractItem extends Item {
	public SpiritContractItem(Settings settings) {
		super(settings);
	}

	@Override
	public ActionResult use(World world, PlayerEntity user, Hand hand) {
		if (world instanceof ServerWorld serverWorld && user instanceof ServerPlayerEntity serverPlayer) {
			ItemStack stack = user.getStackInHand(hand);
			if (SpiritService.tryContract(serverWorld, serverPlayer)) {
				if (!user.isCreative()) {
					stack.decrement(1);
				}
			}
		}
		return ActionResult.SUCCESS;
	}
}
