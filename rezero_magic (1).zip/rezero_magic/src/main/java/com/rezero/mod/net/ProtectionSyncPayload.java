package com.rezero.mod.net;

import com.rezero.mod.ReZeroMod;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Servidor -> cliente: proteções recebidas (máscara) e recarga da ativa (só para exibição). */
public record ProtectionSyncPayload(int mask, int cooldownTicks) implements CustomPayload {
	public static final CustomPayload.Id<ProtectionSyncPayload> ID =
			new CustomPayload.Id<>(Identifier.of(ReZeroMod.MOD_ID, "protection_sync"));

	public static final PacketCodec<RegistryByteBuf, ProtectionSyncPayload> CODEC = PacketCodec.tuple(
			PacketCodecs.VAR_INT, ProtectionSyncPayload::mask,
			PacketCodecs.VAR_INT, ProtectionSyncPayload::cooldownTicks,
			ProtectionSyncPayload::new);

	@Override
	public CustomPayload.Id<? extends CustomPayload> getId() {
		return ID;
	}
}
