package com.rezero.mod.core;

/**
 * Espíritos (Sistema 3), em código puro e testado fora do jogo.
 * CANON verificado nesta sessão (Otaku Mode, página "Magic" de Re:Zero): usuários de espíritos podem conjurar usando o mana ao redor
 * com ajuda do espírito contratado, e espíritos podem servir de "gate" para quem não tem meios de conjurar. Todo o resto é ADAPTAÇÃO de jogo:
 * 6 tipos (um por afinidade), contrato por ritual, vínculo de 1 a 5, temperamentos, custo contínuo de mana, habilidades.
 * Decisão do risco R4: nesta versão o espírito é um companheiro de PARTÍCULAS (sem entidade com modelo próprio).
 */
public final class SpiritRules {
	public static final int MIN_CHANNEL_LEVEL = 4;
	public static final int MAX_BOND = 5;
	public static final int ACTIVE_UNLOCK_BOND = 3;
	public static final int ACTIVE_COST = 30;
	public static final int ACTIVE_COOLDOWN_TICKS = 1200;
	public static final int POWER_PCT_PER_BOND = 3;

	/** Espírito selvagem: a cada 10 s tenta aparecer, dura 60 s e só pode ser contratado de perto. */
	public static final int WISP_CHECK_PERIOD_TICKS = 200;
	public static final int WISP_CHANCE_PCT = 25;
	public static final int WISP_LIFETIME_TICKS = 1200;
	public static final double WISP_CONTRACT_RANGE = 6.0;

	/** Vínculo por tempo juntos: 1 XP a cada 20 s com o espírito manifestado; por feitiço da afinidade: 2 XP; por ação do temperamento: ver o serviço. */
	public static final int TIME_XP_TICKS = 400;
	public static final int SPELL_XP = 2;

	/** O que o espírito gosta de ver o jogador fazer (afeto). */
	public enum Temperament { COMBAT, WATER, TRAVEL, DIGGING, NIGHT, DAY }

	public enum ContractResult { OK, NO_AFFINITY, LEVEL, ALREADY, NO_WISP }

	public enum ActiveResult { OK, NO_CONTRACT, NOT_SUMMONED, LOCKED, ON_COOLDOWN, NO_MANA }

	/** Condições do ambiente onde o jogador está, reunidas pelo servidor. */
	public record Env(boolean nether, int y, boolean raining, boolean touchingWater, boolean skyVisible, boolean night, int light) {}

	private SpiritRules() {}

	public static Temperament temperamentOf(Affinity a) {
		return switch (a) {
			case FIRE -> Temperament.COMBAT;
			case WATER -> Temperament.WATER;
			case WIND -> Temperament.TRAVEL;
			case EARTH -> Temperament.DIGGING;
			case YIN -> Temperament.NIGHT;
			case YANG -> Temperament.DAY;
		};
	}

	/** Em que condições um espírito selvagem do elemento pode aparecer perto do jogador. */
	public static boolean spawnCondition(Affinity a, Env e) {
		if (a == null || e == null) {
			return false;
		}
		return switch (a) {
			case FIRE -> e.nether() || e.y() <= 10;
			case WATER -> (e.raining() && e.skyVisible()) || e.touchingWater();
			case WIND -> e.y() >= 100 && e.skyVisible();
			case EARTH -> e.y() <= 40 && !e.skyVisible();
			case YIN -> e.night() && e.light() <= 7;
			case YANG -> !e.night() && e.skyVisible() && e.y() >= 62;
		};
	}

	/**
	 * Só se contrata o espírito do PRÓPRIO elemento (decisão do projeto: uma afinidade por jogador), com canais no nível mínimo,
	 * sem outro contrato, e com um espírito selvagem por perto.
	 */
	public static ContractResult checkContract(Affinity playerAffinity, int channelLevel, boolean hasContract, boolean wispInRange) {
		if (playerAffinity == null) {
			return ContractResult.NO_AFFINITY;
		}
		if (ChannelModel.clampLevel(channelLevel) < MIN_CHANNEL_LEVEL) {
			return ContractResult.LEVEL;
		}
		if (hasContract) {
			return ContractResult.ALREADY;
		}
		if (!wispInRange) {
			return ContractResult.NO_WISP;
		}
		return ContractResult.OK;
	}

	// ---- vínculo ----

	public static int clampBond(int bond) {
		return Math.max(1, Math.min(MAX_BOND, bond));
	}

	/** XP para sair deste nível de vínculo (0 no máximo): 100, 200, 300, 400. */
	public static int bondXpNeeded(int bond) {
		int b = clampBond(bond);
		return b >= MAX_BOND ? 0 : 100 * b;
	}

	/** @return {novo nível, novo xp}; no nível máximo o XP é descartado. */
	public static int[] applyBondXp(int bond, int xp, int gained) {
		int b = clampBond(bond);
		int x = Math.max(0, xp) + Math.max(0, gained);
		while (b < MAX_BOND && x >= bondXpNeeded(b)) {
			x -= bondXpNeeded(b);
			b++;
		}
		if (b >= MAX_BOND) {
			x = 0;
		}
		return new int[] {b, x};
	}

	/** Custo contínuo de mana enquanto o espírito está manifestado: 0,75/s no vínculo 1 até 1,75/s no 5. */
	public static double drainPerSecond(int bond) {
		return 0.5 + 0.25 * clampBond(bond);
	}

	/** Amplifica a potência dos feitiços da afinidade: +3% por nível de vínculo (até +15%). */
	public static int powerPct(int bond) {
		return POWER_PCT_PER_BOND * clampBond(bond);
	}

	public static boolean activeUnlocked(int bond) {
		return clampBond(bond) >= ACTIVE_UNLOCK_BOND;
	}

	/** @param mana mana atual; @param cooldownLeft ticks de recarga que faltam */
	public static ActiveResult checkActive(boolean hasContract, boolean summoned, int bond, int cooldownLeft, int mana) {
		if (!hasContract) {
			return ActiveResult.NO_CONTRACT;
		}
		if (!summoned) {
			return ActiveResult.NOT_SUMMONED;
		}
		if (!activeUnlocked(bond)) {
			return ActiveResult.LOCKED;
		}
		if (cooldownLeft > 0) {
			return ActiveResult.ON_COOLDOWN;
		}
		if (mana < ACTIVE_COST) {
			return ActiveResult.NO_MANA;
		}
		return ActiveResult.OK;
	}

	/** Dano/valor da habilidade ativa cresce com o vínculo: base + 1,5 por nível. */
	public static double activeStrength(int bond) {
		return 6.0 + 1.5 * clampBond(bond);
	}
}
