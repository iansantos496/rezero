package com.rezero.mod;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.rezero.mod.content.ModBlocks;
import com.rezero.mod.content.ModItems;
import com.rezero.mod.content.ModWorldgen;
import com.rezero.mod.data.PlayerDataStore;
import com.rezero.mod.net.ModNetworking;
import com.rezero.mod.server.AdminCommands;
import com.rezero.mod.server.CrystalService;
import com.rezero.mod.server.InscriptionService;
import com.rezero.mod.server.ServerEvents;
import com.rezero.mod.server.SpellService;
import com.rezero.mod.server.TrainingService;

import net.fabricmc.api.ModInitializer;

/** Ponto de entrada do mod. Cada sistema registra seus serviços aqui, na ordem das etapas. */
public class ReZeroMod implements ModInitializer {
	public static final String MOD_ID = "rezero_magic";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitialize() {
		ModConfig.load();
		PlayerDataStore.init();
		ModBlocks.init();
		ModItems.init();
		ModWorldgen.init();
		ModNetworking.registerCommon();
		ServerEvents.init();
		SpellService.init();
		CrystalService.init();
		InscriptionService.init();
		TrainingService.init();
		AdminCommands.init();
		LOGGER.info("Re:Zero Magia iniciado (núcleo: dados por mundo, rede e MagicGate).");
	}
}
