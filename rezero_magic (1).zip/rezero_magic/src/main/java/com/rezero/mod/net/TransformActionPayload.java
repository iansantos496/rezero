package com.rezero.mod.net;

import com.rezero.mod.ReZeroMod;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Cliente -> servidor: pedido para ativar uma transformação não racial (action = id da Transformation). O servidor confere tudo. */
public record TransformActionPayload(int action) implements CustomPayload {
	public static final CustomPayload.Id<TransformActionPayload> ID =
			new CustomPayload.Id<>(Identifier.of(ReZeroMod.MOD_ID, "transform_action"));

	public static final PacketCodec<RegistryByteBuf, TransformActionPayload> CODEC = PacketCodec.tuple(
			PacketCodecs.VAR_INT, TransformActionPayload::action,
			TransformActionPayload::new);

	@Override
	public CustomPayload.Id<? extends CustomPayload> getId() {
		return ID;
	}
}
