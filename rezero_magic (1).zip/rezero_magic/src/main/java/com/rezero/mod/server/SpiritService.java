package com.rezero.mod.server;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

import com.rezero.mod.core.Affinity;
import com.rezero.mod.core.SpellDef;
import com.rezero.mod.core.SpiritRules;
import com.rezero.mod.data.PlayerDataStore;
import com.rezero.mod.data.PlayerMagicData;
import com.rezero.mod.net.SpiritActionPayload;
import com.rezero.mod.net.SpiritSyncPayload;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/**
 * Espíritos (Sistema 3), no servidor. Espíritos selvagens aparecem como centelhas de partículas perto do jogador (só do elemento da sua
 * afinidade, nas condições de SpiritRules). Com a Pedra de Contrato o jogador firma UM contrato. O espírito contratado pode ser
 * manifestado: orbita o jogador em partículas, custa mana continuamente, concede um efeito passivo do elemento, amplifica os feitiços
 * e, no vínculo 3, libera uma habilidade ativa. O vínculo cresce com tempo juntos, feitiços e o que o temperamento do espírito aprecia.
 * Estado temporário (manifestado, recarga, espírito selvagem) fica em memória; contrato e vínculo são salvos.
 */
public final class SpiritService {
	private static final int SYNC_PERIOD = 20;
	private static final int PASSIVE_PERIOD = 20;
	private static final Random RNG = new Random();

	private static final class Runtime {
		boolean summoned;
		int activeCooldown;
		boolean hasWisp;
		double wispX;
		double wispY;
		double wispZ;
		int wispLeft;
		double drainAcc;
		int timeTicks;
		int sprintTicks;
		int secondTicks;
		boolean dirty;
		int lastSig = Integer.MIN_VALUE;
	}

	private static final Map<UUID, Runtime> STATE = new HashMap<>();
	private static MinecraftServer server;

	private SpiritService() {}

	public static void init() {
		ServerTickEvents.END_SERVER_TICK.register(SpiritService::tick);
		ServerLifecycleEvents.SERVER_STARTED.register(started -> server = started);
		ServerLifecycleEvents.SERVER_STOPPED.register(stopped -> {
			server = null;
			STATE.clear();
		});

		// temperamento "combate" (Fogo): o espírito gosta de ver o jogador causar dano
		ServerLivingEntityEvents.AFTER_DAMAGE.register((entity, source, baseDamageTaken, damageTaken, blocked) -> {
			if (damageTaken > 0.0f && source.getAttacker() instanceof ServerPlayerEntity attacker && entity != attacker) {
				awardTemperament(attacker, SpiritRules.Temperament.COMBAT, Math.max(1, Math.round(damageTaken / 2.0f)));
			}
		});
		// temperamento "escavar" (Terra): o espírito gosta de ver o jogador quebrar blocos
		PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
			if (player instanceof ServerPlayerEntity serverPlayer) {
				awardTemperament(serverPlayer, SpiritRules.Temperament.DIGGING, 1);
			}
		});
	}

	private static Runtime runtime(ServerPlayerEntity player) {
		return STATE.computeIfAbsent(player.getUuid(), k -> new Runtime());
	}

	/** Ao entrar ou renascer: o espírito volta a descansar (não manifestado) e o retrato é enviado. */
	public static void reset(ServerPlayerEntity player) {
		STATE.put(player.getUuid(), new Runtime());
		sync(player, true);
	}

	/** Bônus de potência dos feitiços do espírito manifestado (0 se não há). Usado pelo SpellService. */
	/** Comando de teste restrito (ver AdminCommands): define o vínculo do espírito contratado. @return false se não há contrato. */
	public static boolean adminSetBond(ServerPlayerEntity player, int bond) {
		PlayerMagicData data = PlayerDataStore.get(player);
		if (!data.adminSetBond(bond)) {
			return false;
		}
		PlayerDataStore.save(player, data);
		sync(player, true);
		return true;
	}

	/** O espírito está manifestado agora? (Sintonia Elemental exige.) */
	public static boolean isSummoned(ServerPlayerEntity player) {
		Runtime rt = STATE.get(player.getUuid());
		return rt != null && rt.summoned;
	}

	public static int powerPct(ServerPlayerEntity player) {
		Runtime rt = STATE.get(player.getUuid());
		PlayerMagicData data = PlayerDataStore.get(player);
		return rt != null && rt.summoned && data.spirit() != null ? SpiritRules.powerPct(data.bondLevel()) : 0;
	}

	/** Chamado pelo SpellService depois de um feitiço que funcionou. */
	public static void onSpellCast(ServerPlayerEntity player, SpellDef spell) {
		Runtime rt = STATE.get(player.getUuid());
		PlayerMagicData data = PlayerDataStore.get(player);
		if (rt != null && rt.summoned && data.spirit() == spell.affinity()) {
			addBond(player, SpiritRules.SPELL_XP);
		}
	}

	// ------------------------------------------------------------------ pedidos do cliente

	public static void request(MinecraftServer current, ServerPlayerEntity player, int action) {
		if (!player.isAlive() || player.isSpectator()) {
			return;
		}
		ServerWorld world = WorldLookup.of(current, player);
		if (world == null) {
			return;
		}
		PlayerMagicData data = PlayerDataStore.get(player);
		Runtime rt = runtime(player);
		switch (action) {
			case SpiritActionPayload.TOGGLE -> toggle(player, data, rt);
			case SpiritActionPayload.ACTIVE -> active(world, player, data, rt);
			case SpiritActionPayload.RELEASE -> {
				if (data.spirit() == null) {
					message(player, "spirit.no_contract");
					return;
				}
				data.breakContract();
				PlayerDataStore.save(player, data);
				rt.summoned = false;
				rt.drainAcc = 0.0;
				message(player, "spirit.released");
				sync(player, true);
			}
			default -> {
				// ação desconhecida (pacote adulterado): ignora
			}
		}
	}

	private static void toggle(ServerPlayerEntity player, PlayerMagicData data, Runtime rt) {
		if (data.spirit() == null) {
			message(player, "spirit.no_contract");
			return;
		}
		if (rt.summoned) {
			rt.summoned = false;
			message(player, "spirit.dismissed");
		} else if (data.mana() <= 0) {
			message(player, "spirit.no_mana");
			return;
		} else {
			rt.summoned = true;
			rt.drainAcc = 0.0;
			message(player, "spirit.summoned");
		}
		sync(player, true);
	}

	private static void active(ServerWorld world, ServerPlayerEntity player, PlayerMagicData data, Runtime rt) {
		SpiritRules.ActiveResult result = SpiritRules.checkActive(data.spirit() != null, rt.summoned, data.bondLevel(),
				rt.activeCooldown, data.mana());
		if (result != SpiritRules.ActiveResult.OK) {
			message(player, "spirit.active_" + result.name().toLowerCase());
			return;
		}
		data.setMana(data.mana() - SpiritRules.ACTIVE_COST);
		PlayerDataStore.save(player, data);
		rt.activeCooldown = SpiritRules.ACTIVE_COOLDOWN_TICKS;
		activate(world, player, data.spirit(), data.bondLevel());
		sync(player, true);
	}

	/** Pedra de Contrato: tenta firmar o contrato com o espírito selvagem por perto. @return true se firmou (a pedra é gasta). */
	public static boolean tryContract(ServerWorld world, ServerPlayerEntity player) {
		PlayerMagicData data = PlayerDataStore.get(player);
		Runtime rt = runtime(player);
		boolean near = rt.hasWisp && player.squaredDistanceTo(rt.wispX, rt.wispY, rt.wispZ)
				<= SpiritRules.WISP_CONTRACT_RANGE * SpiritRules.WISP_CONTRACT_RANGE;
		SpiritRules.ContractResult result = SpiritRules.checkContract(data.affinity(), data.channelLevel(), data.spirit() != null, near);
		if (result != SpiritRules.ContractResult.OK) {
			message(player, "spirit.contract_" + result.name().toLowerCase());
			return false;
		}
		Affinity element = data.affinity();
		data.signContract(element);
		PlayerDataStore.save(player, data);
		rt.hasWisp = false;
		world.spawnParticles(particleOf(element), rt.wispX, rt.wispY, rt.wispZ, 30, 0.4, 0.4, 0.4, 0.1);
		world.spawnParticles(ParticleTypes.ENCHANT, rt.wispX, rt.wispY, rt.wispZ, 30, 0.5, 0.5, 0.5, 0.5);
		SpellEffects.sound(world, player.getX(), player.getY(), player.getZ(), SoundEvents.ENTITY_PLAYER_LEVELUP, 1.0f, 0.8f);
		player.sendMessage(Text.translatable("message.rezero_magic.spirit.contracted",
				Text.translatable("spirit.rezero_magic." + element.key())), false);
		sync(player, true);
		return true;
	}

	// ------------------------------------------------------------------ vínculo

	private static void awardTemperament(ServerPlayerEntity player, SpiritRules.Temperament temperament, int xp) {
		Runtime rt = STATE.get(player.getUuid());
		PlayerMagicData data = PlayerDataStore.get(player);
		Affinity element = data.spirit();
		if (rt != null && rt.summoned && element != null && SpiritRules.temperamentOf(element) == temperament) {
			addBond(player, xp);
		}
	}

	private static void addBond(ServerPlayerEntity player, int xp) {
		xp = ProtectionService.bondXp(player, RaceService.spiritBondXp(player, xp));
		PlayerMagicData data = PlayerDataStore.get(player);
		int before = data.bondXp();
		boolean up = data.addBondXp(xp);
		if (!up && data.bondXp() == before) {
			return; // no vínculo máximo: nada mudou
		}
		PlayerDataStore.save(player, data);
		runtime(player).dirty = true;
		if (up) {
			ServerWorld world = server == null ? null : WorldLookup.of(server, player);
			if (world != null) {
				SpellEffects.sound(world, player.getX(), player.getY(), player.getZ(), SoundEvents.ENTITY_PLAYER_LEVELUP, 0.7f, 1.6f);
			}
			player.sendMessage(Text.translatable("message.rezero_magic.spirit.bond_up", data.bondLevel()), false);
			sync(player, true);
		}
	}

	// ------------------------------------------------------------------ tick

	private static void tick(MinecraftServer current) {
		boolean doSync = current.getTicks() % SYNC_PERIOD == 0;
		for (ServerPlayerEntity player : current.getPlayerManager().getPlayerList()) {
			Runtime rt = runtime(player);
			PlayerMagicData data = PlayerDataStore.get(player);
			ServerWorld world = WorldLookup.of(current, player);
			if (rt.activeCooldown > 0) {
				rt.activeCooldown--;
			}
			if (world != null && player.isAlive()) {
				Affinity element = data.spirit();
				if (element == null) {
					wispTick(current, world, player, data, rt);
				} else {
					rt.hasWisp = false;
					if (rt.summoned) {
						summonedTick(current, world, player, data, rt, element);
					}
				}
			} else if (!player.isAlive()) {
				rt.summoned = false;
			}
			if (doSync && (rt.dirty || rt.lastSig != signature(data, rt))) {
				sync(player, false);
			}
		}
		Iterator<UUID> it = STATE.keySet().iterator();
		while (it.hasNext()) {
			if (current.getPlayerManager().getPlayer(it.next()) == null) {
				it.remove();
			}
		}
	}

	/** Espírito selvagem: tenta aparecer de tempos em tempos; some depois de 60 s ou se o jogador se afastar. */
	private static void wispTick(MinecraftServer current, ServerWorld world, ServerPlayerEntity player, PlayerMagicData data, Runtime rt) {
		Affinity affinity = data.affinity();
		if (affinity == null || data.channelLevel() < SpiritRules.MIN_CHANNEL_LEVEL) {
			if (rt.hasWisp) {
				rt.hasWisp = false;
				rt.dirty = true;
			}
			return;
		}
		if (rt.hasWisp) {
			rt.wispLeft--;
			boolean far = player.squaredDistanceTo(rt.wispX, rt.wispY, rt.wispZ) > 24.0 * 24.0;
			if (rt.wispLeft <= 0 || far) {
				rt.hasWisp = false;
				rt.dirty = true;
				return;
			}
			if (current.getTicks() % 5 == 0) {
				world.spawnParticles(particleOf(affinity), rt.wispX, rt.wispY, rt.wispZ, 3, 0.2, 0.2, 0.2, 0.01);
				world.spawnParticles(ParticleTypes.ENCHANT, rt.wispX, rt.wispY + 0.3, rt.wispZ, 2, 0.3, 0.3, 0.3, 0.2);
			}
			return;
		}
		if (current.getTicks() % SpiritRules.WISP_CHECK_PERIOD_TICKS != 0) {
			return;
		}
		if (!SpiritRules.spawnCondition(affinity, envOf(world, player)) || RNG.nextInt(100) >= SpiritRules.WISP_CHANCE_PCT) {
			return;
		}
		double angle = RNG.nextDouble() * 2.0 * Math.PI;
		double dist = 3.0 + RNG.nextDouble() * 3.0;
		rt.wispX = player.getX() + Math.cos(angle) * dist;
		rt.wispY = player.getY() + 1.0;
		rt.wispZ = player.getZ() + Math.sin(angle) * dist;
		rt.wispLeft = SpiritRules.WISP_LIFETIME_TICKS;
		rt.hasWisp = true;
		rt.dirty = true;
		SpellEffects.sound(world, rt.wispX, rt.wispY, rt.wispZ, SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME, 1.0f, 0.7f);
		message(player, "spirit.wisp_near");
	}

	private static SpiritRules.Env envOf(ServerWorld world, ServerPlayerEntity player) {
		BlockPos pos = player.getBlockPos();
		return new SpiritRules.Env(world.getRegistryKey() == World.NETHER, (int) player.getY(), world.isRaining(),
				player.isTouchingWater(), world.isSkyVisible(pos), world.isNight(), world.getLightLevel(pos));
	}

	/** Espírito manifestado: partículas em órbita, custo de mana, vínculo por tempo e temperamento, efeito passivo. */
	private static void summonedTick(MinecraftServer current, ServerWorld world, ServerPlayerEntity player, PlayerMagicData data,
			Runtime rt, Affinity element) {
		int ticks = current.getTicks();
		if (ticks % 4 == 0) {
			double a = ticks * 0.15;
			world.spawnParticles(particleOf(element), player.getX() + Math.cos(a) * 0.9, player.getY() + 1.7 + Math.sin(a * 2.0) * 0.15,
					player.getZ() + Math.sin(a) * 0.9, 1, 0.0, 0.0, 0.0, 0.0);
		}

		// custo contínuo (reserva de mana): ao acabar a mana o espírito descansa
		rt.drainAcc += SpiritRules.drainPerSecond(data.bondLevel()) / 20.0;
		int whole = (int) rt.drainAcc;
		if (whole > 0) {
			rt.drainAcc -= whole;
			data.setMana(Math.max(0, data.mana() - whole));
			PlayerDataStore.save(player, data);
			if (data.mana() <= 0) {
				rt.summoned = false;
				rt.dirty = true;
				message(player, "spirit.exhausted");
				return;
			}
		}

		if (++rt.timeTicks >= SpiritRules.TIME_XP_TICKS) {
			rt.timeTicks = 0;
			addBond(player, 1);
		}
		if (player.isSprinting()) {
			rt.sprintTicks++;
		}
		if (++rt.secondTicks >= 20) {
			rt.secondTicks = 0;
			boolean sprinted = rt.sprintTicks >= 10;
			rt.sprintTicks = 0;
			switch (SpiritRules.temperamentOf(element)) {
				case WATER -> {
					if (player.isTouchingWater() || (world.isRaining() && world.isSkyVisible(player.getBlockPos()))) {
						addBond(player, 1);
					}
				}
				case TRAVEL -> {
					if (sprinted) {
						addBond(player, 1);
					}
				}
				case NIGHT -> {
					if (world.isNight()) {
						addBond(player, 1);
					}
				}
				case DAY -> {
					if (!world.isNight() && world.isSkyVisible(player.getBlockPos())) {
						addBond(player, 1);
					}
				}
				default -> {
					// combate e escavar vêm de eventos
				}
			}
		}
		if (ticks % PASSIVE_PERIOD == 0) {
			applyPassive(player, element);
		}
	}

	/** Um efeito diferente por elemento, renovado a cada segundo enquanto o espírito está manifestado. */
	private static void applyPassive(ServerPlayerEntity player, Affinity element) {
		switch (element) {
			case FIRE -> player.addStatusEffect(new StatusEffectInstance(StatusEffects.FIRE_RESISTANCE, 60, 0, true, false, true));
			case WATER -> player.addStatusEffect(new StatusEffectInstance(StatusEffects.WATER_BREATHING, 60, 0, true, false, true));
			case WIND -> player.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOW_FALLING, 60, 0, true, false, true));
			case EARTH -> player.addStatusEffect(new StatusEffectInstance(StatusEffects.HASTE, 60, 0, true, false, true));
			case YIN -> player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 260, 0, true, false, true));
			case YANG -> {
				if (player.getHealth() < player.getMaxHealth() * 0.5f) {
					player.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 60, 0, true, false, true));
				}
			}
			default -> {
				// sem outros elementos
			}
		}
	}

	/** Habilidade ativa do espírito (vínculo 3+): um efeito diferente por elemento, mais forte com o vínculo. */
	private static void activate(ServerWorld world, ServerPlayerEntity p, Affinity element, int bond) {
		double strength = SpiritRules.activeStrength(bond);
		world.spawnParticles(particleOf(element), p.getX(), p.getY() + 1.0, p.getZ(), 40, 1.2, 0.8, 1.2, 0.1);
		SpellEffects.sound(world, p.getX(), p.getY(), p.getZ(), SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, 1.0f, 0.6f);
		switch (element) {
			case FIRE -> {
				for (LivingEntity e : CombatEffects.inRadius(world, p, 5.0)) {
					SpellEffects.hurt(world, p, e, (float) strength);
					e.setOnFireFor(4.0f);
				}
			}
			case WATER -> {
				p.heal((float) strength);
				p.setFireTicks(0);
			}
			case WIND -> {
				for (LivingEntity e : CombatEffects.inRadius(world, p, 6.0)) {
					CombatEffects.knock(p, e, 1.6, 0.5);
				}
				p.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 100, 1));
			}
			case EARTH -> p.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 160, 1));
			case YIN -> {
				for (LivingEntity e : CombatEffects.inRadius(world, p, 8.0)) {
					e.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 120, 1));
					e.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 120, 0));
				}
			}
			case YANG -> {
				p.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 120, 1));
				p.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 160, 0));
			}
			default -> {
				// sem outros elementos
			}
		}
	}

	private static ParticleEffect particleOf(Affinity element) {
		return switch (element) {
			case FIRE -> ParticleTypes.FLAME;
			case WATER -> ParticleTypes.SPLASH;
			case WIND -> ParticleTypes.CLOUD;
			case EARTH -> ParticleTypes.HAPPY_VILLAGER;
			case YIN -> ParticleTypes.WITCH;
			case YANG -> ParticleTypes.END_ROD;
		};
	}

	// ------------------------------------------------------------------ rede

	private static int signature(PlayerMagicData data, Runtime rt) {
		return java.util.Objects.hash(data.spiritId(), data.bondLevel(), data.bondXp(), rt.summoned, rt.hasWisp);
	}

	public static void sync(ServerPlayerEntity player, boolean force) {
		Runtime rt = runtime(player);
		PlayerMagicData data = PlayerDataStore.get(player);
		int sig = signature(data, rt);
		if (!force && !rt.dirty && sig == rt.lastSig) {
			return;
		}
		rt.lastSig = sig;
		rt.dirty = false;
		ServerPlayNetworking.send(player, new SpiritSyncPayload(data.spiritId(), data.bondLevel(), data.bondXp(),
				rt.summoned ? 1 : 0, rt.hasWisp ? 1 : 0, rt.activeCooldown));
	}

	private static void message(ServerPlayerEntity player, String key) {
		player.sendMessage(Text.translatable("message.rezero_magic." + key), true);
	}
}
