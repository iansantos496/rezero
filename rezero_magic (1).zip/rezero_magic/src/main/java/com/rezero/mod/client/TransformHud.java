package com.rezero.mod.client;

import com.rezero.mod.core.Transformation;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

/**
 * Efeito de tela e HUD das transformações (Sistema 11). Qualquer transformação ativa (racial ou não) tinge as bordas da tela;
 * as duas formas deste sistema ganham uma linha de estado (ativa, recarga) no canto superior direito.
 */
public final class TransformHud {
	private TransformHud() {}

	private static int tint(Transformation t) {
		return switch (t) {
			case BEAST -> 0x55D2873C;
			case ONI -> 0x55C83232;
			case ATTUNEMENT -> 0x554FA8FF;
			case LAST_STAND -> 0x55FFFFFF;
		};
	}

	public static void render(DrawContext context) {
		MinecraftClient client = MinecraftClient.getInstance();
		if (client.player == null || client.options.hudHidden) {
			return;
		}
		int w = client.getWindow().getScaledWidth();
		int h = client.getWindow().getScaledHeight();
		Transformation any = ClientPlayerData.anyTransformation();
		if (any != null) {
			int c = tint(any);
			int t = 6;
			context.fill(0, 0, w, t, c);
			context.fill(0, h - t, w, h, c);
			context.fill(0, t, t, h - t, c);
			context.fill(w - t, t, w, h - t, c);
		}
		int x = w - 150;
		Transformation[] forms = {Transformation.ATTUNEMENT, Transformation.LAST_STAND};
		int y = 70;
		for (int i = 0; i < forms.length; i++) {
			Transformation f = forms[i];
			if (f == Transformation.ATTUNEMENT && ClientPlayerData.spirit() == null) {
				continue; // sem espírito, a Sintonia nem aparece no HUD
			}
			Text name = Text.translatable("transform.rezero_magic." + f.key());
			Text key = ReZeroModClient.transformKeyName(i);
			int left = ClientPlayerData.transformActive() == f ? ClientPlayerData.transformFormLeft() : 0;
			int cd = ClientPlayerData.transformCooldownLeft(f);
			if (left > 0) {
				context.drawTextWithShadow(client.textRenderer, Text.translatable("hud.rezero_magic.transform_on", name,
						String.format("%.0f", left / 20.0)), x, y, 0xFFFFE680);
				y += 11;
			} else if (cd > 0) {
				context.drawTextWithShadow(client.textRenderer, Text.translatable("hud.rezero_magic.transform_cd", key, name,
						String.format("%.0f", cd / 20.0)), x, y, 0xFFAAAAAA);
				y += 11;
			} else if (f == Transformation.ATTUNEMENT) {
				context.drawTextWithShadow(client.textRenderer, Text.translatable("hud.rezero_magic.transform_ready", key, name),
						x, y, 0xFFFFFFFF);
				y += 11;
			}
		}
	}
}
