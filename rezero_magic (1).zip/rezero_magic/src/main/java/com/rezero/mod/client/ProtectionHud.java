package com.rezero.mod.client;

import com.rezero.mod.core.DivineProtection;
import com.rezero.mod.core.ProtectionRules;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

/** HUD da bênção ativa (Indicação do Vento), abaixo da raça. Só aparece para quem a recebeu. */
public final class ProtectionHud {
	private ProtectionHud() {}

	public static void render(DrawContext context) {
		MinecraftClient client = MinecraftClient.getInstance();
		if (client.player == null || client.options.hudHidden
				|| !ProtectionRules.has(ClientPlayerData.protectionMask(), DivineProtection.WIND_INDICATION)) {
			return;
		}
		int x = client.getWindow().getScaledWidth() - 150;
		int y = 58;
		Text name = Text.translatable("protection.rezero_magic.wind_indication");
		int cd = ClientPlayerData.protectionCooldownLeft();
		if (cd > 0) {
			context.drawTextWithShadow(client.textRenderer, Text.translatable("hud.rezero_magic.protection_cd",
					ReZeroModClient.protectionKeyName(), name, String.format("%.0f", cd / 20.0)), x, y, 0xFFAAAAAA);
		} else {
			context.drawTextWithShadow(client.textRenderer, Text.translatable("hud.rezero_magic.protection_ready",
					ReZeroModClient.protectionKeyName(), name), x, y, 0xFFFFFFFF);
		}
	}
}
