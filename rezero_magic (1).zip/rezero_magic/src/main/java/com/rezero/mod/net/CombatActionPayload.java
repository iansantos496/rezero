package com.rezero.mod.net;

import com.rezero.mod.ReZeroMod;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/**
 * Cliente -> servidor: um PEDIDO de ação de combate. action 0 = usar a técnica do espaço {@code arg} (0 a 2) da arma na mão;
 * 1 = esquivar na direção {@code arg} (0 frente, 1 trás, 2 esquerda, 3 direita); 2 = aprender a técnica de id {@code arg}.
 * O servidor valida tudo (arma, estamina, recarga, requisitos).
 */
public record CombatActionPayload(int action, int arg) implements CustomPayload {
	public static final int USE = 0;
	public static final int DODGE = 1;
	public static final int LEARN = 2;

	public static final CustomPayload.Id<CombatActionPayload> ID =
			new CustomPayload.Id<>(Identifier.of(ReZeroMod.MOD_ID, "combat_action"));

	public static final PacketCodec<RegistryByteBuf, CombatActionPayload> CODEC = PacketCodec.tuple(
			PacketCodecs.VAR_INT, CombatActionPayload::action,
			PacketCodecs.VAR_INT, CombatActionPayload::arg,
			CombatActionPayload::new);

	@Override
	public CustomPayload.Id<? extends CustomPayload> getId() {
		return ID;
	}
}
