package com.rezero.mod.core;

import java.util.ArrayList;
import java.util.List;

/**
 * As 15 técnicas de combate (3 por estilo, uma por tier). Todos os números são adaptação de jogo.
 * Cada tier exige o anterior do mesmo estilo e um nível mínimo de um atributo de treino (3 níveis: 1, 3 e 5).
 */
public final class Techniques {
	public static final int SWORD_SWEEP = 0;
	public static final int SWORD_HEAVY = 1;
	public static final int SWORD_RIPOSTE = 2;
	public static final int SPEAR_THRUST = 3;
	public static final int SPEAR_LUNGE = 4;
	public static final int SPEAR_WHIRL = 5;
	public static final int DAGGER_FLURRY = 6;
	public static final int DAGGER_BACKSTAB = 7;
	public static final int DAGGER_SHADOW = 8;
	public static final int FIST_COMBO = 9;
	public static final int FIST_SHOCKWAVE = 10;
	public static final int FIST_GUARD = 11;
	public static final int BOW_PIERCE = 12;
	public static final int BOW_VOLLEY = 13;
	public static final int BOW_SNARE = 14;
	public static final int COUNT = 15;

	private static final TrainingAttribute STR = TrainingAttribute.STRENGTH;
	private static final TrainingAttribute AGI = TrainingAttribute.AGILITY;
	private static final TrainingAttribute VIG = TrainingAttribute.VIGOR;

	private static final List<TechniqueDef> ALL = List.of(
			// id, chave, estilo, tier, estamina, recarga, carga, atributo, nível mínimo, dano %, alcance
			new TechniqueDef(SWORD_SWEEP, "sword_sweep", CombatStyle.SWORD, 1, 15, 40, 0, STR, 1, 80, 3.0),
			new TechniqueDef(SWORD_HEAVY, "sword_heavy", CombatStyle.SWORD, 2, 28, 100, 10, STR, 3, 200, 3.5),
			new TechniqueDef(SWORD_RIPOSTE, "sword_riposte", CombatStyle.SWORD, 3, 25, 160, 0, AGI, 5, 150, 4.0),
			new TechniqueDef(SPEAR_THRUST, "spear_thrust", CombatStyle.SPEAR, 1, 15, 40, 0, STR, 1, 110, 4.5),
			new TechniqueDef(SPEAR_LUNGE, "spear_lunge", CombatStyle.SPEAR, 2, 28, 120, 0, AGI, 3, 100, 3.0),
			new TechniqueDef(SPEAR_WHIRL, "spear_whirl", CombatStyle.SPEAR, 3, 35, 200, 8, STR, 5, 120, 3.5),
			new TechniqueDef(DAGGER_FLURRY, "dagger_flurry", CombatStyle.DAGGER, 1, 15, 40, 0, AGI, 1, 40, 2.5),
			new TechniqueDef(DAGGER_BACKSTAB, "dagger_backstab", CombatStyle.DAGGER, 2, 20, 80, 0, AGI, 3, 150, 3.0),
			new TechniqueDef(DAGGER_SHADOW, "dagger_shadow", CombatStyle.DAGGER, 3, 30, 200, 0, AGI, 5, 0, 5.0),
			new TechniqueDef(FIST_COMBO, "fist_combo", CombatStyle.UNARMED, 1, 12, 30, 0, STR, 1, 70, 2.5),
			new TechniqueDef(FIST_SHOCKWAVE, "fist_shockwave", CombatStyle.UNARMED, 2, 28, 120, 12, STR, 3, 130, 5.0),
			new TechniqueDef(FIST_GUARD, "fist_guard", CombatStyle.UNARMED, 3, 25, 200, 0, VIG, 5, 0, 0.0),
			new TechniqueDef(BOW_PIERCE, "bow_pierce", CombatStyle.BOW, 1, 25, 80, 0, AGI, 1, 100, 30.0),
			new TechniqueDef(BOW_VOLLEY, "bow_volley", CombatStyle.BOW, 2, 35, 160, 12, AGI, 3, 50, 30.0),
			new TechniqueDef(BOW_SNARE, "bow_snare", CombatStyle.BOW, 3, 25, 140, 0, AGI, 5, 60, 30.0));

	private Techniques() {}

	public static List<TechniqueDef> all() {
		return ALL;
	}

	/** @return a técnica com esse id, ou null (id vindo de um pacote adulterado). */
	public static TechniqueDef byId(int id) {
		return id >= 0 && id < ALL.size() ? ALL.get(id) : null;
	}

	/** Técnicas do estilo, do tier 1 ao 3. */
	public static List<TechniqueDef> forStyle(CombatStyle style) {
		List<TechniqueDef> out = new ArrayList<>();
		for (TechniqueDef t : ALL) {
			if (t.style() == style) {
				out.add(t);
			}
		}
		return out;
	}

	/** A técnica do estilo naquele espaço (0 a 2 = tier 1 a 3), ou null. */
	public static TechniqueDef slot(CombatStyle style, int slot) {
		if (style == null || slot < 0 || slot > 2) {
			return null;
		}
		List<TechniqueDef> list = forStyle(style);
		return slot < list.size() ? list.get(slot) : null;
	}
}
