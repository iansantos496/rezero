package com.rezero.mod.server;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import com.rezero.mod.ReZeroMod;
import com.rezero.mod.core.DivineProtection;
import com.rezero.mod.core.ProtectionRules;
import com.rezero.mod.data.PlayerDataStore;
import com.rezero.mod.data.PlayerMagicData;
import com.rezero.mod.net.ProtectionActionPayload;
import com.rezero.mod.net.ProtectionSyncPayload;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.Box;

/**
 * Proteções Divinas (Sistema 4) no servidor: receber (só com a condição cumprida e vaga livre), efeitos passivos (Sol, Espíritos da Terra),
 * bônus (Reunião de Espíritos, Santo da Espada) e a ativa Indicação do Vento. Regras e números em ProtectionRules (testadas fora do jogo).
 * Tudo é decidido aqui; o cliente só pede e mostra.
 */
public final class ProtectionService {
	private static final int PASSIVE_PERIOD = 20;
	private static final int REVEAL_PERIOD = 10;

	private static final class Runtime {
		int cooldown;
		int revealLeft;
		boolean dirty;
	}

	private static final Map<UUID, Runtime> STATE = new HashMap<>();

	private ProtectionService() {}

	public static void init() {
		ServerTickEvents.END_SERVER_TICK.register(ProtectionService::tick);
		ServerLifecycleEvents.SERVER_STOPPED.register(stopped -> STATE.clear());
	}

	private static Runtime runtime(ServerPlayerEntity player) {
		return STATE.computeIfAbsent(player.getUuid(), k -> new Runtime());
	}

	/** Ao entrar ou renascer: recarga zerada e retrato enviado (as proteções recebidas continuam). */
	public static void reset(ServerPlayerEntity player) {
		STATE.put(player.getUuid(), new Runtime());
		sync(player);
	}

	// ------------------------------------------------------------------ consultas (servidor)

	public static int maskOf(ServerPlayerEntity player) {
		return PlayerDataStore.get(player).protectionMask();
	}

	/** XP de vínculo com o bônus da Reunião de Espíritos. */
	public static int bondXp(ServerPlayerEntity player, int xp) {
		return ProtectionRules.bondXp(maskOf(player), xp);
	}

	private static ProtectionRules.Progress progressOf(PlayerMagicData d) {
		return new ProtectionRules.Progress(d.affinity(), d.channelLevel(), d.trainingLevels(),
				Integer.bitCount(d.techniqueMask()), d.spirit() != null ? d.bondLevel() : 0, d.race());
	}

	/** Comando de teste restrito (ver AdminCommands): devolve todas as bênçãos. */
	public static void adminReset(ServerPlayerEntity player) {
		PlayerMagicData data = PlayerDataStore.get(player);
		data.adminClearProtections();
		PlayerDataStore.save(player, data);
		sync(player);
		ReZeroMod.LOGGER.warn("Bênçãos de {} devolvidas por comando administrativo.", player.getName().getString());
	}

	// ------------------------------------------------------------------ pedidos

	public static void request(MinecraftServer current, ServerPlayerEntity player, int action, int arg) {
		if (!player.isAlive()) {
			return;
		}
		switch (action) {
			case ProtectionActionPayload.CLAIM -> claim(player, arg);
			case ProtectionActionPayload.ACTIVE -> active(current, player);
			default -> {
				// ação desconhecida (pacote adulterado): ignora
			}
		}
	}

	private static void claim(ServerPlayerEntity player, int id) {
		DivineProtection p = DivineProtection.fromId(id);
		PlayerMagicData data = PlayerDataStore.get(player);
		ProtectionRules.ClaimResult result = ProtectionRules.checkClaim(data.protectionMask(), p, progressOf(data));
		if (result != ProtectionRules.ClaimResult.OK) {
			message(player, "protection.claim_" + result.name().toLowerCase());
			return;
		}
		data.grantProtection(p);
		PlayerDataStore.save(player, data);
		player.sendMessage(Text.translatable("message.rezero_magic.protection.claimed",
				Text.translatable("protection.rezero_magic." + p.key())), false);
		ReZeroMod.LOGGER.info("{} recebeu a proteção {}.", player.getName().getString(), p.key());
		sync(player);
	}

	/** Indicação do Vento: revela criaturas hostis (inclusive invisíveis) num raio, com partículas, por 8 s. */
	private static void active(MinecraftServer current, ServerPlayerEntity player) {
		PlayerMagicData data = PlayerDataStore.get(player);
		Runtime rt = runtime(player);
		ProtectionRules.ActiveResult result = ProtectionRules.checkActive(data.protectionMask(), rt.cooldown, data.mana());
		if (result != ProtectionRules.ActiveResult.OK) {
			message(player, "protection.active_" + result.name().toLowerCase());
			return;
		}
		ServerWorld world = WorldLookup.of(current, player);
		if (world == null) {
			return;
		}
		data.setMana(data.mana() - ProtectionRules.WIND_COST);
		PlayerDataStore.save(player, data);
		rt.cooldown = ProtectionRules.WIND_COOLDOWN_TICKS;
		rt.revealLeft = ProtectionRules.WIND_REVEAL_TICKS;
		SpellEffects.sound(world, player.getX(), player.getY(), player.getZ(), SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME, 1.0f, 1.4f);
		int found = reveal(world, player);
		player.sendMessage(Text.translatable("message.rezero_magic.protection.wind_sense", found), true);
		sync(player);
	}

	/** Partículas sobre cada criatura hostil no raio. @return quantas foram encontradas. */
	private static int reveal(ServerWorld world, ServerPlayerEntity player) {
		double range = ProtectionRules.WIND_RANGE;
		Box box = player.getBoundingBox().expand(range);
		int count = 0;
		for (HostileEntity e : world.getEntitiesByClass(HostileEntity.class, box,
				x -> x.isAlive() && x.squaredDistanceTo(player) <= range * range)) {
			world.spawnParticles(ParticleTypes.END_ROD, e.getX(), e.getY() + e.getHeight() + 0.4, e.getZ(), 3, 0.1, 0.3, 0.1, 0.01);
			count++;
		}
		return count;
	}

	// ------------------------------------------------------------------ tick

	private static void tick(MinecraftServer current) {
		int ticks = current.getTicks();
		boolean passive = ticks % PASSIVE_PERIOD == 0;
		boolean pulse = ticks % REVEAL_PERIOD == 0;
		for (ServerPlayerEntity player : current.getPlayerManager().getPlayerList()) {
			Runtime rt = STATE.get(player.getUuid());
			if (rt == null || !player.isAlive()) {
				continue;
			}
			if (rt.cooldown > 0) {
				rt.cooldown--;
			}
			int mask = maskOf(player);
			if (mask == 0 && rt.revealLeft == 0 && !rt.dirty) {
				continue;
			}
			ServerWorld world = (passive || pulse) ? WorldLookup.of(current, player) : null;
			if (world != null && passive) {
				applyPassives(world, player, mask);
			}
			if (rt.revealLeft > 0) {
				rt.revealLeft--;
				if (world != null && pulse) {
					reveal(world, player);
				}
			}
			if (rt.dirty || (passive && rt.cooldown > 0)) {
				sync(player);
			}
		}
	}

	/** Sol e Espíritos da Terra: efeitos renovados a cada segundo enquanto a condição vale. */
	private static void applyPassives(ServerWorld world, ServerPlayerEntity player, int mask) {
		if (ProtectionRules.has(mask, DivineProtection.SUN)
				&& ProtectionRules.sunActive(world.isNight(), world.isSkyVisible(player.getBlockPos()))) {
			player.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, ProtectionRules.SUN_EFFECT_TICKS, 0, true, false, true));
		}
		if (ProtectionRules.has(mask, DivineProtection.EARTH_SPIRITS)
				&& ProtectionRules.earthActive(player.isOnGround(), player.getHealth(), player.getMaxHealth())) {
			player.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, ProtectionRules.EARTH_EFFECT_TICKS, 0, true, false, true));
		}
	}

	public static void sync(ServerPlayerEntity player) {
		Runtime rt = runtime(player);
		rt.dirty = false;
		ServerPlayNetworking.send(player, new ProtectionSyncPayload(maskOf(player), rt.cooldown));
	}

	private static void message(ServerPlayerEntity player, String key) {
		player.sendMessage(Text.translatable("message.rezero_magic." + key), true);
	}
}
