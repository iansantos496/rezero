package com.rezero.mod.core;

/**
 * Regras das transformações NÃO raciais (Sistema 11), em código puro e testado fora do jogo.
 *
 * CANON (verificado): só as transformações raciais (fera dos demi-humanos; Forma Oni) — já tratadas em RaceRules.
 * ADAPTAÇÃO: Sintonia Elemental (estado ligado ao espírito contratado) e Último Fôlego (estado de emergência por vida baixa) são
 * invenções de jogo, com condições, custos, duração, recarga e efeito colateral explícitos. Nenhuma delas cura, revive ou evita a morte
 * (não existe Retorno por Morte nem equivalente). Só uma transformação por vez, raciais incluídas.
 */
public final class TransformationRules {
	// ---- Sintonia Elemental (espírito) ----
	public static final int ATTUNE_MIN_BOND = 4;
	public static final int ATTUNE_MIN_CHANNEL = 10;
	public static final int ATTUNE_COST = 40;
	public static final int ATTUNE_TICKS = 600;
	public static final int ATTUNE_COOLDOWN_TICKS = 4800;
	public static final int ATTUNE_POWER_PCT = 25;
	public static final int ATTUNE_COST_REDUCTION_PCT = 20;
	public static final int ATTUNE_REGEN_PCT = 25;
	/** Ao terminar, a mana cai para no máximo esta fração da capacidade (esgotamento) e há fraqueza. */
	public static final double ATTUNE_END_MANA_FRACTION = 0.25;
	public static final int ATTUNE_WEAK_TICKS = 200;

	// ---- Último Fôlego (emergência) ----
	public static final double LAST_STAND_HEALTH_FRACTION = 0.30;
	public static final int LAST_STAND_MIN_VIGOR = 4;
	public static final int LAST_STAND_TICKS = 200;
	public static final int LAST_STAND_COOLDOWN_TICKS = 6000;
	public static final int LAST_STAND_EXHAUST_TICKS = 300;

	public enum Result {
		OK, NOT_SELF_ACTIVATED, OTHER_ACTIVE, ON_COOLDOWN,
		NO_SPIRIT, SPIRIT_BOND, SPIRIT_NOT_SUMMONED, CHANNELS, NO_MANA,
		HEALTH_NOT_LOW, VIGOR
	}

	/** O estado do jogador que as condições consultam (servidor: dados reais; cliente: espelho só para exibição). */
	public record Context(boolean otherActive, int cooldownLeft, int channelLevel, int mana, int bondLevel,
			boolean spiritSummoned, double health, double maxHealth, int vigorLevel) {}

	private TransformationRules() {}

	public static int durationTicks(Transformation t) {
		return switch (t) {
			case BEAST, ONI -> RaceRules.FORM_TICKS;
			case ATTUNEMENT -> ATTUNE_TICKS;
			case LAST_STAND -> LAST_STAND_TICKS;
		};
	}

	public static int cooldownTicks(Transformation t) {
		return switch (t) {
			case BEAST -> RaceRules.DEMI_COOLDOWN_TICKS;
			case ONI -> RaceRules.ONI_COOLDOWN_TICKS;
			case ATTUNEMENT -> ATTUNE_COOLDOWN_TICKS;
			case LAST_STAND -> LAST_STAND_COOLDOWN_TICKS;
		};
	}

	/** Custo de mana ao ativar (as raciais não gastam mana). */
	public static int manaCost(Transformation t) {
		return t == Transformation.ATTUNEMENT ? ATTUNE_COST : 0;
	}

	/** Verifica as condições de uma transformação ativada neste sistema, na ordem: outra ativa, recarga, condições próprias. */
	public static Result check(Transformation t, Context c) {
		if (t == null || !t.selfActivated()) {
			return Result.NOT_SELF_ACTIVATED;
		}
		if (c.otherActive()) {
			return Result.OTHER_ACTIVE;
		}
		if (c.cooldownLeft() > 0) {
			return Result.ON_COOLDOWN;
		}
		if (t == Transformation.ATTUNEMENT) {
			if (c.bondLevel() <= 0) {
				return Result.NO_SPIRIT;
			}
			if (c.bondLevel() < ATTUNE_MIN_BOND) {
				return Result.SPIRIT_BOND;
			}
			if (!c.spiritSummoned()) {
				return Result.SPIRIT_NOT_SUMMONED;
			}
			if (ChannelModel.clampLevel(c.channelLevel()) < ATTUNE_MIN_CHANNEL) {
				return Result.CHANNELS;
			}
			if (c.mana() < ATTUNE_COST) {
				return Result.NO_MANA;
			}
			return Result.OK;
		}
		if (c.maxHealth() <= 0.0 || c.health() > c.maxHealth() * LAST_STAND_HEALTH_FRACTION) {
			return Result.HEALTH_NOT_LOW;
		}
		if (c.vigorLevel() < LAST_STAND_MIN_VIGOR) {
			return Result.VIGOR;
		}
		return Result.OK;
	}

	/** Efeitos da forma ativa sobre a magia: {potência%, redução de custo%, redução de carga%, regeneração%}. */
	public static int[] castPcts(Transformation active) {
		if (active == Transformation.ATTUNEMENT) {
			return new int[] {ATTUNE_POWER_PCT, ATTUNE_COST_REDUCTION_PCT, 0, ATTUNE_REGEN_PCT};
		}
		return new int[] {0, 0, 0, 0};
	}

	/** Soma dois vetores de efeitos de magia (raça + forma). */
	public static int[] sum(int[] a, int[] b) {
		int[] out = new int[4];
		for (int i = 0; i < 4; i++) {
			out[i] = (a != null && i < a.length ? a[i] : 0) + (b != null && i < b.length ? b[i] : 0);
		}
		return out;
	}

	/** Mana ao fim da Sintonia: nunca sobe, e cai para no máximo 25% da capacidade. */
	public static int manaAfterAttunement(int mana, int channelLevel) {
		int cap = (int) Math.floor(ChannelModel.maxMana(channelLevel) * ATTUNE_END_MANA_FRACTION);
		return Math.max(0, Math.min(mana, cap));
	}
}
