package com.rezero.mod.content;

import com.rezero.mod.core.CombatStyle;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;

/**
 * Descobre o estilo de luta pela arma na mão principal. Mão vazia = desarmado; adaga de cristal = adaga;
 * lanças do mod e tridente = lança; arco = arco; espadas do mod e qualquer espada do jogo = espada.
 * Qualquer outra coisa na mão (picareta, cajado, bloco) não tem estilo: devolve null.
 */
public final class CombatStyles {
	private CombatStyles() {}

	public static CombatStyle styleOf(ItemStack stack) {
		if (stack.isEmpty()) {
			return CombatStyle.UNARMED;
		}
		Item item = stack.getItem();
		if (item == ModItems.CRYSTAL_DAGGER) {
			return CombatStyle.DAGGER;
		}
		if (item == ModItems.MANA_SPEAR || item == ModItems.CRYSTAL_SPEAR || stack.isOf(Items.TRIDENT)) {
			return CombatStyle.SPEAR;
		}
		if (stack.isOf(Items.BOW)) {
			return CombatStyle.BOW;
		}
		if (item == ModItems.MANA_SHORTSWORD || item == ModItems.CRYSTAL_RAPIER || item == ModItems.MANA_LONGSWORD
				|| item == ModItems.MANA_GREATSWORD || item == ModItems.PRIMORDIAL_BLADE || stack.isIn(ItemTags.SWORDS)) {
			return CombatStyle.SWORD;
		}
		return null;
	}
}
