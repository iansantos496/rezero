package com.rezero.mod.data;

import java.util.ArrayList;
import java.util.List;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.rezero.mod.core.Affinity;
import com.rezero.mod.core.AffinityRules;
import com.rezero.mod.core.ChannelModel;
import com.rezero.mod.core.CombatRules;
import com.rezero.mod.core.InscriptionRules;
import com.rezero.mod.core.ProtectionRules;
import com.rezero.mod.core.Race;
import com.rezero.mod.core.RaceRules;
import com.rezero.mod.core.SpiritRules;
import com.rezero.mod.core.TrainingAttribute;
import com.rezero.mod.core.TrainingModel;

/**
 * Todos os dados mágicos de UM jogador em UM mundo. Cada sistema terá o seu bloco aqui, adicionado
 * quando o sistema for implementado (sem campos "reservados" que não fazem nada).
 * Hoje: afinidade (E2), canais de mana: mana atual, nível e XP (E3), marcas gravadas (E6b) treinamento (E7a) técnicas de combate aprendidas (E7b) contrato de espírito (E8) raça (E9a) e Proteções Divinas (E9b).
 * O campo "version" permite migrar o formato salvo no futuro.
 */
public final class PlayerMagicData {
	public static final int CURRENT_VERSION = 8;

	public static final Codec<PlayerMagicData> CODEC = RecordCodecBuilder.create(instance -> instance.group(
			Codec.INT.optionalFieldOf("version", CURRENT_VERSION).forGetter(d -> d.version),
			Codec.INT.optionalFieldOf("affinity", -1).forGetter(d -> d.affinityId),
			Codec.INT.optionalFieldOf("channel_level", 1).forGetter(d -> d.channelLevel),
			Codec.INT.optionalFieldOf("channel_xp", 0).forGetter(d -> d.channelXp),
			Codec.INT.optionalFieldOf("mana", -1).forGetter(d -> d.mana),
			Codec.INT.listOf().optionalFieldOf("inscriptions", List.of()).forGetter(d -> d.inscriptions),
			Codec.INT.listOf().optionalFieldOf("training_levels", List.of()).forGetter(d -> toList(d.trainingLevels)),
			Codec.INT.listOf().optionalFieldOf("training_xp", List.of()).forGetter(d -> toList(d.trainingXp)),
			Codec.INT.optionalFieldOf("training_focus", TrainingAttribute.STRENGTH.id()).forGetter(d -> d.trainingFocus),
			Codec.INT.optionalFieldOf("techniques", 0).forGetter(d -> d.techniques),
			Codec.INT.optionalFieldOf("spirit", -1).forGetter(d -> d.spiritId),
			Codec.INT.optionalFieldOf("spirit_bond", 1).forGetter(d -> d.bondLevel),
			Codec.INT.optionalFieldOf("spirit_bond_xp", 0).forGetter(d -> d.bondXp),
			Codec.INT.optionalFieldOf("race", -1).forGetter(d -> d.raceId),
			Codec.INT.optionalFieldOf("protections", 0).forGetter(d -> d.protections)
	).apply(instance, PlayerMagicData::new));

	private int version;
	private int affinityId;
	private int channelLevel;
	private int channelXp;
	/** -1 = nunca inicializada (jogador novo começa com a mana cheia). */
	private int mana;
	/** Marcas gravadas (ids de Inscription), no máximo Inscription.SLOTS, sem repetição. */
	private List<Integer> inscriptions;
	/** Nível (0..10) e XP de cada atributo de treino, indexados por TrainingAttribute.id(). */
	private int[] trainingLevels;
	private int[] trainingXp;
	/** Atributo que o Poste de Treino exercita (escolhido no Hub). */
	private int trainingFocus;
	/** Técnicas de combate aprendidas (máscara de bits pelo id da técnica). */
	private int techniques;
	/** Espírito contratado: id da afinidade do elemento (Affinity.id), ou -1 se não há contrato. Só um por vez. */
	private int spiritId;
	private int bondLevel;
	private int bondXp;
	/** Raça escolhida uma única vez (Race.id), ou -1 se ainda não escolheu. */
	private int raceId;
	/** Proteções Divinas recebidas (máscara de bits pelo id; no máximo ProtectionRules.MAX_SLOTS vagas). */
	private int protections;

	public PlayerMagicData() {
		this(CURRENT_VERSION, -1, 1, 0, -1, List.of(), List.of(), List.of(), TrainingAttribute.STRENGTH.id(), 0, -1, 1, 0, -1, 0);
	}

	private PlayerMagicData(int version, int affinityId, int channelLevel, int channelXp, int mana, List<Integer> inscriptions,
			List<Integer> trainingLevels, List<Integer> trainingXp, int trainingFocus, int techniques,
			int spiritId, int bondLevel, int bondXp, int raceId, int protections) {
		// dados salvos na versão anterior continuam válidos: campos ausentes recebem o padrão
		this.version = CURRENT_VERSION;
		// dados corrompidos ou de versão futura nunca produzem valores inválidos
		this.affinityId = AffinityRules.normalizeId(affinityId);
		this.channelLevel = ChannelModel.clampLevel(channelLevel);
		this.channelXp = Math.max(0, channelXp);
		this.mana = mana < 0 ? ChannelModel.maxMana(this.channelLevel) : ChannelModel.clampMana(mana, this.channelLevel);
		this.inscriptions = new ArrayList<>(InscriptionRules.sanitize(inscriptions));
		this.trainingLevels = TrainingModel.sanitizeLevels(trainingLevels);
		this.trainingXp = TrainingModel.sanitizeXp(trainingXp, this.trainingLevels);
		this.trainingFocus = TrainingAttribute.fromId(trainingFocus) == null ? TrainingAttribute.STRENGTH.id() : trainingFocus;
		this.techniques = CombatRules.sanitizeMask(techniques);
		this.spiritId = Affinity.fromId(spiritId) == null ? -1 : spiritId;
		this.bondLevel = SpiritRules.clampBond(bondLevel);
		this.raceId = RaceRules.normalizeId(raceId);
		this.protections = ProtectionRules.sanitizeMask(protections);
		this.bondXp = this.spiritId < 0 || this.bondLevel >= SpiritRules.MAX_BOND ? 0
				: Math.max(0, Math.min(SpiritRules.bondXpNeeded(this.bondLevel) - 1, bondXp));
	}

	// ---- Proteções Divinas (Sistema 4) ----

	public int protectionMask() {
		return protections;
	}

	/** Uso interno do ProtectionService (que já validou condição e vagas). */
	public void grantProtection(com.rezero.mod.core.DivineProtection p) {
		this.protections = ProtectionRules.sanitizeMask(protections | ProtectionRules.bit(p));
	}

	// ---- raça (Sistema 7) ----

	/** @return a raça escolhida, ou null se ainda não escolheu. */
	public Race race() {
		return Race.fromId(raceId);
	}

	public int raceId() {
		return raceId;
	}

	/** Uso interno do RaceService (que já validou que é a primeira e única escolha). */
	public void setRace(Race race) {
		this.raceId = race == null ? -1 : race.id();
	}

	// ---- espírito (Sistema 3) ----

	/** @return o elemento do espírito contratado, ou null se não há contrato. */
	public Affinity spirit() {
		return Affinity.fromId(spiritId);
	}

	public int spiritId() {
		return spiritId;
	}

	public int bondLevel() {
		return bondLevel;
	}

	public int bondXp() {
		return bondXp;
	}

	/** Uso interno do SpiritService (que já validou o contrato). Começa no vínculo 1. */
	public void signContract(Affinity element) {
		this.spiritId = element.id();
		this.bondLevel = 1;
		this.bondXp = 0;
	}

	public void breakContract() {
		this.spiritId = -1;
		this.bondLevel = 1;
		this.bondXp = 0;
	}

	/** Soma XP de vínculo; @return true se o nível subiu. Sem contrato não faz nada. */
	public boolean addBondXp(int gained) {
		if (spiritId < 0) {
			return false;
		}
		int[] r = SpiritRules.applyBondXp(bondLevel, bondXp, gained);
		boolean up = r[0] > bondLevel;
		bondLevel = r[0];
		bondXp = r[1];
		return up;
	}

	// ---- técnicas de combate (Sistema 9) ----

	public int techniqueMask() {
		return techniques;
	}

	/** Uso interno do CombatService (que já validou requisitos e pontos). */
	public void learnTechnique(int techniqueId) {
		this.techniques = CombatRules.sanitizeMask(techniques | CombatRules.bit(techniqueId));
	}

	private static List<Integer> toList(int[] values) {
		List<Integer> out = new ArrayList<>();
		for (int v : values) {
			out.add(v);
		}
		return out;
	}

	// ---- treinamento (Sistema 6) ----

	public int trainingLevel(TrainingAttribute a) {
		return trainingLevels[a.id()];
	}

	public int trainingXp(TrainingAttribute a) {
		return trainingXp[a.id()];
	}

	/** Cópia dos níveis, indexada por TrainingAttribute.id(). */
	public int[] trainingLevels() {
		return trainingLevels.clone();
	}

	public int[] trainingXpValues() {
		return trainingXp.clone();
	}

	public TrainingAttribute trainingFocus() {
		return TrainingAttribute.fromId(trainingFocus);
	}

	public void setTrainingFocus(TrainingAttribute a) {
		if (a != null) {
			this.trainingFocus = a.id();
		}
	}

	/** Soma XP ao atributo respeitando o teto dado pelo nível dos canais. @return true se o nível subiu. */
	public boolean addTrainingXp(TrainingAttribute a, int gained) {
		int cap = TrainingModel.levelCap(channelLevel);
		int[] r = TrainingModel.applyXp(trainingLevels[a.id()], trainingXp[a.id()], gained, cap);
		boolean up = r[0] > trainingLevels[a.id()];
		trainingLevels[a.id()] = r[0];
		trainingXp[a.id()] = r[1];
		return up;
	}

	/** Teto atual dos atributos (depende do nível dos canais). */
	public int trainingCap() {
		return TrainingModel.levelCap(channelLevel);
	}

	/** @return a afinidade escolhida, ou null se o jogador ainda não escolheu. */
	public Affinity affinity() {
		return Affinity.fromId(affinityId);
	}

	public int affinityId() {
		return affinityId;
	}

	/** Uso interno do MagicGate. Passe null para limpar (somente reset administrativo). */
	public void setAffinity(Affinity affinity) {
		this.affinityId = affinity == null ? -1 : affinity.id();
	}

	public int channelLevel() {
		return channelLevel;
	}

	public int channelXp() {
		return channelXp;
	}

	/** Cópia das marcas gravadas. */
	public List<Integer> inscriptions() {
		return new ArrayList<>(inscriptions);
	}

	public int inscriptionMask() {
		return InscriptionRules.toMask(inscriptions);
	}

	/** Uso interno do InscriptionService (que já validou tudo). */
	public void addInscription(int id) {
		if (!inscriptions.contains(id)) {
			inscriptions.add(id);
			inscriptions = new ArrayList<>(InscriptionRules.sanitize(inscriptions));
		}
	}

	public void removeInscription(int id) {
		inscriptions.remove(Integer.valueOf(id));
	}

	public int mana() {
		return mana;
	}

	public int maxMana() {
		return ChannelModel.maxMana(channelLevel);
	}

	public void setMana(int value) {
		this.mana = ChannelModel.clampMana(value, channelLevel);
	}

	/** Somente comando de teste: define o nível, zera o XP e enche a mana. */
	public void setChannelLevel(int level) {
		this.channelLevel = ChannelModel.clampLevel(level);
		this.channelXp = 0;
		this.mana = ChannelModel.maxMana(this.channelLevel);
	}

	/** Somente comando de teste: define o nível de todos os atributos de treino (limitado a 0..10) e zera o XP. */
	public void adminSetTrainingLevels(int level) {
		int v = TrainingModel.clampLevel(level);
		for (int i = 0; i < trainingLevels.length; i++) {
			trainingLevels[i] = v;
			trainingXp[i] = 0;
		}
	}

	/** Somente comando de teste: define o vínculo do espírito contratado (sem contrato, não faz nada). @return true se aplicou. */
	public boolean adminSetBond(int bond) {
		if (spiritId < 0) {
			return false;
		}
		this.bondLevel = SpiritRules.clampBond(bond);
		this.bondXp = 0;
		return true;
	}

	/** Somente comando de teste: apaga a raça escolhida (a tela de escolha reabre). */
	public void adminClearRace() {
		this.raceId = -1;
	}

	/** Somente comando de teste: devolve todas as bênçãos. */
	public void adminClearProtections() {
		this.protections = 0;
	}

	/** Soma XP dos canais; @return true se o nível subiu. */
	public boolean addChannelXp(int gained) {
		int[] r = ChannelModel.applyXp(channelLevel, channelXp, gained);
		boolean up = r[0] > channelLevel;
		channelLevel = r[0];
		channelXp = r[1];
		return up;
	}
}
