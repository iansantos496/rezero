package com.rezero.mod.data;

import java.util.ArrayList;
import java.util.List;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.rezero.mod.core.Affinity;
import com.rezero.mod.core.AffinityRules;
import com.rezero.mod.core.ChannelModel;
import com.rezero.mod.core.InscriptionRules;
import com.rezero.mod.core.TrainingAttribute;
import com.rezero.mod.core.TrainingModel;

/**
 * Todos os dados mágicos de UM jogador em UM mundo. Cada sistema terá o seu bloco aqui, adicionado
 * quando o sistema for implementado (sem campos "reservados" que não fazem nada).
 * Hoje: afinidade (E2), canais de mana: mana atual, nível e XP (E3), marcas gravadas (E6b) e treinamento (E7a).
 * O campo "version" permite migrar o formato salvo no futuro.
 */
public final class PlayerMagicData {
	public static final int CURRENT_VERSION = 4;

	public static final Codec<PlayerMagicData> CODEC = RecordCodecBuilder.create(instance -> instance.group(
			Codec.INT.optionalFieldOf("version", CURRENT_VERSION).forGetter(d -> d.version),
			Codec.INT.optionalFieldOf("affinity", -1).forGetter(d -> d.affinityId),
			Codec.INT.optionalFieldOf("channel_level", 1).forGetter(d -> d.channelLevel),
			Codec.INT.optionalFieldOf("channel_xp", 0).forGetter(d -> d.channelXp),
			Codec.INT.optionalFieldOf("mana", -1).forGetter(d -> d.mana),
			Codec.INT.listOf().optionalFieldOf("inscriptions", List.of()).forGetter(d -> d.inscriptions),
			Codec.INT.listOf().optionalFieldOf("training_levels", List.of()).forGetter(d -> toList(d.trainingLevels)),
			Codec.INT.listOf().optionalFieldOf("training_xp", List.of()).forGetter(d -> toList(d.trainingXp)),
			Codec.INT.optionalFieldOf("training_focus", TrainingAttribute.STRENGTH.id()).forGetter(d -> d.trainingFocus)
	).apply(instance, PlayerMagicData::new));

	private int version;
	private int affinityId;
	private int channelLevel;
	private int channelXp;
	/** -1 = nunca inicializada (jogador novo começa com a mana cheia). */
	private int mana;
	/** Marcas gravadas (ids de Inscription), no máximo Inscription.SLOTS, sem repetição. */
	private List<Integer> inscriptions;
	/** Nível (0..10) e XP de cada atributo de treino, indexados por TrainingAttribute.id(). */
	private int[] trainingLevels;
	private int[] trainingXp;
	/** Atributo que o Poste de Treino exercita (escolhido no Hub). */
	private int trainingFocus;

	public PlayerMagicData() {
		this(CURRENT_VERSION, -1, 1, 0, -1, List.of(), List.of(), List.of(), TrainingAttribute.STRENGTH.id());
	}

	private PlayerMagicData(int version, int affinityId, int channelLevel, int channelXp, int mana, List<Integer> inscriptions,
			List<Integer> trainingLevels, List<Integer> trainingXp, int trainingFocus) {
		// dados salvos na versão anterior continuam válidos: campos ausentes recebem o padrão
		this.version = CURRENT_VERSION;
		// dados corrompidos ou de versão futura nunca produzem valores inválidos
		this.affinityId = AffinityRules.normalizeId(affinityId);
		this.channelLevel = ChannelModel.clampLevel(channelLevel);
		this.channelXp = Math.max(0, channelXp);
		this.mana = mana < 0 ? ChannelModel.maxMana(this.channelLevel) : ChannelModel.clampMana(mana, this.channelLevel);
		this.inscriptions = new ArrayList<>(InscriptionRules.sanitize(inscriptions));
		this.trainingLevels = TrainingModel.sanitizeLevels(trainingLevels);
		this.trainingXp = TrainingModel.sanitizeXp(trainingXp, this.trainingLevels);
		this.trainingFocus = TrainingAttribute.fromId(trainingFocus) == null ? TrainingAttribute.STRENGTH.id() : trainingFocus;
	}

	private static List<Integer> toList(int[] values) {
		List<Integer> out = new ArrayList<>();
		for (int v : values) {
			out.add(v);
		}
		return out;
	}

	// ---- treinamento (Sistema 6) ----

	public int trainingLevel(TrainingAttribute a) {
		return trainingLevels[a.id()];
	}

	public int trainingXp(TrainingAttribute a) {
		return trainingXp[a.id()];
	}

	/** Cópia dos níveis, indexada por TrainingAttribute.id(). */
	public int[] trainingLevels() {
		return trainingLevels.clone();
	}

	public int[] trainingXpValues() {
		return trainingXp.clone();
	}

	public TrainingAttribute trainingFocus() {
		return TrainingAttribute.fromId(trainingFocus);
	}

	public void setTrainingFocus(TrainingAttribute a) {
		if (a != null) {
			this.trainingFocus = a.id();
		}
	}

	/** Soma XP ao atributo respeitando o teto dado pelo nível dos canais. @return true se o nível subiu. */
	public boolean addTrainingXp(TrainingAttribute a, int gained) {
		int cap = TrainingModel.levelCap(channelLevel);
		int[] r = TrainingModel.applyXp(trainingLevels[a.id()], trainingXp[a.id()], gained, cap);
		boolean up = r[0] > trainingLevels[a.id()];
		trainingLevels[a.id()] = r[0];
		trainingXp[a.id()] = r[1];
		return up;
	}

	/** Teto atual dos atributos (depende do nível dos canais). */
	public int trainingCap() {
		return TrainingModel.levelCap(channelLevel);
	}

	/** @return a afinidade escolhida, ou null se o jogador ainda não escolheu. */
	public Affinity affinity() {
		return Affinity.fromId(affinityId);
	}

	public int affinityId() {
		return affinityId;
	}

	/** Uso interno do MagicGate. Passe null para limpar (somente reset administrativo). */
	public void setAffinity(Affinity affinity) {
		this.affinityId = affinity == null ? -1 : affinity.id();
	}

	public int channelLevel() {
		return channelLevel;
	}

	public int channelXp() {
		return channelXp;
	}

	/** Cópia das marcas gravadas. */
	public List<Integer> inscriptions() {
		return new ArrayList<>(inscriptions);
	}

	public int inscriptionMask() {
		return InscriptionRules.toMask(inscriptions);
	}

	/** Uso interno do InscriptionService (que já validou tudo). */
	public void addInscription(int id) {
		if (!inscriptions.contains(id)) {
			inscriptions.add(id);
			inscriptions = new ArrayList<>(InscriptionRules.sanitize(inscriptions));
		}
	}

	public void removeInscription(int id) {
		inscriptions.remove(Integer.valueOf(id));
	}

	public int mana() {
		return mana;
	}

	public int maxMana() {
		return ChannelModel.maxMana(channelLevel);
	}

	public void setMana(int value) {
		this.mana = ChannelModel.clampMana(value, channelLevel);
	}

	/** Somente comando de teste: define o nível, zera o XP e enche a mana. */
	public void setChannelLevel(int level) {
		this.channelLevel = ChannelModel.clampLevel(level);
		this.channelXp = 0;
		this.mana = ChannelModel.maxMana(this.channelLevel);
	}

	/** Soma XP dos canais; @return true se o nível subiu. */
	public boolean addChannelXp(int gained) {
		int[] r = ChannelModel.applyXp(channelLevel, channelXp, gained);
		boolean up = r[0] > channelLevel;
		channelLevel = r[0];
		channelXp = r[1];
		return up;
	}
}
