package com.rezero.mod.net;

import com.rezero.mod.ReZeroMod;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Servidor -> cliente: raça escolhida, tempo restante da forma e da recarga (só para exibição). */
public record RaceSyncPayload(int raceId, int formTicks, int cooldownTicks) implements CustomPayload {
	public static final CustomPayload.Id<RaceSyncPayload> ID =
			new CustomPayload.Id<>(Identifier.of(ReZeroMod.MOD_ID, "race_sync"));

	public static final PacketCodec<RegistryByteBuf, RaceSyncPayload> CODEC =
			PacketCodec.tuple(PacketCodecs.VAR_INT, RaceSyncPayload::raceId, PacketCodecs.VAR_INT, RaceSyncPayload::formTicks, PacketCodecs.VAR_INT, RaceSyncPayload::cooldownTicks, RaceSyncPayload::new);

	@Override
	public CustomPayload.Id<? extends CustomPayload> getId() {
		return ID;
	}
}
