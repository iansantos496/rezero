package com.rezero.mod.net;

import com.rezero.mod.ReZeroMod;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/**
 * Cliente -> servidor: um PEDIDO sobre o espírito. action 0 = manifestar/dispensar, 1 = habilidade ativa, 2 = romper o contrato.
 * O servidor valida tudo (contrato, mana, vínculo, recarga).
 */
public record SpiritActionPayload(int action) implements CustomPayload {
	public static final int TOGGLE = 0;
	public static final int ACTIVE = 1;
	public static final int RELEASE = 2;

	public static final CustomPayload.Id<SpiritActionPayload> ID =
			new CustomPayload.Id<>(Identifier.of(ReZeroMod.MOD_ID, "spirit_action"));

	public static final PacketCodec<RegistryByteBuf, SpiritActionPayload> CODEC = PacketCodec.tuple(
			PacketCodecs.VAR_INT, SpiritActionPayload::action,
			SpiritActionPayload::new);

	@Override
	public CustomPayload.Id<? extends CustomPayload> getId() {
		return ID;
	}
}
