package com.rezero.mod.server;

import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;

/** Eventos do servidor que mantêm o cliente sincronizado. */
public final class ServerEvents {
	private ServerEvents() {}

	public static void init() {
		// ao entrar no mundo: o cliente recebe os dados reais daquele jogador naquele mundo;
		// sem afinidade escolhida, a tela obrigatória é aberta (reenviada a cada entrada até escolher)
		ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
			SpellService.reset(handler.getPlayer());
			PlayerSync.send(handler.getPlayer());
			TrainingService.reset(handler.getPlayer(), false);
			RaceService.reset(handler.getPlayer());
			ProtectionService.reset(handler.getPlayer());
			TransformService.reset(handler.getPlayer());
			CombatService.reset(handler.getPlayer());
			SpiritService.reset(handler.getPlayer());
			MagicGate.promptAffinityIfNeeded(handler.getPlayer(), 0);
		});

		// ao renascer: os dados são copiados na morte; reenvia para o novo corpo do jogador
		ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> {
			SpellService.reset(newPlayer);
			PlayerSync.send(newPlayer);
			TrainingService.reset(newPlayer, true);
			RaceService.reset(newPlayer);
			ProtectionService.reset(newPlayer);
			TransformService.reset(newPlayer);
			CombatService.reset(newPlayer);
			SpiritService.reset(newPlayer);
		});
	}
}
