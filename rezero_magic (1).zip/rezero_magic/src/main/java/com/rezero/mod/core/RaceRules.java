package com.rezero.mod.core;

/**
 * Regras das raças (Sistema 7), em código puro e testado fora do jogo.
 *
 * CANON (verificado em páginas da Otapedia de Re:Zero): existem humanos, meio-elfos, demi-humanos (que podem se transformar parcial ou
 * totalmente em fera e têm físico superior) e oni (o chifre reúne mana do ambiente e a "Forma Oni" aumenta a força física).
 * Também é canon que um demi-humano transformado perde o juízo ("age sem razão") — a base da limitação da Forma Bestial.
 * TODOS os números, vantagens e limitações abaixo são ADAPTAÇÃO de jogo (a obra não tem atributos numéricos de raça).
 * Nenhuma raça é superior: cada uma troca algo (vida, custo de mana, exaustão) pelo que ganha.
 */
public final class RaceRules {
	/** Duração da Forma Bestial / Forma Oni (20 s). */
	public static final int FORM_TICKS = 400;
	public static final int DEMI_COOLDOWN_TICKS = 1800;
	public static final int ONI_COOLDOWN_TICKS = 2400;
	/** Depois da Forma Oni o jogador fica exausto (10 s). */
	public static final int ONI_EXHAUST_TICKS = 200;
	/** Regeneração de mana extra durante a Forma Oni (o chifre reúne mana do ambiente), em %. */
	public static final int ONI_FORM_REGEN_PCT = 50;

	public enum ActiveResult { OK, NO_ABILITY, ALREADY_ACTIVE, ON_COOLDOWN }

	private RaceRules() {}

	/** A escolha só é aceita se o pedido for válido e o jogador ainda não tiver raça (única vez). */
	public static boolean canChoose(Race current, Race wanted) {
		return current == null && wanted != null;
	}

	public static int normalizeId(int id) {
		return Race.fromId(id) == null ? -1 : id;
	}

	/** Vida máxima extra em pontos (2 pontos = 1 coração). Pode ser negativa. */
	public static double maxHealthBonus(Race race) {
		if (race == null) {
			return 0.0;
		}
		return switch (race) {
			case HUMAN -> 0.0;
			case HALF_ELF -> -2.0;
			case DEMI_HUMAN -> 4.0;
			case ONI -> 2.0;
		};
	}

	public static double attackBonus(Race race) {
		if (race == null) {
			return 0.0;
		}
		return switch (race) {
			case DEMI_HUMAN, ONI -> 0.5;
			default -> 0.0;
		};
	}

	/** Fração da velocidade base (0,03 = +3%). */
	public static double speedFraction(Race race) {
		return race == Race.DEMI_HUMAN ? 0.03 : 0.0;
	}

	/** Bônus (%) de XP de treino para um atributo. */
	public static int trainingXpPct(Race race, TrainingAttribute attribute) {
		if (race == null || attribute == null) {
			return 0;
		}
		return switch (race) {
			case HUMAN -> 10;
			case HALF_ELF -> attribute == TrainingAttribute.FOCUS ? 20 : 0;
			case DEMI_HUMAN -> attribute == TrainingAttribute.VIGOR || attribute == TrainingAttribute.STRENGTH ? 20 : 0;
			case ONI -> attribute == TrainingAttribute.STRENGTH || attribute == TrainingAttribute.CONTROL ? 20 : 0;
		};
	}

	/** XP de treino já com o bônus racial (nunca menos que o original; arredonda para cima). */
	public static int trainingXp(Race race, TrainingAttribute attribute, int xp) {
		if (xp <= 0) {
			return 0;
		}
		return (xp * (100 + trainingXpPct(race, attribute)) + 99) / 100;
	}

	/** Bônus (%) de XP de vínculo com o espírito. */
	public static int spiritBondXpPct(Race race) {
		return race == Race.HALF_ELF ? 25 : 0;
	}

	public static int spiritBondXp(Race race, int xp) {
		if (xp <= 0) {
			return 0;
		}
		return (xp * (100 + spiritBondXpPct(race)) + 99) / 100;
	}

	/**
	 * Efeitos da raça sobre o cálculo de magia: {potência%, redução de custo%, redução de carga%, regeneração%}.
	 * A redução de custo pode ser negativa (a raça gasta mais mana).
	 */
	public static int[] castPcts(Race race, boolean formActive) {
		if (race == null) {
			return new int[] {0, 0, 0, 0};
		}
		return switch (race) {
			case HUMAN -> new int[] {0, 0, 0, 0};
			case HALF_ELF -> new int[] {0, 0, 0, 10};
			case DEMI_HUMAN -> new int[] {0, -15, 0, 0};
			case ONI -> new int[] {0, 0, 0, 15 + (formActive ? ONI_FORM_REGEN_PCT : 0)};
		};
	}

	/** Só demi-humanos e oni têm habilidade ativa (transformação); humano e meio-elfo têm só passivas. */
	public static boolean hasActive(Race race) {
		return race == Race.DEMI_HUMAN || race == Race.ONI;
	}

	public static int cooldownTicks(Race race) {
		return race == Race.ONI ? ONI_COOLDOWN_TICKS : DEMI_COOLDOWN_TICKS;
	}

	/** Limitação canon da Forma Bestial: transformado, o demi-humano age por instinto e não conjura. */
	public static boolean blocksCasting(Race race, boolean formActive) {
		return race == Race.DEMI_HUMAN && formActive;
	}

	public static ActiveResult checkActive(Race race, boolean formActive, int cooldownLeft) {
		if (!hasActive(race)) {
			return ActiveResult.NO_ABILITY;
		}
		if (formActive) {
			return ActiveResult.ALREADY_ACTIVE;
		}
		if (cooldownLeft > 0) {
			return ActiveResult.ON_COOLDOWN;
		}
		return ActiveResult.OK;
	}
}
