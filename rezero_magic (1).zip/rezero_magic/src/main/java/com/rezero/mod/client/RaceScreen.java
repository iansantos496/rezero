package com.rezero.mod.client;

import com.rezero.mod.core.Race;
import com.rezero.mod.net.ChooseRacePayload;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;

/**
 * Tela OBRIGATÓRIA de escolha de raça (única vez). Não fecha com ESC; fecha quando o servidor confirma (ver ReZeroModClient).
 * Só envia um PEDIDO: quem valida é o servidor. Fluxo: escolher uma raça -> "Escolher" -> "Tem certeza?" -> "Sim, confirmar".
 */
public class RaceScreen extends Screen {
	private final Race selected;
	private final boolean confirming;
	private int left;
	private int top;
	private int panelW;
	private int panelH;

	public RaceScreen() {
		this(null, false);
	}

	private RaceScreen(Race selected, boolean confirming) {
		super(Text.translatable("screen.rezero_magic.race.title"));
		this.selected = selected;
		this.confirming = confirming;
	}

	@Override
	public boolean shouldCloseOnEsc() {
		return false;
	}

	@Override
	public boolean shouldPause() {
		// Sem pausar, o servidor integrado continua processando o pedido de escolha.
		return false;
	}

	@Override
	protected void init() {
		panelW = Math.min(width - 16, 400);
		panelH = Math.min(height - 16, 250);
		left = (width - panelW) / 2;
		top = (height - panelH) / 2;

		addDrawable(this::drawContent);

		if (confirming && selected != null) {
			int bw = Math.min(150, (panelW - 30) / 2);
			addDrawableChild(ButtonWidget.builder(Text.translatable("screen.rezero_magic.race.confirm_yes"),
					b -> ClientPlayNetworking.send(new ChooseRacePayload(selected.id())))
					.dimensions(left + panelW / 2 - bw - 5, top + panelH - 34, bw, 20).build());
			addDrawableChild(ButtonWidget.builder(Text.translatable("screen.rezero_magic.race.confirm_back"),
					b -> MinecraftClient.getInstance().setScreen(new RaceScreen(selected, false)))
					.dimensions(left + panelW / 2 + 5, top + panelH - 34, bw, 20).build());
			return;
		}

		Race[] all = Race.values();
		int gap = 6;
		int bw = (panelW - 20 - (all.length - 1) * gap) / all.length;
		for (int i = 0; i < all.length; i++) {
			final Race race = all[i];
			Text name = Text.translatable("race.rezero_magic." + race.key());
			Text label = race == selected ? Text.literal("> ").append(name).append(Text.literal(" <")) : name;
			addDrawableChild(ButtonWidget.builder(label, b -> MinecraftClient.getInstance().setScreen(new RaceScreen(race, false)))
					.dimensions(left + 10 + i * (bw + gap), top + 30, bw, 20).build());
		}
		ButtonWidget choose = ButtonWidget.builder(Text.translatable("screen.rezero_magic.race.choose"),
				b -> MinecraftClient.getInstance().setScreen(new RaceScreen(selected, true)))
				.dimensions(left + panelW / 2 - 70, top + panelH - 30, 140, 20).build();
		choose.active = selected != null;
		addDrawableChild(choose);
	}

	private void drawContent(DrawContext c, int mouseX, int mouseY, float delta) {
		c.fill(left - 2, top - 2, left + panelW + 2, top + panelH + 2, 0xFF000000);
		c.fill(left, top, left + panelW, top + panelH, 0xEE1B1530);
		Text title = Text.translatable("screen.rezero_magic.race.title");
		c.drawTextWithShadow(textRenderer, title, left + (panelW - textRenderer.getWidth(title)) / 2, top + 10, 0xFFFFD34D);

		if (selected == null) {
			wrap(c, Text.translatable("screen.rezero_magic.race.intro"), left + 14, top + 62, panelW - 28, 0xFFDADAEA);
			return;
		}
		String k = selected.key();
		Text name = Text.translatable("race.rezero_magic." + k);
		if (confirming) {
			c.drawTextWithShadow(textRenderer, name, left + 14, top + 34, 0xFFFFD34D);
			wrap(c, Text.translatable("screen.rezero_magic.race.confirm_text", name), left + 14, top + 52, panelW - 28, 0xFFFFFFFF);
			return;
		}
		int w = panelW - 28;
		int y = top + 58;
		c.drawTextWithShadow(textRenderer, name, left + 14, y, 0xFFFFD34D);
		y += 12;
		y = wrap(c, Text.translatable("race.rezero_magic." + k + ".canon"), left + 14, y, w, 0xFFDADAEA);
		y += 3;
		y = wrap(c, Text.translatable("race.rezero_magic." + k + ".pros"), left + 14, y, w, 0xFF7CFF9A);
		y = wrap(c, Text.translatable("race.rezero_magic." + k + ".cons"), left + 14, y, w, 0xFFFF9A6E);
		wrap(c, Text.translatable("race.rezero_magic." + k + ".ability"), left + 14, y, w, 0xFFFFFFFF);
	}

	/** Quebra o texto na largura dada; devolve o próximo y livre. */
	private int wrap(DrawContext c, Text t, int x, int y, int maxWidth, int color) {
		for (OrderedText line : textRenderer.wrapLines(t, maxWidth)) {
			c.drawTextWithShadow(textRenderer, line, x, y, color);
			y += 10;
		}
		return y;
	}
}
