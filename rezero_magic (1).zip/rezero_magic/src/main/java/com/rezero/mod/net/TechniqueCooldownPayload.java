package com.rezero.mod.net;

import com.rezero.mod.ReZeroMod;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Servidor -> cliente: a técnica {@code techniqueId} entrou em recarga por {@code ticks} (id -1 = esquiva). Só para mostrar na tela. */
public record TechniqueCooldownPayload(int techniqueId, int ticks) implements CustomPayload {
	public static final CustomPayload.Id<TechniqueCooldownPayload> ID =
			new CustomPayload.Id<>(Identifier.of(ReZeroMod.MOD_ID, "technique_cooldown"));

	public static final PacketCodec<RegistryByteBuf, TechniqueCooldownPayload> CODEC = PacketCodec.tuple(
			PacketCodecs.VAR_INT, TechniqueCooldownPayload::techniqueId,
			PacketCodecs.VAR_INT, TechniqueCooldownPayload::ticks,
			TechniqueCooldownPayload::new);

	@Override
	public CustomPayload.Id<? extends CustomPayload> getId() {
		return ID;
	}
}
