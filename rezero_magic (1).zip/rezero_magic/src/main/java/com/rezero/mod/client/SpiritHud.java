package com.rezero.mod.client;

import com.rezero.mod.core.Affinity;
import com.rezero.mod.core.SpiritRules;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

/** HUD do espírito (canto superior direito): quem é, vínculo, se está manifestado e a habilidade ativa. Só aparece com contrato. */
public final class SpiritHud {
	private SpiritHud() {}

	public static void render(DrawContext context) {
		MinecraftClient client = MinecraftClient.getInstance();
		Affinity element = ClientPlayerData.spirit();
		if (client.player == null || client.options.hudHidden || element == null) {
			return;
		}
		int x = client.getWindow().getScaledWidth() - 150;
		int y = 10;
		context.drawTextWithShadow(client.textRenderer, Text.translatable("hud.rezero_magic.spirit",
				Text.translatable("spirit.rezero_magic." + element.key()), ClientPlayerData.bondLevel()), x, y, 0xFFB8D8FF);
		boolean summoned = ClientPlayerData.spiritSummoned();
		context.drawTextWithShadow(client.textRenderer, Text.translatable(
				summoned ? "hud.rezero_magic.spirit_on" : "hud.rezero_magic.spirit_off", ReZeroModClient.spiritKeyName(0)),
				x, y + 11, summoned ? 0xFF7CFF9A : 0xFFAAAAAA);
		if (SpiritRules.activeUnlocked(ClientPlayerData.bondLevel())) {
			int cd = ClientPlayerData.spiritCooldownLeft();
			Text line = cd > 0
					? Text.translatable("hud.rezero_magic.spirit_active_cd", ReZeroModClient.spiritKeyName(1), String.format("%.0f", cd / 20.0))
					: Text.translatable("hud.rezero_magic.spirit_active", ReZeroModClient.spiritKeyName(1));
			context.drawTextWithShadow(client.textRenderer, line, x, y + 22, cd > 0 || !summoned ? 0xFFAAAAAA : 0xFFFFFFFF);
		}
	}
}
