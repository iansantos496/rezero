package com.rezero.mod.net;

import com.rezero.mod.ReZeroMod;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Cliente -> servidor: receber uma proteção (CLAIM, arg = id) ou usar a ativa (ACTIVE). Só pedidos; o servidor valida. */
public record ProtectionActionPayload(int action, int arg) implements CustomPayload {
	public static final CustomPayload.Id<ProtectionActionPayload> ID =
			new CustomPayload.Id<>(Identifier.of(ReZeroMod.MOD_ID, "protection_action"));

	public static final PacketCodec<RegistryByteBuf, ProtectionActionPayload> CODEC = PacketCodec.tuple(
			PacketCodecs.VAR_INT, ProtectionActionPayload::action,
			PacketCodecs.VAR_INT, ProtectionActionPayload::arg,
			ProtectionActionPayload::new);
	public static final int CLAIM = 0;
	public static final int ACTIVE = 1;

	@Override
	public CustomPayload.Id<? extends CustomPayload> getId() {
		return ID;
	}
}
