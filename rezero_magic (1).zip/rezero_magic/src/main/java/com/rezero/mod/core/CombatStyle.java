package com.rezero.mod.core;

/**
 * Estilos de luta (Sistema 9). O estilo vem da arma na mão principal. Os nomes são de jogo (adaptação).
 * Os ids NUNCA devem mudar.
 */
public enum CombatStyle {
	SWORD(0, "sword"),
	SPEAR(1, "spear"),
	DAGGER(2, "dagger"),
	UNARMED(3, "unarmed"),
	BOW(4, "bow");

	private final int id;
	private final String key;

	CombatStyle(int id, String key) {
		this.id = id;
		this.key = key;
	}

	public int id() {
		return id;
	}

	public String key() {
		return key;
	}

	public static CombatStyle fromId(int id) {
		for (CombatStyle s : values()) {
			if (s.id == id) {
				return s;
			}
		}
		return null;
	}
}
