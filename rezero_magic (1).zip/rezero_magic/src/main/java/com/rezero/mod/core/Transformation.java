package com.rezero.mod.core;

/**
 * Transformações e estados especiais (Sistema 11). Só uma pode estar ativa por vez.
 * As duas raciais (Forma Bestial e Forma Oni) vêm do Sistema 7; Sintonia Elemental e Último Fôlego são deste sistema.
 * Os ids não são salvos (o estado é temporário), mas mantenha a ordem: a interface usa-a.
 */
public enum Transformation {
	BEAST(0, "beast", Kind.RACIAL),
	ONI(1, "oni", Kind.RACIAL),
	ATTUNEMENT(2, "attunement", Kind.SPIRIT),
	LAST_STAND(3, "last_stand", Kind.EMERGENCY);

	public enum Kind { RACIAL, SPIRIT, EMERGENCY }

	private final int id;
	private final String key;
	private final Kind kind;

	Transformation(int id, String key, Kind kind) {
		this.id = id;
		this.key = key;
		this.kind = kind;
	}

	public int id() {
		return id;
	}

	public String key() {
		return key;
	}

	public Kind kind() {
		return kind;
	}

	/** As duas formas ativadas neste sistema (não raciais). */
	public boolean selfActivated() {
		return kind != Kind.RACIAL;
	}

	public static Transformation fromId(int id) {
		for (Transformation t : values()) {
			if (t.id == id) {
				return t;
			}
		}
		return null;
	}
}
