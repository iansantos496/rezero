package com.rezero.mod.server;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.rezero.mod.ModConfig;
import com.rezero.mod.core.ChannelModel;
import com.rezero.mod.core.SpiritRules;
import com.rezero.mod.core.TrainingModel;

import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

/**
 * Comandos administrativos SÓ para testes (todos afetam apenas o jogador que executa):
 * /rezero admin resetar_afinidade | resetar_raca | resetar_bencaos | nivel_canais <1-20> | nivel_treino <0-10> | vinculo <1-5>
 * Ficam DESLIGADOS por padrão (config/rezero_magic.properties: allowAdminReset=false). Não existe troca de afinidade nem de raça
 * no jogo normal.
 * Pendência conhecida: checar também permissão de operador (a API de permissões mudou na 1.21.9
 * e eu não consegui confirmar os nomes sem compilar). Até lá, a trava é a configuração.
 */
public final class AdminCommands {
	private AdminCommands() {}

	/** Uma ação de teste sobre o jogador; devolve false se não pôde ser aplicada. */
	private interface Action {
		boolean apply(ServerPlayerEntity player);
	}

	private static int run(CommandContext<ServerCommandSource> ctx, Action action, Text done, String failKey) {
		ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
		if (!ModConfig.allowAdminReset()) {
			ctx.getSource().sendError(Text.translatable("message.rezero_magic.admin_reset_disabled"));
			return 0;
		}
		if (!action.apply(player)) {
			ctx.getSource().sendError(Text.translatable(failKey));
			return 0;
		}
		ctx.getSource().sendFeedback(() -> done, false);
		return 1;
	}

	public static void init() {
		CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
				dispatcher.register(CommandManager.literal("rezero")
						.then(CommandManager.literal("admin")
								.then(CommandManager.literal("resetar_afinidade")
										.executes(ctx -> run(ctx, p -> {
											MagicGate.adminResetAffinity(p);
											return true;
										}, Text.translatable("message.rezero_magic.admin_reset_done"), "message.rezero_magic.admin_reset_disabled")))
								.then(CommandManager.literal("resetar_raca")
										.executes(ctx -> run(ctx, p -> {
											RaceService.adminReset(p);
											return true;
										}, Text.translatable("message.rezero_magic.admin_race_done"), "message.rezero_magic.admin_reset_disabled")))
								.then(CommandManager.literal("resetar_bencaos")
										.executes(ctx -> run(ctx, p -> {
											ProtectionService.adminReset(p);
											return true;
										}, Text.translatable("message.rezero_magic.admin_protections_done"), "message.rezero_magic.admin_reset_disabled")))
								.then(CommandManager.literal("nivel_canais")
										.then(CommandManager.argument("nivel", IntegerArgumentType.integer(1, ChannelModel.MAX_LEVEL))
												.executes(ctx -> {
													int level = IntegerArgumentType.getInteger(ctx, "nivel");
													return run(ctx, p -> {
														MagicGate.adminSetChannelLevel(p, level);
														return true;
													}, Text.translatable("message.rezero_magic.admin_level_done", level), "message.rezero_magic.admin_reset_disabled");
												})))
								.then(CommandManager.literal("nivel_treino")
										.then(CommandManager.argument("nivel", IntegerArgumentType.integer(0, TrainingModel.MAX_LEVEL))
												.executes(ctx -> {
													int level = IntegerArgumentType.getInteger(ctx, "nivel");
													return run(ctx, p -> {
														TrainingService.adminSetLevels(p, level);
														return true;
													}, Text.translatable("message.rezero_magic.admin_training_done", level), "message.rezero_magic.admin_reset_disabled");
												})))
								.then(CommandManager.literal("vinculo")
										.then(CommandManager.argument("nivel", IntegerArgumentType.integer(1, SpiritRules.MAX_BOND))
												.executes(ctx -> {
													int bond = IntegerArgumentType.getInteger(ctx, "nivel");
													return run(ctx, p -> SpiritService.adminSetBond(p, bond),
															Text.translatable("message.rezero_magic.admin_bond_done", bond), "message.rezero_magic.admin_no_spirit");
												}))))));
	}
}
