package com.rezero.mod.content;

import com.rezero.mod.server.TrainingService;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.ActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/**
 * Poste de Treino: cada clique direito é uma repetição de treino do atributo escolhido no Hub (aba Treino).
 * Quem decide tudo (comida, fadiga, teto, XP) é o servidor, no TrainingService.
 */
public class TrainingPostBlock extends Block {
	public TrainingPostBlock(Settings settings) {
		super(settings);
	}

	@Override
	public ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, BlockHitResult hit) {
		if (world instanceof ServerWorld serverWorld && player instanceof ServerPlayerEntity serverPlayer) {
			TrainingService.rep(serverWorld, serverPlayer, pos);
		}
		return ActionResult.SUCCESS;
	}
}
