package com.rezero.mod.server;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import com.rezero.mod.core.Transformation;
import com.rezero.mod.core.TransformationRules;
import com.rezero.mod.core.TrainingAttribute;
import com.rezero.mod.data.PlayerDataStore;
import com.rezero.mod.data.PlayerMagicData;
import com.rezero.mod.net.TransformSyncPayload;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;

/**
 * Transformações e estados especiais (Sistema 11) no servidor: Sintonia Elemental (espírito) e Último Fôlego (emergência).
 * As transformações raciais continuam no RaceService; aqui vale a regra de UMA por vez e a soma dos efeitos na magia.
 * Regras e números em TransformationRules (testadas fora do jogo). O estado não é salvo: ao entrar ou renascer tudo volta desligado.
 */
public final class TransformService {
	private static final int PULSE_PERIOD = 10;
	private static final int SYNC_PERIOD = 20;

	private static final class Runtime {
		/** Forma ativa deste sistema (Transformation.id), ou -1. */
		int active = -1;
		int left;
		int cdAttune;
		int cdStand;
		boolean dirty;
	}

	private static final Map<UUID, Runtime> STATE = new HashMap<>();

	private TransformService() {}

	public static void init() {
		ServerTickEvents.END_SERVER_TICK.register(TransformService::tick);
		ServerLifecycleEvents.SERVER_STOPPED.register(stopped -> STATE.clear());
	}

	private static Runtime runtime(ServerPlayerEntity player) {
		return STATE.computeIfAbsent(player.getUuid(), k -> new Runtime());
	}

	public static void reset(ServerPlayerEntity player) {
		STATE.put(player.getUuid(), new Runtime());
		sync(player);
	}

	// ------------------------------------------------------------------ consultas (servidor)

	/** Há uma forma DESTE sistema ativa? (A racial é consultada no RaceService.) */
	public static boolean isActive(ServerPlayerEntity player) {
		Runtime rt = STATE.get(player.getUuid());
		return rt != null && rt.active >= 0;
	}

	/** Efeitos sobre a magia: raça (inclui a forma racial) + forma ativa deste sistema. */
	public static int[] castPcts(ServerPlayerEntity player) {
		Runtime rt = STATE.get(player.getUuid());
		Transformation active = rt == null ? null : Transformation.fromId(rt.active);
		return TransformationRules.sum(RaceService.castPcts(player), TransformationRules.castPcts(active));
	}

	// ------------------------------------------------------------------ ativar

	public static void request(MinecraftServer current, ServerPlayerEntity player, int action) {
		if (!player.isAlive()) {
			return;
		}
		Transformation form = Transformation.fromId(action);
		Runtime rt = runtime(player);
		PlayerMagicData data = PlayerDataStore.get(player);
		int cooldown = form == Transformation.LAST_STAND ? rt.cdStand : rt.cdAttune;
		TransformationRules.Context ctx = new TransformationRules.Context(rt.active >= 0 || RaceService.formActive(player), cooldown,
				data.channelLevel(), data.mana(), data.spirit() != null ? data.bondLevel() : 0, SpiritService.isSummoned(player),
				player.getHealth(), player.getMaxHealth(), data.trainingLevel(TrainingAttribute.VIGOR));
		TransformationRules.Result result = TransformationRules.check(form, ctx);
		if (result != TransformationRules.Result.OK) {
			if (result != TransformationRules.Result.NOT_SELF_ACTIVATED) {
				message(player, "transform.fail_" + result.name().toLowerCase());
			}
			return;
		}
		int mana = TransformationRules.manaCost(form);
		if (mana > 0) {
			data.setMana(data.mana() - mana);
			PlayerDataStore.save(player, data);
		}
		rt.active = form.id();
		rt.left = TransformationRules.durationTicks(form);
		rt.dirty = true;
		SpellService.reset(player);
		if (form == Transformation.ATTUNEMENT) {
			player.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, rt.left, 0));
		} else {
			player.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, rt.left, 1));
			player.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, rt.left, 0));
		}
		ServerWorld world = WorldLookup.of(current, player);
		if (world != null) {
			world.spawnParticles(form == Transformation.ATTUNEMENT ? ParticleTypes.ENCHANT : ParticleTypes.CRIT,
					player.getX(), player.getY() + 1.0, player.getZ(), 40, 0.7, 0.9, 0.7, 0.1);
			SpellEffects.sound(world, player.getX(), player.getY(), player.getZ(), SoundEvents.ENTITY_PLAYER_LEVELUP, 0.8f, 0.7f);
		}
		message(player, "transform.start_" + form.key());
		sync(player);
	}

	private static void end(ServerPlayerEntity player, Runtime rt) {
		Transformation form = Transformation.fromId(rt.active);
		rt.active = -1;
		rt.left = 0;
		rt.dirty = true;
		if (form == Transformation.ATTUNEMENT) {
			rt.cdAttune = TransformationRules.cooldownTicks(form);
			PlayerMagicData data = PlayerDataStore.get(player);
			data.setMana(TransformationRules.manaAfterAttunement(data.mana(), data.channelLevel()));
			PlayerDataStore.save(player, data);
			player.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, TransformationRules.ATTUNE_WEAK_TICKS, 0));
		} else if (form == Transformation.LAST_STAND) {
			rt.cdStand = TransformationRules.cooldownTicks(form);
			player.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, TransformationRules.LAST_STAND_EXHAUST_TICKS, 0));
			player.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, TransformationRules.LAST_STAND_EXHAUST_TICKS, 0));
		}
		if (form != null) {
			message(player, "transform.end_" + form.key());
		}
		sync(player);
	}

	private static void tick(MinecraftServer current) {
		int ticks = current.getTicks();
		boolean pulse = ticks % PULSE_PERIOD == 0;
		boolean periodic = ticks % SYNC_PERIOD == 0;
		for (ServerPlayerEntity player : current.getPlayerManager().getPlayerList()) {
			Runtime rt = STATE.get(player.getUuid());
			if (rt == null || !player.isAlive()) {
				continue;
			}
			if (rt.active >= 0) {
				if (--rt.left <= 0) {
					end(player, rt);
					continue;
				}
				if (pulse) {
					ServerWorld world = WorldLookup.of(current, player);
					if (world != null) {
						world.spawnParticles(rt.active == Transformation.ATTUNEMENT.id() ? ParticleTypes.ENCHANT : ParticleTypes.CRIT,
								player.getX(), player.getY() + 1.0, player.getZ(), 6, 0.5, 0.7, 0.5, 0.05);
					}
				}
			}
			if (rt.cdAttune > 0) {
				rt.cdAttune--;
			}
			if (rt.cdStand > 0) {
				rt.cdStand--;
			}
			if (rt.dirty || (periodic && (rt.active >= 0 || rt.cdAttune > 0 || rt.cdStand > 0))) {
				sync(player);
			}
		}
	}

	public static void sync(ServerPlayerEntity player) {
		Runtime rt = runtime(player);
		rt.dirty = false;
		ServerPlayNetworking.send(player, new TransformSyncPayload(rt.active < 0 ? 0 : rt.active + 1, rt.left, rt.cdAttune, rt.cdStand));
	}

	private static void message(ServerPlayerEntity player, String key) {
		player.sendMessage(Text.translatable("message.rezero_magic." + key), true);
	}
}
