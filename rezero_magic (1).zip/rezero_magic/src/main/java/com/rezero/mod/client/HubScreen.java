package com.rezero.mod.client;

import java.util.ArrayList;
import java.util.List;

import com.rezero.mod.core.Affinity;
import com.rezero.mod.content.EquipmentLookup;
import com.rezero.mod.content.ModItems;
import com.rezero.mod.core.CastModifiers;
import com.rezero.mod.core.CombatRules;
import com.rezero.mod.core.CombatStyle;
import com.rezero.mod.core.TechniqueDef;
import com.rezero.mod.core.Techniques;
import com.rezero.mod.core.Catalyst;
import com.rezero.mod.core.ChannelModel;
import com.rezero.mod.core.Charm;
import com.rezero.mod.core.CrystalRarity;
import com.rezero.mod.core.CrystalRules;
import com.rezero.mod.core.Inscription;
import com.rezero.mod.core.RobeSet;
import com.rezero.mod.core.DivineProtection;
import com.rezero.mod.core.ProtectionRules;
import com.rezero.mod.core.SpellDef;
import com.rezero.mod.core.Spells;
import com.rezero.mod.core.SpiritRules;
import com.rezero.mod.core.Transformation;
import com.rezero.mod.core.TransformationRules;
import com.rezero.mod.core.TrainingAttribute;
import com.rezero.mod.core.TrainingModel;
import com.rezero.mod.net.CombatActionPayload;
import com.rezero.mod.net.InscribePayload;
import com.rezero.mod.net.ProtectionActionPayload;
import com.rezero.mod.net.SelectTrainingPayload;
import com.rezero.mod.net.SpiritActionPayload;
import com.rezero.mod.net.TransformActionPayload;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;

/**
 * Hub: interface central do mod. Mostra SOMENTE dados reais enviados pelo servidor.
 * Regra do projeto: um sistema só ganha aba/botão aqui depois de estar implementado.
 * Hoje: aba "Perfil" (jogador e afinidade), "Magias" (canais de mana e feitiços da afinidade) e "Cristais" (inventário) e "Equipamento" (cajado, acessório e vestes em uso) e "Marcas" (inscrições) "Treino" (atributos de treino) "Técnicas" (combate) e "Espírito" (contrato e vínculo).
 */
public class HubScreen extends Screen {
	private static final int ROW_H = 22;
	private static final int TAB_COUNT = 10;
	private static final int MARK_ROW_H = 30;

	private int left;
	private int top;
	private int panelW;
	private int panelH;
	private int tab = 0;
	private final List<ButtonWidget> selectButtons = new ArrayList<>();
	private final List<SpellDef> rowSpells = new ArrayList<>();
	private final List<ButtonWidget> markButtons = new ArrayList<>();
	private final List<ButtonWidget> pageButtons = new ArrayList<>();
	private int markPage = 0;
	private final List<ButtonWidget> trainButtons = new ArrayList<>();
	private final List<ButtonWidget> learnButtons = new ArrayList<>();
	private final List<ButtonWidget> stylePageButtons = new ArrayList<>();
	private int stylePage = 0;
	private final List<ButtonWidget> spiritButtons = new ArrayList<>();
	private final List<ButtonWidget> protectionButtons = new ArrayList<>();
	private int protectionPage = 0;
	private final List<ButtonWidget> transformButtons = new ArrayList<>();
	private int transformPage = 0;
	/** Abas com rolagem: quantas cabem na largura, a primeira visível e os botões. */
	private final List<ButtonWidget> tabButtons = new ArrayList<>();
	private ButtonWidget tabPrev;
	private ButtonWidget tabNext;
	private int tabsVisible = TAB_COUNT;
	private int tabOffset = 0;
	private int tabW = 50;
	private int tabX0 = 0;

	public HubScreen(int initialTab) {
		super(Text.translatable("screen.rezero_magic.hub.title"));
		this.tab = Math.max(0, Math.min(TAB_COUNT - 1, initialTab));
	}

	@Override
	public boolean shouldPause() {
		return false;
	}

	@Override
	protected void init() {
		panelW = Math.min(width - 16, 520);
		panelH = Math.min(height - 16, 250);
		left = (width - panelW) / 2;
		top = (height - panelH) / 2;
		selectButtons.clear();
		rowSpells.clear();
		markButtons.clear();
		pageButtons.clear();
		trainButtons.clear();
		learnButtons.clear();
		stylePageButtons.clear();
		spiritButtons.clear();
		protectionButtons.clear();
		transformButtons.clear();
		tabButtons.clear();

		addDrawable(this::drawContent);

		String[] tabKeys = {"tab_profile", "tab_spells", "tab_crystals", "tab_equipment", "tab_marks", "tab_training", "tab_combat", "tab_spirit", "tab_protection", "tab_forms"};
		// abas com rolagem: se todas cabem com largura mínima, sem setas; senão, setas < > e só algumas visíveis
		int minTabW = 50;
		int arrowW = 14;
		boolean allFit = (panelW - 16) / TAB_COUNT >= minTabW;
		tabsVisible = allFit ? TAB_COUNT : Math.max(1, Math.min(TAB_COUNT, (panelW - 16 - 2 * (arrowW + 1)) / minTabW));
		tabW = allFit ? (panelW - 16) / TAB_COUNT : (panelW - 16 - 2 * (arrowW + 1)) / tabsVisible;
		tabX0 = left + 8 + (allFit ? 0 : arrowW + 1);
		tabOffset = Math.max(0, Math.min(TAB_COUNT - tabsVisible, tabOffset));
		if (tab < tabOffset) {
			tabOffset = tab;
		} else if (tab >= tabOffset + tabsVisible) {
			tabOffset = tab - tabsVisible + 1;
		}
		for (int t = 0; t < TAB_COUNT; t++) {
			final int target = t;
			ButtonWidget tb = ButtonWidget.builder(Text.translatable("screen.rezero_magic.hub." + tabKeys[t]), b -> setTab(target))
					.dimensions(tabX0 + (t - tabOffset) * tabW, top + 26, tabW - 1, 18).build();
			addDrawableChild(tb);
			tabButtons.add(tb);
		}
		tabPrev = ButtonWidget.builder(Text.literal("<"), b -> scrollTabs(-1))
				.dimensions(left + 8, top + 26, arrowW, 18).build();
		tabNext = ButtonWidget.builder(Text.literal(">"), b -> scrollTabs(1))
				.dimensions(left + panelW - 8 - arrowW, top + 26, arrowW, 18).build();
		tabPrev.visible = !allFit;
		tabNext.visible = !allFit;
		addDrawableChild(tabPrev);
		addDrawableChild(tabNext);

		Affinity a = ClientPlayerData.affinity();
		if (a != null) {
			int row = 0;
			for (SpellDef spell : Spells.forAffinity(a)) {
				final SpellDef s = spell;
				ButtonWidget b = ButtonWidget.builder(Text.translatable("screen.rezero_magic.hub.select"),
						btn -> ClientPlayerData.selectSpell(s.id()))
						.dimensions(left + panelW - 84, rowY(row) - 3, 70, 16).build();
				addDrawableChild(b);
				selectButtons.add(b);
				rowSpells.add(s);
				row++;
			}
		}
		// aba Marcas: 3 linhas (uma categoria por página) e botões de página
		for (int row = 0; row < 3; row++) {
			final int r = row;
			ButtonWidget b = ButtonWidget.builder(Text.translatable("screen.rezero_magic.hub.engrave"), btn -> onMarkClick(r))
					.dimensions(left + panelW - 84, markY(row) - 2, 70, 16).build();
			addDrawableChild(b);
			markButtons.add(b);
		}
		ButtonWidget prev = ButtonWidget.builder(Text.literal("<"), b -> changeMarkPage(-1))
				.dimensions(left + panelW - 68, top + 47, 24, 16).build();
		ButtonWidget next = ButtonWidget.builder(Text.literal(">"), b -> changeMarkPage(1))
				.dimensions(left + panelW - 40, top + 47, 24, 16).build();
		addDrawableChild(prev);
		addDrawableChild(next);
		pageButtons.add(prev);
		pageButtons.add(next);

		// aba Treino: um botão por atributo (só um PEDIDO; o servidor valida)
		for (TrainingAttribute attr : TrainingAttribute.values()) {
			final TrainingAttribute target = attr;
			ButtonWidget b = ButtonWidget.builder(Text.translatable("screen.rezero_magic.hub.train"),
					btn -> ClientPlayNetworking.send(new SelectTrainingPayload(target.id())))
					.dimensions(left + panelW - 84, trainY(attr.id()) - 2, 70, 16).build();
			addDrawableChild(b);
			trainButtons.add(b);
		}

		// aba Técnicas: um botão "Aprender" por técnica do estilo e botões de página (só PEDIDOS; o servidor valida)
		for (int row = 0; row < 3; row++) {
			final int r = row;
			ButtonWidget b = ButtonWidget.builder(Text.translatable("screen.rezero_magic.hub.learn"), btn -> onLearnClick(r))
					.dimensions(left + panelW - 84, techY(row) - 4, 70, 14).build();
			addDrawableChild(b);
			learnButtons.add(b);
		}
		ButtonWidget stylePrev = ButtonWidget.builder(Text.literal("<"), b -> changeStylePage(-1))
				.dimensions(left + panelW - 68, top + 47, 24, 16).build();
		ButtonWidget styleNext = ButtonWidget.builder(Text.literal(">"), b -> changeStylePage(1))
				.dimensions(left + panelW - 40, top + 47, 24, 16).build();
		addDrawableChild(stylePrev);
		addDrawableChild(styleNext);
		stylePageButtons.add(stylePrev);
		stylePageButtons.add(styleNext);

		// aba Espírito: manifestar/dispensar, habilidade e romper contrato (só PEDIDOS; o servidor valida)
		int[] spiritActions = {SpiritActionPayload.TOGGLE, SpiritActionPayload.ACTIVE, SpiritActionPayload.RELEASE};
		for (int i = 0; i < 3; i++) {
			final int action = spiritActions[i];
			ButtonWidget b = ButtonWidget.builder(Text.translatable("screen.rezero_magic.hub.spirit_summon"),
					btn -> ClientPlayNetworking.send(new SpiritActionPayload(action)))
					.dimensions(left + 14 + i * 104, top + panelH - 52, 100, 18).build();
			addDrawableChild(b);
			spiritButtons.add(b);
		}

		// aba Bênçãos: página anterior/próxima, receber e usar a ativa (só PEDIDOS; o servidor valida)
		int by = top + panelH - 52;
		protectionButtons.add(ButtonWidget.builder(Text.literal("<"), b -> changeProtectionPage(-1))
				.dimensions(left + 14, by, 24, 18).build());
		protectionButtons.add(ButtonWidget.builder(Text.literal(">"), b -> changeProtectionPage(1))
				.dimensions(left + 42, by, 24, 18).build());
		protectionButtons.add(ButtonWidget.builder(Text.translatable("screen.rezero_magic.hub.prot_claim"),
				b -> ClientPlayNetworking.send(new ProtectionActionPayload(ProtectionActionPayload.CLAIM, currentProtection().id())))
				.dimensions(left + 74, by, 100, 18).build());
		protectionButtons.add(ButtonWidget.builder(Text.translatable("screen.rezero_magic.hub.prot_use"),
				b -> ClientPlayNetworking.send(new ProtectionActionPayload(ProtectionActionPayload.ACTIVE, 0)))
				.dimensions(left + 178, by, 100, 18).build());
		for (ButtonWidget b : protectionButtons) {
			addDrawableChild(b);
		}

		// aba Formas: página anterior/próxima e ativar (só PEDIDOS; o servidor valida)
		transformButtons.add(ButtonWidget.builder(Text.literal("<"), b -> changeTransformPage(-1))
				.dimensions(left + 14, by, 24, 18).build());
		transformButtons.add(ButtonWidget.builder(Text.literal(">"), b -> changeTransformPage(1))
				.dimensions(left + 42, by, 24, 18).build());
		transformButtons.add(ButtonWidget.builder(Text.translatable("screen.rezero_magic.hub.form_activate"),
				b -> ClientPlayNetworking.send(new TransformActionPayload(currentForm().id())))
				.dimensions(left + 74, by, 100, 18).build());
		for (ButtonWidget b : transformButtons) {
			addDrawableChild(b);
		}

		addDrawableChild(ButtonWidget.builder(Text.translatable("screen.rezero_magic.hub.close"),
				b -> MinecraftClient.getInstance().setScreen(null))
				.dimensions(left + panelW / 2 - 50, top + panelH - 26, 100, 20).build());
		refreshButtons();
	}

	private int markY(int row) {
		return top + 100 + row * MARK_ROW_H;
	}

	private int techY(int row) {
		return top + 80 + row * 46;
	}

	private void changeStylePage(int delta) {
		stylePage = Math.floorMod(stylePage + delta, CombatStyle.values().length);
	}

	private TechniqueDef pageTechnique(int row) {
		return Techniques.slot(CombatStyle.values()[stylePage], row);
	}

	private void onLearnClick(int row) {
		TechniqueDef tech = pageTechnique(row);
		if (tech != null) {
			ClientPlayNetworking.send(new CombatActionPayload(CombatActionPayload.LEARN, tech.id()));
		}
	}

	private int trainY(int index) {
		return top + 90 + index * 20;
	}

	private void changeMarkPage(int delta) {
		markPage = Math.floorMod(markPage + delta, Inscription.Category.values().length);
	}

	/** As inscrições da página atual (uma categoria), na ordem do enum. */
	private List<Inscription> pageMarks() {
		List<Inscription> out = new ArrayList<>();
		Inscription.Category cat = Inscription.Category.values()[markPage];
		for (Inscription i : Inscription.values()) {
			if (i.category() == cat) {
				out.add(i);
			}
		}
		return out;
	}

	private void onMarkClick(int row) {
		List<Inscription> list = pageMarks();
		if (row >= list.size()) {
			return;
		}
		Inscription ins = list.get(row);
		boolean engraved = ClientPlayerData.marks().contains(ins);
		// só um PEDIDO: o servidor confere a mesa, o nível, a tinta e os espaços
		ClientPlayNetworking.send(new InscribePayload(ins.id(), engraved ? 1 : 0));
	}

	private int rowY(int row) {
		return top + 104 + row * ROW_H;
	}

	private void setTab(int t) {
		tab = t;
		if (tab < tabOffset) {
			tabOffset = tab;
		} else if (tab >= tabOffset + tabsVisible) {
			tabOffset = tab - tabsVisible + 1;
		}
		refreshButtons();
	}

	private void scrollTabs(int delta) {
		tabOffset = Math.max(0, Math.min(TAB_COUNT - tabsVisible, tabOffset + delta));
		refreshButtons();
	}

	/** Posiciona as abas conforme a rolagem; só as visíveis aparecem e a aba atual fica desativada (marca onde você está). */
	private void layoutTabs() {
		for (int t = 0; t < tabButtons.size(); t++) {
			ButtonWidget tb = tabButtons.get(t);
			boolean shown = t >= tabOffset && t < tabOffset + tabsVisible;
			tb.visible = shown;
			tb.setX(tabX0 + (t - tabOffset) * tabW);
			tb.active = t != tab;
		}
		if (tabPrev != null && tabNext != null) {
			tabPrev.active = tabOffset > 0;
			tabNext.active = tabOffset < TAB_COUNT - tabsVisible;
		}
	}

	private void refreshMarkButtons() {
		List<Inscription> list = pageMarks();
		List<Inscription> engraved = ClientPlayerData.marks();
		for (int i = 0; i < markButtons.size(); i++) {
			ButtonWidget b = markButtons.get(i);
			b.visible = tab == 4 && i < list.size();
			if (i < list.size()) {
				boolean has = engraved.contains(list.get(i));
				b.setMessage(Text.translatable(has ? "screen.rezero_magic.hub.remove" : "screen.rezero_magic.hub.engrave"));
				b.active = has || (engraved.size() < Inscription.SLOTS && list.get(i).unlockLevel() <= ClientPlayerData.channelLevel());
			}
		}
		for (ButtonWidget b : pageButtons) {
			b.visible = tab == 4;
		}
	}

	private void refreshTrainButtons() {
		TrainingAttribute focus = ClientPlayerData.trainingFocus();
		for (int i = 0; i < trainButtons.size(); i++) {
			ButtonWidget b = trainButtons.get(i);
			boolean selected = focus != null && focus.id() == i;
			b.visible = tab == 5;
			b.active = !selected;
			b.setMessage(Text.translatable(selected ? "screen.rezero_magic.hub.training_selected" : "screen.rezero_magic.hub.train"));
		}
	}

	private void refreshCombatButtons() {
		for (int i = 0; i < learnButtons.size(); i++) {
			ButtonWidget b = learnButtons.get(i);
			TechniqueDef tech = pageTechnique(i);
			b.visible = tab == 6 && tech != null;
			if (tech != null) {
				boolean learned = (ClientPlayerData.techniqueMask() & CombatRules.bit(tech.id())) != 0;
				b.active = !learned && CombatRules.checkLearn(ClientPlayerData.techniqueMask(), tech,
						ClientPlayerData.trainingLevels()) == CombatRules.LearnResult.OK;
				b.setMessage(Text.translatable(learned ? "screen.rezero_magic.hub.technique_learned"
						: "screen.rezero_magic.hub.learn"));
			}
		}
		for (ButtonWidget b : stylePageButtons) {
			b.visible = tab == 6;
		}
	}

	private void refreshSpiritButtons() {
		boolean has = ClientPlayerData.spirit() != null;
		for (int i = 0; i < spiritButtons.size(); i++) {
			ButtonWidget b = spiritButtons.get(i);
			b.visible = tab == 7 && has;
			if (i == 0) {
				b.setMessage(Text.translatable(ClientPlayerData.spiritSummoned() ? "screen.rezero_magic.hub.spirit_dismiss"
						: "screen.rezero_magic.hub.spirit_summon"));
			} else if (i == 1) {
				b.setMessage(Text.translatable("screen.rezero_magic.hub.spirit_use"));
				b.active = ClientPlayerData.spiritSummoned() && SpiritRules.activeUnlocked(ClientPlayerData.bondLevel())
						&& ClientPlayerData.spiritCooldownLeft() <= 0;
			} else {
				b.setMessage(Text.translatable("screen.rezero_magic.hub.spirit_release"));
			}
		}
	}

	private Transformation currentForm() {
		return Transformation.values()[transformPage];
	}

	private void changeTransformPage(int delta) {
		transformPage = Math.floorMod(transformPage + delta, Transformation.values().length);
		refreshButtons();
	}

	private void refreshTransformButtons() {
		Transformation f = currentForm();
		for (int i = 0; i < transformButtons.size(); i++) {
			ButtonWidget b = transformButtons.get(i);
			b.visible = tab == 9;
			if (i == 2) {
				b.visible = tab == 9 && f.selfActivated();
				b.active = TransformationRules.check(f, ClientPlayerData.transformContext(f, MinecraftClient.getInstance().player))
						== TransformationRules.Result.OK;
			}
		}
	}

	private DivineProtection currentProtection() {
		return DivineProtection.values()[protectionPage];
	}

	private void changeProtectionPage(int delta) {
		protectionPage = Math.floorMod(protectionPage + delta, DivineProtection.values().length);
		refreshButtons();
	}

	private void refreshProtectionButtons() {
		DivineProtection p = currentProtection();
		int mask = ClientPlayerData.protectionMask();
		for (int i = 0; i < protectionButtons.size(); i++) {
			ButtonWidget b = protectionButtons.get(i);
			b.visible = tab == 8;
			if (i == 2) {
				boolean owned = ProtectionRules.has(mask, p);
				b.active = ProtectionRules.checkClaim(mask, p, ClientPlayerData.protectionProgress()) == ProtectionRules.ClaimResult.OK;
				b.setMessage(Text.translatable(owned ? "screen.rezero_magic.hub.prot_owned" : "screen.rezero_magic.hub.prot_claim"));
			} else if (i == 3) {
				b.visible = tab == 8 && ProtectionRules.has(mask, DivineProtection.WIND_INDICATION);
				b.active = ClientPlayerData.protectionCooldownLeft() <= 0;
			}
		}
	}

	private void refreshButtons() {
		layoutTabs();
		refreshTransformButtons();
		refreshProtectionButtons();
		refreshSpiritButtons();
		refreshMarkButtons();
		refreshTrainButtons();
		refreshCombatButtons();
		for (int i = 0; i < selectButtons.size(); i++) {
			ButtonWidget b = selectButtons.get(i);
			boolean unlocked = rowSpells.get(i).unlockLevel() <= ClientPlayerData.channelLevel();
			b.visible = tab == 1;
			b.active = unlocked;
		}
	}

	private void drawContent(DrawContext c, int mouseX, int mouseY, float delta) {
		c.fill(left - 2, top - 2, left + panelW + 2, top + panelH + 2, 0xFF000000);
		c.fill(left, top, left + panelW, top + panelH, 0xEE1B1530);

		Text title = Text.translatable("screen.rezero_magic.hub.title");
		c.drawTextWithShadow(textRenderer, title, left + (panelW - textRenderer.getWidth(title)) / 2, top + 8, 0xFFFFD34D);

		if (tab == 0) {
			drawProfile(c);
		} else if (tab == 1) {
			drawSpells(c);
		} else if (tab == 2) {
			drawCrystals(c);
		} else if (tab == 3) {
			drawEquipment(c);
		} else if (tab == 4) {
			refreshMarkButtons();
			drawMarks(c);
		} else if (tab == 5) {
			refreshTrainButtons();
			drawTraining(c);
		} else if (tab == 6) {
			refreshCombatButtons();
			drawCombat(c);
		} else if (tab == 7) {
			refreshSpiritButtons();
			drawSpirit(c);
		} else if (tab == 8) {
			refreshProtectionButtons();
			drawProtections(c);
		} else {
			refreshTransformButtons();
			drawForms(c);
		}
	}

	private void drawProfile(DrawContext c) {
		int x = left + 14;
		int y = top + 54;
		MinecraftClient client = MinecraftClient.getInstance();
		String playerName = client.player == null ? "?" : client.player.getName().getString();
		c.drawTextWithShadow(textRenderer, Text.translatable("screen.rezero_magic.hub.player", playerName), x, y, 0xFFFFFFFF);
		y += 16;

		Affinity affinity = ClientPlayerData.affinity();
		if (affinity == null) {
			wrap(c, Text.translatable("screen.rezero_magic.hub.affinity_none"), x, y, panelW - 28, 0xFFFF7070);
			return;
		}
		Text name = Text.translatable("affinity.rezero_magic." + affinity.key());
		c.drawTextWithShadow(textRenderer, Text.translatable("screen.rezero_magic.hub.affinity", name), x, y, 0xFFB8D8FF);
		y += 12;
		com.rezero.mod.core.Race race = ClientPlayerData.race();
		if (race != null) {
			c.drawTextWithShadow(textRenderer, Text.translatable("screen.rezero_magic.hub.race",
					Text.translatable("race.rezero_magic." + race.key())), x, y, 0xFFB8D8FF);
		} else {
			c.drawTextWithShadow(textRenderer, Text.translatable("screen.rezero_magic.hub.race_none"), x, y, 0xFFFF7070);
		}
		y += 14;
		y = wrap(c, Text.translatable("affinity.rezero_magic." + affinity.key() + ".canon"), x, y, panelW - 28, 0xFFDADAEA);
		y += 4;
		y = wrap(c, Text.translatable("affinity.rezero_magic." + affinity.key() + ".game"), x, y, panelW - 28, 0xFFFFFFFF);
		if (race != null) {
			y += 4;
			y = wrap(c, Text.translatable("race.rezero_magic." + race.key() + ".pros"), x, y, panelW - 28, 0xFF7CFF9A);
			wrap(c, Text.translatable("race.rezero_magic." + race.key() + ".cons"), x, y, panelW - 28, 0xFFFF9A6E);
		}
	}

	private void drawSpells(DrawContext c) {
		int x = left + 14;
		int y = top + 52;
		Affinity affinity = ClientPlayerData.affinity();
		if (affinity == null) {
			wrap(c, Text.translatable("screen.rezero_magic.hub.affinity_none"), x, y, panelW - 28, 0xFFFF7070);
			return;
		}
		int level = ClientPlayerData.channelLevel();
		int needed = ChannelModel.xpNeeded(level);
		Text lv = needed > 0
				? Text.translatable("screen.rezero_magic.hub.channel_level", level, ChannelModel.MAX_LEVEL,
						ClientPlayerData.channelXp(), needed)
				: Text.translatable("screen.rezero_magic.hub.channel_level_max", level, ChannelModel.MAX_LEVEL);
		c.drawTextWithShadow(textRenderer, lv, x, y, 0xFFFFD34D);
		y += 12;
		c.drawTextWithShadow(textRenderer, Text.translatable("screen.rezero_magic.hub.channel_stats",
				ClientPlayerData.mana(), ClientPlayerData.maxMana(),
				String.format("%.2f", ChannelModel.regenPerSecond(level))), x, y, 0xFFB8D8FF);
		y += 12;
		c.drawTextWithShadow(textRenderer, Text.translatable("screen.rezero_magic.hub.channel_bonus",
				Math.round((1.0 - ChannelModel.costMultiplier(level)) * 100),
				Math.round((1.0 - ChannelModel.castTimeMultiplier(level)) * 100),
				Math.round((ChannelModel.powerMultiplier(level) - 1.0) * 100)), x, y, 0xFFDADAEA);

		SpellDef selected = ClientPlayerData.selectedSpell();
		CastModifiers mods = clientMods();
		for (int i = 0; i < rowSpells.size(); i++) {
			SpellDef s = rowSpells.get(i);
			int ry = rowY(i);
			boolean unlocked = s.unlockLevel() <= level;
			boolean isSel = selected != null && selected.id() == s.id();
			if (isSel) {
				c.fill(x - 3, ry - 4, left + panelW - 88, ry + 17, 0x66FFD34D);
			}
			Text name = Text.translatable("spell.rezero_magic." + s.key());
			c.drawTextWithShadow(textRenderer, name, x, ry, unlocked ? 0xFFFFFFFF : 0xFF777777);
			Text info = unlocked
					? Text.translatable("screen.rezero_magic.hub.spell_info",
							ChannelModel.effectiveCost(s.baseCost(), level, mods.cost()),
							String.format("%.1f", ChannelModel.effectiveCastTicks(s.baseCastTicks(), level, mods.cast()) / 20.0),
							String.format("%.1f", s.cooldownTicks() / 20.0))
					: Text.translatable("screen.rezero_magic.hub.spell_locked", s.unlockLevel());
			c.drawTextWithShadow(textRenderer, info, x, ry + 10, unlocked ? 0xFFB8D8FF : 0xFF777777);
		}
	}

	private static CastModifiers clientMods() {
		MinecraftClient client = MinecraftClient.getInstance();
		return client.player == null ? CastModifiers.NONE : EquipmentLookup.modifiersOf(client.player, ClientPlayerData.marks(), ClientPlayerData.trainingLevels(), ClientPlayerData.spiritPowerPct(), ClientPlayerData.racePcts());
	}

	/** Equipamento: o que você está segurando AGORA e os bônus resultantes (os mesmos que o servidor aplica). */
	private void drawEquipment(DrawContext c) {
		int x = left + 14;
		int y = top + 52;
		MinecraftClient client = MinecraftClient.getInstance();
		if (client.player == null) {
			return;
		}
		y = wrap(c, Text.translatable("screen.rezero_magic.hub.equipment_intro"), x, y, panelW - 28, 0xFFDADAEA);
		y += 6;
		Catalyst staff = EquipmentLookup.staffOf(client.player);
		Charm charm = EquipmentLookup.charmOf(client.player);
		Text none = Text.translatable("screen.rezero_magic.hub.equipment_none");
		c.drawTextWithShadow(textRenderer, Text.translatable("screen.rezero_magic.hub.equipment_staff",
				staff == null ? none : Text.translatable("item.rezero_magic." + staff.key())), x, y, 0xFFB8D8FF);
		y += 12;
		c.drawTextWithShadow(textRenderer, Text.translatable("screen.rezero_magic.hub.equipment_charm",
				charm == null ? none : Text.translatable("item.rezero_magic." + charm.key())), x, y, 0xFFB8D8FF);
		y += 12;
		int[] robes = EquipmentLookup.robePieces(client.player);
		c.drawTextWithShadow(textRenderer, Text.translatable("screen.rezero_magic.hub.equipment_robes",
				robes[RobeSet.APPRENTICE.id()], robes[RobeSet.CRYSTAL.id()], robes[RobeSet.PURE.id()]), x, y, 0xFFB8D8FF);
		y += 16;
		CastModifiers m = EquipmentLookup.modifiersOf(client.player, ClientPlayerData.marks(), ClientPlayerData.trainingLevels(), ClientPlayerData.spiritPowerPct(), ClientPlayerData.racePcts());
		c.drawTextWithShadow(textRenderer, Text.translatable("screen.rezero_magic.hub.equipment_total",
				Math.round((m.power() - 1.0) * 100), Math.round((1.0 - m.cost()) * 100),
				Math.round((1.0 - m.cast()) * 100), Math.round((m.regen() - 1.0) * 100)), x, y, 0xFFFFD34D);
	}

	/** Formas: uma transformação por página (racial, espiritual, emergência) com estado, condição, efeito e efeito colateral. */
	private void drawForms(DrawContext c) {
		int x = left + 14;
		int y = top + 50;
		int w = panelW - 28;
		Transformation f = currentForm();
		String k = f.key();
		c.drawTextWithShadow(textRenderer, Text.translatable("screen.rezero_magic.hub.form_title", transformPage + 1,
				Transformation.values().length, Text.translatable("transform.rezero_magic." + k),
				Text.translatable("screen.rezero_magic.hub.form_kind_" + f.kind().name().toLowerCase())), x, y, 0xFFFFD34D);
		y += 12;
		int timeLeft = f.selfActivated() ? (ClientPlayerData.transformActive() == f ? ClientPlayerData.transformFormLeft() : 0)
				: (ClientPlayerData.racialActive() == f ? ClientPlayerData.raceFormLeft() : 0);
		int cd = f.selfActivated() ? ClientPlayerData.transformCooldownLeft(f)
				: (isMyRacial(f) && timeLeft <= 0 ? ClientPlayerData.raceCooldownLeft() : 0);
		Text state = !f.selfActivated() && !isMyRacial(f) ? Text.translatable("screen.rezero_magic.hub.form_state_other_race")
				: timeLeft > 0 ? Text.translatable("screen.rezero_magic.hub.form_state_on", String.format("%.0f", timeLeft / 20.0))
				: cd > 0 ? Text.translatable("screen.rezero_magic.hub.form_state_cd", String.format("%.0f", cd / 20.0))
				: Text.translatable("screen.rezero_magic.hub.form_state_ready");
		c.drawTextWithShadow(textRenderer, state, x, y, timeLeft > 0 ? 0xFF7CFF9A : 0xFFB8D8FF);
		y += 12;
		y = wrap(c, Text.translatable("transform.rezero_magic." + k + ".canon"), x, y, w, 0xFFDADAEA);
		y = wrap(c, Text.translatable("transform.rezero_magic." + k + ".req"), x, y, w, 0xFFFFFFFF);
		y = wrap(c, Text.translatable("transform.rezero_magic." + k + ".effect"), x, y, w, 0xFF7CFF9A);
		y = wrap(c, Text.translatable("transform.rezero_magic." + k + ".side"), x, y, w, 0xFFFF9A6E);
		Text stats = Text.translatable("screen.rezero_magic.hub.form_stats", String.format("%.0f", TransformationRules.durationTicks(f) / 20.0),
				String.format("%.0f", TransformationRules.cooldownTicks(f) / 20.0), TransformationRules.manaCost(f));
		c.drawTextWithShadow(textRenderer, stats, x, y + 2, 0xFFAAAAAA);
	}

	/** A forma racial é a da raça do jogador? */
	private static boolean isMyRacial(Transformation f) {
		com.rezero.mod.core.Race r = ClientPlayerData.race();
		return (f == Transformation.BEAST && r == com.rezero.mod.core.Race.DEMI_HUMAN)
				|| (f == Transformation.ONI && r == com.rezero.mod.core.Race.ONI);
	}

	/** Bênçãos: uma Proteção Divina por página, com canon, efeito, limitação, condição (cumprida ou não) e vagas. */
	private void drawProtections(DrawContext c) {
		int x = left + 14;
		int y = top + 50;
		int w = panelW - 28;
		DivineProtection p = currentProtection();
		int mask = ClientPlayerData.protectionMask();
		c.drawTextWithShadow(textRenderer, Text.translatable("screen.rezero_magic.hub.prot_slots",
				ProtectionRules.slotsUsed(mask), ProtectionRules.MAX_SLOTS), x, y, 0xFFB8D8FF);
		y += 12;
		String k = p.key();
		c.drawTextWithShadow(textRenderer, Text.translatable("screen.rezero_magic.hub.prot_title", protectionPage + 1,
				DivineProtection.values().length, Text.translatable("protection.rezero_magic." + k),
				Text.translatable(p.epic() ? "screen.rezero_magic.hub.prot_epic" : "screen.rezero_magic.hub.prot_rare"), p.slotCost()),
				x, y, 0xFFFFD34D);
		y += 12;
		y = wrap(c, Text.translatable("protection.rezero_magic." + k + ".canon"), x, y, w, 0xFFDADAEA);
		y = wrap(c, Text.translatable("protection.rezero_magic." + k + ".effect"), x, y, w, 0xFF7CFF9A);
		y = wrap(c, Text.translatable("protection.rezero_magic." + k + ".limit"), x, y, w, 0xFFFF9A6E);
		y = wrap(c, Text.translatable("protection.rezero_magic." + k + ".req"), x, y, w, 0xFFFFFFFF);
		boolean owned = ProtectionRules.has(mask, p);
		boolean met = ProtectionRules.conditionMet(p, ClientPlayerData.protectionProgress());
		c.drawTextWithShadow(textRenderer, Text.translatable(owned ? "screen.rezero_magic.hub.prot_state_owned"
				: met ? "screen.rezero_magic.hub.prot_state_met" : "screen.rezero_magic.hub.prot_state_unmet"), x, y + 2,
				owned ? 0xFF7CFF9A : met ? 0xFFFFD34D : 0xFFAAAAAA);
	}

	/** Espírito: contrato, vínculo, temperamento, efeitos e como encontrar um. Só dados reais do servidor. */
	private void drawSpirit(DrawContext c) {
		int x = left + 14;
		int y = top + 50;
		int w = panelW - 28;
		Affinity element = ClientPlayerData.spirit();
		if (element == null) {
			c.drawTextWithShadow(textRenderer, Text.translatable("screen.rezero_magic.hub.spirit_none"), x, y, 0xFFFFD34D);
			y += 14;
			Affinity mine = ClientPlayerData.affinity();
			if (mine != null) {
				y = wrap(c, Text.translatable("screen.rezero_magic.hub.spirit_help", SpiritRules.MIN_CHANNEL_LEVEL,
						Text.translatable("spirit.rezero_magic." + mine.key() + ".where")), x, y, w, 0xFFDADAEA);
				y += 6;
			}
			boolean wisp = ClientPlayerData.wispNearby();
			c.drawTextWithShadow(textRenderer, Text.translatable(wisp ? "screen.rezero_magic.hub.spirit_wisp_here"
					: "screen.rezero_magic.hub.spirit_wisp_none"), x, y, wisp ? 0xFF7CFF9A : 0xFFAAAAAA);
			return;
		}
		String key = element.key();
		int bond = ClientPlayerData.bondLevel();
		c.drawTextWithShadow(textRenderer, Text.translatable("screen.rezero_magic.hub.spirit_name",
				Text.translatable("spirit.rezero_magic." + key)), x, y, 0xFFFFD34D);
		y += 12;
		int needed = SpiritRules.bondXpNeeded(bond);
		c.drawTextWithShadow(textRenderer, needed > 0
				? Text.translatable("screen.rezero_magic.hub.spirit_bond", bond, SpiritRules.MAX_BOND, ClientPlayerData.bondXp(), needed)
				: Text.translatable("screen.rezero_magic.hub.spirit_bond_max", bond, SpiritRules.MAX_BOND), x, y, 0xFFB8D8FF);
		y += 12;
		boolean on = ClientPlayerData.spiritSummoned();
		c.drawTextWithShadow(textRenderer, Text.translatable(on ? "screen.rezero_magic.hub.spirit_state_on"
				: "screen.rezero_magic.hub.spirit_state_off"), x, y, on ? 0xFF7CFF9A : 0xFFAAAAAA);
		y += 14;
		y = wrap(c, Text.translatable("screen.rezero_magic.hub.spirit_temperament",
				Text.translatable("spirit.rezero_magic." + key + ".temperament")), x, y, w, 0xFFDADAEA);
		y = wrap(c, Text.translatable("screen.rezero_magic.hub.spirit_passive",
				Text.translatable("spirit.rezero_magic." + key + ".passive")), x, y, w, 0xFFDADAEA);
		c.drawTextWithShadow(textRenderer, Text.translatable("screen.rezero_magic.hub.spirit_effects",
				SpiritRules.powerPct(bond), String.format("%.2f", SpiritRules.drainPerSecond(bond))), x, y, 0xFF7CFF9A);
		y += 12;
		if (SpiritRules.activeUnlocked(bond)) {
			int cd = ClientPlayerData.spiritCooldownLeft();
			wrap(c, Text.translatable("screen.rezero_magic.hub.spirit_active", Text.translatable("spirit.rezero_magic." + key + ".active"),
					SpiritRules.ACTIVE_COST, String.format("%.0f", SpiritRules.ACTIVE_COOLDOWN_TICKS / 20.0)), x, y, w, 0xFFFFFFFF);
			if (cd > 0) {
				c.drawTextWithShadow(textRenderer, Text.translatable("screen.rezero_magic.hub.spirit_active_cd",
						String.format("%.0f", cd / 20.0)), x, y + 22, 0xFFAAAAAA);
			}
		} else {
			c.drawTextWithShadow(textRenderer, Text.translatable("screen.rezero_magic.hub.spirit_active_locked",
					SpiritRules.ACTIVE_UNLOCK_BOND), x, y, 0xFF777777);
		}
	}

	/** Técnicas: as 3 do estilo da página, com números reais, requisitos, pontos e estado de aprendizado. */
	private void drawCombat(DrawContext c) {
		int x = left + 14;
		CombatStyle style = CombatStyle.values()[stylePage];
		int[] levels = ClientPlayerData.trainingLevels();
		int mask = ClientPlayerData.techniqueMask();
		c.drawTextWithShadow(textRenderer, Text.translatable("screen.rezero_magic.hub.combat_header",
				Text.translatable("style.rezero_magic." + style.key()), stylePage + 1, CombatStyle.values().length,
				CombatRules.availablePoints(levels, mask)), x, top + 50, 0xFFFFD34D);
		c.drawTextWithShadow(textRenderer, Text.translatable("screen.rezero_magic.hub.combat_stamina",
				ClientPlayerData.stamina(), ClientPlayerData.maxStamina(), CombatRules.DODGE_COST), x, top + 62, 0xFFB8D8FF);
		for (int row = 0; row < 3; row++) {
			TechniqueDef tech = pageTechnique(row);
			if (tech == null) {
				continue;
			}
			int ry = techY(row);
			boolean learned = (mask & CombatRules.bit(tech.id())) != 0;
			CombatRules.LearnResult result = CombatRules.checkLearn(mask, tech, levels);
			c.drawTextWithShadow(textRenderer, Text.translatable("technique.rezero_magic." + tech.key()), x, ry,
					learned ? 0xFF7CFF9A : 0xFFFFFFFF);
			c.drawTextWithShadow(textRenderer, Text.translatable("technique.rezero_magic." + tech.key() + ".desc"), x, ry + 10, 0xFFDADAEA);
			// custo de estamina real (com a redução do Santo da Espada, se houver), o mesmo que o servidor cobra
			int stamina = ProtectionRules.effectiveStaminaCost(tech.staminaCost(),
					ProtectionRules.staminaReductionPct(ClientPlayerData.protectionMask(), tech.style()));
			Text info;
			if (tech.damagePct() > 0) {
				info = Text.translatable(tech.windupTicks() > 0 ? "screen.rezero_magic.hub.technique_info_windup" : "screen.rezero_magic.hub.technique_info",
						tech.damagePct(), String.format("%.1f", tech.range()), stamina,
						String.format("%.1f", tech.cooldownTicks() / 20.0), String.format("%.1f", tech.windupTicks() / 20.0));
			} else {
				info = Text.translatable(tech.windupTicks() > 0 ? "screen.rezero_magic.hub.technique_info_nodmg_windup" : "screen.rezero_magic.hub.technique_info_nodmg",
						stamina, String.format("%.1f", tech.cooldownTicks() / 20.0), String.format("%.1f", tech.windupTicks() / 20.0));
			}
			c.drawTextWithShadow(textRenderer, info, x, ry + 20, 0xFFB8D8FF);
			Text req;
			int color;
			if (learned) {
				req = Text.translatable("screen.rezero_magic.hub.technique_learned");
				color = 0xFF7CFF9A;
			} else if (result == CombatRules.LearnResult.OK) {
				req = Text.translatable("screen.rezero_magic.hub.technique_can_learn", tech.pointCost());
				color = 0xFFFFD34D;
			} else {
				req = Text.translatable("screen.rezero_magic.hub.technique_req",
						Text.translatable("training.rezero_magic." + tech.attribute().key()), tech.minLevel(), tech.pointCost(),
						Text.translatable("screen.rezero_magic.hub.learn_reason_" + result.name().toLowerCase()));
				color = 0xFFFF9090;
			}
			c.drawTextWithShadow(textRenderer, req, x, ry + 30, color);
		}
	}

	/** Treino: nível, XP e efeito reais de cada atributo, teto atual, fadiga e o atributo exercitado pelo Poste de Treino. */
	private void drawTraining(DrawContext c) {
		int x = left + 14;
		wrap(c, Text.translatable("screen.rezero_magic.hub.training_intro"), x, top + 44, panelW - 28, 0xFFDADAEA);
		c.drawTextWithShadow(textRenderer, Text.translatable("screen.rezero_magic.hub.training_cap",
				TrainingModel.levelCap(ClientPlayerData.channelLevel()), ClientPlayerData.fatigue()), x, top + 76, 0xFFFFD34D);
		int cap = TrainingModel.levelCap(ClientPlayerData.channelLevel());
		TrainingAttribute focus = ClientPlayerData.trainingFocus();
		for (TrainingAttribute attr : TrainingAttribute.values()) {
			int ry = trainY(attr.id());
			int level = ClientPlayerData.trainingLevel(attr);
			int needed = TrainingModel.xpNeeded(level);
			Text name = Text.translatable("training.rezero_magic." + attr.key());
			Text row;
			if (level >= TrainingModel.MAX_LEVEL) {
				row = Text.translatable("screen.rezero_magic.hub.training_row_max", name, level);
			} else if (level >= cap) {
				row = Text.translatable("screen.rezero_magic.hub.training_row_capped", name, level);
			} else {
				row = Text.translatable("screen.rezero_magic.hub.training_row", name, level, ClientPlayerData.trainingXp(attr), needed);
			}
			boolean isFocus = focus != null && focus.id() == attr.id();
			if (isFocus) {
				c.fill(x - 3, ry - 4, left + panelW - 88, ry + 20, 0x66FFD34D);
			}
			c.drawTextWithShadow(textRenderer, row, x, ry, 0xFFFFFFFF);
			c.drawTextWithShadow(textRenderer, Text.translatable("training.rezero_magic." + attr.key() + ".desc"),
					x, ry + 10, 0xFFB8D8FF);
		}
		int[] lv = ClientPlayerData.trainingLevels();
		wrap(c, Text.translatable("screen.rezero_magic.hub.training_effects",
				String.format("%.1f", TrainingModel.maxHealthBonus(lv[TrainingAttribute.VIGOR.id()])),
				String.format("%.1f", TrainingModel.attackBonus(lv[TrainingAttribute.STRENGTH.id()])),
				String.format("%.1f", TrainingModel.speedFraction(lv[TrainingAttribute.AGILITY.id()]) * 100.0),
				TrainingModel.castReductionPct(lv[TrainingAttribute.FOCUS.id()]),
				TrainingModel.costReductionPct(lv[TrainingAttribute.CONTROL.id()]),
				TrainingModel.regenPct(lv[TrainingAttribute.CONTROL.id()])), x, top + 194, panelW - 28, 0xFF7CFF9A);
	}

	/** Marcas: as 3 da categoria atual, com custo de tinta, nível e efeito; mostra espaços e tinta REAIS. */
	private void drawMarks(DrawContext c) {
		int x = left + 14;
		int y = top + 50;
		Inscription.Category cat = Inscription.Category.values()[markPage];
		c.drawTextWithShadow(textRenderer, Text.translatable("screen.rezero_magic.hub.marks_category",
				Text.translatable("screen.rezero_magic.hub.category_" + cat.name().toLowerCase()), markPage + 1,
				Inscription.Category.values().length), x, y, 0xFFFFD34D);
		y += 14;
		MinecraftClient client = MinecraftClient.getInstance();
		int ink = 0;
		if (client.player != null) {
			PlayerInventory inv = client.player.getInventory();
			for (int i = 0; i < inv.size(); i++) {
				ItemStack st = inv.getStack(i);
				if (st.getItem() == ModItems.MANA_INK) {
					ink += st.getCount();
				}
			}
		}
		c.drawTextWithShadow(textRenderer, Text.translatable("screen.rezero_magic.hub.marks_status",
				ClientPlayerData.marks().size(), Inscription.SLOTS, ink), x, y, 0xFFB8D8FF);
		y += 12;
		wrap(c, Text.translatable("screen.rezero_magic.hub.marks_hint"), x, y, panelW - 28, 0xFFDADAEA);
		List<Inscription> list = pageMarks();
		List<Inscription> engraved = ClientPlayerData.marks();
		for (int i = 0; i < list.size(); i++) {
			Inscription ins = list.get(i);
			int ry = markY(i);
			boolean has = engraved.contains(ins);
			boolean unlocked = ins.unlockLevel() <= ClientPlayerData.channelLevel();
			int nameColor = has ? 0xFF7CFF9A : unlocked ? 0xFFFFFFFF : 0xFF777777;
			c.drawTextWithShadow(textRenderer, Text.translatable("inscription.rezero_magic." + ins.key()), x, ry, nameColor);
			c.drawTextWithShadow(textRenderer, Text.translatable("screen.rezero_magic.hub.mark_info", ins.inkCost(), ins.unlockLevel()),
					x, ry + 10, unlocked ? 0xFFB8D8FF : 0xFF777777);
			c.drawTextWithShadow(textRenderer, Text.translatable("inscription.rezero_magic." + ins.key() + ".desc"),
					x, ry + 20, 0xFFDADAEA);
		}
	}

	/** Cristais: contagem REAL do inventário do jogador e o valor de cada raridade. */
	private void drawCrystals(DrawContext c) {
		int x = left + 14;
		int y = top + 52;
		y = wrap(c, Text.translatable("screen.rezero_magic.hub.crystals_intro"), x, y, panelW - 28, 0xFFDADAEA);
		y += 6;
		MinecraftClient client = MinecraftClient.getInstance();
		if (client.player == null) {
			return;
		}
		PlayerInventory inv = client.player.getInventory();
		for (CrystalRarity r : CrystalRarity.values()) {
			int count = 0;
			for (int i = 0; i < inv.size(); i++) {
				ItemStack st = inv.getStack(i);
				if (st.getItem() == ModItems.crystalItem(r)) {
					count += st.getCount();
				}
			}
			c.drawTextWithShadow(textRenderer, Text.translatable("screen.rezero_magic.hub.crystal_row",
					Text.translatable("item.rezero_magic." + r.key()), count, r.mana()), x, y, 0xFFB8D8FF);
			y += 12;
		}
		int receptors = 0;
		int stored = 0;
		for (int i = 0; i < inv.size(); i++) {
			ItemStack st = inv.getStack(i);
			if (st.getItem() == ModItems.MANA_RECEPTOR) {
				receptors += st.getCount();
				stored += CrystalRules.storedFromDamage(st.getDamage());
			}
		}
		y += 4;
		c.drawTextWithShadow(textRenderer, Text.translatable("screen.rezero_magic.hub.receptors", receptors, stored),
				x, y, 0xFFFFD34D);
	}

	private int wrap(DrawContext c, Text t, int x, int y, int maxWidth, int color) {
		for (OrderedText line : textRenderer.wrapLines(t, maxWidth)) {
			c.drawTextWithShadow(textRenderer, line, x, y, color);
			y += 10;
		}
		return y;
	}
}
