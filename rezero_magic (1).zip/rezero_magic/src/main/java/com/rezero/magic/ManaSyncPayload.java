package com.rezero.magic;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Servidor -> cliente: mana atual e máxima, para a barra do HUD. */
public record ManaSyncPayload(int mana, int maxMana) implements CustomPayload {
	public static final CustomPayload.Id<ManaSyncPayload> ID =
			new CustomPayload.Id<>(Identifier.of(ReZeroMagic.MOD_ID, "mana_sync"));

	public static final PacketCodec<RegistryByteBuf, ManaSyncPayload> CODEC =
			PacketCodec.tuple(
					PacketCodecs.VAR_INT, ManaSyncPayload::mana,
					PacketCodecs.VAR_INT, ManaSyncPayload::maxMana,
					ManaSyncPayload::new);

	@Override
	public CustomPayload.Id<? extends CustomPayload> getId() {
		return ID;
	}
}
