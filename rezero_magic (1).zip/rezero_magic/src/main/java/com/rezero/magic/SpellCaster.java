package com.rezero.magic;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

/**
 * Toda a lógica das magias roda no servidor (o servidor integrado, no singleplayer).
 * Os projéteis são simulados aqui mesmo, sem entidades novas, para manter o mod simples.
 */
public final class SpellCaster {
	public static final int FIREBALL = 0;
	public static final int ICE_LANCE = 1;
	public static final int UNSEEN_HAND = 2;

	private static final int[] MANA_COST = {25, 15, 20};
	private static final int[] COOLDOWN_TICKS = {20, 8, 10};

	private static final double HAND_RANGE = 24.0;
	private static final int HAND_MAX_TICKS = 200; // 10 segundos

	private static final List<Bolt> BOLTS = new ArrayList<>();
	private static final Map<UUID, Held> HELD = new HashMap<>();
	private static final Map<UUID, int[]> NEXT_USE = new HashMap<>();

	private SpellCaster() {}

	private static final class Bolt {
		final ServerWorld world;
		final ServerPlayerEntity owner;
		final boolean fire;
		final Vec3d velocity;
		final int maxAge;
		Vec3d pos;
		int age;

		Bolt(ServerWorld world, ServerPlayerEntity owner, boolean fire, Vec3d pos, Vec3d velocity, int maxAge) {
			this.world = world;
			this.owner = owner;
			this.fire = fire;
			this.pos = pos;
			this.velocity = velocity;
			this.maxAge = maxAge;
		}
	}

	private static final class Held {
		final ServerWorld world;
		final ServerPlayerEntity owner;
		final LivingEntity target;
		final double distance;
		int age;

		Held(ServerWorld world, ServerPlayerEntity owner, LivingEntity target, double distance) {
			this.world = world;
			this.owner = owner;
			this.target = target;
			this.distance = distance;
		}
	}

	public static void init() {
		ServerTickEvents.END_SERVER_TICK.register(server -> {
			tickBolts();
			tickHands();
		});
		ServerLifecycleEvents.SERVER_STOPPED.register(server -> {
			BOLTS.clear();
			HELD.clear();
			NEXT_USE.clear();
		});
	}

	// ------------------------------------------------------------------ entrada

	public static void cast(MinecraftServer server, ServerPlayerEntity player, int spell) {
		if (spell < 0 || spell >= MANA_COST.length) {
			return;
		}
		ServerWorld world = Compat.worldOf(server, player);
		if (world == null) {
			return;
		}

		int now = server.getTicks();
		int[] next = NEXT_USE.computeIfAbsent(player.getUuid(), k -> new int[MANA_COST.length]);
		if (now < next[spell]) {
			return;
		}

		switch (spell) {
			case FIREBALL -> {
				if (!ManaManager.consume(player, MANA_COST[spell])) {
					noMana(player);
					return;
				}
				launchBolt(world, player, true);
			}
			case ICE_LANCE -> {
				if (!ManaManager.consume(player, MANA_COST[spell])) {
					noMana(player);
					return;
				}
				launchBolt(world, player, false);
			}
			case UNSEEN_HAND -> {
				if (!castUnseenHand(world, player)) {
					return;
				}
			}
			default -> {
				return;
			}
		}
		next[spell] = now + COOLDOWN_TICKS[spell];
	}

	private static void noMana(ServerPlayerEntity player) {
		player.sendMessage(Text.translatable("message.rezero_magic.no_mana"), true);
	}

	// ------------------------------------------------------- bola de fogo / gelo

	private static void launchBolt(ServerWorld world, ServerPlayerEntity player, boolean fire) {
		Vec3d look = player.getRotationVec(1.0f);
		Vec3d start = player.getEyePos().add(look.multiply(1.0)).add(0.0, -0.15, 0.0);
		double speed = fire ? 1.1 : 2.4;
		int maxAge = fire ? 120 : 60;
		BOLTS.add(new Bolt(world, player, fire, start, look.multiply(speed), maxAge));

		// círculo mágico aos pés do jogador
		if (fire) {
			Fx.magicCircle(world, ParticleTypes.FLAME, ParticleTypes.SOUL_FIRE_FLAME,
					player.getX(), player.getY() + 0.1, player.getZ(), 1.6);
		} else {
			Fx.magicCircle(world, ParticleTypes.SNOWFLAKE, ParticleTypes.END_ROD,
					player.getX(), player.getY() + 0.1, player.getZ(), 1.6);
		}
		world.playSound(null, player.getX(), player.getY(), player.getZ(),
				SoundEvents.ENTITY_EVOKER_CAST_SPELL, SoundCategory.PLAYERS, 0.7f, 0.5f);

		if (fire) {
			world.playSound(null, player.getX(), player.getY(), player.getZ(),
					SoundEvents.ENTITY_BLAZE_SHOOT, SoundCategory.PLAYERS, 1.0f, 0.8f);
		} else {
			world.playSound(null, player.getX(), player.getY(), player.getZ(),
					SoundEvents.BLOCK_GLASS_BREAK, SoundCategory.PLAYERS, 0.8f, 1.6f);
		}
	}

	private static void tickBolts() {
		Iterator<Bolt> it = BOLTS.iterator();
		while (it.hasNext()) {
			Bolt bolt = it.next();
			if (bolt.owner.isRemoved() || bolt.age++ > bolt.maxAge) {
				it.remove();
				continue;
			}

			Vec3d next = bolt.pos.add(bolt.velocity);
			BlockHitResult blockHit = bolt.world.raycast(new RaycastContext(
					bolt.pos, next,
					RaycastContext.ShapeType.COLLIDER,
					RaycastContext.FluidHandling.NONE,
					bolt.owner));
			boolean hitBlock = blockHit.getType() != HitResult.Type.MISS;
			Vec3d end = hitBlock ? blockHit.getPos() : next;

			LivingEntity hitEntity = findTarget(bolt.world, bolt.owner, bolt.pos, end, 0.35);
			if (hitEntity != null || hitBlock) {
				Vec3d at = hitEntity != null
						? new Vec3d(hitEntity.getX(), hitEntity.getBodyY(0.5), hitEntity.getZ())
						: blockHit.getPos();
				if (bolt.fire) {
					fireImpact(bolt, at);
				} else {
					iceImpact(bolt, at, hitEntity);
				}
				it.remove();
				continue;
			}

			if (bolt.fire) {
				// núcleo brilhante + chamas em volta + fumaça
				bolt.world.spawnParticles(ParticleTypes.LAVA, next.x, next.y, next.z, 1, 0.1, 0.1, 0.1, 0.0);
				bolt.world.spawnParticles(ParticleTypes.FLAME, next.x, next.y, next.z, 8, 0.2, 0.2, 0.2, 0.02);
				bolt.world.spawnParticles(ParticleTypes.SOUL_FIRE_FLAME, next.x, next.y, next.z, 2, 0.1, 0.1, 0.1, 0.0);
				bolt.world.spawnParticles(ParticleTypes.SMOKE, next.x, next.y, next.z, 2, 0.15, 0.15, 0.15, 0.0);
			} else {
				// espiral de gelo + ponta brilhante
				Fx.spiral(bolt.world, ParticleTypes.SNOWFLAKE, next, bolt.velocity, bolt.age, 0.35);
				bolt.world.spawnParticles(ParticleTypes.END_ROD, next.x, next.y, next.z, 2, 0.0, 0.0, 0.0, 0.0);
				bolt.world.spawnParticles(ParticleTypes.SNOWFLAKE, next.x, next.y, next.z, 3, 0.05, 0.05, 0.05, 0.01);
			}
			bolt.pos = next;
		}
	}

	private static void fireImpact(Bolt bolt, Vec3d at) {
		ServerWorld world = bolt.world;
		world.spawnParticles(ParticleTypes.EXPLOSION, at.x, at.y, at.z, 2, 0.4, 0.4, 0.4, 0.0);
		world.spawnParticles(ParticleTypes.FLAME, at.x, at.y, at.z, 60, 0.8, 0.6, 0.8, 0.08);
		world.spawnParticles(ParticleTypes.LARGE_SMOKE, at.x, at.y, at.z, 20, 0.7, 0.5, 0.7, 0.05);
		world.playSound(null, at.x, at.y, at.z,
				SoundEvents.ENTITY_DRAGON_FIREBALL_EXPLODE, SoundCategory.PLAYERS, 1.2f, 1.0f);
		// anéis de fogo expandindo
		Fx.burst(world, ParticleTypes.FLAME, at, 28, 0.35);
		Fx.burst(world, ParticleTypes.SOUL_FIRE_FLAME, at.add(0.0, 0.2, 0.0), 18, 0.2);
		Fx.circle(world, ParticleTypes.FLAME, at.x, at.y + 0.1, at.z, 3.0, 30);

		double radius = 3.5;
		Box area = new Box(at.x - radius, at.y - radius, at.z - radius, at.x + radius, at.y + radius, at.z + radius);
		DamageSource source = world.getDamageSources().playerAttack(bolt.owner);
		for (LivingEntity entity : world.getEntitiesByClass(LivingEntity.class, area,
				e -> e != bolt.owner && e.isAlive() && !e.isSpectator())) {
			double dist = Math.sqrt(entity.squaredDistanceTo(at.x, at.y, at.z));
			if (dist > radius) {
				continue;
			}
			float damage = 3.0f + (float) (10.0 * (1.0 - dist / radius));
			entity.damage(world, source, damage);
			entity.setOnFireFor(6);

			double dx = entity.getX() - at.x;
			double dz = entity.getZ() - at.z;
			double len = Math.sqrt(dx * dx + dz * dz);
			if (len > 0.01) {
				entity.addVelocity(dx / len * 0.6, 0.35, dz / len * 0.6);
			}
		}
	}

	private static void iceImpact(Bolt bolt, Vec3d at, LivingEntity direct) {
		ServerWorld world = bolt.world;
		world.spawnParticles(ParticleTypes.SNOWFLAKE, at.x, at.y, at.z, 50, 0.6, 0.6, 0.6, 0.1);
		world.spawnParticles(ParticleTypes.END_ROD, at.x, at.y, at.z, 15, 0.4, 0.4, 0.4, 0.05);
		world.playSound(null, at.x, at.y, at.z,
				SoundEvents.BLOCK_GLASS_BREAK, SoundCategory.PLAYERS, 1.0f, 0.7f);
		// pilares de gelo e anel de neve
		Fx.icePillars(world, at);
		Fx.burst(world, ParticleTypes.SNOWFLAKE, at, 24, 0.25);

		double radius = 2.0;
		Box area = new Box(at.x - radius, at.y - radius, at.z - radius, at.x + radius, at.y + radius, at.z + radius);
		DamageSource source = world.getDamageSources().playerAttack(bolt.owner);
		for (LivingEntity entity : world.getEntitiesByClass(LivingEntity.class, area,
				e -> e != bolt.owner && e.isAlive() && !e.isSpectator())) {
			if (Math.sqrt(entity.squaredDistanceTo(at.x, at.y, at.z)) > radius) {
				continue;
			}
			entity.damage(world, source, entity == direct ? 8.0f : 3.0f);
			entity.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 120, 3));
			entity.setFrozenTicks(260);
		}
	}

	// --------------------------------------------------------- mãos invisíveis

	/** @return true se algo aconteceu (agarrou ou arremessou), para aplicar o cooldown. */
	private static boolean castUnseenHand(ServerWorld world, ServerPlayerEntity player) {
		Held held = HELD.remove(player.getUuid());
		if (held != null) {
			throwHeld(held);
			return true;
		}

		Vec3d eye = player.getEyePos();
		Vec3d look = player.getRotationVec(1.0f);
		Vec3d far = eye.add(look.multiply(HAND_RANGE));
		BlockHitResult blockHit = world.raycast(new RaycastContext(
				eye, far,
				RaycastContext.ShapeType.COLLIDER,
				RaycastContext.FluidHandling.NONE,
				player));
		Vec3d end = blockHit.getType() == HitResult.Type.MISS ? far : blockHit.getPos();

		LivingEntity target = findTarget(world, player, eye, end, 0.6);
		if (target == null) {
			player.sendMessage(Text.translatable("message.rezero_magic.no_target"), true);
			return false;
		}
		if (!ManaManager.consume(player, MANA_COST[UNSEEN_HAND])) {
			noMana(player);
			return false;
		}

		double dist = MathHelper.clamp(Math.sqrt(player.squaredDistanceTo(target)), 3.0, 8.0);
		HELD.put(player.getUuid(), new Held(world, player, target, dist));
		Fx.magicCircle(world, ParticleTypes.WITCH, ParticleTypes.ENCHANT,
				player.getX(), player.getY() + 0.1, player.getZ(), 1.4);
		Fx.burst(world, ParticleTypes.WITCH,
				new Vec3d(target.getX(), target.getBodyY(0.5), target.getZ()), 20, 0.2);
		world.playSound(null, player.getX(), player.getY(), player.getZ(),
				SoundEvents.ENTITY_EVOKER_CAST_SPELL, SoundCategory.PLAYERS, 1.0f, 0.6f);
		return true;
	}

	private static void tickHands() {
		Iterator<Map.Entry<UUID, Held>> it = HELD.entrySet().iterator();
		while (it.hasNext()) {
			Held held = it.next().getValue();
			LivingEntity target = held.target;

			boolean invalid = held.owner.isRemoved()
					|| target.isRemoved()
					|| !target.isAlive()
					|| held.age++ > HAND_MAX_TICKS
					|| held.owner.squaredDistanceTo(target) > 40.0 * 40.0;
			if (invalid) {
				if (target.isAlive() && !target.isRemoved()) {
					// evita dano de queda ao soltar de longe
					target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOW_FALLING, 60, 0));
				}
				it.remove();
				continue;
			}

			Vec3d eye = held.owner.getEyePos();
			Vec3d look = held.owner.getRotationVec(1.0f);
			Vec3d want = eye.add(look.multiply(held.distance));
			Vec3d have = new Vec3d(target.getX(), target.getBodyY(0.5), target.getZ());

			Vec3d delta = want.subtract(have);
			double len = delta.length();
			if (len > 2.0) {
				delta = delta.multiply(2.0 / len);
			}
			target.setVelocity(0.0, 0.0, 0.0);
			target.addVelocity(delta.x * 0.5, delta.y * 0.5, delta.z * 0.5);

			// várias "mãos" escuras ondulando do peito do jogador até o alvo
			Vec3d chest = new Vec3d(held.owner.getX(), held.owner.getBodyY(0.7), held.owner.getZ());
			Fx.hands(held.world, chest, have, held.age);
			held.world.spawnParticles(ParticleTypes.SMOKE, have.x, have.y, have.z, 3, 0.3, 0.4, 0.3, 0.01);
		}
	}

	private static void throwHeld(Held held) {
		LivingEntity target = held.target;
		if (target.isRemoved() || !target.isAlive()) {
			return;
		}
		Vec3d look = held.owner.getRotationVec(1.0f);
		target.setVelocity(0.0, 0.0, 0.0);
		target.addVelocity(look.x * 2.4, look.y * 2.4 + 0.25, look.z * 2.4);
		target.damage(held.world, held.world.getDamageSources().playerAttack(held.owner), 4.0f);

		Vec3d from = new Vec3d(held.owner.getX(), held.owner.getBodyY(0.7), held.owner.getZ());
		Vec3d to = new Vec3d(target.getX(), target.getBodyY(0.5), target.getZ());
		Fx.line(held.world, ParticleTypes.ENCHANT, from, to, 16);
		Fx.burst(held.world, ParticleTypes.WITCH, to, 28, 0.4);
		held.world.spawnParticles(ParticleTypes.WITCH, to.x, to.y, to.z, 25, 0.4, 0.5, 0.4, 0.1);
		held.world.playSound(null, target.getX(), target.getY(), target.getZ(),
				SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, SoundCategory.PLAYERS, 1.0f, 0.7f);
	}

	// ------------------------------------------------------------------ util

	/** Primeira entidade viva cruzada pelo segmento a->b (com margem extra de hitbox). */
	private static LivingEntity findTarget(ServerWorld world, ServerPlayerEntity owner, Vec3d a, Vec3d b, double grow) {
		Box search = new Box(a, b).expand(grow + 0.5);
		LivingEntity best = null;
		double bestDist = Double.MAX_VALUE;
		for (LivingEntity entity : world.getEntitiesByClass(LivingEntity.class, search,
				e -> e != owner && e.isAlive() && !e.isSpectator())) {
			Optional<Vec3d> hit = entity.getBoundingBox().expand(grow).raycast(a, b);
			if (hit.isPresent()) {
				double d = a.squaredDistanceTo(hit.get());
				if (d < bestDist) {
					bestDist = d;
					best = entity;
				}
			}
		}
		return best;
	}
}
