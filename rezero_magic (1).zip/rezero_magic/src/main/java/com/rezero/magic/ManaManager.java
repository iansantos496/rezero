package com.rezero.magic;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.network.ServerPlayerEntity;

/** Mana por jogador (guardada em memória; volta a encher ao entrar no mundo). */
public final class ManaManager {
	public static final int MAX_MANA = 100;
	/** 1 ponto de mana a cada N ticks (20 ticks = 1 segundo). */
	private static final int REGEN_INTERVAL_TICKS = 6;

	private static final Map<UUID, Integer> MANA = new HashMap<>();

	private ManaManager() {}

	public static int get(ServerPlayerEntity player) {
		return MANA.getOrDefault(player.getUuid(), MAX_MANA);
	}

	public static boolean consume(ServerPlayerEntity player, int amount) {
		int current = get(player);
		if (current < amount) {
			return false;
		}
		MANA.put(player.getUuid(), current - amount);
		sync(player);
		return true;
	}

	public static void refill(ServerPlayerEntity player) {
		MANA.put(player.getUuid(), MAX_MANA);
		sync(player);
	}

	public static void sync(ServerPlayerEntity player) {
		ServerPlayNetworking.send(player, new ManaSyncPayload(get(player), MAX_MANA));
	}

	public static void init() {
		ServerTickEvents.END_SERVER_TICK.register(server -> {
			if (server.getTicks() % REGEN_INTERVAL_TICKS != 0) {
				return;
			}
			for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
				int current = get(player);
				if (current < MAX_MANA) {
					MANA.put(player.getUuid(), current + 1);
					sync(player);
				}
			}
		});

		ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> refill(handler.getPlayer()));

		ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> refill(newPlayer));

		ServerLifecycleEvents.SERVER_STOPPED.register(server -> MANA.clear());
	}
}
