package com.rezero.magic;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;

/**
 * Nível e XP por jogador. Cada magia lançada dá XP.
 * O progresso é salvo em config/rezero_magic_progress.properties (vale para todos os mundos).
 */
public final class Progression {
	public static final int MAX_LEVEL = 20;

	/** UUID -> {nível, xp atual} */
	private static final Map<UUID, int[]> DATA = new HashMap<>();

	private Progression() {}

	private static Path file() {
		return FabricLoader.getInstance().getConfigDir().resolve("rezero_magic_progress.properties");
	}

	public static void init() {
		ServerLifecycleEvents.SERVER_STARTED.register(server -> load());
		ServerLifecycleEvents.SERVER_STOPPING.register(server -> save());
	}

	private static void load() {
		DATA.clear();
		Path path = file();
		if (!Files.exists(path)) {
			return;
		}
		Properties props = new Properties();
		try (InputStream in = Files.newInputStream(path)) {
			props.load(in);
		} catch (IOException e) {
			return;
		}
		for (String key : props.stringPropertyNames()) {
			if (!key.endsWith(".level")) {
				continue;
			}
			try {
				String id = key.substring(0, key.length() - ".level".length());
				UUID uuid = UUID.fromString(id);
				int level = Integer.parseInt(props.getProperty(key));
				int xp = Integer.parseInt(props.getProperty(id + ".xp", "0"));
				DATA.put(uuid, new int[] {Math.max(1, Math.min(MAX_LEVEL, level)), Math.max(0, xp)});
			} catch (IllegalArgumentException ignored) {
				// linha inválida: ignora
			}
		}
	}

	public static void save() {
		Properties props = new Properties();
		for (Map.Entry<UUID, int[]> e : DATA.entrySet()) {
			props.setProperty(e.getKey() + ".level", Integer.toString(e.getValue()[0]));
			props.setProperty(e.getKey() + ".xp", Integer.toString(e.getValue()[1]));
		}
		try (OutputStream out = Files.newOutputStream(file())) {
			props.store(out, "Re:Zero Magic - progresso dos jogadores");
		} catch (IOException ignored) {
			// sem permissão de escrita: o progresso só vale nesta sessão
		}
	}

	private static int[] data(ServerPlayerEntity player) {
		return DATA.computeIfAbsent(player.getUuid(), k -> new int[] {1, 0});
	}

	public static int level(ServerPlayerEntity player) {
		return data(player)[0];
	}

	public static int xp(ServerPlayerEntity player) {
		return data(player)[1];
	}

	/** XP necessário para sair deste nível (0 no nível máximo). */
	public static int xpNeeded(int level) {
		return level >= MAX_LEVEL ? 0 : 40 + level * 20;
	}

	public static int maxMana(ServerPlayerEntity player) {
		return ManaManager.MAX_MANA + (level(player) - 1) * 10;
	}

	public static float damageMultiplier(ServerPlayerEntity player) {
		return 1.0f + (level(player) - 1) * 0.06f;
	}

	/** Quanto de mana volta a cada intervalo de regeneração. */
	public static int regenAmount(ServerPlayerEntity player) {
		return 1 + (level(player) - 1) / 7;
	}

	public static void addXp(ServerWorld world, ServerPlayerEntity player, int amount) {
		int[] d = data(player);
		if (d[0] >= MAX_LEVEL) {
			return;
		}
		d[1] += amount;
		boolean levelUp = false;
		while (d[0] < MAX_LEVEL && d[1] >= xpNeeded(d[0])) {
			d[1] -= xpNeeded(d[0]);
			d[0]++;
			levelUp = true;
		}
		if (d[0] >= MAX_LEVEL) {
			d[1] = 0;
		}

		if (levelUp) {
			player.sendMessage(Text.translatable("message.rezero_magic.level_up", d[0]), false);
			world.playSound(null, player.getX(), player.getY(), player.getZ(),
					SoundEvents.ENTITY_PLAYER_LEVELUP, SoundCategory.PLAYERS, 1.0f, 1.0f);
			Fx.magicCircle(world, ParticleTypes.END_ROD, ParticleTypes.ENCHANT,
					player.getX(), player.getY() + 0.1, player.getZ(), 1.8);
			world.spawnParticles(ParticleTypes.ENCHANT, player.getX(), player.getY() + 1.0, player.getZ(),
					40, 0.6, 0.8, 0.6, 0.5);
			save();
			ManaManager.refill(player);
		} else {
			ManaManager.sync(player);
		}
	}
}
