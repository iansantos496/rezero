package com.rezero.magic;

import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;

public final class ModNetworking {
	private ModNetworking() {}

	public static void registerCommon() {
		PayloadTypeRegistry.playC2S().register(CastSpellPayload.ID, CastSpellPayload.CODEC);
		PayloadTypeRegistry.playS2C().register(ManaSyncPayload.ID, ManaSyncPayload.CODEC);

		ServerPlayNetworking.registerGlobalReceiver(CastSpellPayload.ID, (payload, context) ->
				SpellCaster.cast(context.server(), context.player(), payload.spell()));
	}
}
