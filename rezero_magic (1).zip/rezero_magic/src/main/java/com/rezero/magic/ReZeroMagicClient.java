package com.rezero.magic;

import org.lwjgl.glfw.GLFW;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class ReZeroMagicClient implements ClientModInitializer {
	private static volatile int mana = ManaManager.MAX_MANA;
	private static volatile int maxMana = ManaManager.MAX_MANA;

	private static KeyBinding fireballKey;
	private static KeyBinding iceLanceKey;
	private static KeyBinding unseenHandKey;

	@Override
	public void onInitializeClient() {
		// Em 1.21.9+ a categoria de teclas é um objeto, não mais uma String.
		KeyBinding.Category category = KeyBinding.Category.create(Identifier.of(ReZeroMagic.MOD_ID, "magic"));

		fireballKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.rezero_magic.fireball", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_R, category));
		iceLanceKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.rezero_magic.ice_lance", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_G, category));
		unseenHandKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.rezero_magic.unseen_hand", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_V, category));

		ClientPlayNetworking.registerGlobalReceiver(ManaSyncPayload.ID, (payload, context) -> {
			mana = payload.mana();
			maxMana = payload.maxMana();
		});

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			if (client.player == null) {
				return;
			}
			send(fireballKey, SpellCaster.FIREBALL, client);
			send(iceLanceKey, SpellCaster.ICE_LANCE, client);
			send(unseenHandKey, SpellCaster.UNSEEN_HAND, client);
		});

		// HudRenderCallback está marcado como deprecated nas versões novas do Fabric API,
		// mas continua funcionando. Se for removido, troque por HudElementRegistry.
		HudRenderCallback.EVENT.register((context, tickCounter) -> {
			MinecraftClient client = MinecraftClient.getInstance();
			if (client.player == null || client.options.hudHidden) {
				return;
			}
			int x = 10;
			int y = 10;
			int width = 100;
			int height = 8;
			int filled = width * mana / Math.max(1, maxMana);

			context.fill(x - 1, y - 1, x + width + 1, y + height + 1, 0xAA000000);
			context.fill(x, y, x + filled, y + height, 0xFF3A7BFF);
			context.drawTextWithShadow(client.textRenderer,
					Text.translatable("hud.rezero_magic.mana", mana, maxMana),
					x, y + height + 3, 0xFFFFFFFF);
		});
	}

	private static void send(KeyBinding key, int spell, MinecraftClient client) {
		while (key.wasPressed()) {
			if (client.currentScreen == null) {
				ClientPlayNetworking.send(new CastSpellPayload(spell));
			}
		}
	}
}
