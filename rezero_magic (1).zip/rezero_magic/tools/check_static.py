#!/usr/bin/env python3
"""Verificações estáticas do projeto (não substituem compilar com o Minecraft)."""
import json
import pathlib
import re
import sys

root = pathlib.Path(__file__).resolve().parent.parent
errors = []

# 1. JSON válido
for f in root.rglob("*.json"):
    try:
        json.loads(f.read_text(encoding="utf-8"))
    except Exception as e:  # noqa: BLE001
        errors.append(f"JSON inválido: {f.relative_to(root)}: {e}")

# 2. Java: chaves/parênteses, pacote x pasta, imports não usados
for f in (root / "src").rglob("*.java"):
    s = f.read_text(encoding="utf-8")
    t = re.sub(r'"(\\.|[^"\\])*"', '""', s)
    t = re.sub(r"//.*", "", t)
    t = re.sub(r"/\*.*?\*/", "", t, flags=re.S)
    if t.count("{") != t.count("}") or t.count("(") != t.count(")"):
        errors.append(f"Chaves ou parênteses desbalanceados: {f.relative_to(root)}")
    m = re.search(r"^package ([\w.]+);", s, flags=re.M)
    expected = ".".join(f.parent.relative_to(root / "src/main/java").parts)
    if not m or m.group(1) != expected:
        errors.append(f"Pacote não confere com a pasta: {f.relative_to(root)}")
    for imp in re.findall(r"^import [\w.]+\.(\w+);", s, flags=re.M):
        if len(re.findall(r"\b" + imp + r"\b", s)) < 2:
            errors.append(f"Import não usado ({imp}): {f.relative_to(root)}")

# 3. Chaves de tradução usadas no código existem em pt_br e en_us
lang_dir = root / "src/main/resources/assets/rezero_magic/lang"
langs = {p.name: set(json.loads(p.read_text(encoding="utf-8"))) for p in lang_dir.glob("*.json")}
if "pt_br.json" in langs and "en_us.json" in langs and langs["pt_br.json"] != langs["en_us.json"]:
    errors.append("pt_br.json e en_us.json têm chaves diferentes: " + str(langs["pt_br.json"] ^ langs["en_us.json"]))
used = set()
for f in (root / "src").rglob("*.java"):
    used |= set(re.findall(r'"((?:[a-z_]+)\.rezero_magic\.[\w.]+)"', f.read_text(encoding="utf-8")))
for key in sorted(k for k in used if not k.endswith('.') and not k.endswith('_')):
    for name, keys in langs.items():
        if key not in keys:
            errors.append(f"Chave de tradução ausente em {name}: {key}")

# 3b. Chaves dinâmicas: toda afinidade precisa de nome, .canon e .game nos dois idiomas
aff_src = (root / "src/main/java/com/rezero/mod/core/Affinity.java").read_text(encoding="utf-8")
for k in re.findall(r'\(\d+,\s*"(\w+)"\)', aff_src):
    for suffix in ("", ".canon", ".game"):
        for name, keys in langs.items():
            if f"affinity.rezero_magic.{k}{suffix}" not in keys:
                errors.append(f"Chave de afinidade ausente em {name}: affinity.rezero_magic.{k}{suffix}")


# 3c. Feitiços: nome traduzido; resultados de CastRules: mensagem traduzida
spell_src = (root / "src/main/java/com/rezero/mod/core/Spells.java").read_text(encoding="utf-8")
spell_keys = re.findall(r'new SpellDef\(\w+,\s*"(\w+)"', spell_src)
if len(spell_keys) != len(set(spell_keys)):
    errors.append("Chaves de feitiço repetidas em Spells.java")
for k in spell_keys:
    for name, keys in langs.items():
        if f"spell.rezero_magic.{k}" not in keys:
            errors.append(f"Nome de feitiço ausente em {name}: spell.rezero_magic.{k}")
rules_src = (root / "src/main/java/com/rezero/mod/core/CastRules.java").read_text(encoding="utf-8")
enum_body = re.search(r"enum Result \{(.*?)\}", rules_src, flags=re.S).group(1)
for r in re.findall(r"[A-Z_]{2,}", enum_body):
    if r == "OK":
        continue
    for name, keys in langs.items():
        if f"message.rezero_magic.cast.{r.lower()}" not in keys:
            errors.append(f"Mensagem de conjuração ausente em {name}: cast.{r.lower()}")
for extra in ("interrupted", "failed", "full_health", "no_target"):
    for name, keys in langs.items():
        if f"message.rezero_magic.cast.{extra}" not in keys:
            errors.append(f"Mensagem de conjuração ausente em {name}: cast.{extra}")

# 3d. Todo pacote (CustomPayload) é registrado em ModNetworking
net_dir = root / "src/main/java/com/rezero/mod/net"
net_src = (net_dir / "ModNetworking.java").read_text(encoding="utf-8")
for f in net_dir.glob("*Payload.java"):
    cls = f.stem
    if f"{cls}.ID" not in net_src:
        errors.append(f"Pacote não registrado em ModNetworking: {cls}")


# 3e. Todo item/bloco registrado tem modelo, textura, definição de item, tradução (e bloco: blockstate e loot table)
content = root / "src/main/java/com/rezero/mod/content"
res = root / "src/main/resources"
assets = res / "assets/rezero_magic"
reg_items = set(re.findall(r'register\("(\w+)"', (content / "ModItems.java").read_text(encoding="utf-8")))
for enum_file in ("CrystalRarity", "Catalyst", "Charm"):
    reg_items |= set(re.findall(r'\(\d+,\s*"(\w+)"', (root / f"src/main/java/com/rezero/mod/core/{enum_file}.java").read_text(encoding="utf-8")))
reg_blocks = set(re.findall(r'register\("(\w+)"', (content / "ModBlocks.java").read_text(encoding="utf-8")))
core_dir = root / "src/main/java/com/rezero/mod/core"
robe_keys = re.findall(r'\(\d+,\s*"(\w+)"', (core_dir / "RobeSet.java").read_text(encoding="utf-8"))
robe_suffixes = re.findall(r'\(\d+,\s*"(\w+)"', (core_dir / "RobePiece.java").read_text(encoding="utf-8"))
reg_items |= {f"{k}_{sfx}" for k in robe_keys for sfx in robe_suffixes}
for name in sorted(reg_items):
    for rel in (f"models/item/{name}.json", f"items/{name}.json", f"textures/item/{name}.png"):
        if not (assets / rel).exists():
            errors.append(f"Asset ausente para item {name}: {rel}")
    for lname, keys in langs.items():
        if f"item.rezero_magic.{name}" not in keys:
            errors.append(f"Tradução de item ausente em {lname}: item.rezero_magic.{name}")
for name in sorted(reg_blocks):
    for rel in (f"blockstates/{name}.json", f"models/block/{name}.json", f"items/{name}.json", f"textures/block/{name}.png"):
        if not (assets / rel).exists():
            errors.append(f"Asset ausente para bloco {name}: {rel}")
    if not (res / f"data/rezero_magic/loot_table/blocks/{name}.json").exists():
        errors.append(f"Loot table ausente para bloco {name}")
    for lname, keys in langs.items():
        if f"block.rezero_magic.{name}" not in keys:
            errors.append(f"Tradução de bloco ausente em {lname}: block.rezero_magic.{name}")
for f in res.rglob("*.json"):
    try:
        json.loads(f.read_text(encoding="utf-8"))
    except ValueError as e:
        errors.append(f"JSON inválido: {f.relative_to(root)} ({e})")
for rel in ("data/rezero_magic/worldgen/configured_feature/mana_crystal_ore.json", "data/rezero_magic/worldgen/placed_feature/mana_crystal_ore.json"):
    if not (res / rel).exists():
        errors.append(f"Geração de mundo ausente: {rel}")


# 3f. Inscrições: nome e descrição; resultados de InscriptionRules: mensagem; categorias do Hub
insc_src = (root / "src/main/java/com/rezero/mod/core/Inscription.java").read_text(encoding="utf-8")
insc_keys = re.findall(r'^\t[A-Z_]+\(\d+,\s*"(\w+)"', insc_src, flags=re.M)
if len(insc_keys) != 12:
    errors.append(f"Esperava 12 inscrições, achei {len(insc_keys)}")
for k in insc_keys:
    for name, keys in langs.items():
        for suffix in ("", ".desc"):
            if f"inscription.rezero_magic.{k}{suffix}" not in keys:
                errors.append(f"Texto de inscrição ausente em {name}: inscription.rezero_magic.{k}{suffix}")
irules = (root / "src/main/java/com/rezero/mod/core/InscriptionRules.java").read_text(encoding="utf-8")
ienum = re.search(r"enum Result \{(.*?)\}", irules, flags=re.S).group(1)
for r in re.findall(r"[A-Z_]{2,}", ienum):
    if r == "OK":
        continue
    for name, keys in langs.items():
        if f"message.rezero_magic.inscription.{r.lower()}" not in keys:
            errors.append(f"Mensagem de inscrição ausente em {name}: inscription.{r.lower()}")
for cat in ("power", "economy", "defense", "utility"):
    for name, keys in langs.items():
        if f"screen.rezero_magic.hub.category_{cat}" not in keys:
            errors.append(f"Categoria ausente em {name}: category_{cat}")
for conj in robe_keys:
    if not (assets / f"equipment/{conj}.json").exists():
        errors.append(f"Definição de equipamento (veste) ausente: equipment/{conj}.json")
    for layer in ("humanoid", "humanoid_leggings"):
        if not (assets / f"textures/entity/equipment/{layer}/{conj}.png").exists():
            errors.append(f"Textura vestida ausente: {layer}/{conj}.png")


# 3g. Treinamento: nome e descrição de cada atributo; toda mensagem enviada com message(player, "x") existe nos idiomas
train_src = (root / "src/main/java/com/rezero/mod/core/TrainingAttribute.java").read_text(encoding="utf-8")
train_keys = re.findall(r'^\t[A-Z_]+\(\d+,\s*"(\w+)"\)', train_src, flags=re.M)
if len(train_keys) != 5:
    errors.append(f"Esperava 5 atributos de treino, achei {len(train_keys)}")
for k in train_keys:
    for name, keys in langs.items():
        for suffix in ("", ".desc"):
            if f"training.rezero_magic.{k}{suffix}" not in keys:
                errors.append(f"Texto de treino ausente em {name}: training.rezero_magic.{k}{suffix}")
for f in (root / "src/main/java/com/rezero/mod/server").glob("*.java"):
    text = f.read_text(encoding="utf-8")
    # cada serviço tem o seu auxiliar message(); descobre o prefixo que ele usa (ex.: "crystal.")
    helper = re.search(r'translatable\("message\.rezero_magic\.([\w.]*)"\s*\+\s*key\)', text)
    prefix = helper.group(1) if helper else ""
    for key in re.findall(r'\bmessage\(\s*\w+,\s*"([\w.]+)"\s*\)', text):
        for name, keys in langs.items():
            if f"message.rezero_magic.{prefix}{key}" not in keys:
                errors.append(f"Mensagem ausente em {name}: message.rezero_magic.{prefix}{key} ({f.name})")


# 3h. Combate: técnicas (nome e descrição), estilos, resultados de uso/aprendizado (mensagens e motivos no Hub), lanças
tech_src = (root / "src/main/java/com/rezero/mod/core/Techniques.java").read_text(encoding="utf-8")
tech_keys = re.findall(r'new TechniqueDef\(\w+,\s*"(\w+)"', tech_src)
if len(tech_keys) != 15 or len(set(tech_keys)) != 15:
    errors.append(f"Esperava 15 técnicas únicas, achei {len(tech_keys)}")
for k in tech_keys:
    for name, keys in langs.items():
        for suffix in ("", ".desc"):
            if f"technique.rezero_magic.{k}{suffix}" not in keys:
                errors.append(f"Texto de técnica ausente em {name}: technique.rezero_magic.{k}{suffix}")
style_src = (root / "src/main/java/com/rezero/mod/core/CombatStyle.java").read_text(encoding="utf-8")
for k in re.findall(r'^\t[A-Z_]+\(\d+,\s*"(\w+)"\)', style_src, flags=re.M):
    for name, keys in langs.items():
        if f"style.rezero_magic.{k}" not in keys:
            errors.append(f"Nome de estilo ausente em {name}: style.rezero_magic.{k}")
rules_src = (root / "src/main/java/com/rezero/mod/core/CombatRules.java").read_text(encoding="utf-8")
use_enum = re.search(r"enum UseResult \{(.*?)\}", rules_src, flags=re.S).group(1)
for r in re.findall(r"[A-Z_]{2,}", use_enum):
    if r != "OK":
        for name, keys in langs.items():
            if f"message.rezero_magic.combat.{r.lower()}" not in keys:
                errors.append(f"Mensagem de combate ausente em {name}: combat.{r.lower()}")
learn_enum = re.search(r"enum LearnResult \{(.*?)\}", rules_src, flags=re.S).group(1)
for r in re.findall(r"[A-Z_]{2,}", learn_enum):
    if r != "OK":
        for name, keys in langs.items():
            for key in (f"message.rezero_magic.combat.learn_{r.lower()}", f"screen.rezero_magic.hub.learn_reason_{r.lower()}"):
                if key not in keys:
                    errors.append(f"Texto de aprendizado ausente em {name}: {key}")
for sp in ("mana_spear", "crystal_spear"):
    for rel in (f"assets/rezero_magic/textures/item/{sp}.png", f"assets/rezero_magic/models/item/{sp}.json",
                f"assets/rezero_magic/items/{sp}.json", f"data/rezero_magic/recipe/{sp}.json"):
        if not (root / "src/main/resources" / rel).exists():
            errors.append(f"Arquivo da lança ausente: {rel}")
    for name, keys in langs.items():
        if f"item.rezero_magic.{sp}" not in keys:
            errors.append(f"Nome da lança ausente em {name}: {sp}")

# 3i. Espíritos: nomes/textos por elemento, resultados de contrato e habilidade, item da Pedra de Contrato
spirit_src = (root / "src/main/java/com/rezero/mod/core/SpiritRules.java").read_text(encoding="utf-8")
for enum_name, prefix in (("ContractResult", "contract_"), ("ActiveResult", "active_")):
    body = re.search(r"enum " + enum_name + r" \{(.*?)\}", spirit_src, flags=re.S).group(1)
    for r in re.findall(r"[A-Z_]{2,}", body):
        if r != "OK":
            for name, keys in langs.items():
                if f"message.rezero_magic.spirit.{prefix}{r.lower()}" not in keys:
                    errors.append(f"Mensagem de espírito ausente em {name}: spirit.{prefix}{r.lower()}")
aff_src = (root / "src/main/java/com/rezero/mod/core/Affinity.java").read_text(encoding="utf-8")
for k in re.findall(r'^\t[A-Z_]+\(\d+,\s*"(\w+)"\)', aff_src, flags=re.M):
    for name, keys in langs.items():
        for suffix in ("", ".where", ".temperament", ".passive", ".active"):
            if f"spirit.rezero_magic.{k}{suffix}" not in keys:
                errors.append(f"Texto de espírito ausente em {name}: spirit.rezero_magic.{k}{suffix}")
for rel in ("assets/rezero_magic/textures/item/spirit_contract_stone.png", "assets/rezero_magic/models/item/spirit_contract_stone.json",
            "assets/rezero_magic/items/spirit_contract_stone.json", "data/rezero_magic/recipe/spirit_contract_stone.json"):
    if not (root / "src/main/resources" / rel).exists():
        errors.append(f"Arquivo da Pedra de Contrato ausente: {rel}")
for name, keys in langs.items():
    if "item.rezero_magic.spirit_contract_stone" not in keys:
        errors.append(f"Nome da Pedra de Contrato ausente em {name}")

# 3j. Raças: nomes e textos por raça, transformação (só quem tem), resultados da habilidade, mensagens
race_src = (root / "src/main/java/com/rezero/mod/core/Race.java").read_text(encoding="utf-8")
race_keys = re.findall(r'^\t[A-Z_]+\(\d+,\s*"(\w+)"\)', race_src, flags=re.M)
if len(race_keys) != 4:
    errors.append(f"Esperava 4 raças, achei {len(race_keys)}")
for k in race_keys:
    suffixes = ["", ".canon", ".pros", ".cons", ".ability"] + ([".form"] if k in ("demi_human", "oni") else [])
    for name, keys in langs.items():
        for suffix in suffixes:
            if f"race.rezero_magic.{k}{suffix}" not in keys:
                errors.append(f"Texto de raça ausente em {name}: race.rezero_magic.{k}{suffix}")
        if k in ("demi_human", "oni"):
            for pre in ("form_start_", "form_end_"):
                if f"message.rezero_magic.race.{pre}{k}" not in keys:
                    errors.append(f"Mensagem de forma ausente em {name}: race.{pre}{k}")
rr_src = (root / "src/main/java/com/rezero/mod/core/RaceRules.java").read_text(encoding="utf-8")
rr_enum = re.search(r"enum ActiveResult \{(.*?)\}", rr_src, flags=re.S).group(1)
for r in re.findall(r"[A-Z_]{2,}", rr_enum):
    if r != "OK":
        for name, keys in langs.items():
            if f"message.rezero_magic.race.active_{r.lower()}" not in keys:
                errors.append(f"Mensagem de raça ausente em {name}: race.active_{r.lower()}")

# 3k. Proteções Divinas: textos por proteção, resultados de pedido e da ativa
prot_src = (root / "src/main/java/com/rezero/mod/core/DivineProtection.java").read_text(encoding="utf-8")
prot_keys = re.findall(r'^\t[A-Z_]+\(\d+,\s*"(\w+)"', prot_src, flags=re.M)
if len(prot_keys) != 5:
    errors.append(f"Esperava 5 proteções, achei {len(prot_keys)}")
for k in prot_keys:
    for name, keys in langs.items():
        for suffix in ("", ".canon", ".effect", ".limit", ".req"):
            if f"protection.rezero_magic.{k}{suffix}" not in keys:
                errors.append(f"Texto de proteção ausente em {name}: protection.rezero_magic.{k}{suffix}")
pr_src = (root / "src/main/java/com/rezero/mod/core/ProtectionRules.java").read_text(encoding="utf-8")
for enum_name, prefix in (("ClaimResult", "claim_"), ("ActiveResult", "active_")):
    body = re.search(r"enum " + enum_name + r" \{(.*?)\}", pr_src, flags=re.S).group(1)
    for r in re.findall(r"[A-Z_]{2,}", body):
        if r != "OK":
            for name, keys in langs.items():
                if f"message.rezero_magic.protection.{prefix}{r.lower()}" not in keys:
                    errors.append(f"Mensagem de proteção ausente em {name}: protection.{prefix}{r.lower()}")

# 3l. Transformações: textos por forma, resultados das condições e mensagens de início/fim
tr_src = (root / "src/main/java/com/rezero/mod/core/Transformation.java").read_text(encoding="utf-8")
tr_keys = re.findall(r'^\t[A-Z_]+\(\d+,\s*"(\w+)",\s*Kind', tr_src, flags=re.M)
if len(tr_keys) != 4:
    errors.append(f"Esperava 4 transformações, achei {len(tr_keys)}")
for k in tr_keys:
    for name, keys in langs.items():
        for suffix in ("", ".canon", ".req", ".effect", ".side"):
            if f"transform.rezero_magic.{k}{suffix}" not in keys:
                errors.append(f"Texto de transformação ausente em {name}: transform.rezero_magic.{k}{suffix}")
        if k in ("attunement", "last_stand"):
            for pre in ("start_", "end_"):
                if f"message.rezero_magic.transform.{pre}{k}" not in keys:
                    errors.append(f"Mensagem de transformação ausente em {name}: transform.{pre}{k}")
trr_src = (root / "src/main/java/com/rezero/mod/core/TransformationRules.java").read_text(encoding="utf-8")
trr_enum = re.search(r"enum Result \{(.*?)\}", trr_src, flags=re.S).group(1)
for r in re.findall(r"[A-Z_]{2,}", trr_enum):
    if r not in ("OK", "NOT_SELF_ACTIVATED"):
        for name, keys in langs.items():
            if f"message.rezero_magic.transform.fail_{r.lower()}" not in keys:
                errors.append(f"Mensagem de transformação ausente em {name}: transform.fail_{r.lower()}")
for kind in ("racial", "spirit", "emergency"):
    for name, keys in langs.items():
        if f"screen.rezero_magic.hub.form_kind_{kind}" not in keys:
            errors.append(f"Tipo de transformação ausente em {name}: form_kind_{kind}")

# 3m. Auditoria de integração (E11): pacotes registrados e com receptor, serviços ligados, teclas sem repetição
net_dir = root / "src/main/java/com/rezero/mod/net"
networking = (net_dir / "ModNetworking.java").read_text(encoding="utf-8")
client_main = (root / "src/main/java/com/rezero/mod/client/ReZeroModClient.java").read_text(encoding="utf-8")
for f in sorted(net_dir.glob("*Payload.java")):
    n = f.stem
    m = re.search(r"PayloadTypeRegistry\.play(C2S|S2C)\(\)\.register\(" + n + r"\.ID", networking)
    if not m:
        errors.append(f"Pacote sem registro em ModNetworking: {n}")
        continue
    if m.group(1) == "C2S" and not re.search(r"ServerPlayNetworking\.registerGlobalReceiver\(\s*" + n + r"\.ID", networking):
        errors.append(f"Pacote do cliente sem receptor no servidor: {n}")
    if m.group(1) == "S2C" and not re.search(r"ClientPlayNetworking\.registerGlobalReceiver\(\s*" + n + r"\.ID", client_main):
        errors.append(f"Pacote do servidor sem receptor no cliente: {n}")
main_src = (root / "src/main/java/com/rezero/mod/ReZeroMod.java").read_text(encoding="utf-8")
events_src = (root / "src/main/java/com/rezero/mod/server/ServerEvents.java").read_text(encoding="utf-8")
for f in sorted((root / "src/main/java/com/rezero/mod/server").glob("*Service.java")):
    n = f.stem
    src = f.read_text(encoding="utf-8")
    if "static void init(" in src and f"{n}.init()" not in main_src:
        errors.append(f"Serviço com init() não chamado em ReZeroMod: {n}")
    if "static void reset(" in src and events_src.count(f"{n}.reset(") < 2:
        errors.append(f"Serviço com reset() não chamado ao entrar E ao renascer em ServerEvents: {n}")
keys_used = re.findall(r"GLFW\.(GLFW_KEY_[A-Z0-9_]+)", client_main)
for k in set(keys_used):
    if keys_used.count(k) > 1:
        errors.append(f"Tecla padrão repetida em ReZeroModClient: {k}")
key_names = [k for k in re.findall(r'"(key\.rezero_magic\.[\w]+)"', client_main) if not k.endswith("_")]
key_names += [f"key.rezero_magic.technique_{i}" for i in (1, 2, 3)]  # nome dinâmico: "technique_" + (i + 1)
for kb in key_names:
    for name, keys in langs.items():
        if kb not in keys:
            errors.append(f"Nome de tecla sem tradução em {name}: {kb}")

# 4. fabric.mod.json: entrypoint existe
mod = json.loads((root / "src/main/resources/fabric.mod.json").read_text(encoding="utf-8"))
for kind, entries in mod.get("entrypoints", {}).items():
    for cls in entries:
        path = root / "src/main/java" / (cls.replace(".", "/") + ".java")
        if not path.exists():
            errors.append(f"Entrypoint '{kind}' aponta para classe inexistente: {cls}")

if errors:
    print("PROBLEMAS ENCONTRADOS:")
    for e in errors:
        print(" -", e)
    sys.exit(1)
print("Verificação estática OK (JSON, chaves, pacotes, imports, traduções, entrypoints).")
