import com.rezero.mod.core.Affinity;
import com.rezero.mod.core.AffinityPicker;
import com.rezero.mod.core.AffinityRules;
import com.rezero.mod.core.CastModifiers;
import com.rezero.mod.core.CastRules;
import com.rezero.mod.core.Catalyst;
import com.rezero.mod.core.Charm;
import com.rezero.mod.core.EquipmentRules;
import com.rezero.mod.core.Inscription;
import com.rezero.mod.core.InscriptionRules;
import com.rezero.mod.core.RobePiece;
import com.rezero.mod.core.RobeSet;
import com.rezero.mod.core.ChannelModel;
import com.rezero.mod.core.CrystalRarity;
import com.rezero.mod.core.CrystalRules;
import com.rezero.mod.core.SpellDef;
import com.rezero.mod.core.CombatRules;
import com.rezero.mod.core.CombatStyle;
import com.rezero.mod.core.DivineProtection;
import com.rezero.mod.core.ProtectionRules;
import com.rezero.mod.core.Race;
import com.rezero.mod.core.RaceRules;
import com.rezero.mod.core.SpiritRules;
import com.rezero.mod.core.Spells;
import com.rezero.mod.core.TechniqueDef;
import com.rezero.mod.core.Techniques;
import com.rezero.mod.core.Transformation;
import com.rezero.mod.core.TransformationRules;
import com.rezero.mod.core.TrainingAttribute;
import com.rezero.mod.core.TrainingModel;

/** Testes do código puro (sem Minecraft). Rodar com tools/test_core.sh. */
public class CoreTests {
	private static int passed = 0;
	private static int failed = 0;

	private static void check(String name, boolean condition) {
		if (condition) {
			passed++;
			System.out.println("OK    " + name);
		} else {
			failed++;
			System.out.println("FALHA " + name);
		}
	}

	public static void main(String[] args) {
		// ids são fixos e únicos
		check("seis afinidades", Affinity.values().length == 6);
		boolean idsOk = true;
		for (int i = 0; i < Affinity.values().length; i++) {
			if (Affinity.values()[i].id() != i || Affinity.fromId(i) != Affinity.values()[i]) {
				idsOk = false;
			}
		}
		check("ids 0..5 em ordem e fromId coerente", idsOk);
		check("id inválido negativo vira null", Affinity.fromId(-1) == null);
		check("id inválido grande vira null", Affinity.fromId(6) == null);
		check("id absurdo vira null", Affinity.fromId(Integer.MAX_VALUE) == null);
		check("ordem do prompt: fogo, água, vento, terra, yin, yang",
				Affinity.FIRE.id() == 0 && Affinity.WATER.id() == 1 && Affinity.WIND.id() == 2
						&& Affinity.EARTH.id() == 3 && Affinity.YIN.id() == 4 && Affinity.YANG.id() == 5);

		// escolha única
		check("sem afinidade pode escolher uma válida", AffinityRules.canChoose(null, Affinity.FIRE));
		check("pedido nulo (id inválido) é recusado", !AffinityRules.canChoose(null, null));
		boolean noSwap = true;
		for (Affinity a : Affinity.values()) {
			for (Affinity b : Affinity.values()) {
				if (AffinityRules.canChoose(a, b)) {
					noSwap = false;
				}
			}
		}
		check("depois de escolher, nenhuma troca é aceita (36 combinações)", noSwap);

		// uso de poderes
		check("sem afinidade escolhida, nenhum poder é liberado", !AffinityRules.canUse(null, Affinity.FIRE));
		boolean onlyOwn = true;
		for (Affinity chosen : Affinity.values()) {
			for (Affinity required : Affinity.values()) {
				boolean allowed = AffinityRules.canUse(chosen, required);
				if (allowed != (chosen == required)) {
					onlyOwn = false;
				}
			}
		}
		check("só libera poder da própria afinidade (36 combinações)", onlyOwn);
		check("poder sem afinidade definida é recusado", !AffinityRules.canUse(Affinity.FIRE, null));

		// dados salvos/recebidos adulterados ou corrompidos
		check("normalizeId mantém ids válidos", AffinityRules.normalizeId(0) == 0 && AffinityRules.normalizeId(5) == 5);
		check("normalizeId: -1 continua -1", AffinityRules.normalizeId(-1) == -1);
		check("normalizeId: 6, 99 e valores extremos viram -1",
				AffinityRules.normalizeId(6) == -1 && AffinityRules.normalizeId(99) == -1
						&& AffinityRules.normalizeId(Integer.MIN_VALUE) == -1
						&& AffinityRules.normalizeId(Integer.MAX_VALUE) == -1);

		// fluxo da tela: escolher -> confirmar -> enviar
		AffinityPicker p0 = new AffinityPicker();
		check("tela começa sem seleção e sem confirmação", p0.selected() == null && !p0.confirming());
		check("sem seleção, pedir confirmação não faz nada", !p0.requestConfirm().confirming());
		check("sem seleção, nada a enviar", p0.choiceToSend() == null);
		AffinityPicker p1 = p0.select(Affinity.WIND);
		check("selecionar guarda o cartão, ainda sem confirmar", p1.selected() == Affinity.WIND && !p1.confirming());
		check("selecionado mas não confirmado: NADA é enviado", p1.choiceToSend() == null);
		AffinityPicker p2 = p1.requestConfirm();
		check("confirmando: envia exatamente o cartão escolhido", p2.confirming() && p2.choiceToSend() == Affinity.WIND);
		check("voltar cancela a confirmação e mantém o cartão",
				!p2.back().confirming() && p2.back().selected() == Affinity.WIND && p2.back().choiceToSend() == null);
		check("trocar de cartão durante a confirmação cancela a confirmação",
				!p2.select(Affinity.YIN).confirming() && p2.select(Affinity.YIN).choiceToSend() == null);
		check("select(null) não muda o estado", p1.select(null) == p1);
		check("estados antigos continuam intactos (imutável)", p1.selected() == Affinity.WIND && !p1.confirming());

		// ---------------- canais de mana ----------------
		check("nível 1: 100 de mana, 1,5/s, sem bônus",
				ChannelModel.maxMana(1) == 100 && ChannelModel.regenPerSecond(1) == 1.5
						&& ChannelModel.costMultiplier(1) == 1.0 && ChannelModel.castTimeMultiplier(1) == 1.0
						&& ChannelModel.powerMultiplier(1) == 1.0);
		check("nível 20: 385 de mana", ChannelModel.maxMana(20) == 385);
		boolean mono = true;
		for (int l = 1; l < 20; l++) {
			if (ChannelModel.maxMana(l + 1) <= ChannelModel.maxMana(l)
					|| ChannelModel.regenPerSecond(l + 1) <= ChannelModel.regenPerSecond(l)
					|| ChannelModel.costMultiplier(l + 1) >= ChannelModel.costMultiplier(l)
					|| ChannelModel.castTimeMultiplier(l + 1) >= ChannelModel.castTimeMultiplier(l)
					|| ChannelModel.powerMultiplier(l + 1) <= ChannelModel.powerMultiplier(l)) {
				mono = false;
			}
		}
		check("cada nível melhora capacidade, regeneração, custo, conjuração e potência", mono);
		check("níveis fora da faixa são limitados a 1..20",
				ChannelModel.clampLevel(-5) == 1 && ChannelModel.clampLevel(0) == 1 && ChannelModel.clampLevel(99) == 20);
		check("mana é limitada entre 0 e o máximo do nível",
				ChannelModel.clampMana(-3, 1) == 0 && ChannelModel.clampMana(500, 1) == 100 && ChannelModel.clampMana(50, 1) == 50);
		check("custo efetivo nunca é menor que 1 e nunca passa do custo base",
				ChannelModel.effectiveCost(1, 20) == 1 && ChannelModel.effectiveCost(75, 20) < 75
						&& ChannelModel.effectiveCost(75, 1) == 75);
		check("conjuração instantânea continua 0; as outras nunca zeram",
				ChannelModel.effectiveCastTicks(0, 20) == 0 && ChannelModel.effectiveCastTicks(1, 20) >= 1);
		check("XP de nível: 100 no nível 1, 0 no máximo", ChannelModel.xpNeeded(1) == 100 && ChannelModel.xpNeeded(20) == 0);
		int[] up = ChannelModel.applyXp(1, 0, 100);
		check("100 de XP no nível 1 sobe para o nível 2 com 0 de XP", up[0] == 2 && up[1] == 0);
		int[] two = ChannelModel.applyXp(1, 0, 100 + 140 + 30);
		check("XP grande sobe vários níveis e guarda o resto", two[0] == 3 && two[1] == 30);
		int[] maxed = ChannelModel.applyXp(20, 5, 9999);
		check("no nível máximo o XP não acumula", maxed[0] == 20 && maxed[1] == 0);
		int[] negative = ChannelModel.applyXp(5, 10, -50);
		check("XP negativo não tira nível nem XP", negative[0] == 5 && negative[1] == 10);
		int totalXp = 0;
		for (int l = 1; l < 20; l++) {
			totalXp += ChannelModel.xpNeeded(l);
		}
		check("nível 20 exige bastante XP (total >= 8000)", totalXp >= 8000);

		// ---------------- feitiços ----------------
		boolean fiveEach = Spells.all().size() == 30;
		for (Affinity a : Affinity.values()) {
			if (Spells.forAffinity(a).size() != 5) {
				fiveEach = false;
			}
		}
		check("30 feitiços registrados (5 por afinidade)", fiveEach);
		boolean contiguous = true;
		for (int i = 0; i < 30; i++) {
			if (Spells.byId(i) == null || Spells.byId(i).id() != i) {
				contiguous = false;
			}
		}
		check("ids de feitiço 0..29 contíguos (o cliente usa vetores de 32)", contiguous);
		boolean idsFine = true;
		java.util.Set<Integer> seenIds = new java.util.HashSet<>();
		java.util.Set<String> seenKeys = new java.util.HashSet<>();
		for (SpellDef s : Spells.all()) {
			if (!seenIds.add(s.id()) || !seenKeys.add(s.key()) || Spells.byId(s.id()) != s) {
				idsFine = false;
			}
		}
		check("ids e chaves de feitiços são únicos e byId coerente", idsFine);
		check("byId com id inválido devolve null", Spells.byId(-1) == null && Spells.byId(999) == null);
		boolean sane = true;
		for (SpellDef s : Spells.all()) {
			if (s.baseCost() <= 0 || s.cooldownTicks() <= 0 || s.unlockLevel() < 1 || s.unlockLevel() > 20
					|| s.baseCastTicks() < 0 || s.range() < 0 || s.affinity() == null || s.kind() == null) {
				sane = false;
			}
		}
		check("todo feitiço tem custo, recarga e nível de desbloqueio válidos", sane);
		boolean firstAtOne = true;
		for (Affinity a : Affinity.values()) {
			java.util.List<SpellDef> list = Spells.forAffinity(a);
			if (list.get(0).unlockLevel() != 1) {
				firstAtOne = false;
			}
			for (int i = 1; i < list.size(); i++) {
				if (list.get(i).unlockLevel() < list.get(i - 1).unlockLevel()) {
					firstAtOne = false;
				}
			}
		}
		check("cada afinidade começa no nível 1 e desbloqueia em ordem crescente", firstAtOne);
		boolean costGrows = true;
		for (Affinity a : Affinity.values()) {
			java.util.List<SpellDef> list = Spells.forAffinity(a);
			if (list.get(list.size() - 1).baseCost() <= list.get(0).baseCost()) {
				costGrows = false;
			}
		}
		check("o feitiço mais avançado custa mais que o inicial", costGrows);
		boolean mostExpensiveAffordable = true;
		for (SpellDef s : Spells.all()) {
			if (ChannelModel.effectiveCost(s.baseCost(), s.unlockLevel()) > ChannelModel.maxMana(s.unlockLevel())) {
				mostExpensiveAffordable = false;
			}
		}
		check("ao desbloquear, o jogador consegue pagar o feitiço com a mana cheia", mostExpensiveAffordable);

		// ---------------- regras de conjuração ----------------
		SpellDef goa = Spells.byId(Spells.GOA);
		SpellDef algoa = Spells.byId(Spells.ALGOA);
		check("feitiço inexistente é recusado",
				CastRules.check(Affinity.FIRE, 20, 999, 0, false, false, null) == CastRules.Result.UNKNOWN_SPELL);
		check("sem afinidade escolhida, nada é liberado",
				CastRules.check(null, 20, 999, 0, false, false, goa) == CastRules.Result.NO_AFFINITY);
		boolean onlyOwnAffinity = true;
		for (Affinity a : Affinity.values()) {
			for (SpellDef s : Spells.all()) {
				CastRules.Result r = CastRules.check(a, 20, 999, 0, false, false, s);
				boolean expectOk = a == s.affinity();
				if ((r == CastRules.Result.OK) != expectOk
						|| (!expectOk && r != CastRules.Result.WRONG_AFFINITY)) {
					onlyOwnAffinity = false;
				}
			}
		}
		check("com tudo liberado, só a afinidade própria conjura (6 x 10 combinações)", onlyOwnAffinity);
		boolean lockedBelow = true;
		for (SpellDef s : Spells.all()) {
			for (int lvl = 1; lvl < s.unlockLevel(); lvl++) {
				if (CastRules.check(s.affinity(), lvl, 999, 0, false, false, s) != CastRules.Result.LOCKED) {
					lockedBelow = false;
				}
			}
			if (CastRules.check(s.affinity(), s.unlockLevel(), 999, 0, false, false, s) != CastRules.Result.OK) {
				lockedBelow = false;
			}
		}
		check("feitiço fica bloqueado abaixo do nível e liberado no nível exato", lockedBelow);
		check("já conjurando é recusado",
				CastRules.check(Affinity.FIRE, 20, 999, 0, false, true, goa) == CastRules.Result.ALREADY_CASTING);
		check("exausto é recusado",
				CastRules.check(Affinity.FIRE, 20, 999, 0, true, false, goa) == CastRules.Result.EXHAUSTED);
		check("em recarga é recusado",
				CastRules.check(Affinity.FIRE, 20, 999, 5, false, false, goa) == CastRules.Result.ON_COOLDOWN);
		int cost = ChannelModel.effectiveCost(goa.baseCost(), 1);
		check("mana exatamente no custo permite; um a menos recusa",
				CastRules.check(Affinity.FIRE, 1, cost, 0, false, false, goa) == CastRules.Result.OK
						&& CastRules.check(Affinity.FIRE, 1, cost - 1, 0, false, false, goa) == CastRules.Result.NO_MANA);
		check("feitiço caro sem mana suficiente é recusado",
				CastRules.check(Affinity.FIRE, 14, 10, 0, false, false, algoa) == CastRules.Result.NO_MANA);
		check("nível de canal absurdo é tratado como 20, nunca estoura",
				CastRules.check(Affinity.FIRE, Integer.MAX_VALUE, 999, 0, false, false, algoa) == CastRules.Result.OK);

		// ---------------- cristais de mana ----------------
		check("4 raridades de cristal, ids 0..3 e chaves únicas",
				CrystalRarity.values().length == 4 && CrystalRarity.values()[0].id() == 0 && CrystalRarity.values()[3].id() == 3
						&& new java.util.HashSet<>(java.util.Arrays.asList(
								CrystalRarity.FRAGMENT.key(), CrystalRarity.CRYSTAL.key(),
								CrystalRarity.PURE.key(), CrystalRarity.PRIMORDIAL.key())).size() == 4);
		boolean rising = true;
		for (int i = 1; i < 4; i++) {
			if (CrystalRarity.values()[i].mana() <= CrystalRarity.values()[i - 1].mana()) {
				rising = false;
			}
		}
		check("cada raridade restaura mais mana que a anterior", rising);
		check("restaurar com mana cheia não adiciona nada", CrystalRules.restoreAmount(100, 100, 40) == 0);
		check("restaurar nunca passa do máximo", CrystalRules.restoreAmount(90, 100, 200) == 10);
		check("restaurar com mana vazia adiciona o valor do cristal", CrystalRules.restoreAmount(0, 385, 40) == 40);
		check("valores negativos não restauram nem estouram",
				CrystalRules.restoreAmount(-5, 100, -10) == 0 && CrystalRules.restoreAmount(-5, 100, 10) == 10);
		check("Receptor novo (dano máximo de capacidade) começa vazio",
				CrystalRules.storedFromDamage(CrystalRules.RECEPTOR_CAPACITY) == 0
						&& CrystalRules.storedFromDamage(0) == CrystalRules.RECEPTOR_CAPACITY);
		boolean roundTrip = true;
		for (int st = 0; st <= CrystalRules.RECEPTOR_CAPACITY; st++) {
			if (CrystalRules.storedFromDamage(CrystalRules.damageFromStored(st)) != st) {
				roundTrip = false;
			}
		}
		check("dano <-> mana guardada é reversível em toda a faixa", roundTrip);
		check("dano do Receptor vazio nunca quebra o item (dano < máximo)",
				CrystalRules.damageFromStored(0) < CrystalRules.RECEPTOR_MAX_DAMAGE);
		check("dano absurdo é limitado", CrystalRules.storedFromDamage(-50) == 300 && CrystalRules.storedFromDamage(9999) == 0);
		check("Concentrador dá +25%: fragmento 15 -> 19, cristal 40 -> 50",
				CrystalRules.concentratedCharge(CrystalRarity.FRAGMENT) == 19 && CrystalRules.concentratedCharge(CrystalRarity.CRYSTAL) == 50);
		boolean concentratedBetter = true;
		for (CrystalRarity r : CrystalRarity.values()) {
			if (CrystalRules.concentratedCharge(r) <= r.mana()) {
				concentratedBetter = false;
			}
		}
		check("Concentrador sempre rende mais que o uso direto", concentratedBetter);
		check("carregar soma e limita na capacidade", CrystalRules.load(0, 50) == 50 && CrystalRules.load(280, 50) == 300);
		check("Receptor cheio recusa carga", CrystalRules.load(300, 10) == -1);
		check("saque limitado pelo que há guardado e pelo espaço de mana",
				CrystalRules.withdraw(100, 0, 385) == 100 && CrystalRules.withdraw(100, 350, 385) == 35
						&& CrystalRules.withdraw(0, 0, 385) == 0 && CrystalRules.withdraw(100, 385, 385) == 0);
		check("trava de saturação: restante nunca negativo",
				CrystalRules.lockRemaining(10, 30) == 20 && CrystalRules.lockRemaining(30, 30) == 0 && CrystalRules.lockRemaining(99, 30) == 0);
		check("cristal Primordial não esvazia a progressão: restaura no máximo o que falta",
				CrystalRules.restoreAmount(0, ChannelModel.maxMana(1), CrystalRarity.PRIMORDIAL.mana()) == 100);

		// ---------------- equipamento ----------------
		CastModifiers none = EquipmentRules.combine(null, null);
		check("sem equipamento, nenhum bônus", none.power() == 1.0 && none.cost() == 1.0 && none.cast() == 1.0 && none.regen() == 1.0
				&& none.equals(CastModifiers.NONE));
		check("4 cajados e 5 acessórios, ids contíguos",
				Catalyst.values().length == 4 && Charm.values().length == 5 && Catalyst.PRIMORDIAL.id() == 3 && Charm.RESONANCE.id() == 4);
		boolean staffRising = true;
		for (int i = 1; i < Catalyst.values().length; i++) {
			Catalyst a = Catalyst.values()[i - 1];
			Catalyst b = Catalyst.values()[i];
			if (b.powerPct() <= a.powerPct() || b.costReductionPct() < a.costReductionPct() || b.castReductionPct() < a.castReductionPct()) {
				staffRising = false;
			}
		}
		check("cada cajado é melhor que o anterior", staffRising);
		CastModifiers prim = EquipmentRules.combine(Catalyst.PRIMORDIAL, null);
		check("cajado Primordial: +40% potência, -18% custo, -20% conjuração",
				Math.abs(prim.power() - 1.4) < 1e-9 && Math.abs(prim.cost() - 0.82) < 1e-9 && Math.abs(prim.cast() - 0.8) < 1e-9);
		CastModifiers flux = EquipmentRules.combine(null, Charm.FLUX);
		check("anel da Fluência: só regeneração +35%", flux.regen() == 1.35 && flux.power() == 1.0 && flux.cost() == 1.0 && flux.cast() == 1.0);
		boolean capped = true;
		for (Catalyst c : Catalyst.values()) {
			for (Charm h : Charm.values()) {
				CastModifiers m = EquipmentRules.combine(c, h);
				if (m.power() > EquipmentRules.MAX_POWER || m.cost() < EquipmentRules.MIN_COST || m.cast() < EquipmentRules.MIN_CAST
						|| m.regen() > EquipmentRules.MAX_REGEN || m.power() < 1.0 || m.cost() > 1.0 || m.cast() > 1.0 || m.regen() < 1.0) {
					capped = false;
				}
			}
		}
		check("nenhuma combinação (4x5 + nulos) passa dos limites nem piora o jogador", capped);
		check("custo efetivo cai com cajado mas nunca fica abaixo de 1",
				ChannelModel.effectiveCost(75, 1, prim.cost()) < 75 && ChannelModel.effectiveCost(1, 20, 0.6) == 1);
		check("conjuração mais rápida com cajado; instantânea continua 0",
				ChannelModel.effectiveCastTicks(45, 1, prim.cast()) < 45 && ChannelModel.effectiveCastTicks(0, 1, 0.6) == 0);
		SpellDef algoaS = Spells.byId(Spells.ALGOA);
		int needNormal = ChannelModel.effectiveCost(algoaS.baseCost(), 14);
		int needStaff = ChannelModel.effectiveCost(algoaS.baseCost(), 14, prim.cost());
		check("cajado permite conjurar com menos mana, na regra do servidor",
				CastRules.check(Affinity.FIRE, 14, needStaff, 0, false, false, algoaS, prim.cost()) == CastRules.Result.OK
						&& CastRules.check(Affinity.FIRE, 14, needStaff, 0, false, false, algoaS) == CastRules.Result.NO_MANA
						&& needStaff < needNormal);

		// ---------------- vestes ----------------
		check("3 conjuntos de 4 peças, chaves de item únicas",
				RobeSet.values().length == 3 && RobePiece.values().length == 4
						&& new java.util.HashSet<>(java.util.Arrays.asList(
								RobeSet.APPRENTICE.itemKey(RobePiece.HOOD), RobeSet.APPRENTICE.itemKey(RobePiece.TUNIC),
								RobeSet.CRYSTAL.itemKey(RobePiece.HOOD), RobeSet.PURE.itemKey(RobePiece.BOOTS))).size() == 4);
		check("sem vestes e sem marcas é igual a sem equipamento",
				EquipmentRules.combine(null, null, new int[] {0, 0, 0}, java.util.List.of()).equals(CastModifiers.NONE));
		CastModifiers oneHood = EquipmentRules.combine(null, null, new int[] {0, 0, 1}, null);
		check("1 peça Pura: +5% potência, -3% custo (sem bônus de conjunto)",
				Math.abs(oneHood.power() - 1.05) < 1e-9 && Math.abs(oneHood.cost() - 0.97) < 1e-9 && oneHood.regen() == 1.05);
		CastModifiers fullPure = EquipmentRules.combine(null, null, new int[] {0, 0, 4}, null);
		check("conjunto Puro completo soma o bônus de conjunto: +30% potência, -12% custo, -10% conjuração, +40% regen",
				Math.abs(fullPure.power() - 1.30) < 1e-9 && Math.abs(fullPure.cost() - 0.88) < 1e-9
						&& Math.abs(fullPure.cast() - 0.90) < 1e-9 && Math.abs(fullPure.regen() - 1.40) < 1e-9);
		CastModifiers threePieces = EquipmentRules.combine(null, null, new int[] {0, 0, 3}, null);
		check("3 de 4 peças NÃO ganham bônus de conjunto", Math.abs(threePieces.power() - 1.15) < 1e-9);
		CastModifiers mixed = EquipmentRules.combine(null, null, new int[] {2, 2, 0}, null);
		check("peças de conjuntos diferentes não formam conjunto", Math.abs(mixed.regen() - 1.10) < 1e-9 && Math.abs(mixed.power() - 1.06) < 1e-9);
		check("contagem de peças fora da faixa é limitada",
				EquipmentRules.combine(null, null, new int[] {99, -3, 0}, null).equals(EquipmentRules.combine(null, null, new int[] {4, 0, 0}, null)));
		boolean maxLoadCapped = true;
		for (Catalyst c : Catalyst.values()) {
			for (Charm h : Charm.values()) {
				CastModifiers m = EquipmentRules.combine(c, h, new int[] {4, 4, 4},
						java.util.List.of(Inscription.GREEDY, Inscription.FORCE, Inscription.BALANCE));
				if (m.power() > EquipmentRules.MAX_POWER || m.cost() < EquipmentRules.MIN_COST || m.cast() < EquipmentRules.MIN_CAST
						|| m.regen() > EquipmentRules.MAX_REGEN) {
					maxLoadCapped = false;
				}
			}
		}
		check("o limite vale mesmo com tudo vestido (4 conjuntos x 5 cajados/acessórios x marcas)", maxLoadCapped);

		// ---------------- inscrições ----------------
		check("12 inscrições, ids 0..11, 3 espaços", Inscription.values().length == 12 && Inscription.SLOTS == 3
				&& Inscription.fromId(0) == Inscription.FORCE && Inscription.fromId(11) == Inscription.DIVER
				&& Inscription.fromId(12) == null && Inscription.fromId(-1) == null);
		int[] perCategory = new int[4];
		for (Inscription i : Inscription.values()) {
			perCategory[i.category().ordinal()]++;
		}
		check("4 categorias com 3 inscrições cada", perCategory[0] == 3 && perCategory[1] == 3 && perCategory[2] == 3 && perCategory[3] == 3);
		boolean tiersOk = true;
		java.util.Set<String> inscKeys = new java.util.HashSet<>();
		for (Inscription i : Inscription.values()) {
			inscKeys.add(i.key());
			if (i.inkCost() != i.tier() + 1 || i.unlockLevel() != (i.tier() == 1 ? 1 : i.tier() == 2 ? 5 : 10)
					|| (1 << i.id()) != i.bit()) {
				tiersOk = false;
			}
		}
		check("custo de tinta 2/3/4, níveis 1/5/10, bits e chaves únicas", tiersOk && inscKeys.size() == 12);
		java.util.List<Integer> noMarks = java.util.List.of();
		check("gravar sem afinidade, sem mesa, sem nível, sem tinta: cada recusa certa",
				InscriptionRules.checkEngrave(null, noMarks, Inscription.FORCE, 20, 99, true) == InscriptionRules.Result.NO_AFFINITY
						&& InscriptionRules.checkEngrave(Affinity.FIRE, noMarks, Inscription.FORCE, 20, 99, false) == InscriptionRules.Result.NO_TABLE
						&& InscriptionRules.checkEngrave(Affinity.FIRE, noMarks, Inscription.GREEDY, 9, 99, true) == InscriptionRules.Result.LEVEL
						&& InscriptionRules.checkEngrave(Affinity.FIRE, noMarks, Inscription.FORCE, 1, 1, true) == InscriptionRules.Result.NO_INK
						&& InscriptionRules.checkEngrave(Affinity.FIRE, noMarks, null, 1, 99, true) == InscriptionRules.Result.UNKNOWN);
		check("gravar no nível e tinta exatos funciona",
				InscriptionRules.checkEngrave(Affinity.WATER, noMarks, Inscription.GREEDY, 10, 4, true) == InscriptionRules.Result.OK);
		check("repetida e cheia são recusadas",
				InscriptionRules.checkEngrave(Affinity.FIRE, java.util.List.of(0), Inscription.FORCE, 20, 99, true) == InscriptionRules.Result.ALREADY
						&& InscriptionRules.checkEngrave(Affinity.FIRE, java.util.List.of(0, 1, 3), Inscription.SPRING, 20, 99, true)
								== InscriptionRules.Result.FULL);
		check("remover: precisa da mesa e de estar gravada",
				InscriptionRules.checkRemove(java.util.List.of(0), Inscription.FORCE, true) == InscriptionRules.Result.OK
						&& InscriptionRules.checkRemove(java.util.List.of(0), Inscription.FORCE, false) == InscriptionRules.Result.NO_TABLE
						&& InscriptionRules.checkRemove(noMarks, Inscription.FORCE, true) == InscriptionRules.Result.NOT_ENGRAVED
						&& InscriptionRules.checkRemove(noMarks, null, true) == InscriptionRules.Result.UNKNOWN);
		check("sanitize remove inválidas, repetidas e corta em 3",
				InscriptionRules.sanitize(java.util.Arrays.asList(0, 0, 99, -1, null, 3, 4, 5)).equals(java.util.List.of(0, 3, 4))
						&& InscriptionRules.sanitize(null).isEmpty());
		check("máscara <-> lista é reversível",
				InscriptionRules.toMask(java.util.List.of(0, 3, 11)) == (1 | 8 | 2048)
						&& InscriptionRules.fromMask(1 | 8 | 2048).equals(java.util.List.of(Inscription.FORCE, Inscription.THRIFT, Inscription.DIVER)));
		check("máscara com mais de 3 bits é cortada em 3", InscriptionRules.fromMask(0xFFF).size() == 3);
		CastModifiers marked = EquipmentRules.combine(null, null, null, java.util.List.of(Inscription.GREEDY));
		check("Marca Voraz: +15% potência, mas conjurar custa 10% a mais",
				Math.abs(marked.power() - 1.15) < 1e-9 && Math.abs(marked.cost() - 1.10) < 1e-9);

		// ---- E7a: treinamento ----
		check("5 atributos de treino com ids 0..4 e chaves únicas",
				TrainingAttribute.values().length == 5 && TrainingAttribute.COUNT == 5
						&& TrainingAttribute.fromId(0) == TrainingAttribute.VIGOR && TrainingAttribute.fromId(4) == TrainingAttribute.CONTROL
						&& TrainingAttribute.fromId(5) == null && TrainingAttribute.fromId(-1) == null);
		check("XP necessário: 40 no nível 0, 310 no 9, 0 no 10 (máximo)",
				TrainingModel.xpNeeded(0) == 40 && TrainingModel.xpNeeded(9) == 310 && TrainingModel.xpNeeded(10) == 0);
		check("teto do atributo acompanha os canais: 2, 3, 7, 10, 10",
				TrainingModel.levelCap(1) == 2 && TrainingModel.levelCap(2) == 3 && TrainingModel.levelCap(10) == 7
						&& TrainingModel.levelCap(16) == 10 && TrainingModel.levelCap(20) == 10 && TrainingModel.levelCap(-5) == 2);
		int[] t1 = TrainingModel.applyXp(0, 0, 40, 2);
		check("40 de XP sobem do nível 0 para 1 sem sobra", t1[0] == 1 && t1[1] == 0);
		int[] t2 = TrainingModel.applyXp(0, 10, 100, 2);
		check("XP grande sobe vários níveis até o teto e descarta o resto", t2[0] == 2 && t2[1] == 0);
		int[] t3 = TrainingModel.applyXp(2, 0, 500, 2);
		check("no teto o XP não acumula", t3[0] == 2 && t3[1] == 0);
		int[] t4 = TrainingModel.applyXp(0, 0, 30, 5);
		check("abaixo do necessário só acumula", t4[0] == 0 && t4[1] == 30);
		int[] t5 = TrainingModel.applyXp(9, 0, 10000, 10);
		check("nunca passa do nível 10", t5[0] == 10 && t5[1] == 0);
		check("XP negativo é ignorado", TrainingModel.applyXp(0, 5, -50, 5)[1] == 5);
		boolean decreasing = true;
		for (int f = 1; f <= 100; f++) {
			if (TrainingModel.repXp(f) > TrainingModel.repXp(f - 1)) {
				decreasing = false;
			}
		}
		check("rendimento do treino ativo nunca aumenta com a fadiga e fica entre 1 e 6",
				decreasing && TrainingModel.repXp(0) == 6 && TrainingModel.repXp(100) >= 1 && TrainingModel.yieldPct(100) == 25
						&& TrainingModel.yieldPct(0) == 100 && TrainingModel.yieldPct(-10) == 100 && TrainingModel.yieldPct(500) == 25);
		int f = 0;
		int reps = 0;
		int total = 0;
		while (f < TrainingModel.FATIGUE_MAX) {
			total += TrainingModel.repXp(f);
			f = TrainingModel.fatigueAfterRep(f);
			reps++;
		}
		check("uma sessão até a fadiga máxima dura 13 repetições e rende pouco (menos de 60 XP)",
				reps == 13 && total < 60 && f == TrainingModel.FATIGUE_MAX);
		check("XP por uso: Foco, Controle, Força e Vigor têm mínimo 1",
				TrainingModel.focusXpForCast(0) == 1 && TrainingModel.focusXpForCast(45) == 11
						&& TrainingModel.controlXpForMana(2) == 1 && TrainingModel.controlXpForMana(75) == 18
						&& TrainingModel.strengthXpForDamage(0.2f) == 1 && TrainingModel.strengthXpForDamage(7.4f) == 7
						&& TrainingModel.vigorXpForDamage(0.1f) == 1 && TrainingModel.vigorXpForDamage(3.2f) == 4);
		check("efeitos no nível máximo: +8 vida, +3 ataque, +15% velocidade, -20% conjuração, -10% custo, +20% regeneração",
				Math.abs(TrainingModel.maxHealthBonus(10) - 8.0) < 1e-9 && Math.abs(TrainingModel.attackBonus(10) - 3.0) < 1e-9
						&& Math.abs(TrainingModel.speedFraction(10) - 0.15) < 1e-9 && TrainingModel.castReductionPct(10) == 20
						&& TrainingModel.costReductionPct(10) == 10 && TrainingModel.regenPct(10) == 20);
		check("efeitos com nível fora da faixa são limitados a 0..10",
				TrainingModel.maxHealthBonus(-3) == 0.0 && TrainingModel.maxHealthBonus(99) == TrainingModel.maxHealthBonus(10)
						&& TrainingModel.castReductionPct(99) == 20);
		int[] lv = {10, 3, 0, 7, 9};
		check("empacotar e desempacotar níveis é reversível",
				java.util.Arrays.equals(TrainingModel.unpackLevels(TrainingModel.packLevels(lv)), lv)
						&& java.util.Arrays.equals(TrainingModel.unpackLevels(TrainingModel.packLevels(null)), new int[5])
						&& TrainingModel.packLevels(new int[] {99, 99, 99, 99, 99}) == TrainingModel.packLevels(new int[] {10, 10, 10, 10, 10}));
		int[] xps = {309, 0, 1023, 55, 200};
		check("empacotar e desempacotar XP é reversível (10 bits cada)",
				java.util.Arrays.equals(TrainingModel.unpackXp(TrainingModel.packXpA(xps), TrainingModel.packXpB(xps)), xps)
						&& TrainingModel.packXpA(new int[] {5000, -3, 0, 0, 0}) == 1023);
		int[] sl = TrainingModel.sanitizeLevels(java.util.Arrays.asList(99, -4, null));
		check("dados salvos corrompidos: níveis limitados, faltantes viram 0",
				sl.length == 5 && sl[0] == 10 && sl[1] == 0 && sl[2] == 0 && sl[4] == 0 && TrainingModel.sanitizeLevels(null).length == 5);
		int[] sx = TrainingModel.sanitizeXp(java.util.Arrays.asList(999, 5, null, 3, 8), new int[] {0, 0, 0, 10, 0});
		check("dados salvos corrompidos: XP abaixo do necessário e zero no nível máximo",
				sx[0] == 39 && sx[1] == 5 && sx[2] == 0 && sx[3] == 0 && sx[4] == 8);
		CastModifiers trained = EquipmentRules.combine(null, null, null, null, new int[] {0, 0, 0, 10, 10});
		check("treino soma ao equipamento: Foco 10 e Controle 10 dão -20% conjuração, -10% custo, +20% regeneração",
				Math.abs(trained.cast() - 0.80) < 1e-9 && Math.abs(trained.cost() - 0.90) < 1e-9
						&& Math.abs(trained.regen() - 1.20) < 1e-9 && Math.abs(trained.power() - 1.0) < 1e-9);
		CastModifiers stacked = EquipmentRules.combine(Catalyst.PRIMORDIAL, Charm.THRIFT,
				new int[] {0, 0, 4}, java.util.List.of(Inscription.FOCUS, Inscription.THRIFT), new int[] {0, 0, 0, 10, 10});
		check("treino + equipamento + marcas continuam respeitando os limites (conjuração e custo >= 0,6; regeneração <= 2,0)",
				stacked.cast() >= EquipmentRules.MIN_CAST - 1e-9 && stacked.cost() >= EquipmentRules.MIN_COST - 1e-9
						&& stacked.regen() <= EquipmentRules.MAX_REGEN + 1e-9 && stacked.power() <= EquipmentRules.MAX_POWER + 1e-9);
		check("sem treino o resultado é igual ao de antes (compatibilidade)",
				EquipmentRules.combine(Catalyst.CRYSTAL, Charm.FOCUS, null, null).cast()
						== EquipmentRules.combine(Catalyst.CRYSTAL, Charm.FOCUS, null, null, null).cast()
						&& EquipmentRules.combine(null, null, null, null, new int[0]).cost() == 1.0);

		// ---- E7b: técnicas de combate ----
		check("5 estilos com ids 0..4 em ordem e chaves únicas",
				CombatStyle.values().length == 5 && CombatStyle.fromId(0) == CombatStyle.SWORD && CombatStyle.fromId(4) == CombatStyle.BOW
						&& CombatStyle.fromId(5) == null && CombatStyle.fromId(-1) == null);
		boolean techOk = Techniques.all().size() == 15 && Techniques.COUNT == 15;
		java.util.Set<String> techKeys = new java.util.HashSet<>();
		for (int i = 0; i < Techniques.all().size(); i++) {
			TechniqueDef t = Techniques.all().get(i);
			techKeys.add(t.key());
			techOk &= t.id() == i && Techniques.byId(i) == t && t.tier() >= 1 && t.tier() <= 3 && t.staminaCost() > 0
					&& t.cooldownTicks() > 0 && t.minLevel() == (t.tier() == 1 ? 1 : t.tier() == 2 ? 3 : 5) && t.pointCost() == t.tier();
		}
		check("15 técnicas, ids sequenciais, chaves únicas, níveis 1/3/5 e custo em pontos = tier", techOk && techKeys.size() == 15);
		check("id de técnica inválido vira null", Techniques.byId(-1) == null && Techniques.byId(15) == null);
		boolean styleOk = true;
		for (CombatStyle st : CombatStyle.values()) {
			java.util.List<TechniqueDef> l = Techniques.forStyle(st);
			styleOk &= l.size() == 3 && l.get(0).tier() == 1 && l.get(1).tier() == 2 && l.get(2).tier() == 3
					&& Techniques.slot(st, 0) == l.get(0) && Techniques.slot(st, 2) == l.get(2);
		}
		check("cada estilo tem 3 técnicas (tier 1, 2, 3) e os espaços 0..2 apontam para elas",
				styleOk && Techniques.slot(CombatStyle.SWORD, 3) == null && Techniques.slot(CombatStyle.SWORD, -1) == null
						&& Techniques.slot(null, 0) == null);
		check("estamina: 100 sem Vigor, 160 com Vigor 10, regeneração 10 a 15 por segundo, limitada a 0..10 níveis",
				CombatRules.maxStamina(0) == 100 && CombatRules.maxStamina(10) == 160 && CombatRules.maxStamina(99) == 160
						&& CombatRules.maxStamina(-4) == 100 && CombatRules.regenPerSecond(0) == 10.0 && CombatRules.regenPerSecond(10) == 15.0);
		TechniqueDef sweep = Techniques.byId(Techniques.SWORD_SWEEP);
		int sweepBit = CombatRules.bit(Techniques.SWORD_SWEEP);
		check("usar: sem arma, sem aprender, ocupado, em recarga e sem estamina, cada recusa na ordem certa",
				CombatRules.checkUse(sweepBit, null, 0, 100, false) == CombatRules.UseResult.NO_WEAPON
						&& CombatRules.checkUse(0, sweep, 0, 100, false) == CombatRules.UseResult.NOT_LEARNED
						&& CombatRules.checkUse(sweepBit, sweep, 0, 100, true) == CombatRules.UseResult.BUSY
						&& CombatRules.checkUse(sweepBit, sweep, 5, 100, false) == CombatRules.UseResult.ON_COOLDOWN
						&& CombatRules.checkUse(sweepBit, sweep, 0, 14.9, false) == CombatRules.UseResult.NO_STAMINA
						&& CombatRules.checkUse(sweepBit, sweep, 0, 15, false) == CombatRules.UseResult.OK);
		check("esquiva: custa 20, tem recarga e não acontece ocupado",
				CombatRules.checkDodge(0, 20, false) == CombatRules.UseResult.OK
						&& CombatRules.checkDodge(0, 19.9, false) == CombatRules.UseResult.NO_STAMINA
						&& CombatRules.checkDodge(1, 100, false) == CombatRules.UseResult.ON_COOLDOWN
						&& CombatRules.checkDodge(0, 100, true) == CombatRules.UseResult.BUSY);
		check("combo: só o 3º golpe é o final; contra-ataque e combo somam o eco",
				!CombatRules.isFinisher(1) && !CombatRules.isFinisher(2) && CombatRules.isFinisher(3) && CombatRules.isFinisher(4)
						&& CombatRules.echoBonusPct(false, false) == 0 && CombatRules.echoBonusPct(true, false) == 25
						&& CombatRules.echoBonusPct(false, true) == 50 && CombatRules.echoBonusPct(true, true) == 75);
		check("o eco espera o fim da invulnerabilidade do alvo (mais de 10 ticks)", CombatRules.ECHO_DELAY_TICKS > 10);
		int[] zeros = new int[5];
		int[] lv1 = {1, 1, 1, 1, 1};
		check("pontos: soma dos níveis menos o gasto, nunca negativo",
				CombatRules.availablePoints(zeros, 0) == 0 && CombatRules.availablePoints(lv1, 0) == 5
						&& CombatRules.availablePoints(lv1, sweepBit) == 4 && CombatRules.availablePoints(zeros, sweepBit) == 0
						&& CombatRules.availablePoints(null, 0) == 0
						&& CombatRules.spentPoints(0x7FFF) == 30);
		TechniqueDef heavy = Techniques.byId(Techniques.SWORD_HEAVY);
		int[] str3 = {0, 3, 0, 0, 0};
		check("aprender: tier 1 com nível e ponto; sem nível recusa; sem ponto recusa",
				CombatRules.checkLearn(0, sweep, lv1) == CombatRules.LearnResult.OK
						&& CombatRules.checkLearn(0, sweep, zeros) == CombatRules.LearnResult.LEVEL
						&& CombatRules.checkLearn(0, null, lv1) == CombatRules.LearnResult.UNKNOWN
						&& CombatRules.checkLearn(sweepBit, sweep, lv1) == CombatRules.LearnResult.ALREADY);
		check("aprender: o tier 2 exige o tier 1, nível 3 e 2 pontos; o 3 exige o 2",
				CombatRules.checkLearn(0, heavy, str3) == CombatRules.LearnResult.NO_PREREQ
						&& CombatRules.checkLearn(sweepBit, heavy, new int[] {0, 2, 0, 0, 0}) == CombatRules.LearnResult.LEVEL
						&& CombatRules.checkLearn(sweepBit, heavy, new int[] {0, 3, 0, 0, 0}) == CombatRules.LearnResult.OK
						&& CombatRules.checkLearn(sweepBit, heavy, new int[] {0, 3, 0, 0, 0}) == CombatRules.LearnResult.OK
						&& CombatRules.checkLearn(sweepBit, Techniques.byId(Techniques.SWORD_RIPOSTE), new int[] {0, 5, 5, 0, 0}) == CombatRules.LearnResult.NO_PREREQ
						&& CombatRules.checkLearn(sweepBit | CombatRules.bit(Techniques.SWORD_HEAVY), Techniques.byId(Techniques.SWORD_RIPOSTE),
								new int[] {0, 5, 5, 0, 0}) == CombatRules.LearnResult.OK);
		check("aprender sem pontos suficientes: nível ok, pontos gastos em outra técnica",
				CombatRules.checkLearn(CombatRules.bit(Techniques.SPEAR_THRUST) | CombatRules.bit(Techniques.DAGGER_FLURRY),
						sweep, new int[] {0, 1, 1, 0, 0}) == CombatRules.LearnResult.NO_POINTS);
		check("com tudo no máximo (50 pontos) dá para aprender as 15 técnicas (custam 30)",
				CombatRules.availablePoints(new int[] {10, 10, 10, 10, 10}, 0) == 50
						&& CombatRules.availablePoints(new int[] {10, 10, 10, 10, 10}, 0x7FFF) == 20);
		check("máscara fora das 15 técnicas é cortada", CombatRules.sanitizeMask(-1) == 0x7FFF && CombatRules.sanitizeMask(0x8001) == 1);
		check("prerequisito: tier 1 não tem; tier 2 e 3 apontam para o anterior",
				CombatRules.prerequisite(sweep) == null && CombatRules.prerequisite(heavy) == sweep
						&& CombatRules.prerequisite(Techniques.byId(Techniques.BOW_SNARE)) == Techniques.byId(Techniques.BOW_VOLLEY));

		// ---- E8: espíritos ----
		check("cada afinidade tem um temperamento diferente (6 únicos)",
				java.util.Arrays.stream(Affinity.values()).map(SpiritRules::temperamentOf).distinct().count() == 6
						&& SpiritRules.temperamentOf(Affinity.FIRE) == SpiritRules.Temperament.COMBAT
						&& SpiritRules.temperamentOf(Affinity.YANG) == SpiritRules.Temperament.DAY);
		SpiritRules.Env nowhere = new SpiritRules.Env(false, 70, false, false, true, false, 15);
		check("condições de aparição: fogo no Nether ou fundo; água na chuva ou na água; vento no alto; terra em caverna; yin à noite no escuro; yang de dia",
				SpiritRules.spawnCondition(Affinity.FIRE, new SpiritRules.Env(true, 70, false, false, true, false, 15))
						&& SpiritRules.spawnCondition(Affinity.FIRE, new SpiritRules.Env(false, 5, false, false, false, false, 0))
						&& !SpiritRules.spawnCondition(Affinity.FIRE, nowhere)
						&& SpiritRules.spawnCondition(Affinity.WATER, new SpiritRules.Env(false, 70, true, false, true, false, 15))
						&& SpiritRules.spawnCondition(Affinity.WATER, new SpiritRules.Env(false, 70, false, true, true, false, 15))
						&& !SpiritRules.spawnCondition(Affinity.WATER, new SpiritRules.Env(false, 70, true, false, false, false, 15))
						&& SpiritRules.spawnCondition(Affinity.WIND, new SpiritRules.Env(false, 120, false, false, true, false, 15))
						&& !SpiritRules.spawnCondition(Affinity.WIND, new SpiritRules.Env(false, 120, false, false, false, false, 15))
						&& SpiritRules.spawnCondition(Affinity.EARTH, new SpiritRules.Env(false, 30, false, false, false, false, 4))
						&& !SpiritRules.spawnCondition(Affinity.EARTH, new SpiritRules.Env(false, 30, false, false, true, false, 15))
						&& SpiritRules.spawnCondition(Affinity.YIN, new SpiritRules.Env(false, 70, false, false, true, true, 6))
						&& !SpiritRules.spawnCondition(Affinity.YIN, new SpiritRules.Env(false, 70, false, false, true, true, 12))
						&& SpiritRules.spawnCondition(Affinity.YANG, nowhere)
						&& !SpiritRules.spawnCondition(Affinity.YANG, new SpiritRules.Env(false, 70, false, false, true, true, 15))
						&& !SpiritRules.spawnCondition(null, nowhere) && !SpiritRules.spawnCondition(Affinity.FIRE, null));
		check("contrato: cada recusa na ordem certa e só OK com tudo certo",
				SpiritRules.checkContract(null, 20, false, true) == SpiritRules.ContractResult.NO_AFFINITY
						&& SpiritRules.checkContract(Affinity.FIRE, 3, false, true) == SpiritRules.ContractResult.LEVEL
						&& SpiritRules.checkContract(Affinity.FIRE, 4, true, true) == SpiritRules.ContractResult.ALREADY
						&& SpiritRules.checkContract(Affinity.FIRE, 4, false, false) == SpiritRules.ContractResult.NO_WISP
						&& SpiritRules.checkContract(Affinity.FIRE, 4, false, true) == SpiritRules.ContractResult.OK);
		check("vínculo: XP 100, 200, 300, 400 e 0 no máximo; nunca passa de 5",
				SpiritRules.bondXpNeeded(1) == 100 && SpiritRules.bondXpNeeded(4) == 400 && SpiritRules.bondXpNeeded(5) == 0
						&& SpiritRules.clampBond(0) == 1 && SpiritRules.clampBond(99) == 5);
		int[] b1 = SpiritRules.applyBondXp(1, 0, 250);
		int[] b2 = SpiritRules.applyBondXp(4, 399, 1000);
		int[] b3 = SpiritRules.applyBondXp(1, 40, 20);
		check("aplicar XP de vínculo: sobe com sobra, para no 5 sem acumular, e só acumula quando falta",
				b1[0] == 2 && b1[1] == 150 && b2[0] == 5 && b2[1] == 0 && b3[0] == 1 && b3[1] == 60
						&& SpiritRules.applyBondXp(1, 5, -30)[1] == 5);
		check("custo contínuo cresce com o vínculo (0,75 a 1,75 por segundo) e nunca passa da regeneração do nível mínimo de canais exigido para o contrato",
				Math.abs(SpiritRules.drainPerSecond(1) - 0.75) < 1e-9 && Math.abs(SpiritRules.drainPerSecond(5) - 1.75) < 1e-9
						&& SpiritRules.drainPerSecond(5) < ChannelModel.regenPerSecond(SpiritRules.MIN_CHANNEL_LEVEL));
		check("potência: +3% por nível de vínculo, até +15%", SpiritRules.powerPct(1) == 3 && SpiritRules.powerPct(5) == 15
				&& SpiritRules.powerPct(99) == 15);
		check("habilidade ativa: liberada no vínculo 3; recusas na ordem certa",
				!SpiritRules.activeUnlocked(2) && SpiritRules.activeUnlocked(3)
						&& SpiritRules.checkActive(false, true, 5, 0, 100) == SpiritRules.ActiveResult.NO_CONTRACT
						&& SpiritRules.checkActive(true, false, 5, 0, 100) == SpiritRules.ActiveResult.NOT_SUMMONED
						&& SpiritRules.checkActive(true, true, 2, 0, 100) == SpiritRules.ActiveResult.LOCKED
						&& SpiritRules.checkActive(true, true, 3, 5, 100) == SpiritRules.ActiveResult.ON_COOLDOWN
						&& SpiritRules.checkActive(true, true, 3, 0, 29) == SpiritRules.ActiveResult.NO_MANA
						&& SpiritRules.checkActive(true, true, 3, 0, 30) == SpiritRules.ActiveResult.OK);
		check("força da habilidade: 7,5 no vínculo 1 até 13,5 no 5",
				Math.abs(SpiritRules.activeStrength(1) - 7.5) < 1e-9 && Math.abs(SpiritRules.activeStrength(5) - 13.5) < 1e-9);
		CastModifiers spirited = EquipmentRules.combine(null, null, null, null, null, 15);
		check("o espírito soma +15% de potência ao equipamento e respeita o teto 2,0",
				Math.abs(spirited.power() - 1.15) < 1e-9
						&& EquipmentRules.combine(Catalyst.PRIMORDIAL, Charm.RESONANCE, new int[] {0, 0, 4},
								java.util.List.of(Inscription.FORCE, Inscription.GREEDY), null, 1000).power() <= EquipmentRules.MAX_POWER_ABS + 1e-9
						&& EquipmentRules.combine(null, null, null, null, null, -50).power() == 1.0);

		// ---- E9a: raças ----
		check("4 raças com ids 0..3 únicos e fromId inválido = null",
				Race.values().length == 4 && Race.fromId(0) == Race.HUMAN && Race.fromId(3) == Race.ONI
						&& Race.fromId(-1) == null && Race.fromId(4) == null && RaceRules.normalizeId(9) == -1 && RaceRules.normalizeId(2) == 2);
		check("escolha de raça é única: só aceita sem raça atual e com pedido válido",
				RaceRules.canChoose(null, Race.ONI) && !RaceRules.canChoose(Race.HUMAN, Race.ONI) && !RaceRules.canChoose(null, null));
		check("vida: humano 0, meio-elfo -2, demi-humano +4, oni +2; sem raça 0",
				RaceRules.maxHealthBonus(Race.HUMAN) == 0.0 && RaceRules.maxHealthBonus(Race.HALF_ELF) == -2.0
						&& RaceRules.maxHealthBonus(Race.DEMI_HUMAN) == 4.0 && RaceRules.maxHealthBonus(Race.ONI) == 2.0
						&& RaceRules.maxHealthBonus(null) == 0.0);
		check("ataque e velocidade só para demi-humano/oni (ataque) e demi-humano (velocidade)",
				RaceRules.attackBonus(Race.HUMAN) == 0.0 && RaceRules.attackBonus(Race.ONI) == 0.5 && RaceRules.attackBonus(Race.DEMI_HUMAN) == 0.5
						&& RaceRules.speedFraction(Race.DEMI_HUMAN) == 0.03 && RaceRules.speedFraction(Race.ONI) == 0.0);
		check("XP de treino: humano +10% em tudo; demi-humano +20% Vigor/Força; oni +20% Força/Controle; meio-elfo +20% Foco",
				RaceRules.trainingXpPct(Race.HUMAN, TrainingAttribute.AGILITY) == 10
						&& RaceRules.trainingXpPct(Race.DEMI_HUMAN, TrainingAttribute.VIGOR) == 20
						&& RaceRules.trainingXpPct(Race.DEMI_HUMAN, TrainingAttribute.FOCUS) == 0
						&& RaceRules.trainingXpPct(Race.ONI, TrainingAttribute.CONTROL) == 20
						&& RaceRules.trainingXpPct(Race.HALF_ELF, TrainingAttribute.FOCUS) == 20
						&& RaceRules.trainingXpPct(null, TrainingAttribute.FOCUS) == 0);
		check("XP com bônus arredonda para cima e nunca perde XP; 0 continua 0",
				RaceRules.trainingXp(Race.HUMAN, TrainingAttribute.FOCUS, 10) == 11 && RaceRules.trainingXp(Race.HUMAN, TrainingAttribute.FOCUS, 1) == 2
						&& RaceRules.trainingXp(null, TrainingAttribute.FOCUS, 7) == 7 && RaceRules.trainingXp(Race.ONI, TrainingAttribute.STRENGTH, 0) == 0
						&& RaceRules.trainingXp(Race.ONI, TrainingAttribute.STRENGTH, 5) == 6);
		check("vínculo com espírito: só o meio-elfo ganha +25% (arredondado para cima)",
				RaceRules.spiritBondXp(Race.HALF_ELF, 2) == 3 && RaceRules.spiritBondXp(Race.HALF_ELF, 4) == 5
						&& RaceRules.spiritBondXp(Race.HUMAN, 2) == 2 && RaceRules.spiritBondXp(null, 2) == 2 && RaceRules.spiritBondXp(Race.HALF_ELF, 0) == 0);
		check("magia por raça: demi-humano gasta 15% a mais; oni regenera 15% (65% na forma); meio-elfo 10%",
				java.util.Arrays.equals(RaceRules.castPcts(Race.DEMI_HUMAN, false), new int[] {0, -15, 0, 0})
						&& RaceRules.castPcts(Race.ONI, false)[3] == 15 && RaceRules.castPcts(Race.ONI, true)[3] == 65
						&& RaceRules.castPcts(Race.HALF_ELF, true)[3] == 10 && RaceRules.castPcts(null, true)[3] == 0);
		CastModifiers demi = EquipmentRules.combine(null, null, null, null, null, 0, RaceRules.castPcts(Race.DEMI_HUMAN, false));
		CastModifiers oniForm = EquipmentRules.combine(null, null, null, null, null, 0, RaceRules.castPcts(Race.ONI, true));
		check("o custo maior do demi-humano chega ao cálculo (1,15) e a regeneração da Forma Oni respeita o teto 2,0",
				Math.abs(demi.cost() - 1.15) < 1e-9 && Math.abs(oniForm.regen() - 1.65) < 1e-9
						&& EquipmentRules.combine(null, null, null, null, null, 0, new int[] {0, 0, 0, 500}).regen() == EquipmentRules.MAX_REGEN_ABS
						&& EquipmentRules.combine(null, null, null, null, null, 0, null).cost() == 1.0);
		check("só demi-humano e oni têm ativa; recusas: sem habilidade, já ativa, recarga",
				!RaceRules.hasActive(Race.HUMAN) && !RaceRules.hasActive(Race.HALF_ELF) && RaceRules.hasActive(Race.ONI)
						&& RaceRules.checkActive(Race.HUMAN, false, 0) == RaceRules.ActiveResult.NO_ABILITY
						&& RaceRules.checkActive(null, false, 0) == RaceRules.ActiveResult.NO_ABILITY
						&& RaceRules.checkActive(Race.ONI, true, 0) == RaceRules.ActiveResult.ALREADY_ACTIVE
						&& RaceRules.checkActive(Race.DEMI_HUMAN, false, 5) == RaceRules.ActiveResult.ON_COOLDOWN
						&& RaceRules.checkActive(Race.DEMI_HUMAN, false, 0) == RaceRules.ActiveResult.OK);
		check("Forma Bestial bloqueia conjuração; Forma Oni não; recargas 90 s e 120 s",
				RaceRules.blocksCasting(Race.DEMI_HUMAN, true) && !RaceRules.blocksCasting(Race.DEMI_HUMAN, false)
						&& !RaceRules.blocksCasting(Race.ONI, true) && !RaceRules.blocksCasting(null, true)
						&& RaceRules.cooldownTicks(Race.DEMI_HUMAN) == 1800 && RaceRules.cooldownTicks(Race.ONI) == 2400);
		check("equilíbrio: nenhuma raça sem custo — toda raça com ganho tem uma limitação mensurável",
				RaceRules.maxHealthBonus(Race.HALF_ELF) < 0 && RaceRules.castPcts(Race.DEMI_HUMAN, false)[1] < 0
						&& RaceRules.ONI_EXHAUST_TICKS > 0 && RaceRules.ONI_COOLDOWN_TICKS > RaceRules.DEMI_COOLDOWN_TICKS);

		// ---- E9b: Proteções Divinas ----
		ProtectionRules.Progress none9 = new ProtectionRules.Progress(null, 1, new int[5], 0, 0, null);
		ProtectionRules.Progress yang8 = new ProtectionRules.Progress(Affinity.YANG, 8, new int[5], 0, 0, Race.HUMAN);
		ProtectionRules.Progress earth5 = new ProtectionRules.Progress(Affinity.EARTH, 3, new int[] {5, 0, 0, 0, 0}, 0, 0, Race.ONI);
		ProtectionRules.Progress wind = new ProtectionRules.Progress(Affinity.WIND, 6, new int[] {0, 0, 4, 0, 0}, 0, 0, null);
		ProtectionRules.Progress saint = new ProtectionRules.Progress(Affinity.FIRE, 1, new int[] {0, 8, 0, 0, 0}, 6, 0, null);
		ProtectionRules.Progress bond3 = new ProtectionRules.Progress(Affinity.FIRE, 1, new int[5], 0, 3, null);
		check("5 proteções com ids 0..4 únicos; Santo da Espada é a única épica e ocupa 2 vagas",
				DivineProtection.values().length == 5 && DivineProtection.fromId(4) == DivineProtection.SWORD_SAINT
						&& DivineProtection.fromId(5) == null && DivineProtection.fromId(-1) == null
						&& java.util.Arrays.stream(DivineProtection.values()).filter(DivineProtection::epic).count() == 1
						&& DivineProtection.SWORD_SAINT.slotCost() == 2 && DivineProtection.SUN.slotCost() == 1);
		check("nenhuma proteção é concedida sem critério: sem marcos, nenhuma condição é cumprida",
				java.util.Arrays.stream(DivineProtection.values()).noneMatch(p -> ProtectionRules.conditionMet(p, none9))
						&& !ProtectionRules.conditionMet(null, yang8) && !ProtectionRules.conditionMet(DivineProtection.SUN, null));
		check("Sol: afinidade Yang e canais 8; Terra: afinidade Terra e Vigor 5; Vento: afinidade Vento, canais 6, Agilidade 4",
				ProtectionRules.conditionMet(DivineProtection.SUN, yang8)
						&& !ProtectionRules.conditionMet(DivineProtection.SUN, new ProtectionRules.Progress(Affinity.YANG, 7, new int[5], 0, 0, null))
						&& !ProtectionRules.conditionMet(DivineProtection.SUN, new ProtectionRules.Progress(Affinity.YIN, 20, new int[5], 0, 0, null))
						&& ProtectionRules.conditionMet(DivineProtection.EARTH_SPIRITS, earth5)
						&& !ProtectionRules.conditionMet(DivineProtection.EARTH_SPIRITS, new ProtectionRules.Progress(Affinity.EARTH, 3, new int[] {4, 0, 0, 0, 0}, 0, 0, null))
						&& ProtectionRules.conditionMet(DivineProtection.WIND_INDICATION, wind)
						&& !ProtectionRules.conditionMet(DivineProtection.WIND_INDICATION, new ProtectionRules.Progress(Affinity.WIND, 6, new int[] {0, 0, 3, 0, 0}, 0, 0, null)));
		check("Reunião de Espíritos: vínculo 3+; Santo da Espada: Força 8 e 6 técnicas (qualquer afinidade)",
				ProtectionRules.conditionMet(DivineProtection.GATHERING_SPIRITS, bond3)
						&& !ProtectionRules.conditionMet(DivineProtection.GATHERING_SPIRITS, new ProtectionRules.Progress(null, 1, new int[5], 0, 2, null))
						&& ProtectionRules.conditionMet(DivineProtection.SWORD_SAINT, saint)
						&& !ProtectionRules.conditionMet(DivineProtection.SWORD_SAINT, new ProtectionRules.Progress(null, 1, new int[] {0, 8, 0, 0, 0}, 5, 0, null))
						&& !ProtectionRules.conditionMet(DivineProtection.SWORD_SAINT, new ProtectionRules.Progress(null, 1, new int[] {0, 7, 0, 0, 0}, 9, 0, null)));
		int mSun = ProtectionRules.bit(DivineProtection.SUN);
		int mSun2 = mSun | ProtectionRules.bit(DivineProtection.GATHERING_SPIRITS);
		check("vagas: 2 no total; duas comuns cabem, a terceira não; a épica (2 vagas) só entra sozinha",
				ProtectionRules.slotsUsed(0) == 0 && ProtectionRules.slotsUsed(mSun2) == 2
						&& ProtectionRules.checkClaim(mSun, DivineProtection.EARTH_SPIRITS, earth5) == ProtectionRules.ClaimResult.OK
						&& ProtectionRules.checkClaim(mSun2, DivineProtection.EARTH_SPIRITS, earth5) == ProtectionRules.ClaimResult.NO_SLOTS
						&& ProtectionRules.checkClaim(mSun, DivineProtection.SWORD_SAINT, saint) == ProtectionRules.ClaimResult.NO_SLOTS
						&& ProtectionRules.checkClaim(0, DivineProtection.SWORD_SAINT, saint) == ProtectionRules.ClaimResult.OK);
		check("pedido: já tem = ALREADY; condição não cumprida = CONDITION; id inválido = UNKNOWN",
				ProtectionRules.checkClaim(mSun, DivineProtection.SUN, yang8) == ProtectionRules.ClaimResult.ALREADY
						&& ProtectionRules.checkClaim(0, DivineProtection.SUN, none9) == ProtectionRules.ClaimResult.CONDITION
						&& ProtectionRules.checkClaim(0, null, yang8) == ProtectionRules.ClaimResult.UNKNOWN);
		check("máscara adulterada vira segura: bits inválidos somem e nunca passa das vagas",
				ProtectionRules.sanitizeMask(-1) == (ProtectionRules.bit(DivineProtection.SUN) | ProtectionRules.bit(DivineProtection.GATHERING_SPIRITS))
						&& ProtectionRules.sanitizeMask(1 << 20) == 0
						&& ProtectionRules.sanitizeMask(ProtectionRules.bit(DivineProtection.SWORD_SAINT)) == ProtectionRules.bit(DivineProtection.SWORD_SAINT)
						&& ProtectionRules.slotsUsed(ProtectionRules.sanitizeMask(-1)) <= ProtectionRules.MAX_SLOTS);
		check("Sol só de dia com o céu à vista; Terra só no chão com vida abaixo de 60%",
				ProtectionRules.sunActive(false, true) && !ProtectionRules.sunActive(true, true) && !ProtectionRules.sunActive(false, false)
						&& ProtectionRules.earthActive(true, 11.9, 20.0) && !ProtectionRules.earthActive(true, 12.0, 20.0)
						&& !ProtectionRules.earthActive(false, 1.0, 20.0) && !ProtectionRules.earthActive(true, 1.0, 0.0));
		check("Reunião de Espíritos: +50% de XP de vínculo (arredonda para cima); sem ela, nada muda",
				ProtectionRules.bondXp(ProtectionRules.bit(DivineProtection.GATHERING_SPIRITS), 3) == 5
						&& ProtectionRules.bondXp(ProtectionRules.bit(DivineProtection.GATHERING_SPIRITS), 0) == 0
						&& ProtectionRules.bondXp(0, 3) == 3);
		int mSaint = ProtectionRules.bit(DivineProtection.SWORD_SAINT);
		check("Santo da Espada: -25% de estamina só em técnicas de espada; custo nunca abaixo de 1",
				ProtectionRules.staminaReductionPct(mSaint, CombatStyle.SWORD) == 25
						&& ProtectionRules.staminaReductionPct(mSaint, CombatStyle.SPEAR) == 0
						&& ProtectionRules.staminaReductionPct(0, CombatStyle.SWORD) == 0
						&& ProtectionRules.effectiveStaminaCost(40, 25) == 30 && ProtectionRules.effectiveStaminaCost(1, 90) == 1
						&& ProtectionRules.effectiveStaminaCost(40, 0) == 40 && ProtectionRules.effectiveStaminaCost(40, -5) == 40);
		TechniqueDef anySword = Techniques.slot(CombatStyle.SWORD, 0);
		int full = anySword.staminaCost();
		check("a redução de estamina vale na regra de uso: com estamina entre o custo reduzido e o cheio só passa com a bênção",
				CombatRules.checkUse(CombatRules.bit(anySword.id()), anySword, 0, ProtectionRules.effectiveStaminaCost(full, 25), false, 25) == CombatRules.UseResult.OK
						&& CombatRules.checkUse(CombatRules.bit(anySword.id()), anySword, 0, ProtectionRules.effectiveStaminaCost(full, 25), false, 0) == CombatRules.UseResult.NO_STAMINA
						&& CombatRules.checkUse(CombatRules.bit(anySword.id()), anySword, 0, full, false) == CombatRules.UseResult.OK);
		check("Indicação do Vento (ativa): sem a bênção, recarga e mana recusam na ordem certa",
				ProtectionRules.checkActive(0, 0, 100) == ProtectionRules.ActiveResult.NOT_OWNED
						&& ProtectionRules.checkActive(ProtectionRules.bit(DivineProtection.WIND_INDICATION), 5, 100) == ProtectionRules.ActiveResult.ON_COOLDOWN
						&& ProtectionRules.checkActive(ProtectionRules.bit(DivineProtection.WIND_INDICATION), 0, 19) == ProtectionRules.ActiveResult.NO_MANA
						&& ProtectionRules.checkActive(ProtectionRules.bit(DivineProtection.WIND_INDICATION), 0, 20) == ProtectionRules.ActiveResult.OK);

		// ---- E10: transformações ----
		TransformationRules.Context attuneOk = new TransformationRules.Context(false, 0, 10, 40, 4, true, 20.0, 20.0, 0);
		TransformationRules.Context standOk = new TransformationRules.Context(false, 0, 1, 0, 0, false, 6.0, 20.0, 4);
		check("4 transformações com ids 0..3; só Sintonia e Último Fôlego são ativadas por este sistema (as raciais vêm das raças)",
				Transformation.values().length == 4 && Transformation.fromId(3) == Transformation.LAST_STAND && Transformation.fromId(4) == null
						&& !Transformation.BEAST.selfActivated() && !Transformation.ONI.selfActivated()
						&& Transformation.ATTUNEMENT.selfActivated() && Transformation.LAST_STAND.selfActivated()
						&& TransformationRules.check(Transformation.BEAST, attuneOk) == TransformationRules.Result.NOT_SELF_ACTIVATED
						&& TransformationRules.check(null, attuneOk) == TransformationRules.Result.NOT_SELF_ACTIVATED);
		check("durações e recargas: raciais iguais às de RaceRules; Sintonia 30 s/4 min; Último Fôlego 10 s/5 min",
				TransformationRules.durationTicks(Transformation.BEAST) == RaceRules.FORM_TICKS
						&& TransformationRules.cooldownTicks(Transformation.ONI) == RaceRules.ONI_COOLDOWN_TICKS
						&& TransformationRules.durationTicks(Transformation.ATTUNEMENT) == 600 && TransformationRules.cooldownTicks(Transformation.ATTUNEMENT) == 4800
						&& TransformationRules.durationTicks(Transformation.LAST_STAND) == 200 && TransformationRules.cooldownTicks(Transformation.LAST_STAND) == 6000
						&& TransformationRules.manaCost(Transformation.ATTUNEMENT) == 40 && TransformationRules.manaCost(Transformation.LAST_STAND) == 0);
		check("Sintonia: tudo certo = OK; recusas na ordem: outra ativa, recarga, sem espírito, vínculo, não manifestado, canais, mana",
				TransformationRules.check(Transformation.ATTUNEMENT, attuneOk) == TransformationRules.Result.OK
						&& TransformationRules.check(Transformation.ATTUNEMENT, new TransformationRules.Context(true, 5, 10, 40, 4, true, 20.0, 20.0, 0)) == TransformationRules.Result.OTHER_ACTIVE
						&& TransformationRules.check(Transformation.ATTUNEMENT, new TransformationRules.Context(false, 5, 10, 40, 4, true, 20.0, 20.0, 0)) == TransformationRules.Result.ON_COOLDOWN
						&& TransformationRules.check(Transformation.ATTUNEMENT, new TransformationRules.Context(false, 0, 10, 40, 0, true, 20.0, 20.0, 0)) == TransformationRules.Result.NO_SPIRIT
						&& TransformationRules.check(Transformation.ATTUNEMENT, new TransformationRules.Context(false, 0, 10, 40, 3, true, 20.0, 20.0, 0)) == TransformationRules.Result.SPIRIT_BOND
						&& TransformationRules.check(Transformation.ATTUNEMENT, new TransformationRules.Context(false, 0, 10, 40, 4, false, 20.0, 20.0, 0)) == TransformationRules.Result.SPIRIT_NOT_SUMMONED
						&& TransformationRules.check(Transformation.ATTUNEMENT, new TransformationRules.Context(false, 0, 9, 40, 4, true, 20.0, 20.0, 0)) == TransformationRules.Result.CHANNELS
						&& TransformationRules.check(Transformation.ATTUNEMENT, new TransformationRules.Context(false, 0, 10, 39, 4, true, 20.0, 20.0, 0)) == TransformationRules.Result.NO_MANA);
		check("Último Fôlego: só com vida a 30% ou menos e Vigor 4+; sem custo de mana; recusas na ordem certa",
				TransformationRules.check(Transformation.LAST_STAND, standOk) == TransformationRules.Result.OK
						&& TransformationRules.check(Transformation.LAST_STAND, new TransformationRules.Context(false, 0, 1, 0, 0, false, 6.1, 20.0, 4)) == TransformationRules.Result.HEALTH_NOT_LOW
						&& TransformationRules.check(Transformation.LAST_STAND, new TransformationRules.Context(false, 0, 1, 0, 0, false, 6.0, 20.0, 3)) == TransformationRules.Result.VIGOR
						&& TransformationRules.check(Transformation.LAST_STAND, new TransformationRules.Context(false, 0, 1, 0, 0, false, 1.0, 0.0, 9)) == TransformationRules.Result.HEALTH_NOT_LOW
						&& TransformationRules.check(Transformation.LAST_STAND, new TransformationRules.Context(true, 0, 1, 0, 0, false, 1.0, 20.0, 9)) == TransformationRules.Result.OTHER_ACTIVE
						&& TransformationRules.check(Transformation.LAST_STAND, new TransformationRules.Context(false, 9, 1, 0, 0, false, 1.0, 20.0, 9)) == TransformationRules.Result.ON_COOLDOWN);
		check("a Sintonia soma potência +25%, custo -20%, regeneração +25% ao cálculo e respeita os tetos; as demais formas não mexem na magia",
				java.util.Arrays.equals(TransformationRules.castPcts(Transformation.ATTUNEMENT), new int[] {25, 20, 0, 25})
						&& java.util.Arrays.equals(TransformationRules.castPcts(Transformation.LAST_STAND), new int[] {0, 0, 0, 0})
						&& java.util.Arrays.equals(TransformationRules.castPcts(null), new int[] {0, 0, 0, 0})
						&& java.util.Arrays.equals(TransformationRules.sum(new int[] {0, -15, 0, 15}, new int[] {25, 20, 0, 25}), new int[] {25, 5, 0, 40})
						&& java.util.Arrays.equals(TransformationRules.sum(null, new int[] {1, 2, 3, 4}), new int[] {1, 2, 3, 4})
						&& Math.abs(EquipmentRules.combine(null, null, null, null, null, 0, TransformationRules.castPcts(Transformation.ATTUNEMENT)).power() - 1.25) < 1e-9
						&& EquipmentRules.combine(Catalyst.PRIMORDIAL, Charm.RESONANCE, null, null, null, 0, new int[] {900, 900, 900, 900}).cost() >= EquipmentRules.MIN_COST_ABS - 1e-9);
		check("esgotamento da Sintonia: a mana cai para no máximo 25% da capacidade e nunca sobe",
				TransformationRules.manaAfterAttunement(1000, 10) == (int) Math.floor(ChannelModel.maxMana(10) * 0.25)
						&& TransformationRules.manaAfterAttunement(1, 10) == 1 && TransformationRules.manaAfterAttunement(0, 10) == 0);
		check("equilíbrio: toda forma tem recarga longa (>= 90 s) e a mais forte para magia tem efeito colateral e recarga maior que a racial",
				java.util.Arrays.stream(Transformation.values()).allMatch(t -> TransformationRules.cooldownTicks(t) >= 1800)
						&& TransformationRules.cooldownTicks(Transformation.ATTUNEMENT) > RaceRules.ONI_COOLDOWN_TICKS
						&& TransformationRules.ATTUNE_WEAK_TICKS > 0 && TransformationRules.LAST_STAND_EXHAUST_TICKS > 0);

		// ---- E12: balanceamento cruzado (duas camadas de tetos) ----
		int[] max10 = {10, 10, 10, 10, 10};
		java.util.List<Inscription> topMarks = java.util.List.of(Inscription.SPRING, Inscription.BALANCE, Inscription.FORCE);
		int[] fullRobe = new int[RobeSet.values().length];
		fullRobe[RobeSet.values().length - 1] = 4;
		CastModifiers gearOnly = EquipmentRules.combine(Catalyst.PRIMORDIAL, Charm.FLUX, fullRobe, topMarks, max10, 0, null);
		CastModifiers gearAttune = EquipmentRules.combine(Catalyst.PRIMORDIAL, Charm.FLUX, fullRobe, topMarks, max10, 0,
				TransformationRules.castPcts(Transformation.ATTUNEMENT));
		CastModifiers gearDemi = EquipmentRules.combine(Catalyst.PRIMORDIAL, Charm.FLUX, fullRobe, topMarks, max10, 0, RaceRules.castPcts(Race.DEMI_HUMAN, false));
		check("com equipamento completo e treino 10 os tetos da camada 1 são atingidos (custo 0,6, regeneração 2,0, potência <= 2,0)",
				Math.abs(gearOnly.cost() - EquipmentRules.MIN_COST) < 1e-9 && Math.abs(gearOnly.regen() - EquipmentRules.MAX_REGEN) < 1e-9
						&& gearOnly.power() <= EquipmentRules.MAX_POWER + 1e-9 && gearOnly.cast() <= EquipmentRules.MIN_CAST + 1e-9);
		check("mesmo no fim do jogo a Sintonia ainda ajuda: mais potência, menos custo e mais regeneração que o equipamento sozinho",
				gearAttune.power() > gearOnly.power() && gearAttune.cost() < gearOnly.cost() && gearAttune.regen() > gearOnly.regen());
		check("e a penalidade de custo do demi-humano continua valendo no fim do jogo (custo 0,6 -> 0,75)",
				Math.abs(gearDemi.cost() - 0.75) < 1e-9 && gearDemi.cost() > gearOnly.cost());
		check("o espírito também soma depois do teto: com equipamento completo, +15% de potência ainda muda o resultado",
				EquipmentRules.combine(Catalyst.PRIMORDIAL, Charm.FLUX, fullRobe, topMarks, max10, 15, null).power() > gearOnly.power());
		boolean allInside = true;
		int combos = 0;
		for (Catalyst st : Catalyst.values()) {
			for (Charm ch : Charm.values()) {
				for (int spirit : new int[] {0, 15}) {
					for (Transformation tf : Transformation.values()) {
						for (Race rc : Race.values()) {
							int[] pcts = TransformationRules.sum(RaceRules.castPcts(rc, tf == Transformation.BEAST || tf == Transformation.ONI),
									TransformationRules.castPcts(tf));
							CastModifiers m = EquipmentRules.combine(st, ch, fullRobe, topMarks, max10, spirit, pcts);
							combos++;
							if (m.power() > EquipmentRules.MAX_POWER_ABS + 1e-9 || m.cost() < EquipmentRules.MIN_COST_ABS - 1e-9
									|| m.cast() < EquipmentRules.MIN_CAST_ABS - 1e-9 || m.regen() > EquipmentRules.MAX_REGEN_ABS + 1e-9
									|| m.power() < 1.0 - 1e-9 && false) {
								allInside = false;
							}
						}
					}
				}
			}
		}
		check("varredura de pior caso (" + combos + " combinações de cajado, acessório, espírito, forma e raça): nenhum valor passa dos limites absolutos",
				allInside && combos > 300);

		check("raça e bênção: o meio-elfo recebe a Reunião de Espíritos com vínculo 2; as demais raças precisam de 3",
				ProtectionRules.gatheringBond(Race.HALF_ELF) == 2 && ProtectionRules.gatheringBond(Race.HUMAN) == 3 && ProtectionRules.gatheringBond(null) == 3
						&& ProtectionRules.conditionMet(DivineProtection.GATHERING_SPIRITS, new ProtectionRules.Progress(null, 1, new int[5], 0, 2, Race.HALF_ELF))
						&& !ProtectionRules.conditionMet(DivineProtection.GATHERING_SPIRITS, new ProtectionRules.Progress(null, 1, new int[5], 0, 2, Race.ONI))
						&& !ProtectionRules.conditionMet(DivineProtection.GATHERING_SPIRITS, new ProtectionRules.Progress(null, 1, new int[5], 0, 1, Race.HALF_ELF)));

		System.out.println();
		System.out.println("Resultado: " + passed + " ok, " + failed + " falhas");
		if (failed > 0) {
			System.exit(1);
		}
	}
}
