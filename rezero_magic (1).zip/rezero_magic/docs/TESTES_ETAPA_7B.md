# Testes da Etapa 7b (para você fazer quando puder)

Compile no GitHub (mesmo processo). Versão 0.9.0 (jar `rezero_magic-0.9.0.jar`; apague o jar antigo da pasta mods).
Arquivos mais prováveis de falhar no build: `server/CombatService.java` e `server/CombatEffects.java` (eventos de dano do Fabric,
pacote de velocidade da entidade, atributos). Se falhar, me mande o erro. Mundos antigos funcionam (dados versão 4 -> 5).

## Teclas (Controles > Re:Zero Magia)
- V = esquivar (para a direção em que você anda; sem tecla de direção, esquiva para trás). G, H, J = técnica 1, 2 e 3 da arma na mão.

## Estamina e esquiva
1. HUD (canto superior esquerdo): barra verde de Estamina (100 no começo; +6 por nível de Vigor). Regenera 10/s (+0,5 por nível de Agilidade),
   começando 1 s depois do último gasto.
2. Esquiva custa 20, recarga de 1,5 s. Por 0,4 s você não recebe dano de ataques de criaturas (queda, fogo e vazio continuam valendo).
   Depois de esquivar, o PRÓXIMO golpe comum em até 1,5 s causa 50% a mais ("Contra-ataque!").
3. Combo: 3 golpes comuns seguidos (até 1,25 s entre eles) -> o 3º ganha +25% ("Combo! Golpe final."). O bônus chega ~0,5 s depois do golpe
   (como um segundo impacto), porque o jogo ignora dano durante a invulnerabilidade do alvo. Se contra-ataque e combo coincidem, os dois somam.

## Aprender técnicas (Hub > aba "Técnicas")
4. Pontos de técnica = soma dos níveis dos 5 atributos de treino menos o que já gastou. Cada técnica custa o número do seu tier (1, 2 ou 3).
   Todas as 15 custam 30 pontos no total; com tudo no nível 10 você tem 50.
5. Requisitos: tier 1 = atributo nível 1; tier 2 = nível 3 e ter o tier 1; tier 3 = nível 5 e ter o tier 2. As páginas (< >) mostram um estilo
   por vez, com dano %, alcance, estamina, recarga, carga, requisito e o motivo da recusa. Aprender é irreversível (não há esquecer).
   Para testar rápido: /rezero admin nivel_canais 16 (allowAdminReset=true) e treinar no Poste, pois o teto dos atributos sobe com os canais.

## Estilos (a arma na mão principal decide)
6. Espada: qualquer espada do jogo ou do mod (exceto a Adaga de Cristal). Lança: Lança de Mana, Lança de Cristal (novas, receita em diagonal:
   cristal/cristal puro no canto superior direito e 2 gravetos) ou tridente. Adaga: Adaga de Cristal. Desarmado: mão vazia. Arco: arco.
   Qualquer outro item na mão: sem técnicas.
7. Técnicas (3 por estilo), números na aba:
   - Espada: Corte Largo (arco), Golpe Pesado (carga 0,5 s, forte, arremessa), Contra-golpe (1 s de postura: bloqueia um ataque de criatura e revida).
   - Lança: Estocada (linha, até 2 alvos), Investida (avança e golpeia no fim), Giro da Lança (carga, atinge todos ao redor).
   - Adaga: Rajada (3 golpes), Golpe pelas Costas (dobro se o alvo estiver de costas), Passo Sombrio (avanço, invulnerável 0,3 s e Velocidade).
   - Desarmado: Soco Duplo, Onda de Impacto (carga), Guarda Firme (Resistência por 2 s).
   - Arco: Tiro Perfurante (até 3 alvos), Salva (5 disparos em leque, carga), Tiro de Amarração (Lentidão III e Fraqueza por 4 s).
     As técnicas de arco gastam 1 flecha do inventário (no criativo não gastam) e não disparam flecha física: são acertos instantâneos em linha.
8. Técnicas com carga são interrompidas se você sofrer dano ou trocar de arma (a estamina já gasta não volta).
9. Dano: usa o ataque da arma na mão (já com o bônus de Força do treino); desarmado e arco usam valor fixo (5 e 7) mais o bônus de Força.
   Técnicas treinam Força (como golpes comuns) e não formam combo.
10. Sair e entrar: técnicas aprendidas continuam; estamina e recargas voltam ao cheio/zero.
