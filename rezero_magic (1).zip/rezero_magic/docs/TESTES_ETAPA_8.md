# Testes da Etapa 8 (para você fazer quando puder)

Compile no GitHub (mesmo processo). Versão 0.10.0 (jar `rezero_magic-0.10.0.jar`; apague o jar antigo da pasta mods).
Arquivos mais prováveis de falhar no build: `server/SpiritService.java` (evento de quebra de bloco do Fabric, `isNight`, `isSkyVisible`,
`getLightLevel`, efeitos de status) e `client/HubScreen.java`. Se falhar, me mande o erro. Mundos antigos funcionam (dados versão 5 -> 6).

## Honestidade sobre o canon
- Da obra só duas coisas foram verificadas (página "Magic" do Otaku Mode): existem espíritos e é possível formar contrato com eles.
  Todo o resto (luzes, condições de aparição, vínculo, custo de mana, habilidades, números) é ADAPTAÇÃO de jogo.
- Nenhum personagem da obra é usado (sem Puck, Beatrice etc.). O espírito é só um companheiro de partículas, sem modelo nem entidade própria.
- Como o jogador tem UMA afinidade, só dá para contratar o espírito do SEU elemento. Os outros 5 tipos existem no código, mas ficam
  inalcançáveis para você (por design do mod).

## Teclas (Controles > Re:Zero Magia)
- B = manifestar/dispensar o espírito. N = habilidade do espírito (vínculo 3+).

## Luzes de espírito e contrato
1. Requisitos: afinidade escolhida e canais de mana no nível 4 ou mais (use /rezero admin nivel_canais 4 com allowAdminReset=true para testar).
2. Luzes aparecem (faíscas de partículas, só você as vê, só do seu elemento) a cada ~10 s com 25% de chance, se você não tem contrato e
   estiver no ambiente certo; duram 1 min. Mensagem: "Uma luz de espírito do seu elemento está por perto."
   - Fogo: Nether ou Y 10 ou menos. Água: chuva a céu aberto ou dentro d'água. Vento: Y 100 ou mais, céu aberto.
     Terra: Y 40 ou menos, sem céu. Yin: noite com luz 7 ou menos. Yang: dia, céu aberto, Y 62 ou mais.
3. Pedra de Contrato (receita sem forma: cristal puro + fragmento de ametista + barra de ouro + lápis-lazúli). Use com a luz a até 6 blocos.
   A pedra é gasta (não no criativo). Recusas: sem afinidade, canais baixos, já tem contrato, sem luz por perto.

## Vínculo e manifestação
4. B manifesta o espírito (partículas em órbita). Enquanto manifestado, gasta mana (0,5 + 0,25 x vínculo por segundo). Se a mana acaba, ele se dissipa.
5. Vínculo 1 a 5. XP: +1 a cada 20 s juntos, +2 por feitiço lançado e o temperamento do elemento:
   Fogo (causar dano), Água (chuva/dentro d'água), Vento (correr), Terra (quebrar blocos), Yin (noite), Yang (dia a céu aberto).
   XP necessário = 100 x vínculo atual. Subir de nível mostra mensagem.
6. Manifestado: +3% de potência dos feitiços por nível de vínculo (entra na mesma soma limitada do equipamento; teto de potência 2,0).
7. Passiva (renovada a cada segundo): Fogo resistência ao fogo; Água respiração aquática; Vento queda lenta; Terra pressa;
   Yin visão noturna; Yang regeneração com vida abaixo de 50%.
8. Habilidade (vínculo 3+, espírito manifestado, 30 mana, recarga 60 s): Fogo explosão de chamas (5 blocos); Água cura e apaga fogo;
   Vento empurra (6 blocos) e dá Velocidade; Terra Resistência II 8 s; Yin lentidão e fraqueza (8 blocos); Yang Regeneração II e Força.
9. Hub > aba "Espírito" (8ª aba): contrato, vínculo, XP, estado, temperamento, passiva, números e botões Manifestar/Dispensar,
   Habilidade e Romper contrato. Sem contrato, mostra onde procurar e se há luz por perto. Romper apaga o vínculo.
10. HUD (canto superior direito, só com contrato): nome, vínculo, estado e habilidade.
11. Sair e entrar: contrato e vínculo ficam; o espírito volta dispensado e a recarga zera. Morrer mantém o contrato (dados copiados).
