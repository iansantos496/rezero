# Relatório final — Mod Re:Zero Magia (Fabric 1.21.11) — versão 1.0.0

Data: 04/11/2026. Projeto feito do zero em 13 etapas (E0 a E12). Idioma do jogo: português do Brasil (en_us tem as mesmas chaves).

## AVISO HONESTO (leia primeiro)
- **O projeto NUNCA foi compilado nem jogado.** Este ambiente não consegue compilar o Minecraft. Só o código "puro" (pacote `core`) foi compilado e testado aqui.
- Só o projeto ANTIGO (v1.2) teve build confirmado, com as mesmas versões. O código novo usa muitas APIs do Minecraft/Yarn que eu escrevi de memória e marquei como "não confirmado" no PROGRESSO.md. **É esperado que o primeiro build no GitHub dê alguns erros de compilação.** Me mande o erro e eu corrijo.
- Nenhum número de equilíbrio foi sentido no jogo; só foi checado por conta (testes de limites).
- Nada aqui usa Retorno por Morte nem equivalente. Nenhum personagem de Re:Zero aparece como NPC, entidade ou jogável. Conteúdo só até o fim do Arco 9.

---

## 1. Sistemas implementados (estado de cada um)
Classificação obrigatória. "Não testado" = código escrito e verificado só por testes do core + checagem estática; nunca executado no Minecraft.

| # | Sistema | Classificação |
|---|---|---|
| S1 | Magia elemental | Parcialmente implementado (não testado) |
| S2 | Cristais de mana | Parcialmente implementado (não testado) |
| S3 | Espíritos | Parcialmente implementado (não testado) |
| S4 | Proteções Divinas | Parcialmente implementado (não testado) |
| S5 | Equipamentos | Parcialmente implementado (não testado) |
| S6 | Treinamento | Parcialmente implementado (não testado) |
| S7 | Raças | Parcialmente implementado (não testado) |
| S8 | Inscrições mágicas | Parcialmente implementado (não testado) |
| S9 | Técnicas de combate | Parcialmente implementado (não testado) |
| S10 | Canais de mana | Parcialmente implementado (não testado) |
| S11 | Transformações | Parcialmente implementado (não testado) |
| S12 | Seleção de afinidade | Implementado mas não testado |
| Hub | Painel central (10 abas) | Implementado mas não testado |

Nenhum sistema está "implementado e testado" no sentido de jogo: a lógica pura tem testes (185 ok), o resto não foi executado.

## 2. Funcionalidades de cada sistema
- **S1 Magia elemental:** 6 afinidades (Fogo, Água, Vento, Terra, Yin, Yang) × 5 feitiços = 30. Cada feitiço tem custo, tempo de conjuração, recarga, alcance e efeito próprios (projéteis, zonas, paredes, cura, prisões, buffs). Seleção por Z/X, conjuração por R, regras de mana/recarga validadas no servidor. Canon: os nomes Goa/Elgoa/Urgoa/Algoa (Fogo), Dona (Terra), Shamak (Yin) e o sistema de afinidade; o que cada feitiço faz é adaptação. Falta: interação entre elementos (sem base canônica), feitiços de nível acima de 5 por afinidade.
- **S2 Cristais:** 4 raridades (Fragmento, Cristal, Puro, Primordial) com carga de mana; minério gerado no mundo; Concentrador de Mana (bloco); usados como carga de mana e como tinta de inscrição. Falta: reparo de equipamento com cristal.
- **S3 Espíritos:** contrato único com o espírito da sua afinidade (Pedra de Contrato usada perto de uma centelha de espírito, que é só efeito de partículas, não entidade; o servidor confere afinidade, canais, contrato anterior e distância), nível de vínculo 1–5 com XP, manifestação com custo de mana (tecla B), habilidade ativa (tecla N, vínculo >= 4), passivas e bônus de potência. Falta: espírito como entidade com modelo, mais de um contrato, espíritos selvagens, persistência do estado manifestado.
- **S4 Proteções Divinas:** 5 proteções (Sol, Reunião de Espíritos, Espíritos da Terra, Indicação do Vento, Santo da Espada [épica, ocupa 2 vagas]); 2 vagas; condições para receber validadas no servidor; passivas (Sol: Força de dia ao céu aberto; Terra: Regeneração no chão com vida baixa), bônus de vínculo (+50%), redução de estamina de espada (25%) e uma ativa (Indicação do Vento, tecla Y: revela hostis próximos). Meio-elfo precisa de vínculo 3 para Reunião de Espíritos. Falta: Linguagem das Almas, Deus da Morte, Clarividência, Trissecção; perda temporária por corte com o Od Laguna.
- **S5 Equipamentos:** 4 cajados (Aprendiz, Cristal, Puro, Primordial), 5 amuletos, robe em 4 peças, 8 armas (adaga de cristal, espada curta, rapieira de cristal, espada longa, espada grande, lâmina primordial, lança de mana, lança de cristal), catalisadores com bônus de potência/custo/conjuração/regeneração. Falta: requisitos para equipar, proteção física das armaduras, melhoria/reparo.
- **S6 Treinamento:** 5 atributos (Vigor, Força, Agilidade, Foco, Controle) níveis 0–10, treinados por ações reais (correr, bater, pular, conjurar, gastar mana) e por Poste de Treino; atributos aplicados no servidor (vida, ataque, velocidade, conjuração, custo/regeneração). Falta: tetos de treino por raça.
- **S7 Raças:** Humano, Meio-elfo, Demi-humano, Oni; escolha única; bônus/limitações de vida, ataque, velocidade, XP de treino e de vínculo; efeitos na magia; forma ativa (tecla C, 400 ticks; recargas 1800/2400; exaustão do oni; demi-humano não conjura na forma). Canon: existem as 4 raças e as formas fera/Oni; números são adaptação.
- **S8 Inscrições:** 12 marcas em 4 categorias (Poder, Economia, Defesa, Utilidade), até 3 por vez, gravadas NO JOGADOR numa Mesa de Inscrição com tinta (Tinta de Mana). Desvio do plano: o plano previa gravar em itens; isso foi cortado por exigir componente de item não confirmado.
- **S9 Técnicas de combate:** 5 estilos (Espada, Lança, Adaga, Punhos, Arco) × 3 técnicas = 15, com estamina, recarga, nível de treino mínimo e dano; teclas G/H/J, esquiva V. Falta: técnicas imbuídas com mana.
- **S10 Canais de mana:** níveis 1–20 com XP, define o mana máximo e a regeneração. Falta: o "Gate" canônico (adaptação de progressão, sem sistema de Gate).
- **S11 Transformações:** Fera, Forma Oni (raciais), Sintonia Elemental (tecla U; espiritual; exige vínculo 4, canais 10, 40 de mana; 600 ticks; custa mana depois) e Último Fôlego (tecla O; vida <= 30% e Vigor >= 4; 200 ticks; exaustão depois). Nenhuma evita a morte. Sintonia e Último Fôlego são adaptação. Falta: modelo visual novo, formas por elemento.
- **S12 Seleção de afinidade:** tela obrigatória na primeira entrada, escolha de 1 entre 6 cartões com confirmação, escolha única e salva no jogador; reset só por comando de teste (desligado por padrão).
- **Hub:** ver item 4.

## 3. Integrações realizadas
Tudo passa pelo servidor (autoridade): equipamento + treino + marcas + robe → camada 1; espírito + raça + forma → camada 2 (ver item 11). Treino aplica atributos de raça; raça multiplica XP de treino e de vínculo; Proteções somam ao vínculo e reduzem estamina de técnica; Transformações somam à raça; forma da raça e transformação não coexistem (uma por vez); demi-humano em forma não conjura; ganhar afinidade abre a tela de raça; todo estado temporário é zerado ao entrar e ao renascer. A auditoria (docs/AUDITORIA_E11.md + `check_static.py` seção 3m) confere automaticamente registro de pacotes, receptores, `init/reset` dos serviços e teclas sem duplicata.

## 4. Funcionamento do Hub
Tecla K. Abre com 10 abas: Perfil, Magias, Cristais, Equip., Marcas, Treino, Técn., Espír., Bênç., Formas (com < > para rolar quando a janela é pequena). Só mostra dados que o servidor enviou (espelho no cliente); botões só enviam pedidos, e o servidor pode recusar com mensagem. Mostra custos reais (inclusive estamina já reduzida). Sem dados inventados.

## 5. Funcionamento da seleção de afinidade
Na primeira entrada o servidor abre a tela. O jogador escolhe UM entre 6 cartões (Fogo, Água, Vento, Terra, Yin, Yang) e confirma numa segunda etapa (lógica pura em `AffinityPicker`, testada); o servidor valida (`AffinityRules.canChoose`) e grava (campo `affinity`). Não há sorteio. Uma só por jogador, sem troca no jogo normal. `/rezero admin resetar_afinidade` só funciona com `allowAdminReset=true`.

## 6. Arquivos criados
Todos (projeto do zero). Código Java em `src/main/java/com/rezero/mod`: `core` 30 arquivos/2299 linhas; `data` 2/368; `net` 24/670; `server` 20/4148; `client` 11/2205; `content` 14/625; mais 2 na raiz (`ReZeroMod`, config). Recursos: 183 arquivos (lang pt_br/en_us, modelos, texturas, blockstates, loot tables, receitas, worldgen). Ferramentas: `tools/core-tests/CoreTests.java`, `tools/test_core.sh`, `tools/check_static.py`. Docs: PLANO, PROGRESSO, AUDITORIA_E11, TESTES_ETAPA_*, este relatório. Build: `build.gradle`, `settings.gradle`, `gradle.properties`, wrapper.

## 7. Arquivos modificados
Como o projeto é do zero, não há arquivo "original" modificado; os arquivos foram sendo ampliados ao longo das etapas. Os mais reescritos na E12: `core/EquipmentRules.java` (2 camadas), `core/ProtectionRules.java` (vínculo do meio-elfo), `tools/core-tests/CoreTests.java`, `docs/*`, `gradle.properties` (1.0.0).

## 8. Dependências utilizadas
Minecraft 1.21.11; Yarn 1.21.11+build.4; Fabric Loader 0.18.4 (exige >= 0.18.1); Fabric API 0.141.1+1.21.11; Fabric Loom 1.14-SNAPSHOT; Java 21; Gradle 9.2.1. Nenhuma biblioteca externa além do Fabric.

## 9. Resultado da compilação
**NÃO compilado.** Nem o jar nem o Minecraft foram compilados por mim. Compilado e testado aqui: apenas `core` (javac). A primeira compilação real será no seu GitHub.

## 10. Testes executados
- `bash tools/test_core.sh` → **185 ok, 0 falhas** (regras de afinidade, canais, feitiços, cristais, equipamentos, treino, espírito, raças, proteções, transformações, inscrições, técnicas; inclui varredura de 640 combinações de pior caso dentro dos tetos).
- `python3 -I tools/check_static.py` → **OK** (JSON válido, chaves de tradução idênticas, textos de tudo que aparece na tela, pacotes/receptores/serviços/teclas coerentes).
- **NÃO executado:** compilação, jogo, teclas, partículas, sons, efeitos de tela, rede em servidor real, persistência real, equilíbrio sentido.

## 11. Problemas encontrados e corrigidos (principais, E12)
- **Equilíbrio:** com equipamento máximo, o teto único (potência 2.0, custo 0.6...) fazia espírito, raça e forma não valerem nada no fim do jogo. Corrigido com 2 camadas: camada 1 permanente com os tetos antigos; camada 2 situacional somada depois, com tetos absolutos (potência 2.25, custo 0.5, conjuração 0.5, regeneração 2.5). Testado nas 640 combinações e em casos de borda (penalidade de custo do demi-humano; Sintonia ainda importa).
- Falso alarme do `check_static` com chave dinâmica de tecla de técnica: corrigido.
- Conflito de tecla (raça × outra): raça passou para C.
- Import não usado em `TransformService`: removido.

## 12. Problemas ainda existentes (riscos conhecidos)
- **Risco principal: erros de compilação** de APIs não confirmadas. Mais prováveis: `client/HubScreen.java` (`ButtonWidget.setX`), `server/AdminCommands.java` (lambdas de comando), `server/ProtectionService.java` (`HostileEntity`, `getEntitiesByClass` com Predicate, `World.isNight/isSkyVisible`, `isOnGround`), `server/TrainingService.java` (modificador de vida negativo), efeitos/partículas em `SpellEffects`.
- Equilíbrio nunca sentido no jogo (pode precisar de ajuste de números).
- Comandos de teste não checam permissão de operador (protegidos só por `allowAdminReset=false` por padrão).
- Estado de transformação não é salvo (some ao relogar; é intencional, mas não testado).

## 13. Funcionalidades que não puderam ser concluídas
Requisitos para equipar; reparo com cristal; tetos de treino por raça; técnicas imbuídas com mana; interação entre elementos; armaduras com proteção física (3 sets); inscrições em itens (feitas no jogador); espíritos como entidades com modelo, múltiplos contratos e selvagens; formas por elemento; Linguagem das Almas, Deus da Morte, Clarividência, Trissecção; perda de proteção por Od Laguna; Gate canônico. Todas foram cortadas por falta de base canônica verificada ou por exigirem API que não pude confirmar sem compilar. Nada disso aparece no jogo como se existisse.

## 14. Instruções para instalar e executar
1. Envie o `rezero_magic.zip` (sem extrair) para o seu repositório do GitHub; o workflow `build.yml` descompacta e roda `gradle build` em `work/rezero_magic`.
2. Em Actions, baixe o artefato e use o jar **sem** `-sources`: `rezero_magic-1.0.0.jar`.
3. Instale Minecraft 1.21.11 com Fabric Loader (>= 0.18.1) e coloque na pasta `mods`: o jar + **Fabric API 0.141.1+1.21.11**. Apague qualquer jar antigo do mod.
4. Opcional (para testar): crie `config/rezero_magic.properties` com `allowAdminReset=true` para usar `/rezero admin ...` (só afeta você).
5. Entre num mundo novo: afinidade → raça → K abre o Hub. Teclas: K Hub, R conjurar, Z/X feitiço, V esquiva, G/H/J técnicas, B espírito, N habilidade do espírito, C forma racial, Y proteção ativa, U Sintonia, O Último Fôlego.
6. Se o build falhar, me envie o erro.

---
## Canon x adaptação (resumo)
**Verificado (Otapedia/obra):** Od Lagna; os 6 atributos e prefixos (Goa, Huma, Dona, Shamak; El/Ur/Al); espíritos existem e fazem contrato; conceito e exemplos de Proteção Divina; traços básicos das 4 raças; formas raciais (fera, Oni). **Todo o resto** (números, custos, efeitos, estrutura de progressão, equipamentos, marcas, técnicas, Sintonia e Último Fôlego) é **adaptação de jogo** e está rotulado assim nas telas.
