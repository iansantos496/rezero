# Testes da Etapa 10 (Transformações) — para você fazer quando puder

Compile no GitHub (mesmo processo). Versão 0.13.0 (jar `rezero_magic-0.13.0.jar`; apague o jar antigo da pasta mods).
Arquivos mais prováveis de falhar no build: `server/TransformService.java`, `client/TransformHud.java` e `client/HubScreen.java`
(agora com 10 abas). Se falhar, me mande o erro. Nenhum dado novo é salvo (estados são temporários): mundos antigos funcionam.

## Honestidade sobre o canon
- Verificado: só as transformações RACIAIS (fera dos demi-humanos, Forma Oni) — já vinham das Raças (E9a).
- Sintonia Elemental e Último Fôlego são INVENÇÕES de jogo (adaptação), marcadas assim na tela. Nenhuma cura, revive ou evita a morte.
- Visual: só partículas e tingimento nas bordas da tela; o modelo do jogador não muda.

## Regra geral
1. Só UMA transformação por vez (racial ou não). Tentar outra mostra "Você já está transformado."
2. Todas têm duração, recarga longa (90 s a 5 min) e efeito colateral ao terminar. Nada é salvo: ao sair/entrar ou morrer tudo desliga e as recargas zeram.
3. Efeito de tela: as 4 bordas ficam tingidas enquanto qualquer forma está ativa (laranja = Bestial, vermelho = Oni, azul = Sintonia, branco = Último Fôlego).

## Sintonia Elemental (tecla U) — espírito
4. Condições (servidor): contrato com espírito no vínculo 4+, espírito MANIFESTADO (tecla B), canais nível 10+, 40 mana. Recusas com mensagem própria.
5. 30 s: +25% de potência, -20% de custo de mana, +25% de regeneração (somam com o equipamento, respeitando os tetos) e Resistência I.
   Os números dos feitiços no Hub/HUD já mostram esses valores (mesmo cálculo do servidor).
6. Ao terminar: a mana cai para no máximo 25% da capacidade e 10 s de Fraqueza. Recarga de 4 min. Custa 40 mana ao ativar.
   Para testar: /rezero admin nivel_canais 10 (allowAdminReset=true), contrato de espírito e vínculo 4 (leva tempo; ou use o gasto de mana no vínculo).

## Último Fôlego (tecla O) — emergência
7. Condições: vida em 30% ou menos e Vigor no nível 4+. Sem custo de mana. 10 s: Resistência II e Velocidade I.
8. NÃO cura e NÃO impede a morte (um golpe forte ainda mata). Ao terminar: 15 s de Lentidão e Fraqueza. Recarga de 5 min.

## Formas raciais (tecla C, já da E9a)
9. Continuam como estavam; agora respeitam "uma por vez" (não dá para usar Sintonia ou Último Fôlego durante a Forma Bestial/Oni e vice-versa).

## Hub > aba "Formas" (10ª aba; rótulos das abas foram encurtados)
10. Uma forma por página (< >): tipo, estado (ativa/recarregando/pronta/"não é da sua raça"), canon ou aviso de invenção, condição, efeito, efeito
    colateral, duração/recarga/custo. O botão "Ativar" existe só para Sintonia e Último Fôlego e fica ativo só se as condições valem no momento.
11. HUD (canto superior direito, abaixo das bênçãos): linha da Sintonia (se você tem espírito) e do Último Fôlego quando ativo ou recarregando.

## Limites conhecidos
- Sem transformação com modelo novo do jogador; sem transformações de espírito por elemento (a Sintonia é única para os seis elementos).
- O ícone de efeito de tela é simples (bordas coloridas); não há distorção de imagem.
- As abas do Hub estão apertadas em janelas pequenas; o Hub final (E11) vai reorganizá-las.
