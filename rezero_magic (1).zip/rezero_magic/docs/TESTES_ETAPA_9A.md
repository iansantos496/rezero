# Testes da Etapa 9a (Raças) — para você fazer quando puder

Compile no GitHub (mesmo processo). Versão 0.11.0 (jar `rezero_magic-0.11.0.jar`; apague o jar antigo da pasta mods).
Arquivos mais prováveis de falhar no build: `server/RaceService.java`, `server/TrainingService.java` (modificador de vida negativo,
`setHealth`) e `client/RaceScreen.java`. Se falhar, me mande o erro. Mundos antigos funcionam (dados versão 6 -> 7).

## Honestidade sobre o canon
- Verificado (Otapedia): existem humanos, meio-elfos (sofrem preconceito), demi-humanos (físico superior; transformam-se em fera, parcial ou
  total, e agem por instinto), oni (chifre reúne mana do ambiente; a Forma Oni aumenta a força física).
- Aptidão para espíritos como traço de RAÇA é adaptação (na obra é traço pessoal). TODOS os números são adaptação.
- Nenhum personagem da obra é usado; só as raças.

## Escolha da raça (única vez)
1. Depois de escolher a afinidade, abre a tela "Escolha sua raça" (não fecha com ESC). Escolha -> "Escolher" -> "Sim, confirmar".
   Em mundo antigo (afinidade já escolhida, sem raça), a tela abre ao entrar. Não é possível trocar depois (o servidor recusa).
2. Hub > Perfil mostra a raça, as vantagens e as limitações.

## O que cada raça faz (números exatos também aparecem na tela)
- Humano: +10% de XP em todos os atributos de treino. Sem outro bônus e sem limitação (opção neutra).
- Meio-elfo: -1 coração; +25% de XP de vínculo com o espírito; +10% de regeneração de mana; +20% de XP de Foco.
- Demi-humano: +2 corações, +0,5 de ataque, +3% de velocidade, +20% de XP de Vigor e Força; feitiços gastam 15% MAIS de mana.
  Tecla C: Forma Bestial (20 s de Força I e Velocidade I). Transformado você NÃO conjura (mensagem). Recarga 90 s.
- Oni: +1 coração, +0,5 de ataque, +15% de regeneração de mana, +20% de XP de Força e Controle.
  Tecla C: Forma Oni (20 s de Força I e +50% de regeneração de mana). Ao terminar: 10 s de lentidão e fraqueza. Recarga 120 s.
3. Vida, ataque e velocidade da raça somam com o treino. Confira os corações no HUD e o ataque no tooltip da arma.
4. O custo maior do demi-humano e a regeneração do oni aparecem nos números da aba Feitiços e no custo do HUD (mesmo cálculo do servidor).
5. A transformação não é salva: ao sair/entrar ou morrer ela desliga e a recarga zera. Humano e meio-elfo apertando C: mensagem "sem transformação".
6. HUD (canto superior direito, abaixo do espírito): só para demi-humano e oni: tecla, estado e tempo.

## Limites conhecidos
- Não há resistências/fraquezas por tipo de dano (só vida, custo de mana, exaustão). Sem raça "gigante", "kobold" etc. (pouca base de canon).
- Não há comando para trocar de raça (nem administrativo) neste momento; para testar outra raça, use outro mundo.
