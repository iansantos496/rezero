# Testes da Etapa 9b (Proteções Divinas) — para você fazer quando puder

Compile no GitHub (mesmo processo). Versão 0.12.0 (jar `rezero_magic-0.12.0.jar`; apague o jar antigo da pasta mods).
Arquivos mais prováveis de falhar no build: `server/ProtectionService.java` (HostileEntity, getEntitiesByClass com filtro, isNight,
isSkyVisible, isOnGround) e `client/HubScreen.java`. Se falhar, me mande o erro. Mundos antigos funcionam (dados versão 7 -> 8).

## Honestidade sobre o canon
- Verificado (Otapedia): Proteção Divina é uma bênção do mundo recebida AO NASCER; a maioria nasce sem; cerca de 1 em 1000 tem uma útil;
  é incompatível com Fator de Bruxa; pode ser perdida temporariamente se a ligação com o Od Laguna for cortada; algumas têm restrições.
  Existem (entre outras) Indicação do Vento, Sol (mais forte de dia), Reunião de Espíritos, Santo da Espada e Espíritos da Terra.
- ADAPTAÇÃO: a bênção "desperta" ao cumprir um marco e é recebida por pedido (nada é sorteado); 2 vagas no total; todos os números.
- Não foram feitas: Linguagem das Almas, Deus da Morte, Clarividência, Trissecção (sem base de jogo segura). Nada de Retorno por Morte.
- O Santo da Espada aqui é só uma versão leve (menos estamina em técnicas de espada), não o poder completo da obra.

## Receber (Hub > aba "Bênçãos")
1. A aba mostra uma proteção por página (< >): canon, efeito, limitação, condição e se ela já foi cumprida. Botão "Receber" só fica ativo com a
   condição cumprida e vaga livre. A escolha é PERMANENTE (não há devolver). Vagas: 2; as quatro comuns ocupam 1; a épica ocupa as 2.
2. Condições (todas conferidas no servidor):
   - Sol: afinidade Yang e canais nível 8. Reunião de Espíritos: contrato com espírito no vínculo 3.
   - Espíritos da Terra: afinidade Terra e Vigor 5. Indicação do Vento: afinidade Vento, canais 6 e Agilidade 4.
   - Santo da Espada: Força 8 e 6 técnicas aprendidas (qualquer afinidade).
   Para testar rápido: /rezero admin nivel_canais 16 (allowAdminReset=true) e treinar no Poste (o teto dos atributos sobe com os canais).
3. Recusas com mensagem: sem condição, sem vaga, já tem.

## Efeitos
4. Sol: de dia e com o céu à vista, Força I (renovada a cada segundo). À noite/sob teto, nada.
5. Reunião de Espíritos: +50% de XP de vínculo (soma com o bônus do meio-elfo).
6. Espíritos da Terra: com os pés no chão e a vida abaixo de 60%, Regeneração I.
7. Indicação do Vento (tecla Y): custa 20 mana, recarga 30 s. Partículas brancas sobre criaturas HOSTIS (inclusive invisíveis) até 24 blocos por 8 s;
   mensagem com a quantidade. HUD abaixo da raça mostra tecla e recarga.
8. Santo da Espada: técnicas de ESPADA gastam 25% menos estamina (o HUD já mostra o custo reduzido; o Hub mostra o custo base).
9. Sair e entrar: as bênçãos continuam; a recarga zera. Morrer não perde as bênçãos.

## Limites conhecidos
- Não há perda temporária por corte do Od Laguna nem incompatibilidade com Fator de Bruxa (sem mecânica de jogo correspondente).
- O Hub (aba Técnicas) mostra o custo base de estamina, sem a redução do Santo da Espada.
- Não há comando para devolver/trocar bênçãos.
