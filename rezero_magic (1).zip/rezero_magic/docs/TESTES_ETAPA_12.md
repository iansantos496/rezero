# Testes da Etapa 12 (balanceamento + entrega final) — para você fazer quando puder

Versão 1.0.0 (jar `rezero_magic-1.0.0.jar`, o SEM `-sources`). Apague qualquer jar antigo do mod da pasta mods (inclusive o do projeto antigo, que também se chamava 1.0.0).
Se o build do GitHub falhar, me mande o texto do erro (a linha com `error:` e o nome do arquivo). Os arquivos mais prováveis de falhar estão no `RELATORIO_FINAL.md`, item 12.

## O que mudou na E12
- Modificadores de magia em 2 camadas (ver PROGRESSO.md): camada 1 permanente (equipamento, robe, marcas, treino) com os tetos de antes
  (potência 2.0, custo 0.6, conjuração 0.6, regeneração 2.0); camada 2 situacional (espírito, raça, forma ativa) somada DEPOIS, com tetos absolutos
  (potência 2.25, custo 0.5, conjuração 0.5, regeneração 2.5). Antes, o espírito e as formas ficavam "engolidos" pelo teto de quem já tinha equipamento máximo.
- Meio-elfo só precisa de vínculo 3 (não 4) para a bênção Reunião de Espíritos (adaptação do canon de que meio-elfos têm afinidade com espíritos).

## Roteiro mínimo para ver se o mod sobe (5 minutos)
1. Abra o jogo com Fabric Loader + Fabric API + o jar. Se o jogo não abrir, pegue o `latest.log` e me mande.
2. Crie um mundo novo. Deve aparecer a tela de escolha de afinidade; depois, a de raça. Cada uma só aceita UMA escolha.
3. Aperte K: o Hub abre com 10 abas (use < > se a janela for pequena). Aperte R com um feitiço selecionado (Z/X troca).
4. Para ver tudo sem jogar horas, ative `allowAdminReset=true` em `config/rezero_magic.properties` e use:
   `/rezero admin nivel_canais 16`, `/rezero admin nivel_treino 10`, `/rezero admin vinculo 5` (precisa de contrato com espírito).
5. Teste o equilíbrio: com cajado primordial + amuleto + robe completo + marcas + treino 10 + espírito + forma, o custo e a potência não devem passar dos tetos
   (custo >= 0.5x, potência <= 2.25x). Isso já é testado no core (640 combinações), mas só o jogo mostra se a sensação é boa.

## Testes por etapa
Os roteiros detalhados de cada sistema continuam em `TESTES_ETAPA_*.md` (E0 a E11).
