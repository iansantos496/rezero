# Testes da Etapa 7a (para você fazer quando puder)

Compile no GitHub (mesmo processo). Versão 0.8.0 (jar `rezero_magic-0.8.0.jar`; apague o jar antigo da pasta mods).
Arquivos mais prováveis de falhar no build: `server/TrainingService.java` (API de atributos do jogo e evento de dano).
Se falhar, me mande o erro. Um mundo novo ou antigo funciona: os dados antigos continuam válidos (versão 3 -> 4).

## Poste de Treino
1. Receita: 1 Bloco de Feno em cima de 2 Toras de Carvalho (em coluna). Também está na aba de blocos funcionais do criativo (se estiver lá) ou use /give.
   Textura: madeira com alvo vermelho e branco.
2. Abra o Hub (K) > aba "Treino". Devem aparecer 5 atributos (Vigor, Força, Agilidade, Foco, Controle de mana) com nível, XP,
   descrição, o teto atual e a fadiga. O botão "Treinar" marca qual atributo o Poste exercita ("Em treino").
3. Clique direito no Poste: cada clique é uma repetição (partículas + som). Mensagem na barra: "Treino de X: +N XP | Fadiga F/100".
   O XP por repetição cai conforme a fadiga sobe (6 XP sem fadiga, mínimo 25%). Cada repetição gasta um pouco de fome.
   Com fome abaixo de 6 corações de comida (menos de 6 pontos) recusa: "fome demais para treinar".
4. Fadiga 100 = treino em excesso: Lentidão e Fraqueza por 10 s e o Poste recusa até a fadiga baixar a 40 (cai 1 por segundo).
5. Teto: no nível 1 dos canais, os atributos só vão até o nível 2. O teto sobe 1 a cada 2 níveis dos canais (nível 16 = teto 10).
   Para testar sem esperar: /rezero admin nivel_canais 16 (precisa de allowAdminReset=true na configuração).
   No teto o Poste diz que os canais limitam, e o Hub mostra "no teto dos canais".

## Treino por uso (sem Poste)
6. Vigor: correr (1 XP por segundo correndo) e sofrer dano (dano arredondado para cima).
7. Força: causar dano corpo a corpo (dano arredondado). Dano de FEITIÇO não conta.
8. Agilidade: pular (2 XP) e andar (1 XP a cada 32 blocos). Teletransporte, elytra e veículos não contam.
9. Foco: conjurar (1 XP por 4 ticks de conjuração base). Controle de mana: gastar mana (1 XP por 4 pontos gastos).
10. Ao subir de nível: som, mensagem no chat e aplicação imediata do efeito.

## Efeitos (por nível; máximo 10)
- Vigor: +0,8 de vida máxima (conferir os corações). Força: +0,3 de dano de ataque. Agilidade: +1,5% de velocidade.
- Foco: -2% no tempo de conjuração. Controle: -1% no custo e +2% na regeneração de mana.
  Foco e Controle somam com cajado, acessório, vestes e marcas, respeitando os mesmos limites. O HUD e o Hub mostram o custo já com o treino.
11. Sair e entrar no mundo: níveis e XP continuam (a fadiga zera). Morrer e renascer: níveis continuam, vida volta ao máximo novo.
