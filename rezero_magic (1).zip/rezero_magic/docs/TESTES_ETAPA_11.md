# Testes da Etapa 11 (Hub final + auditoria) — para você fazer quando puder

Compile no GitHub (mesmo processo). Versão 0.14.0 (jar `rezero_magic-0.14.0.jar`; apague o jar antigo da pasta mods).
Arquivos mais prováveis de falhar no build: `client/HubScreen.java` (rolagem das abas com `setX`) e `server/AdminCommands.java`. Se falhar, me mande o erro.
Nenhum dado novo é salvo. A auditoria completa está em `AUDITORIA_E11.md`.

## Hub
1. Abra o Hub (K). Em janela grande as 10 abas aparecem juntas. Em janela pequena aparecem só algumas, com < > nas pontas para rolar. A aba atual fica cinza.
2. Aba Técnicas: o custo de estamina mostrado já inclui a redução do Santo da Espada (se você tiver).
3. Todas as abas só mostram dados do servidor; os botões só enviam pedidos (o servidor pode recusar com mensagem).

## Comandos de teste (precisam de allowAdminReset=true em config/rezero_magic.properties; afetam só você)
4. `/rezero admin nivel_canais <1-20>` (já existia), `nivel_treino <0-10>` (todos os atributos), `vinculo <1-5>` (precisa de contrato com espírito),
   `resetar_raca` (reabre a tela de raça), `resetar_bencaos` (devolve as bênçãos), `resetar_afinidade` (já existia).
5. Roteiro rápido para ver tudo: nivel_canais 16 -> nivel_treino 10 -> aprender técnicas no Hub -> (com espírito) vinculo 5 -> bênçãos e formas no Hub.
