# Auditoria de integrações (E11) — feita lendo o código e com checagens automáticas

Nada abaixo foi COMPILADO nem jogado. "Ligado" = o código faz a ligação (conferido por leitura/busca); "não funciona" só se descobre no jogo.

## Checagens automáticas novas (tools/check_static.py, seção 3m)
- Todo pacote em `net/` está registrado em `ModNetworking`; todo pacote do cliente tem receptor no servidor; todo pacote do servidor tem receptor no cliente.
- Todo serviço com `init()` é chamado em `ReZeroMod`; todo serviço com `reset()` é chamado ao entrar E ao renascer.
- Nenhuma tecla padrão repetida; todo nome de tecla tem tradução nos dois idiomas.
- Prova de que a checagem pega erro: removi de propósito o registro de um pacote, a checagem falhou, restaurei e passou.

## Matriz do PLANO (seção 8), sistema por sistema
Legenda: LIGADO / PARCIAL / NÃO FEITO.

| Ligação | Estado | Onde / observação |
|---|---|---|
| Afinidade -> S1 magia | LIGADO | `MagicGate.checkCast` / `CastRules` (só feitiços da própria afinidade) |
| Afinidade -> S3 espíritos | LIGADO | contrato só com o espírito do próprio elemento (`SpiritRules.checkContract`) |
| Afinidade -> S10 canais | PARCIAL | a regeneração de mana só roda com afinidade escolhida; o resto dos canais independe dela |
| Afinidade -> S11 | PARCIAL | indireta: a Sintonia exige espírito, que exige a afinidade |
| Afinidade -> S6 treino | NÃO FEITO | treino não depende de afinidade (decisão: não há base de canon) |
| Canais -> S1 | LIGADO | nível dos canais muda custo, carga, regeneração e libera feitiços |
| Canais -> S3 | LIGADO | contrato exige canais nível 4 |
| Canais -> S6 | LIGADO | teto dos atributos de treino = f(nível dos canais) |
| Canais -> S8 | LIGADO | marcas têm nível mínimo de canais (`unlockLevel`) |
| Canais -> S9 (técnicas imbuídas com mana) | NÃO FEITO | técnicas gastam estamina, não mana |
| Canais -> S11 | LIGADO | Sintonia exige canais nível 10 |
| Treino -> S10 | LIGADO | Foco reduz carga; Controle reduz custo e aumenta regeneração |
| Treino -> S9 | LIGADO | pontos e requisitos das técnicas; estamina por Vigor/Agilidade; dano por Força |
| Treino -> S5 (requisitos de equipamento) | NÃO FEITO | nenhum item exige nível de treino |
| Treino -> S7 (tetos por raça) | NÃO FEITO | raças dão bônus de XP, não mudam o teto |
| Treino -> S4 / S11 | LIGADO | marcos de Vigor/Agilidade/Força nas bênçãos; Vigor no Último Fôlego |
| Raça -> S6 | LIGADO | vida/ataque/velocidade e XP de treino por raça |
| Raça -> S3 | LIGADO | meio-elfo: +25% de XP de vínculo |
| Raça -> S4 | NÃO FEITO | nenhuma condição de bênção usa a raça (o dado já viaja em `Progress`, sem uso) |
| Raça -> S10 | LIGADO | custo de mana (demi-humano) e regeneração (meio-elfo, oni) |
| Raça -> S11 | LIGADO | Forma Bestial e Forma Oni; regra de "uma forma por vez" |
| Espíritos -> S1 | LIGADO | +3% de potência por nível de vínculo (limitado pelo teto) |
| Espíritos -> S10 | LIGADO | mana drenada enquanto manifestado |
| Espíritos -> S11 | LIGADO | Sintonia exige espírito manifestado, vínculo 4 |
| Cristais -> S5 | PARCIAL | receitas de cajados/acessórios/vestes/armas usam cristais; "reparo com cristal" NÃO existe |
| Cristais -> S8 | LIGADO | Tinta de Cristal é gasta ao gravar marcas |
| Cristais -> S10 | LIGADO | cristal/Receptor/Concentrador restauram mana |
| Inscrições -> S5 | LIGADO | marcas gravadas no jogador entram no cálculo do equipamento (`EquipmentRules`) |
| Equipamentos -> S9 | LIGADO | a arma na mão define o estilo e as técnicas |
| Equipamentos -> S10 | LIGADO | cajado, acessório e vestes mudam potência/custo/carga/regeneração |
| Proteções -> S9 | LIGADO | Santo da Espada reduz a estamina das técnicas de espada |
| Proteções -> S10 | LIGADO | Indicação do Vento gasta mana |
| Proteções -> S3 | LIGADO | Reunião de Espíritos: +50% de XP de vínculo; condição usa o vínculo |
| Proteções -> S11 | NÃO FEITO | nenhuma proteção interage com transformações |
| Hub -> todos | LIGADO | 10 abas (Perfil, Magias, Cristais, Equipamento, Marcas, Treino, Técnicas, Espírito, Bênçãos, Formas); só mostram o espelho do servidor; ações são pedidos |

## Regra "dependência em uma direção / nenhum sistema escreve em outro" (PLANO seção 8)
DESVIOS honestos (não quebram nada conhecido, mas não são o desenho ideal):
- Serviços chamam métodos públicos uns dos outros (consultas e `reset`), por exemplo `RaceService` -> `TrainingService.refreshAttributes` e
  `SpellService.reset`; `TransformService` -> `SpellService.reset`.
- A MANA é um recurso compartilhado: espírito, bênção ativa e transformação gravam `mana` no `PlayerMagicData` (via `setMana`). Cada uma só no próprio gasto.
- Os dados de um sistema são lidos por vários serviços via `PlayerDataStore`; só o serviço dono grava o próprio bloco (exceto a mana).

## Lacunas encontradas e o que fiz nesta etapa
- CORRIGIDO: o Hub (aba Técnicas) mostrava o custo de estamina base; agora mostra o custo real (com o Santo da Espada).
- CORRIGIDO: 10 abas não cabiam em janelas pequenas; agora rolam com < > (e a aba atual fica desativada).
- ADICIONADO (só testes, desligados por padrão): `/rezero admin resetar_raca`, `resetar_bencaos`, `nivel_treino <0-10>`, `vinculo <1-5>`.
- NÃO CORRIGIDO (fica para a E12 ou para depois): requisitos de equipamento, reparo com cristal, tetos de treino por raça,
  condição de bênção por raça, técnicas imbuídas com mana, verificação de permissão de operador nos comandos de teste.

## APIs novas desta etapa NÃO confirmadas (só o build do GitHub confirma)
`ButtonWidget.setX(int)`, `ButtonWidget.visible/active` (já usados), brigadier `CommandContext`/`ServerCommandSource` (assinaturas dos comandos com `sendError/sendFeedback`, já usados).
