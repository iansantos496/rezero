# Porte para Minecraft 1.20.1 (Fabric)

**Estado: NUNCA COMPILADO.** O código foi portado da versão 1.21.11 (que compilou no GitHub) sem acesso ao Minecraft/Yarn 1.20.1.
Só foram verificados fora do jogo: o pacote `core` (185 testes), JSON/traduções/pacotes (`tools/check_static.py`) e a sintaxe Java 17.
Espere uma ou mais rodadas de erros de compilação (nomes de API); mande o log que eu corrijo.

Versões: Minecraft 1.20.1, Yarn 1.20.1+build.10, Fabric API 0.92.2+1.20.1, Loader >=0.14.21, Java 17.

## O que mudou em relação à 1.21.11
- **Dados do jogador**: Data Attachment -> `PersistentState` do Overworld (`data/rezero_magic_players.dat` no mundo, por UUID). Sobrevivem à morte sem cópia. Saves da 1.21.11 NÃO são lidos.
- **Rede**: os pacotes viraram `Identifier` + `PacketByteBuf` (`ModPacket`, `ModNet`, `ModNetClient`). Receptores são executados na thread principal.
- **Itens**: espadas/lanças são `SwordItem` (dano inteiro: rapieira 2,5 virou 2 e espada longa 3,5 virou 3). Vestes são `ArmorItem` com `RobeMaterial` (proteção 0, sem durabilidade); texturas em `assets/minecraft/textures/models/armor/rezero_<conjunto>_layer_1/2.png`.
- **Receptor de Mana**: nasce vazio via `getDefaultStack()` e `onCraft()` (a receita em si entrega "cheio" e é corrigida ao retirar do craft; a prévia do resultado na grade pode aparecer cheia).
- **Blocos**: `Material` + `AbstractBlock.Settings.of(...)`; `onUse` com `Hand`; modelos de item dos blocos adicionados.
- **Recursos**: `recipe`->`recipes`, `loot_table`->`loot_tables`, `tags/block`->`tags/blocks`; receitas no formato antigo (`{"item": ...}`); removidos `items/` e `equipment/` (formato da 1.21.x).
- **Eventos de dano**: o Fabric API 0.92.2 não tem `AFTER_DAMAGE`. Combo/contra-golpe, XP de Vigor/Força e vínculo de espírito (temperamento combate) usam `ALLOW_DAMAGE` e o dano **antes da armadura** (golpes durante a invulnerabilidade do alvo são ignorados). Efeito prático: esses XP/bônus podem ficar um pouco maiores que na 1.21.11.
- **Atributos de treino/raça**: modificadores por UUID derivado do nome.
- Teclas: categoria como texto traduzível (`key.category.rezero_magic.hub`).

## Incertezas de API (conferir se o build reclamar)
- `FabricBlockSettings`/`Material`: usei `AbstractBlock.Settings.of(Material, MapColor)` (vanilla 1.20.1).
- `ArmorMaterial` (assinaturas com `ArmorItem.Type`), `Ingredient.empty()`.
- `ServerLivingEntityEvents.ALLOW_DAMAGE` com 3 argumentos; campo `timeUntilRegen` em `LivingEntity`/`Entity`.
- `PersistentStateManager.getOrCreate(Function, Supplier, String)`.
- `Entity.setOnFireFor(int)`, `NbtCompound.putIntArray(String, List<Integer>)`.
- Empurrões (`addVelocity`) em jogadores podem não sincronizar com o cliente em alguns feitiços (o `CombatService.push` já envia o pacote de velocidade).

## Não existe nesta versão
Nada foi removido de funcionalidade; as diferenças são as listadas acima. Os itens futuros (Retorno pela Morte etc.) continuam pendentes.
