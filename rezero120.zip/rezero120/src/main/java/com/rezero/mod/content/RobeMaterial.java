package com.rezero.mod.content;

import com.rezero.mod.core.RobeSet;

import net.minecraft.item.ArmorItem;
import net.minecraft.item.ArmorMaterial;
import net.minecraft.recipe.Ingredient;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;

/**
 * Material das vestes (1.20.1): sem proteção física, sem durabilidade, só serve para vestir.
 * A textura vem de assets/minecraft/textures/models/armor/rezero_&lt;conjunto&gt;_layer_1.png e _layer_2.png.
 */
public final class RobeMaterial implements ArmorMaterial {
	private final String name;

	public RobeMaterial(RobeSet set) {
		this.name = "rezero_" + set.key();
	}

	@Override
	public int getDurability(ArmorItem.Type type) {
		return 0;
	}

	@Override
	public int getProtection(ArmorItem.Type type) {
		return 0;
	}

	@Override
	public int getEnchantability() {
		return 0;
	}

	@Override
	public SoundEvent getEquipSound() {
		return SoundEvents.ITEM_ARMOR_EQUIP_LEATHER;
	}

	@Override
	public Ingredient getRepairIngredient() {
		return Ingredient.empty();
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public float getToughness() {
		return 0.0f;
	}

	@Override
	public float getKnockbackResistance() {
		return 0.0f;
	}
}
