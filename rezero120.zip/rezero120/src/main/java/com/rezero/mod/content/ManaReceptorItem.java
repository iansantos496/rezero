package com.rezero.mod.content;

import com.rezero.mod.core.CrystalRules;
import com.rezero.mod.server.CrystalService;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.Hand;
import net.minecraft.world.World;

/**
 * Receptor de Mana: guarda mana (no "dano" do item) e a devolve ao jogador ao usar.
 * Para carregar, use o Concentrador de Mana. Lógica no servidor.
 */
public class ManaReceptorItem extends Item {
	public ManaReceptorItem(Settings settings) {
		super(settings);
	}

	/** Receptor novo nasce VAZIO (dano = capacidade): vale para a aba criativa e para o resultado da receita. */
	@Override
	public ItemStack getDefaultStack() {
		ItemStack stack = new ItemStack(this);
		stack.setDamage(CrystalRules.damageFromStored(0));
		return stack;
	}

	/** A receita entrega um ItemStack "zerado" (cheio); ao retirar do craft, ele passa a vazio. */
	@Override
	public void onCraft(ItemStack stack, World world, PlayerEntity player) {
		stack.setDamage(CrystalRules.damageFromStored(0));
	}

	@Override
	public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
		if (world instanceof ServerWorld serverWorld && user instanceof ServerPlayerEntity player) {
			ItemStack stack = user.getStackInHand(hand);
			CrystalService.useReceptor(serverWorld, player, stack);
		}
		return TypedActionResult.success(user.getStackInHand(hand), world.isClient());
	}
}
