package com.rezero.mod.content;

import com.rezero.mod.ReZeroMod;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Material;
import net.minecraft.block.MapColor;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.util.Identifier;

/** Blocos do mod. Cada bloco precisa de: blockstate, modelo (bloco e item), textura, loot table (loot_tables) e tradução. */
public final class ModBlocks {
	public static final Block MANA_CRYSTAL_ORE = register("mana_crystal_ore", new Block(
			AbstractBlock.Settings.of(Material.STONE, MapColor.STONE_GRAY).strength(3.0f, 3.0f).requiresTool()
					.sounds(BlockSoundGroup.AMETHYST_BLOCK).luminance(state -> 4)));

	public static final Block MANA_CONCENTRATOR = register("mana_concentrator", new ManaConcentratorBlock(
			AbstractBlock.Settings.of(Material.STONE, MapColor.PURPLE).strength(3.5f, 6.0f).requiresTool()
					.sounds(BlockSoundGroup.AMETHYST_BLOCK).luminance(state -> 8)));

	public static final Block INSCRIPTION_TABLE = register("inscription_table", new InscriptionTableBlock(
			AbstractBlock.Settings.of(Material.WOOD, MapColor.BROWN).strength(2.5f).sounds(BlockSoundGroup.WOOD)
					.luminance(state -> 6)));

	public static final Block TRAINING_POST = register("training_post", new TrainingPostBlock(
			AbstractBlock.Settings.of(Material.WOOD, MapColor.OAK_TAN).strength(2.0f).sounds(BlockSoundGroup.WOOD)));

	private ModBlocks() {}

	private static Block register(String path, Block block) {
		Identifier id = new Identifier(ReZeroMod.MOD_ID, path);
		Registry.register(Registries.BLOCK, id, block);
		Registry.register(Registries.ITEM, id, new BlockItem(block, new Item.Settings())); // item do bloco, com o mesmo id
		return block;
	}

	/** Força o registro durante a inicialização do mod. */
	public static void init() {
		ReZeroMod.LOGGER.info("Blocos registrados: minério de cristal de mana, concentrador, mesa de inscrição e poste de treino.");
	}
}
