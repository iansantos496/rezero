package com.rezero.mod.net;

import com.rezero.mod.ReZeroMod;

import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;

/** Servidor -> cliente: técnicas aprendidas (máscara de bits), estamina atual e máxima. Só para mostrar na tela. */
public record CombatSyncPayload(int techniqueMask, int stamina, int maxStamina) implements ModPacket {

	public static final Identifier ID = new Identifier(ReZeroMod.MOD_ID, "combat_sync");

	public static CombatSyncPayload read(PacketByteBuf buf) {
		return new CombatSyncPayload(buf.readVarInt(), buf.readVarInt(), buf.readVarInt());
	}

	@Override
	public Identifier id() {
		return ID;
	}

	@Override
	public void write(PacketByteBuf buf) {
		buf.writeVarInt(techniqueMask);
		buf.writeVarInt(stamina);
		buf.writeVarInt(maxStamina);
	}
}
