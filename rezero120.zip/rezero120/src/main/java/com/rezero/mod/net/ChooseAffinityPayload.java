package com.rezero.mod.net;

import com.rezero.mod.ReZeroMod;

import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;

/** Cliente -> servidor: "quero a afinidade X". É só um pedido; o servidor decide. */
public record ChooseAffinityPayload(int affinityId) implements ModPacket {

	public static final Identifier ID = new Identifier(ReZeroMod.MOD_ID, "choose_affinity");

	public static ChooseAffinityPayload read(PacketByteBuf buf) {
		return new ChooseAffinityPayload(buf.readVarInt());
	}

	@Override
	public Identifier id() {
		return ID;
	}

	@Override
	public void write(PacketByteBuf buf) {
		buf.writeVarInt(affinityId);
	}
}
