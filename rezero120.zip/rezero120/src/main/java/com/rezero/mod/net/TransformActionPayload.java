package com.rezero.mod.net;

import com.rezero.mod.ReZeroMod;

import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;

/** Cliente -> servidor: pedido para ativar uma transformação não racial (action = id da Transformation). O servidor confere tudo. */
public record TransformActionPayload(int action) implements ModPacket {

	public static final Identifier ID = new Identifier(ReZeroMod.MOD_ID, "transform_action");

	public static TransformActionPayload read(PacketByteBuf buf) {
		return new TransformActionPayload(buf.readVarInt());
	}

	@Override
	public Identifier id() {
		return ID;
	}

	@Override
	public void write(PacketByteBuf buf) {
		buf.writeVarInt(action);
	}
}
