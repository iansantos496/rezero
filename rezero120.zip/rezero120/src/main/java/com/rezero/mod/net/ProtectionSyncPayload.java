package com.rezero.mod.net;

import com.rezero.mod.ReZeroMod;

import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;

/** Servidor -> cliente: proteções recebidas (máscara) e recarga da ativa (só para exibição). */
public record ProtectionSyncPayload(int mask, int cooldownTicks) implements ModPacket {

	public static final Identifier ID = new Identifier(ReZeroMod.MOD_ID, "protection_sync");

	public static ProtectionSyncPayload read(PacketByteBuf buf) {
		return new ProtectionSyncPayload(buf.readVarInt(), buf.readVarInt());
	}

	@Override
	public Identifier id() {
		return ID;
	}

	@Override
	public void write(PacketByteBuf buf) {
		buf.writeVarInt(mask);
		buf.writeVarInt(cooldownTicks);
	}
}
