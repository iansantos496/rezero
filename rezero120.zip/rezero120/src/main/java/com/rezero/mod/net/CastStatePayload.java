package com.rezero.mod.net;

import com.rezero.mod.ReZeroMod;

import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;

/**
 * Servidor -> cliente, só para a barra de conjuração e a recarga na tela:
 * início de conjuração = (id, castTicks > 0, 0); fim = (id, 0, recarga); interrompida = (id, 0, 0).
 */
public record CastStatePayload(int spellId, int castTicks, int cooldownTicks) implements ModPacket {

	public static final Identifier ID = new Identifier(ReZeroMod.MOD_ID, "cast_state");

	public static CastStatePayload read(PacketByteBuf buf) {
		return new CastStatePayload(buf.readVarInt(), buf.readVarInt(), buf.readVarInt());
	}

	@Override
	public Identifier id() {
		return ID;
	}

	@Override
	public void write(PacketByteBuf buf) {
		buf.writeVarInt(spellId);
		buf.writeVarInt(castTicks);
		buf.writeVarInt(cooldownTicks);
	}
}
