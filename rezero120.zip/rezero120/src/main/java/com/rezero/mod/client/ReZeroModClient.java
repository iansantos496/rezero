package com.rezero.mod.client;

import org.lwjgl.glfw.GLFW;

import com.rezero.mod.core.SpellDef;
import com.rezero.mod.net.CastSpellPayload;
import com.rezero.mod.net.CombatActionPayload;
import com.rezero.mod.net.CombatSyncPayload;
import com.rezero.mod.net.CastStatePayload;
import com.rezero.mod.net.ManaSyncPayload;
import com.rezero.mod.net.OpenAffinityScreenPayload;
import com.rezero.mod.net.OpenHubPayload;
import com.rezero.mod.net.OpenRaceScreenPayload;
import com.rezero.mod.net.PlayerSyncPayload;
import com.rezero.mod.net.ProtectionActionPayload;
import com.rezero.mod.net.ProtectionSyncPayload;
import com.rezero.mod.net.RaceActionPayload;
import com.rezero.mod.net.RaceSyncPayload;
import com.rezero.mod.net.SpiritActionPayload;
import com.rezero.mod.net.TransformActionPayload;
import com.rezero.mod.net.TransformSyncPayload;
import com.rezero.mod.net.SpiritSyncPayload;
import com.rezero.mod.net.TechniqueCooldownPayload;
import com.rezero.mod.net.TrainingSyncPayload;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;

/** Lado do cliente: recebe os retratos do servidor, abre a tela de afinidade e o Hub, mostra o HUD. */
public class ReZeroModClient implements ClientModInitializer {
	private static KeyBinding hubKey;
	private static KeyBinding castKey;
	private static KeyBinding prevKey;
	private static KeyBinding nextKey;
	private static KeyBinding dodgeKey;
	private static KeyBinding spiritToggleKey;
	private static KeyBinding spiritActiveKey;
	private static KeyBinding raceKey;
	private static KeyBinding protectionKey;
	private static KeyBinding attuneKey;
	private static KeyBinding standKey;
	private static final KeyBinding[] SLOT_KEYS = new KeyBinding[3];

	/** Nome da tecla de técnica do espaço 0 a 2, como o jogador configurou (para o HUD). */
	public static Text slotKeyName(int slot) {
		return slot >= 0 && slot < SLOT_KEYS.length && SLOT_KEYS[slot] != null
				? SLOT_KEYS[slot].getBoundKeyLocalizedText() : Text.literal("?");
	}

	/** Nome da tecla para manifestar (0) ou usar a habilidade (1) do espírito, como o jogador configurou (para o HUD). */
	public static Text spiritKeyName(int which) {
		KeyBinding key = which == 0 ? spiritToggleKey : spiritActiveKey;
		return key != null ? key.getBoundKeyLocalizedText() : Text.literal("?");
	}

	/** Nome da tecla da habilidade racial, como o jogador configurou (para o HUD). */
	public static Text raceKeyName() {
		return raceKey != null ? raceKey.getBoundKeyLocalizedText() : Text.literal("?");
	}

	/** Nome da tecla da bênção ativa, como o jogador configurou (para o HUD). */
	public static Text protectionKeyName() {
		return protectionKey != null ? protectionKey.getBoundKeyLocalizedText() : Text.literal("?");
	}

	/** Nome da tecla da transformação (0 = Sintonia Elemental, 1 = Último Fôlego), como o jogador configurou (para o HUD). */
	public static Text transformKeyName(int which) {
		KeyBinding key = which == 0 ? attuneKey : standKey;
		return key != null ? key.getBoundKeyLocalizedText() : Text.literal("?");
	}

	@Override
	public void onInitializeClient() {
		// Em 1.20.1 a categoria de teclas é uma String (chave de tradução; ver "key.category.rezero_magic.hub" no lang).
		final String category = "key.category.rezero_magic.hub";
		hubKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.rezero_magic.hub", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_K, category));
		castKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.rezero_magic.cast", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_R, category));
		prevKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.rezero_magic.prev_spell", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_Z, category));
		nextKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.rezero_magic.next_spell", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_X, category));
		dodgeKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.rezero_magic.dodge", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_V, category));
		spiritToggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.rezero_magic.spirit_toggle", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_B, category));
		spiritActiveKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.rezero_magic.spirit_active", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_N, category));
		raceKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.rezero_magic.race_ability", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C, category));
		protectionKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.rezero_magic.protection_active", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_Y, category));
		attuneKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.rezero_magic.transform_attune", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_U, category));
		standKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.rezero_magic.transform_stand", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_O, category));
		int[] slotDefaults = {GLFW.GLFW_KEY_G, GLFW.GLFW_KEY_H, GLFW.GLFW_KEY_J};
		for (int i = 0; i < SLOT_KEYS.length; i++) {
			SLOT_KEYS[i] = KeyBindingHelper.registerKeyBinding(new KeyBinding(
					"key.rezero_magic.technique_" + (i + 1), InputUtil.Type.KEYSYM, slotDefaults[i], category));
		}

		ModNetClient.register(PlayerSyncPayload.ID, PlayerSyncPayload::read, (payload, mc) -> {
			ClientPlayerData.update(payload.affinityId(), payload.channelLevel(), payload.channelXp(), payload.marksMask());
			// o servidor confirmou a escolha: a tela obrigatória pode fechar
			if (ClientPlayerData.affinity() != null && mc.currentScreen instanceof AffinityScreen) {
				mc.setScreen(null);
			}
		});

		ModNetClient.register(TrainingSyncPayload.ID, TrainingSyncPayload::read, (payload, mc) ->
				ClientPlayerData.updateTraining(payload.levelsPack(), payload.xpA(), payload.xpB(), payload.focus(), payload.fatigue()));

		ModNetClient.register(TransformSyncPayload.ID, TransformSyncPayload::read, (payload, mc) ->
				ClientPlayerData.updateTransform(payload.activePlus1(), payload.leftTicks(), payload.cooldownAttune(), payload.cooldownStand()));

		ModNetClient.register(ProtectionSyncPayload.ID, ProtectionSyncPayload::read, (payload, mc) ->
				ClientPlayerData.updateProtection(payload.mask(), payload.cooldownTicks()));

		ModNetClient.register(OpenRaceScreenPayload.ID, OpenRaceScreenPayload::read, (payload, mc) ->
				ClientPlayerData.requestRaceScreen());

		ModNetClient.register(RaceSyncPayload.ID, RaceSyncPayload::read, (payload, mc) -> {
			ClientPlayerData.updateRace(payload.raceId(), payload.formTicks(), payload.cooldownTicks());
			// o servidor confirmou a escolha: a tela obrigatória pode fechar
			if (ClientPlayerData.race() != null && mc.currentScreen instanceof RaceScreen) {
				mc.setScreen(null);
			}
		});

		ModNetClient.register(SpiritSyncPayload.ID, SpiritSyncPayload::read, (payload, mc) ->
				ClientPlayerData.updateSpirit(payload.spiritId(), payload.bondLevel(), payload.bondXp(), payload.summoned() != 0,
						payload.wisp() != 0, payload.cooldownTicks()));

		ModNetClient.register(CombatSyncPayload.ID, CombatSyncPayload::read, (payload, mc) ->
				ClientPlayerData.updateCombat(payload.techniqueMask(), payload.stamina(), payload.maxStamina()));

		ModNetClient.register(TechniqueCooldownPayload.ID, TechniqueCooldownPayload::read, (payload, mc) ->
				ClientPlayerData.onTechniqueCooldown(payload.techniqueId(), payload.ticks()));

		ModNetClient.register(ManaSyncPayload.ID, ManaSyncPayload::read, (payload, mc) ->
				ClientPlayerData.updateMana(payload.mana(), payload.exhausted() != 0));

		ModNetClient.register(CastStatePayload.ID, CastStatePayload::read, (payload, mc) ->
				ClientPlayerData.onCastState(payload.spellId(), payload.castTicks(), payload.cooldownTicks()));

		ModNetClient.register(OpenHubPayload.ID, OpenHubPayload::read, (payload, mc) ->
				ClientPlayerData.requestHubTab(payload.tab()));

		ModNetClient.register(OpenAffinityScreenPayload.ID, OpenAffinityScreenPayload::read, (payload, mc) ->
				ClientPlayerData.requestAffinityScreen());

		// Em 1.20.1 (Fabric API 0.92.2) o 2º parâmetro do HudRenderCallback é um float (tickDelta).
		HudRenderCallback.EVENT.register((context, tickDelta) -> {
			SpellHud.render(context);
			CombatHud.render(context);
			SpiritHud.render(context);
			RaceHud.render(context);
			ProtectionHud.render(context);
			TransformHud.render(context);
		});

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			ClientPlayerData.tick();
			if (client.player == null) {
				return;
			}
			// abre a tela quando o jogo estiver livre (ex.: depois da tela de carregamento do mundo)
			if (ClientPlayerData.affinityScreenRequested() && client.currentScreen == null) {
				ClientPlayerData.clearAffinityScreenRequest();
				client.setScreen(new AffinityScreen());
				return;
			}
			// depois da afinidade, a tela obrigatória da raça (também para mundos antigos que ainda não têm raça)
			if (ClientPlayerData.raceScreenRequested() && client.currentScreen == null && ClientPlayerData.affinity() != null) {
				ClientPlayerData.clearRaceScreenRequest();
				client.setScreen(new RaceScreen());
				return;
			}
			if (client.currentScreen == null && ClientPlayerData.affinity() != null) {
				int requested = ClientPlayerData.takeHubTabRequest();
				if (requested >= 0) {
					client.setScreen(new HubScreen(requested));
					return;
				}
			}
			while (hubKey.wasPressed()) {
				// o Hub só abre depois da escolha de afinidade (antes disso a tela obrigatória tem prioridade)
				if (client.currentScreen == null && ClientPlayerData.affinity() != null) {
					client.setScreen(new HubScreen(0));
				}
			}
			while (prevKey.wasPressed()) {
				if (client.currentScreen == null) {
					ClientPlayerData.cycleSpell(-1);
				}
			}
			while (nextKey.wasPressed()) {
				if (client.currentScreen == null) {
					ClientPlayerData.cycleSpell(1);
				}
			}
			// combate: só PEDIDOS; o servidor confere arma, aprendizado, estamina e recarga
			while (dodgeKey.wasPressed()) {
				if (client.currentScreen == null) {
					int dir = client.options.forwardKey.isPressed() ? 0
							: client.options.leftKey.isPressed() ? 2
							: client.options.rightKey.isPressed() ? 3 : 1;
					ModNetClient.send(new CombatActionPayload(CombatActionPayload.DODGE, dir));
				}
			}
			// transformações: só PEDIDOS; o servidor confere espírito, mana, vida, recarga e se outra forma está ativa
			while (attuneKey.wasPressed()) {
				if (client.currentScreen == null) {
					ModNetClient.send(new TransformActionPayload(com.rezero.mod.core.Transformation.ATTUNEMENT.id()));
				}
			}
			while (standKey.wasPressed()) {
				if (client.currentScreen == null) {
					ModNetClient.send(new TransformActionPayload(com.rezero.mod.core.Transformation.LAST_STAND.id()));
				}
			}
			// bênção ativa: só PEDIDO; o servidor confere se a tem, recarga e mana
			while (protectionKey.wasPressed()) {
				if (client.currentScreen == null) {
					ModNetClient.send(new ProtectionActionPayload(ProtectionActionPayload.ACTIVE, 0));
				}
			}
			// raça: só PEDIDO; o servidor confere raça, recarga e estado
			while (raceKey.wasPressed()) {
				if (client.currentScreen == null) {
					ModNetClient.send(new RaceActionPayload(RaceActionPayload.ACTIVATE));
				}
			}
			// espírito: só PEDIDOS; o servidor confere contrato, mana, vínculo e recarga
			while (spiritToggleKey.wasPressed()) {
				if (client.currentScreen == null) {
					ModNetClient.send(new SpiritActionPayload(SpiritActionPayload.TOGGLE));
				}
			}
			while (spiritActiveKey.wasPressed()) {
				if (client.currentScreen == null) {
					ModNetClient.send(new SpiritActionPayload(SpiritActionPayload.ACTIVE));
				}
			}
			for (int i = 0; i < SLOT_KEYS.length; i++) {
				while (SLOT_KEYS[i].wasPressed()) {
					if (client.currentScreen == null) {
						ModNetClient.send(new CombatActionPayload(CombatActionPayload.USE, i));
					}
				}
			}
			while (castKey.wasPressed()) {
				SpellDef spell = ClientPlayerData.selectedSpell();
				// só um PEDIDO: o servidor confere afinidade, nível, mana e recarga
				if (client.currentScreen == null && spell != null) {
					ModNetClient.send(new CastSpellPayload(spell.id()));
				}
			}
		});

		// ao sair do mundo, esquece os dados para não "vazar" para o próximo mundo
		ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> ClientPlayerData.clear());
	}
}
