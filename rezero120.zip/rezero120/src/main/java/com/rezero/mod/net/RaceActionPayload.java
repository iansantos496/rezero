package com.rezero.mod.net;

import com.rezero.mod.ReZeroMod;

import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;

/** Cliente -> servidor: pedido para usar a habilidade racial (a transformação). O servidor confere raça, recarga e estado. */
public record RaceActionPayload(int action) implements ModPacket {
	public static final int ACTIVATE = 0;
	public static final Identifier ID = new Identifier(ReZeroMod.MOD_ID, "race_action");

	public static RaceActionPayload read(PacketByteBuf buf) {
		return new RaceActionPayload(buf.readVarInt());
	}

	@Override
	public Identifier id() {
		return ID;
	}

	@Override
	public void write(PacketByteBuf buf) {
		buf.writeVarInt(action);
	}
}
