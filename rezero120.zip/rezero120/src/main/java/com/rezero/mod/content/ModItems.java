package com.rezero.mod.content;

import com.rezero.mod.ReZeroMod;
import com.rezero.mod.core.Catalyst;
import com.rezero.mod.core.Charm;
import com.rezero.mod.core.CrystalRarity;
import com.rezero.mod.core.CrystalRules;
import com.rezero.mod.core.RobePiece;
import com.rezero.mod.core.RobeSet;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolMaterials;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import net.minecraft.util.Rarity;

/** Itens do mod. Cada item precisa de: modelo (models/item), textura e tradução. */
public final class ModItems {
	public static final Item MANA_CRYSTAL_FRAGMENT = crystal(CrystalRarity.FRAGMENT, Rarity.COMMON);
	public static final Item MANA_CRYSTAL = crystal(CrystalRarity.CRYSTAL, Rarity.UNCOMMON);
	public static final Item MANA_CRYSTAL_PURE = crystal(CrystalRarity.PURE, Rarity.RARE);
	public static final Item MANA_CRYSTAL_PRIMORDIAL = crystal(CrystalRarity.PRIMORDIAL, Rarity.EPIC);

	// o Receptor nasce VAZIO: dano = capacidade (guardado = capacidade - dano); ver ManaReceptorItem.getDefaultStack/onCraft
	public static final Item MANA_RECEPTOR = register("mana_receptor", new ManaReceptorItem(
			new Item.Settings().maxDamage(CrystalRules.RECEPTOR_MAX_DAMAGE).rarity(Rarity.UNCOMMON)));

	// espadas (SwordItem do jogo base: dano = material + valor inteiro, velocidade, durabilidade e reparo do material; a rapieira e a espada longa perdem 0,5 de dano base ao arredondar para inteiro)
	public static final Item CRYSTAL_DAGGER = register("crystal_dagger", new SwordItem(ToolMaterials.IRON, 1, -1.6f,
			new Item.Settings().rarity(Rarity.UNCOMMON)));
	public static final Item MANA_SHORTSWORD = register("mana_shortsword", new SwordItem(ToolMaterials.IRON, 2, -2.2f,
			new Item.Settings().rarity(Rarity.UNCOMMON)));
	public static final Item CRYSTAL_RAPIER = register("crystal_rapier", new SwordItem(ToolMaterials.IRON, 2, -1.4f,
			new Item.Settings().rarity(Rarity.UNCOMMON)));
	public static final Item MANA_LONGSWORD = register("mana_longsword", new SwordItem(ToolMaterials.IRON, 3, -2.6f,
			new Item.Settings().rarity(Rarity.RARE)));
	public static final Item MANA_GREATSWORD = register("mana_greatsword", new SwordItem(ToolMaterials.DIAMOND, 4, -3.0f,
			new Item.Settings().rarity(Rarity.RARE)));
	public static final Item PRIMORDIAL_BLADE = register("primordial_blade", new SwordItem(ToolMaterials.NETHERITE, 4, -2.4f,
			new Item.Settings().rarity(Rarity.EPIC)));

	// lanças (mesmas propriedades de arma do jogo base; o estilo "lança" do combate reconhece estas e o tridente)
	public static final Item MANA_SPEAR = register("mana_spear", new SwordItem(ToolMaterials.IRON, 3, -2.4f,
			new Item.Settings().rarity(Rarity.UNCOMMON)));
	public static final Item CRYSTAL_SPEAR = register("crystal_spear", new SwordItem(ToolMaterials.DIAMOND, 3, -2.4f,
			new Item.Settings().rarity(Rarity.RARE)));

	// cajados catalisadores (mão principal) e acessórios (mão secundária)
	public static final Item MANA_STAFF_APPRENTICE = catalyst(Catalyst.APPRENTICE, Rarity.COMMON);
	public static final Item MANA_STAFF_CRYSTAL = catalyst(Catalyst.CRYSTAL, Rarity.UNCOMMON);
	public static final Item MANA_STAFF_PURE = catalyst(Catalyst.PURE, Rarity.RARE);
	public static final Item MANA_STAFF_PRIMORDIAL = catalyst(Catalyst.PRIMORDIAL, Rarity.EPIC);
	public static final Item CHARM_FLUX = charm(Charm.FLUX, Rarity.UNCOMMON);
	public static final Item CHARM_FOCUS = charm(Charm.FOCUS, Rarity.UNCOMMON);
	public static final Item CHARM_CRYSTAL = charm(Charm.CRYSTAL, Rarity.UNCOMMON);
	public static final Item CHARM_THRIFT = charm(Charm.THRIFT, Rarity.UNCOMMON);
	public static final Item CHARM_RESONANCE = charm(Charm.RESONANCE, Rarity.RARE);

	// tinta de cristal (gasta ao gravar marcas na Mesa de Inscrição)
	public static final Item SPIRIT_CONTRACT_STONE = register("spirit_contract_stone", new SpiritContractItem(new Item.Settings().rarity(Rarity.RARE)));
	public static final Item MANA_INK = register("mana_ink", new Item(new Item.Settings().rarity(Rarity.UNCOMMON)));

	// vestes: ROBES[conjunto][peça]
	public static final Item[][] ROBES = buildRobes();

	private ModItems() {}

	private static Item[][] buildRobes() {
		Item[][] all = new Item[RobeSet.values().length][RobePiece.values().length];
		for (RobeSet set : RobeSet.values()) {
			RobeMaterial material = new RobeMaterial(set);
			Rarity rarity = set == RobeSet.APPRENTICE ? Rarity.COMMON : set == RobeSet.CRYSTAL ? Rarity.UNCOMMON : Rarity.RARE;
			for (RobePiece piece : RobePiece.values()) {
				ArmorItem.Type type = switch (piece) {
					case HOOD -> ArmorItem.Type.HELMET;
					case TUNIC -> ArmorItem.Type.CHESTPLATE;
					case TROUSERS -> ArmorItem.Type.LEGGINGS;
					case BOOTS -> ArmorItem.Type.BOOTS;
				};
				// peça vestível (textura em assets/minecraft/textures/models/armor/rezero_<conjunto>_layer_N.png); sem proteção física
				all[set.id()][piece.id()] = register(set.itemKey(piece),
						new RobeItem(material, type, new Item.Settings().maxCount(1).rarity(rarity), set, piece));
			}
		}
		return all;
	}

	private static Item catalyst(Catalyst c, Rarity rarity) {
		return register(c.key(), new CatalystItem(new Item.Settings().maxCount(1).rarity(rarity), c));
	}

	private static Item charm(Charm c, Rarity rarity) {
		return register(c.key(), new CharmItem(new Item.Settings().maxCount(1).rarity(rarity), c));
	}

	private static Item crystal(CrystalRarity rarity, Rarity itemRarity) {
		return register(rarity.key(), new ManaCrystalItem(new Item.Settings().rarity(itemRarity), rarity));
	}

	private static Item register(String path, Item item) {
		return Registry.register(Registries.ITEM, new Identifier(ReZeroMod.MOD_ID, path), item);
	}

	/** O cristal de uma raridade (usado pela interface e pelo servidor). */
	public static Item crystalItem(CrystalRarity rarity) {
		return switch (rarity) {
			case FRAGMENT -> MANA_CRYSTAL_FRAGMENT;
			case CRYSTAL -> MANA_CRYSTAL;
			case PURE -> MANA_CRYSTAL_PURE;
			case PRIMORDIAL -> MANA_CRYSTAL_PRIMORDIAL;
		};
	}

	/** Força o registro e coloca tudo nas abas do modo criativo. */
	public static void init() {
		ItemGroupEvents.modifyEntriesEvent(ItemGroups.INGREDIENTS).register(entries -> {
			entries.add(MANA_CRYSTAL_FRAGMENT);
			entries.add(MANA_CRYSTAL);
			entries.add(MANA_CRYSTAL_PURE);
			entries.add(MANA_CRYSTAL_PRIMORDIAL);
		});
		ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(entries -> {
			entries.add(MANA_RECEPTOR);
			entries.add(MANA_INK);
			entries.add(SPIRIT_CONTRACT_STONE);
			entries.add(MANA_STAFF_APPRENTICE);
			entries.add(MANA_STAFF_CRYSTAL);
			entries.add(MANA_STAFF_PURE);
			entries.add(MANA_STAFF_PRIMORDIAL);
			entries.add(CHARM_FLUX);
			entries.add(CHARM_FOCUS);
			entries.add(CHARM_CRYSTAL);
			entries.add(CHARM_THRIFT);
			entries.add(CHARM_RESONANCE);
		});
		ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(entries -> {
			for (Item[] set : ROBES) {
				for (Item piece : set) {
					entries.add(piece);
				}
			}
			entries.add(CRYSTAL_DAGGER);
			entries.add(MANA_SHORTSWORD);
			entries.add(CRYSTAL_RAPIER);
			entries.add(MANA_LONGSWORD);
			entries.add(MANA_GREATSWORD);
			entries.add(PRIMORDIAL_BLADE);
			entries.add(MANA_SPEAR);
			entries.add(CRYSTAL_SPEAR);
		});
		ItemGroupEvents.modifyEntriesEvent(ItemGroups.NATURAL).register(entries -> entries.add(ModBlocks.MANA_CRYSTAL_ORE));
		ItemGroupEvents.modifyEntriesEvent(ItemGroups.FUNCTIONAL).register(entries -> {
			entries.add(ModBlocks.MANA_CONCENTRATOR);
			entries.add(ModBlocks.INSCRIPTION_TABLE);
		});
		ReZeroMod.LOGGER.info("Itens registrados: cristais, Receptor, tinta, Pedra de Contrato, 6 espadas, 2 lanças, 4 cajados, 5 acessórios e 12 peças de veste.");
	}
}
