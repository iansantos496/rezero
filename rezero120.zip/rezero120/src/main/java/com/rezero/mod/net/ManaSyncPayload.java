package com.rezero.mod.net;

import com.rezero.mod.ReZeroMod;

import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;

/** Servidor -> cliente: mana atual e se o jogador está exausto (1) ou não (0). Enviado só quando muda. */
public record ManaSyncPayload(int mana, int exhausted) implements ModPacket {

	public static final Identifier ID = new Identifier(ReZeroMod.MOD_ID, "mana_sync");

	public static ManaSyncPayload read(PacketByteBuf buf) {
		return new ManaSyncPayload(buf.readVarInt(), buf.readVarInt());
	}

	@Override
	public Identifier id() {
		return ID;
	}

	@Override
	public void write(PacketByteBuf buf) {
		buf.writeVarInt(mana);
		buf.writeVarInt(exhausted);
	}
}
