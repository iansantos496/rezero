package com.rezero.mod.net;

import java.util.function.Function;

import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;

/** Lado do SERVIDOR (e comum) da rede do mod, no estilo do Fabric API para 1.20.1 (Identifier + PacketByteBuf). */
public final class ModNet {
	private ModNet() {}

	/** Quem enviou o pedido e o servidor onde ele deve ser executado. */
	public record Ctx(ServerPlayerEntity player, MinecraftServer server) {}

	public interface Handler<T> {
		void handle(T payload, Ctx context);
	}

	/** Servidor -> cliente. */
	public static void send(ServerPlayerEntity player, ModPacket packet) {
		PacketByteBuf buf = PacketByteBufs.create();
		packet.write(buf);
		ServerPlayNetworking.send(player, packet.id(), buf);
	}

	/** Receptor do servidor; o pedido é lido na thread de rede e EXECUTADO na thread principal do servidor. */
	public static <T extends ModPacket> void registerC2S(Identifier id, Function<PacketByteBuf, T> reader, Handler<T> handler) {
		ServerPlayNetworking.registerGlobalReceiver(id, (server, player, networkHandler, buf, responseSender) -> {
			T payload = reader.apply(buf);
			server.execute(() -> handler.handle(payload, new Ctx(player, server)));
		});
	}
}
