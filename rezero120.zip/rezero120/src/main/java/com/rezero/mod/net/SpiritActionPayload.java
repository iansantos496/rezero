package com.rezero.mod.net;

import com.rezero.mod.ReZeroMod;

import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;

/**
 * Cliente -> servidor: um PEDIDO sobre o espírito. action 0 = manifestar/dispensar, 1 = habilidade ativa, 2 = romper o contrato.
 * O servidor valida tudo (contrato, mana, vínculo, recarga).
 */
public record SpiritActionPayload(int action) implements ModPacket {
	public static final int TOGGLE = 0;
	public static final int ACTIVE = 1;
	public static final int RELEASE = 2;
	public static final Identifier ID = new Identifier(ReZeroMod.MOD_ID, "spirit_action");

	public static SpiritActionPayload read(PacketByteBuf buf) {
		return new SpiritActionPayload(buf.readVarInt());
	}

	@Override
	public Identifier id() {
		return ID;
	}

	@Override
	public void write(PacketByteBuf buf) {
		buf.writeVarInt(action);
	}
}
