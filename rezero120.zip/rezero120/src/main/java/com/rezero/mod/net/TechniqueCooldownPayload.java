package com.rezero.mod.net;

import com.rezero.mod.ReZeroMod;

import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;

/** Servidor -> cliente: a técnica {@code techniqueId} entrou em recarga por {@code ticks} (id -1 = esquiva). Só para mostrar na tela. */
public record TechniqueCooldownPayload(int techniqueId, int ticks) implements ModPacket {

	public static final Identifier ID = new Identifier(ReZeroMod.MOD_ID, "technique_cooldown");

	public static TechniqueCooldownPayload read(PacketByteBuf buf) {
		return new TechniqueCooldownPayload(buf.readVarInt(), buf.readVarInt());
	}

	@Override
	public Identifier id() {
		return ID;
	}

	@Override
	public void write(PacketByteBuf buf) {
		buf.writeVarInt(techniqueId);
		buf.writeVarInt(ticks);
	}
}
