package com.rezero.mod.net;

import com.rezero.mod.ReZeroMod;

import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;

/** Cliente -> servidor: "quero gravar (remove = 0) ou remover (remove = 1) a marca X". É só um pedido. */
public record InscribePayload(int inscriptionId, int remove) implements ModPacket {

	public static final Identifier ID = new Identifier(ReZeroMod.MOD_ID, "inscribe");

	public static InscribePayload read(PacketByteBuf buf) {
		return new InscribePayload(buf.readVarInt(), buf.readVarInt());
	}

	@Override
	public Identifier id() {
		return ID;
	}

	@Override
	public void write(PacketByteBuf buf) {
		buf.writeVarInt(inscriptionId);
		buf.writeVarInt(remove);
	}
}
