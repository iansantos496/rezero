package com.rezero.mod.data;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import com.rezero.mod.ReZeroMod;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtList;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.world.PersistentState;
import net.minecraft.world.PersistentStateManager;

/**
 * ÚNICO ponto que sabe COMO os dados do jogador são guardados (Minecraft 1.20.1).
 * Usa um PersistentState do Overworld: um arquivo "data/rezero_magic_players.dat" DENTRO de cada mundo, com os dados
 * de todos os jogadores pelo UUID. Os dados não se perdem ao morrer (não dependem da entidade do jogador).
 */
public final class PlayerDataStore {
	private static final String STATE_ID = ReZeroMod.MOD_ID + "_players";

	private PlayerDataStore() {}

	/** Estado salvo no mundo. */
	public static final class State extends PersistentState {
		private final Map<UUID, PlayerMagicData> players = new HashMap<>();

		static State fromNbt(NbtCompound root) {
			State state = new State();
			NbtList list = root.getList("players", NbtElement.COMPOUND_TYPE);
			for (int i = 0; i < list.size(); i++) {
				NbtCompound entry = list.getCompound(i);
				if (entry.containsUuid("uuid")) {
					state.players.put(entry.getUuid("uuid"), PlayerMagicData.fromNbt(entry.getCompound("data")));
				}
			}
			return state;
		}

		@Override
		public NbtCompound writeNbt(NbtCompound nbt) {
			NbtList list = new NbtList();
			for (Map.Entry<UUID, PlayerMagicData> e : players.entrySet()) {
				NbtCompound entry = new NbtCompound();
				entry.putUuid("uuid", e.getKey());
				entry.put("data", e.getValue().toNbt());
				list.add(entry);
			}
			nbt.put("players", list);
			return nbt;
		}
	}

	/** Mantido por compatibilidade com o ReZeroMod. */
	public static void init() {
		ReZeroMod.LOGGER.info("Dados do jogador: PersistentState por mundo (1.20.1).");
	}

	private static State state(ServerPlayerEntity player) {
		MinecraftServer server = player.getServer();
		if (server == null) {
			throw new IllegalStateException("Jogador sem servidor");
		}
		PersistentStateManager manager = server.getOverworld().getPersistentStateManager();
		return manager.getOrCreate(State::fromNbt, State::new, STATE_ID);
	}

	public static PlayerMagicData get(ServerPlayerEntity player) {
		return state(player).players.computeIfAbsent(player.getUuid(), id -> new PlayerMagicData());
	}

	public static void save(ServerPlayerEntity player, PlayerMagicData data) {
		State st = state(player);
		st.players.put(player.getUuid(), data);
		st.markDirty();
	}
}
