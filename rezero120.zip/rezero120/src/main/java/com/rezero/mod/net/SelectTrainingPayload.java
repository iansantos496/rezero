package com.rezero.mod.net;

import com.rezero.mod.ReZeroMod;

import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;

/** Cliente -> servidor: "quero que o Poste de Treino exercite o atributo X". É só um pedido; o servidor valida o id. */
public record SelectTrainingPayload(int attributeId) implements ModPacket {

	public static final Identifier ID = new Identifier(ReZeroMod.MOD_ID, "select_training");

	public static SelectTrainingPayload read(PacketByteBuf buf) {
		return new SelectTrainingPayload(buf.readVarInt());
	}

	@Override
	public Identifier id() {
		return ID;
	}

	@Override
	public void write(PacketByteBuf buf) {
		buf.writeVarInt(attributeId);
	}
}
