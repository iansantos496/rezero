package com.rezero.mod.net;

import com.rezero.mod.ReZeroMod;

import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;

/** Servidor -> cliente: forma ativa (0 = nenhuma, senão id + 1), tempo restante e recargas da Sintonia e do Último Fôlego (só exibição). */
public record TransformSyncPayload(int activePlus1, int leftTicks, int cooldownAttune, int cooldownStand) implements ModPacket {

	public static final Identifier ID = new Identifier(ReZeroMod.MOD_ID, "transform_sync");

	public static TransformSyncPayload read(PacketByteBuf buf) {
		return new TransformSyncPayload(buf.readVarInt(), buf.readVarInt(), buf.readVarInt(), buf.readVarInt());
	}

	@Override
	public Identifier id() {
		return ID;
	}

	@Override
	public void write(PacketByteBuf buf) {
		buf.writeVarInt(activePlus1);
		buf.writeVarInt(leftTicks);
		buf.writeVarInt(cooldownAttune);
		buf.writeVarInt(cooldownStand);
	}
}
