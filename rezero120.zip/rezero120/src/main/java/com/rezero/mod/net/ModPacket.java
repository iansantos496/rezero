package com.rezero.mod.net;

import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;

/** Pacote do mod (Minecraft 1.20.1): um Identifier e uma escrita em PacketByteBuf. Só números inteiros (VarInt). */
public interface ModPacket {
	Identifier id();

	void write(PacketByteBuf buf);
}
