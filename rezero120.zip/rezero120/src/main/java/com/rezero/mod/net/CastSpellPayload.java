package com.rezero.mod.net;

import com.rezero.mod.ReZeroMod;

import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;

/** Cliente -> servidor: "quero conjurar o feitiço X". É só um pedido; o servidor decide tudo. */
public record CastSpellPayload(int spellId) implements ModPacket {

	public static final Identifier ID = new Identifier(ReZeroMod.MOD_ID, "cast_spell");

	public static CastSpellPayload read(PacketByteBuf buf) {
		return new CastSpellPayload(buf.readVarInt());
	}

	@Override
	public Identifier id() {
		return ID;
	}

	@Override
	public void write(PacketByteBuf buf) {
		buf.writeVarInt(spellId);
	}
}
