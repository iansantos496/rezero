package com.rezero.mod.content;

import com.rezero.mod.core.RobePiece;
import com.rezero.mod.core.RobeSet;

import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ArmorItem;

/** Peça de veste mágica (vestível). Sem lógica própria: o SpellService conta as peças vestidas (ver core/RobeSet). */
public class RobeItem extends ArmorItem {
	private final RobeSet set;
	private final RobePiece piece;

	public RobeItem(RobeMaterial material, ArmorItem.Type type, Settings settings, RobeSet set, RobePiece piece) {
		super(material, type, settings);
		this.set = set;
		this.piece = piece;
	}

	public RobeSet set() {
		return set;
	}

	public RobePiece piece() {
		return piece;
	}

	/** Slot onde a peça deve estar vestida para contar. */
	public EquipmentSlot slot() {
		return getSlotType();
	}
}
