package com.rezero.mod.net;

import com.rezero.mod.ReZeroMod;

import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;

/**
 * Servidor -> cliente: retrato dos dados do jogador (afinidade, -1 = ainda não escolheu; nível e XP dos canais; máscara de bits das marcas gravadas).
 * O cliente só usa isto para mostrar informação; nunca para decidir permissões.
 */
public record PlayerSyncPayload(int affinityId, int channelLevel, int channelXp, int marksMask) implements ModPacket {

	public static final Identifier ID = new Identifier(ReZeroMod.MOD_ID, "player_sync");

	public static PlayerSyncPayload read(PacketByteBuf buf) {
		return new PlayerSyncPayload(buf.readVarInt(), buf.readVarInt(), buf.readVarInt(), buf.readVarInt());
	}

	@Override
	public Identifier id() {
		return ID;
	}

	@Override
	public void write(PacketByteBuf buf) {
		buf.writeVarInt(affinityId);
		buf.writeVarInt(channelLevel);
		buf.writeVarInt(channelXp);
		buf.writeVarInt(marksMask);
	}
}
