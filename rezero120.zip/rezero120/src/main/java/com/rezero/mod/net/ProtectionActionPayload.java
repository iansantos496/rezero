package com.rezero.mod.net;

import com.rezero.mod.ReZeroMod;

import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;

/** Cliente -> servidor: receber uma proteção (CLAIM, arg = id) ou usar a ativa (ACTIVE). Só pedidos; o servidor valida. */
public record ProtectionActionPayload(int action, int arg) implements ModPacket {
	public static final int CLAIM = 0;
	public static final int ACTIVE = 1;
	public static final Identifier ID = new Identifier(ReZeroMod.MOD_ID, "protection_action");

	public static ProtectionActionPayload read(PacketByteBuf buf) {
		return new ProtectionActionPayload(buf.readVarInt(), buf.readVarInt());
	}

	@Override
	public Identifier id() {
		return ID;
	}

	@Override
	public void write(PacketByteBuf buf) {
		buf.writeVarInt(action);
		buf.writeVarInt(arg);
	}
}
