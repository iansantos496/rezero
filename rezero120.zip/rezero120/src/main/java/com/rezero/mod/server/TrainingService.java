package com.rezero.mod.server;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

import com.rezero.mod.ReZeroMod;
import com.rezero.mod.core.Race;
import com.rezero.mod.core.RaceRules;
import com.rezero.mod.core.SpellDef;
import com.rezero.mod.core.TrainingAttribute;
import com.rezero.mod.core.TrainingModel;
import com.rezero.mod.data.PlayerDataStore;
import com.rezero.mod.data.PlayerMagicData;
import com.rezero.mod.net.TrainingSyncPayload;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import com.rezero.mod.net.ModNet;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;

/**
 * Treinamento e evolução (Sistema 6), no servidor. O XP dos 5 atributos vem de:
 * USO (correr e sofrer dano = Vigor; dano corpo a corpo = Força; pular e andar = Agilidade; conjurar = Foco; gastar mana = Controle)
 * e de TREINO ATIVO no Poste de Treino (rendimento decrescente, fadiga, comida e penalidade por exagero).
 * Vigor, Força e Agilidade viram modificadores de atributo do jogo (vida, ataque, velocidade); Foco e Controle entram em
 * EquipmentRules (conjuração, custo, regeneração). Tudo é decidido aqui; o cliente só mostra.
 * Estado temporário (fadiga, recarga de repetição) fica só em memória e zera ao entrar; níveis e XP são salvos.
 */
public final class TrainingService {
	private static final int SYNC_PERIOD = 20;
	private static final int ATTRIBUTE_CHECK_PERIOD = 100;
	/** Deslocamentos maiores que isto num tick (teletransporte, pérola) não contam como caminhada. */
	private static final double MAX_STEP = 2.0;
	private static final double BLOCKS_PER_AGILITY_XP = 32.0;
	private static final int TICKS_PER_SPRINT_XP = 20;
	private static final int JUMP_XP = 2;

	private static final String MOD_HEALTH = "training_vigor";
	private static final String MOD_ATTACK = "training_strength";
	private static final String MOD_SPEED = "training_agility";

	/** Verdadeiro enquanto um feitiço causa dano: esse dano não treina Força. Só a thread do servidor usa. */
	static boolean spellDamage = false;

	private static final class Runtime {
		int fatigue;
		int fatigueTick;
		boolean overtrained;
		int repCooldown;
		boolean hasLast;
		double lastX;
		double lastY;
		double lastZ;
		boolean lastOnGround;
		int sprintTicks;
		double distAcc;
		boolean dirty;
		int lastSentFatigue = -1;
		int appliedSig = Integer.MIN_VALUE;
	}

	private static final Map<UUID, Runtime> STATE = new HashMap<>();
	/** Servidor em execução (para achar o mundo do jogador fora de um tick); null quando parado. */
	private static MinecraftServer server;

	private TrainingService() {}

	public static void init() {
		ServerTickEvents.END_SERVER_TICK.register(TrainingService::tick);
		// (1.20.1: sem AFTER_DAMAGE no Fabric API 0.92.2; usa ALLOW_DAMAGE, com o dano ANTES da armadura e ignorando golpes
		// durante a invulnerabilidade do alvo. Pode contar um golpe que a esquiva cancela depois.)
		ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, damageTaken) -> {
			if (damageTaken <= 0.0f || entity.timeUntilRegen > 10) {
				return true;
			}
			if (entity instanceof ServerPlayerEntity victim) {
				award(victim, TrainingAttribute.VIGOR, TrainingModel.vigorXpForDamage(damageTaken));
			}
			if (!spellDamage && source.getAttacker() instanceof ServerPlayerEntity attacker
					&& source.getSource() == attacker && entity != attacker) {
				award(attacker, TrainingAttribute.STRENGTH, TrainingModel.strengthXpForDamage(damageTaken));
			}
			return true;
		});
		ServerLifecycleEvents.SERVER_STARTED.register(started -> server = started);
		ServerLifecycleEvents.SERVER_STOPPED.register(stopped -> {
			server = null;
			STATE.clear();
		});
	}

	private static Runtime runtime(ServerPlayerEntity player) {
		return STATE.computeIfAbsent(player.getUuid(), k -> new Runtime());
	}

	/** Ao entrar ou renascer: zera o estado temporário, reaplica os atributos e envia o retrato. */
	public static void reset(ServerPlayerEntity player, boolean healToMax) {
		STATE.put(player.getUuid(), new Runtime());
		applyAttributes(player, true);
		if (healToMax) {
			player.setHealth(player.getMaxHealth());
		}
		sync(player);
	}

	/** Níveis atuais (servidor), indexados por TrainingAttribute.id(). */
	public static int[] levelsOf(ServerPlayerEntity player) {
		return PlayerDataStore.get(player).trainingLevels();
	}

	// ------------------------------------------------------------------ XP por uso

	/** Chamado pelo SpellService depois de um feitiço que funcionou. */
	public static void onSpellCast(ServerPlayerEntity player, SpellDef spell, int spentMana) {
		award(player, TrainingAttribute.FOCUS, TrainingModel.focusXpForCast(spell.baseCastTicks()));
		award(player, TrainingAttribute.CONTROL, TrainingModel.controlXpForMana(spentMana));
	}

	/** Soma XP ao atributo (respeitando o teto dos canais), salva e avisa se subiu de nível. */
	static void award(ServerPlayerEntity player, TrainingAttribute attr, int xp) {
		if (xp <= 0 || !player.isAlive()) {
			return;
		}
		xp = RaceService.trainingXp(player, attr, xp);
		PlayerMagicData data = PlayerDataStore.get(player);
		int levelBefore = data.trainingLevel(attr);
		int xpBefore = data.trainingXp(attr);
		boolean up = data.addTrainingXp(attr, xp);
		if (!up && data.trainingXp(attr) == xpBefore && data.trainingLevel(attr) == levelBefore) {
			return; // no teto: nada mudou
		}
		PlayerDataStore.save(player, data);
		runtime(player).dirty = true;
		if (up) {
			applyAttributes(player, false);
			sync(player);
			ServerWorld world = server == null ? null : WorldLookup.of(server, player);
			if (world != null) {
				world.playSound(null, player.getX(), player.getY(), player.getZ(),
						SoundEvents.ENTITY_PLAYER_LEVELUP, SoundCategory.PLAYERS, 0.6f, 1.4f);
			}
			player.sendMessage(Text.translatable("message.rezero_magic.training_up",
					Text.translatable("training.rezero_magic." + attr.key()), data.trainingLevel(attr)), false);
		}
	}

	// ------------------------------------------------------------------ treino ativo

	/** Pedido do cliente (Hub): qual atributo o Poste de Treino exercita. */
	public static void selectFocus(ServerPlayerEntity player, int attributeId) {
		TrainingAttribute attr = TrainingAttribute.fromId(attributeId);
		if (attr == null) {
			return;
		}
		PlayerMagicData data = PlayerDataStore.get(player);
		data.setTrainingFocus(attr);
		PlayerDataStore.save(player, data);
		sync(player);
	}

	/** Uma repetição no Poste de Treino (clique direito). Todas as regras são conferidas aqui. */
	public static void rep(ServerWorld world, ServerPlayerEntity player, BlockPos pos) {
		Runtime rt = runtime(player);
		if (rt.repCooldown > 0) {
			return;
		}
		if (rt.overtrained) {
			message(player, "training.overtrained");
			return;
		}
		if (player.getHungerManager().getFoodLevel() < TrainingModel.MIN_FOOD) {
			message(player, "training.hungry");
			return;
		}
		PlayerMagicData data = PlayerDataStore.get(player);
		TrainingAttribute attr = data.trainingFocus();
		if (data.trainingLevel(attr) >= data.trainingCap()) {
			message(player, "training.capped");
			return;
		}
		rt.repCooldown = TrainingModel.REP_COOLDOWN_TICKS;
		int xp = TrainingModel.repXp(rt.fatigue);
		rt.fatigue = TrainingModel.fatigueAfterRep(rt.fatigue);
		player.getHungerManager().addExhaustion(TrainingModel.REP_EXHAUSTION);
		rt.dirty = true;
		world.spawnParticles(ParticleTypes.CRIT, pos.getX() + 0.5, pos.getY() + 1.1, pos.getZ() + 0.5, 6, 0.3, 0.2, 0.3, 0.1);
		world.playSound(null, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5,
				SoundEvents.ENTITY_PLAYER_ATTACK_STRONG, SoundCategory.BLOCKS, 0.7f, 1.0f);
		award(player, attr, xp);
		if (rt.fatigue >= TrainingModel.FATIGUE_MAX) {
			rt.overtrained = true;
			player.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, TrainingModel.OVERTRAIN_PENALTY_TICKS, 0));
			player.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, TrainingModel.OVERTRAIN_PENALTY_TICKS, 0));
			message(player, "training.overtrained_start");
		} else {
			player.sendMessage(Text.translatable("message.rezero_magic.training.rep",
					Text.translatable("training.rezero_magic." + attr.key()), xp, rt.fatigue), true);
		}
	}

	// ------------------------------------------------------------------ tick

	private static void tick(MinecraftServer current) {
		boolean doSync = current.getTicks() % SYNC_PERIOD == 0;
		boolean doCheck = current.getTicks() % ATTRIBUTE_CHECK_PERIOD == 0;
		for (ServerPlayerEntity player : current.getPlayerManager().getPlayerList()) {
			Runtime rt = runtime(player);
			if (rt.repCooldown > 0) {
				rt.repCooldown--;
			}
			if (rt.fatigue > 0 && ++rt.fatigueTick >= TrainingModel.FATIGUE_DECAY_TICKS) {
				rt.fatigueTick = 0;
				rt.fatigue--;
				if (rt.overtrained && rt.fatigue <= TrainingModel.FATIGUE_RESUME) {
					rt.overtrained = false;
					message(player, "training.recovered");
				}
			}
			trackMovement(player, rt);
			if (doCheck) {
				applyAttributes(player, false);
			}
			if (doSync && (rt.dirty || rt.lastSentFatigue != rt.fatigue)) {
				sync(player);
			}
		}
		Iterator<UUID> it = STATE.keySet().iterator();
		while (it.hasNext()) {
			if (current.getPlayerManager().getPlayer(it.next()) == null) {
				it.remove();
			}
		}
	}

	/** Correr (Vigor), pular e andar (Agilidade). Ignora espectador, veículo e planador. */
	private static void trackMovement(ServerPlayerEntity player, Runtime rt) {
		double x = player.getX();
		double y = player.getY();
		double z = player.getZ();
		boolean onGround = player.isOnGround();
		boolean valid = player.isAlive() && !player.isSpectator() && !player.hasVehicle() && !player.isFallFlying();
		if (valid && rt.hasLast) {
			double dx = x - rt.lastX;
			double dz = z - rt.lastZ;
			double dist = Math.sqrt(dx * dx + dz * dz);
			if (dist < MAX_STEP) {
				rt.distAcc += dist;
				if (rt.distAcc >= BLOCKS_PER_AGILITY_XP) {
					int whole = (int) (rt.distAcc / BLOCKS_PER_AGILITY_XP);
					rt.distAcc -= whole * BLOCKS_PER_AGILITY_XP;
					award(player, TrainingAttribute.AGILITY, whole);
				}
				if (player.isSprinting() && dist > 0.05) {
					rt.sprintTicks++;
					if (rt.sprintTicks >= TICKS_PER_SPRINT_XP) {
						rt.sprintTicks -= TICKS_PER_SPRINT_XP;
						award(player, TrainingAttribute.VIGOR, 1);
					}
				}
			}
			double dy = y - rt.lastY;
			if (rt.lastOnGround && !onGround && dy > 0.2 && dy < 1.5) {
				award(player, TrainingAttribute.AGILITY, JUMP_XP);
			}
		}
		rt.hasLast = valid;
		rt.lastX = x;
		rt.lastY = y;
		rt.lastZ = z;
		rt.lastOnGround = onGround;
	}

	// ------------------------------------------------------------------ atributos do jogo

	/** Comando de teste restrito (ver AdminCommands): define o nível de todos os atributos de treino. */
	public static void adminSetLevels(ServerPlayerEntity player, int level) {
		PlayerMagicData data = PlayerDataStore.get(player);
		data.adminSetTrainingLevels(level);
		PlayerDataStore.save(player, data);
		applyAttributes(player, true);
		sync(player);
	}

	/** Reaplica vida, ataque e velocidade (chamado pelo RaceService quando a raça é escolhida). */
	static void refreshAttributes(ServerPlayerEntity player) {
		applyAttributes(player, true);
	}

	/** Vida, ataque e velocidade vindos do treino E da raça. Só reaplica se algo mudou ou o modificador sumiu. */
	private static void applyAttributes(ServerPlayerEntity player, boolean force) {
		Runtime rt = runtime(player);
		PlayerMagicData data = PlayerDataStore.get(player);
		int[] levels = data.trainingLevels();
		Race race = data.race();
		double health = TrainingModel.maxHealthBonus(levels[TrainingAttribute.VIGOR.id()]) + RaceRules.maxHealthBonus(race);
		int sig = Arrays.hashCode(levels) * 31 + data.raceId();
		boolean missing = health != 0.0 && !hasModifier(player, EntityAttributes.GENERIC_MAX_HEALTH, MOD_HEALTH);
		if (!force && !missing && sig == rt.appliedSig) {
			return;
		}
		rt.appliedSig = sig;
		setModifier(player, EntityAttributes.GENERIC_MAX_HEALTH, MOD_HEALTH, health, EntityAttributeModifier.Operation.ADDITION);
		setModifier(player, EntityAttributes.GENERIC_ATTACK_DAMAGE, MOD_ATTACK,
				TrainingModel.attackBonus(levels[TrainingAttribute.STRENGTH.id()]) + RaceRules.attackBonus(race),
				EntityAttributeModifier.Operation.ADDITION);
		setModifier(player, EntityAttributes.GENERIC_MOVEMENT_SPEED, MOD_SPEED,
				TrainingModel.speedFraction(levels[TrainingAttribute.AGILITY.id()]) + RaceRules.speedFraction(race),
				EntityAttributeModifier.Operation.MULTIPLY_BASE);
		// vida máxima menor (meio-elfo): a vida atual não pode passar do novo máximo
		if (player.getHealth() > player.getMaxHealth()) {
			player.setHealth(player.getMaxHealth());
		}
	}

	/** Em 1.20.1 os modificadores são identificados por UUID: derivado do nome, então é sempre o mesmo. */
	private static UUID modifierId(String name) {
		return UUID.nameUUIDFromBytes((ReZeroMod.MOD_ID + ":" + name).getBytes(StandardCharsets.UTF_8));
	}

	private static boolean hasModifier(ServerPlayerEntity player, EntityAttribute attribute, String name) {
		EntityAttributeInstance inst = player.getAttributeInstance(attribute);
		return inst != null && inst.getModifier(modifierId(name)) != null;
	}

	/** Modificador temporário (não é salvo no jogador: é reaplicado a cada entrada, então nunca fica "preso"). */
	private static void setModifier(ServerPlayerEntity player, EntityAttribute attribute, String name,
			double value, EntityAttributeModifier.Operation operation) {
		EntityAttributeInstance inst = player.getAttributeInstance(attribute);
		if (inst == null) {
			return;
		}
		UUID id = modifierId(name);
		inst.removeModifier(id);
		if (value != 0.0) {
			inst.addTemporaryModifier(new EntityAttributeModifier(id, ReZeroMod.MOD_ID + ":" + name, value, operation));
		}
	}

	// ------------------------------------------------------------------ rede

	public static void sync(ServerPlayerEntity player) {
		PlayerMagicData d = PlayerDataStore.get(player);
		Runtime rt = runtime(player);
		int[] xp = d.trainingXpValues();
		ModNet.send(player, new TrainingSyncPayload(TrainingModel.packLevels(d.trainingLevels()),
				TrainingModel.packXpA(xp), TrainingModel.packXpB(xp), d.trainingFocus().id(), rt.fatigue));
		rt.dirty = false;
		rt.lastSentFatigue = rt.fatigue;
	}

	private static void message(ServerPlayerEntity player, String key) {
		player.sendMessage(Text.translatable("message.rezero_magic." + key), true);
	}
}
