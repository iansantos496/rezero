package com.rezero.mod.net;

import com.rezero.mod.ReZeroMod;

import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;

/**
 * Cliente -> servidor: um PEDIDO de ação de combate. action 0 = usar a técnica do espaço {@code arg} (0 a 2) da arma na mão;
 * 1 = esquivar na direção {@code arg} (0 frente, 1 trás, 2 esquerda, 3 direita); 2 = aprender a técnica de id {@code arg}.
 * O servidor valida tudo (arma, estamina, recarga, requisitos).
 */
public record CombatActionPayload(int action, int arg) implements ModPacket {
	public static final int USE = 0;
	public static final int DODGE = 1;
	public static final int LEARN = 2;
	public static final Identifier ID = new Identifier(ReZeroMod.MOD_ID, "combat_action");

	public static CombatActionPayload read(PacketByteBuf buf) {
		return new CombatActionPayload(buf.readVarInt(), buf.readVarInt());
	}

	@Override
	public Identifier id() {
		return ID;
	}

	@Override
	public void write(PacketByteBuf buf) {
		buf.writeVarInt(action);
		buf.writeVarInt(arg);
	}
}
