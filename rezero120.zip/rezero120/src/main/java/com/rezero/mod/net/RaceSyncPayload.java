package com.rezero.mod.net;

import com.rezero.mod.ReZeroMod;

import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;

/** Servidor -> cliente: raça escolhida, tempo restante da forma e da recarga (só para exibição). */
public record RaceSyncPayload(int raceId, int formTicks, int cooldownTicks) implements ModPacket {

	public static final Identifier ID = new Identifier(ReZeroMod.MOD_ID, "race_sync");

	public static RaceSyncPayload read(PacketByteBuf buf) {
		return new RaceSyncPayload(buf.readVarInt(), buf.readVarInt(), buf.readVarInt());
	}

	@Override
	public Identifier id() {
		return ID;
	}

	@Override
	public void write(PacketByteBuf buf) {
		buf.writeVarInt(raceId);
		buf.writeVarInt(formTicks);
		buf.writeVarInt(cooldownTicks);
	}
}
