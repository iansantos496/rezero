package com.rezero.mod.net;

import com.rezero.mod.ReZeroMod;

import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;

/** Cliente -> servidor: "quero a raça X". É só um pedido; o servidor decide (escolha única). */
public record ChooseRacePayload(int raceId) implements ModPacket {

	public static final Identifier ID = new Identifier(ReZeroMod.MOD_ID, "choose_race");

	public static ChooseRacePayload read(PacketByteBuf buf) {
		return new ChooseRacePayload(buf.readVarInt());
	}

	@Override
	public Identifier id() {
		return ID;
	}

	@Override
	public void write(PacketByteBuf buf) {
		buf.writeVarInt(raceId);
	}
}
