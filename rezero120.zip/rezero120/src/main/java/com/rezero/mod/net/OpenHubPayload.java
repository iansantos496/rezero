package com.rezero.mod.net;

import com.rezero.mod.ReZeroMod;

import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;

/** Servidor -> cliente: abra o Hub na aba indicada (usado pela Mesa de Inscrição). */
public record OpenHubPayload(int tab) implements ModPacket {

	public static final Identifier ID = new Identifier(ReZeroMod.MOD_ID, "open_hub");

	public static OpenHubPayload read(PacketByteBuf buf) {
		return new OpenHubPayload(buf.readVarInt());
	}

	@Override
	public Identifier id() {
		return ID;
	}

	@Override
	public void write(PacketByteBuf buf) {
		buf.writeVarInt(tab);
	}
}
