package com.rezero.mod.net;

import com.rezero.mod.server.CombatService;
import com.rezero.mod.server.InscriptionService;
import com.rezero.mod.server.MagicGate;
import com.rezero.mod.server.ProtectionService;
import com.rezero.mod.server.RaceService;
import com.rezero.mod.server.SpellService;
import com.rezero.mod.server.SpiritService;
import com.rezero.mod.server.TrainingService;
import com.rezero.mod.server.TransformService;


/** Registro dos pacotes e dos receptores do SERVIDOR. Todo pedido do cliente passa pelo MagicGate. */
public final class ModNetworking {
	private ModNetworking() {}

	public static void registerCommon() {

		ModNet.registerC2S(ChooseAffinityPayload.ID, ChooseAffinityPayload::read, (payload, context) ->
				MagicGate.tryChooseAffinity(context.player(), payload.affinityId()));
		ModNet.registerC2S(CastSpellPayload.ID, CastSpellPayload::read, (payload, context) ->
				SpellService.requestCast(context.server(), context.player(), payload.spellId()));
		ModNet.registerC2S(InscribePayload.ID, InscribePayload::read, (payload, context) ->
				InscriptionService.request(context.server(), context.player(), payload.inscriptionId(), payload.remove() != 0));
		ModNet.registerC2S(SelectTrainingPayload.ID, SelectTrainingPayload::read, (payload, context) ->
				TrainingService.selectFocus(context.player(), payload.attributeId()));
		ModNet.registerC2S(CombatActionPayload.ID, CombatActionPayload::read, (payload, context) ->
				CombatService.request(context.server(), context.player(), payload.action(), payload.arg()));
		ModNet.registerC2S(SpiritActionPayload.ID, SpiritActionPayload::read, (payload, context) ->
				SpiritService.request(context.server(), context.player(), payload.action()));
		ModNet.registerC2S(ProtectionActionPayload.ID, ProtectionActionPayload::read, (payload, context) ->
				ProtectionService.request(context.server(), context.player(), payload.action(), payload.arg()));
		ModNet.registerC2S(TransformActionPayload.ID, TransformActionPayload::read, (payload, context) ->
				TransformService.request(context.server(), context.player(), payload.action()));
		ModNet.registerC2S(ChooseRacePayload.ID, ChooseRacePayload::read, (payload, context) ->
				RaceService.tryChoose(context.player(), payload.raceId()));
		ModNet.registerC2S(RaceActionPayload.ID, RaceActionPayload::read, (payload, context) ->
				RaceService.request(context.server(), context.player(), payload.action()));
	}
}
