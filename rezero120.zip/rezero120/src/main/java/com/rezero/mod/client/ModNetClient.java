package com.rezero.mod.client;

import java.util.function.BiConsumer;
import java.util.function.Function;

import com.rezero.mod.net.ModPacket;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.MinecraftClient;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;

/** Lado do CLIENTE da rede do mod (1.20.1). Os receptores rodam na thread principal do cliente. */
public final class ModNetClient {
	private ModNetClient() {}

	/** Cliente -> servidor. */
	public static void send(ModPacket packet) {
		PacketByteBuf buf = PacketByteBufs.create();
		packet.write(buf);
		ClientPlayNetworking.send(packet.id(), buf);
	}

	public static <T extends ModPacket> void register(Identifier id, Function<PacketByteBuf, T> reader, BiConsumer<T, MinecraftClient> handler) {
		ClientPlayNetworking.registerGlobalReceiver(id, (client, networkHandler, buf, responseSender) -> {
			T payload = reader.apply(buf);
			client.execute(() -> handler.accept(payload, client));
		});
	}
}
