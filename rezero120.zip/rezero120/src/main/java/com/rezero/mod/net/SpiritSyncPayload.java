package com.rezero.mod.net;

import com.rezero.mod.ReZeroMod;

import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;

/**
 * Servidor -> cliente: retrato do espírito. spiritId = elemento contratado (-1 = sem contrato); vínculo e XP;
 * manifestado (0/1); espírito selvagem por perto (0/1); recarga da habilidade ativa em ticks. Só para mostrar na tela.
 */
public record SpiritSyncPayload(int spiritId, int bondLevel, int bondXp, int summoned, int wisp, int cooldownTicks) implements ModPacket {

	public static final Identifier ID = new Identifier(ReZeroMod.MOD_ID, "spirit_sync");

	public static SpiritSyncPayload read(PacketByteBuf buf) {
		return new SpiritSyncPayload(buf.readVarInt(), buf.readVarInt(), buf.readVarInt(), buf.readVarInt(), buf.readVarInt(), buf.readVarInt());
	}

	@Override
	public Identifier id() {
		return ID;
	}

	@Override
	public void write(PacketByteBuf buf) {
		buf.writeVarInt(spiritId);
		buf.writeVarInt(bondLevel);
		buf.writeVarInt(bondXp);
		buf.writeVarInt(summoned);
		buf.writeVarInt(wisp);
		buf.writeVarInt(cooldownTicks);
	}
}
