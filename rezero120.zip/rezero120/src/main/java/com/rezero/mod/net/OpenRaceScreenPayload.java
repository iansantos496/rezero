package com.rezero.mod.net;

import com.rezero.mod.ReZeroMod;

import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;

/** Servidor -> cliente: "abra a tela de escolha de raça" (afinidade já escolhida, raça ainda não). */
public record OpenRaceScreenPayload(int reason) implements ModPacket {

	public static final Identifier ID = new Identifier(ReZeroMod.MOD_ID, "open_race_screen");

	public static OpenRaceScreenPayload read(PacketByteBuf buf) {
		return new OpenRaceScreenPayload(buf.readVarInt());
	}

	@Override
	public Identifier id() {
		return ID;
	}

	@Override
	public void write(PacketByteBuf buf) {
		buf.writeVarInt(reason);
	}
}
