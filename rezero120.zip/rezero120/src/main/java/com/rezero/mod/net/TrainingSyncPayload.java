package com.rezero.mod.net;

import com.rezero.mod.ReZeroMod;

import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;

/**
 * Servidor -> cliente: retrato do treinamento. Os níveis dos 5 atributos vêm empacotados em 4 bits cada
 * e o XP em 10 bits cada (TrainingModel.pack*), além do atributo em foco e da fadiga atual (0..100).
 * O cliente só usa isto para mostrar informação.
 */
public record TrainingSyncPayload(int levelsPack, int xpA, int xpB, int focus, int fatigue) implements ModPacket {

	public static final Identifier ID = new Identifier(ReZeroMod.MOD_ID, "training_sync");

	public static TrainingSyncPayload read(PacketByteBuf buf) {
		return new TrainingSyncPayload(buf.readVarInt(), buf.readVarInt(), buf.readVarInt(), buf.readVarInt(), buf.readVarInt());
	}

	@Override
	public Identifier id() {
		return ID;
	}

	@Override
	public void write(PacketByteBuf buf) {
		buf.writeVarInt(levelsPack);
		buf.writeVarInt(xpA);
		buf.writeVarInt(xpB);
		buf.writeVarInt(focus);
		buf.writeVarInt(fatigue);
	}
}
