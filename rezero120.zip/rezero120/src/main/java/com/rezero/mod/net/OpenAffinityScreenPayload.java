package com.rezero.mod.net;

import com.rezero.mod.ReZeroMod;

import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;

/**
 * Servidor -> cliente: "abra a tela de afinidade". Enviado quando o jogador entra no mundo sem afinidade
 * (reason 0) e após um reset administrativo (reason 1).
 */
public record OpenAffinityScreenPayload(int reason) implements ModPacket {

	public static final Identifier ID = new Identifier(ReZeroMod.MOD_ID, "open_affinity_screen");

	public static OpenAffinityScreenPayload read(PacketByteBuf buf) {
		return new OpenAffinityScreenPayload(buf.readVarInt());
	}

	@Override
	public Identifier id() {
		return ID;
	}

	@Override
	public void write(PacketByteBuf buf) {
		buf.writeVarInt(reason);
	}
}
