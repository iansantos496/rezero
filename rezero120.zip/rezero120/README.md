# Re:Zero Magia (Fabric 1.20.1)

> **Port da versão 1.21.11 para Minecraft 1.20.1.** Veja `docs/PORTE_1_20_1.md` (o que mudou e o que NÃO foi compilado).

Projeto novo, em construção por etapas. Veja `docs/PLANO.md` (plano técnico) e `docs/PROGRESSO.md` (estado atual).

## Compilar
Pelo GitHub: envie `rezero120.zip` ao repositório com o workflow `build-rezero120.yml` em `.github/workflows/`; o artifact é `rezero120-jar`.
Localmente: JDK 17 ou superior + `gradle build` (precisa acesso à internet para baixar o Minecraft e o Fabric).

## Verificações que não precisam do Minecraft
- `bash tools/test_core.sh`  -> compila e testa o código puro (pacote `core`).
- `python3 tools/check_static.py` -> JSON, chaves de tradução, pacotes, imports e entrypoints.
