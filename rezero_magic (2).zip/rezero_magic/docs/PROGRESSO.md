# PROGRESSO — Mod Re:Zero (projeto novo)

Última atualização: 04/11/2026

## Estado real
- Parte 1 (planejamento): docs/PLANO.md. Usuário autorizou ("pode seguir") em 31/10/2026.
- Ritmo: UMA etapa por vez (padrão, o usuário não escolheu outro).
- Pasta do projeto: /home/claude/rezero_v2. Zip de entrega: /home/claude/rezero_magic.zip (pasta interna: rezero_magic/).
- Projeto antigo preservado em /home/claude/rezero_magic (não mexer; só a versão 1.2 teve build confirmado).

## Etapas
- E0 Estrutura: FEITA (31/10/2026).
  - Criados: build.gradle, settings.gradle, gradle.properties (versão 0.1.0), wrapper properties, fabric.mod.json,
    lang pt_br/en_us (6 afinidades), ReZeroMod (entrypoint, só log), core/Affinity, core/AffinityRules,
    tools/test_core.sh, tools/core-tests/CoreTests.java, tools/check_static.py, README, docs/TESTES_ETAPA_0.md.
  - Executado AQUI: testes do core (12 ok, 0 falhas) e verificação estática (OK).
  - NÃO executado: compilação com Minecraft (só o GitHub do usuário faz), jogo, logs.
  - Estado dos sistemas: nenhum dos 12 sistemas está implementado ainda. Só existem as regras puras da afinidade (core).
- E1 Núcleo: FEITA (31/10/2026). Mod 0.1.0 -> mesma versão no gradle (sem bump).
  - Criados: data/PlayerMagicData (Codec; só afinidade), data/PlayerDataStore (Data Attachment, ÚNICO ponto de persistência),
    net/ChooseAffinityPayload (C2S), net/PlayerSyncPayload (S2C), net/ModNetworking, server/MagicGate (porta única),
    server/PlayerSync, server/ServerEvents (JOIN e AFTER_RESPAWN), server/AdminCommands, ModConfig (config/rezero_magic.properties),
    client/ReZeroModClient, client/ClientPlayerData, core/AffinityRules.normalizeId, docs/TESTES_ETAPA_1.md.
  - Modificados: ReZeroMod (chamadas de init), fabric.mod.json (entrypoint client), lang pt_br/en_us (2 mensagens), CoreTests.
  - Executado AQUI: testes do core (15 ok, 0 falhas); verificação estática (achou 1 parêntese faltando em AdminCommands, corrigido, OK).
  - NÃO executado: compilação com Minecraft, jogo, persistência real, rede real.
  - Estado real: afinidade tem dados, rede e validação no servidor, mas AINDA NÃO há tela para escolher (E2). Nenhum dos 12 sistemas
    está completo; o Sistema 12 está parcial (regras + dados + validação; falta a tela e o bloqueio nos poderes, que só existem a partir da E3).
  - Pendências conhecidas: (a) comando admin sem checagem de operador (API de permissões 1.21.9+ não confirmada; trava = config
    allowAdminReset=false por padrão); (b) APIs não confirmadas por build: AttachmentRegistry.builder()/getAttachedOrCreate/setAttached,
    CommandRegistrationCallback v2, ClientPlayConnectionEvents.DISCONNECT, PacketCodec.tuple de 1 campo.
- E2 Seleção de afinidade + Hub esqueleto: FEITA (31/10/2026).
  - Criados: core/AffinityPicker (fluxo escolher -> confirmar -> enviar, testável), net/OpenAffinityScreenPayload (S2C),
    client/AffinityScreen (obrigatória, ESC não fecha, 6 cartões, confirmação em 2 passos), client/HubScreen (dados reais: jogador e
    afinidade), docs/TESTES_ETAPA_2.md.
  - Modificados: MagicGate (promptAffinityIfNeeded; reset admin reabre a tela), ServerEvents (JOIN abre a tela se faltar afinidade),
    ModNetworking, ClientPlayerData (pedido de abrir tela), ReZeroModClient (tecla K, abertura segura no tick, fecha ao confirmar),
    lang pt_br/en_us (descrições "Da obra" / "No jogo (adaptação)"), check_static.py (verifica chaves dinâmicas das 6 afinidades),
    PLANO.md (removida afirmação não verificada de que Yin/Yang são raros).
  - Executado AQUI: testes do core (25 ok, 0 falhas) e verificação estática (OK).
  - NÃO executado: compilação, jogo, abertura real das telas, persistência real.
  - Estado real do Sistema 12: tela obrigatória + confirmação + validação no servidor + persistência por mundo IMPLEMENTADOS, NÃO TESTADOS.
    Falta o bloqueio de poderes por afinidade, que só pode existir quando houver poderes (E3 em diante). O Hub tem só informações do jogador
    e afinidade (os demais sistemas ainda não existem, por isso não têm botão).
  - Limitações conhecidas: durante a escolha o jogo NÃO pausa (shouldPause=false) e o jogador pode ser atacado; o cliente só abre a tela
    quando não há outra tela aberta.
- E3 Canais de mana (S10) + framework de magia (S1) + Fogo e Água: FEITA (01/11/2026). Mod 0.1.0 -> 0.3.0 (gradle.properties).
  - Canon pesquisado: só o Od Lagna ("reserva de mana, coração do mundo") foi confirmado. Gate, consumo de mana, exaustão e
    regeneração NÃO foram confirmados: tudo isso é ADAPTAÇÃO de jogo (rotulado em ChannelModel e Spells). Os nomes Goa/Elgoa/Urgoa/Algoa
    seguem o padrão de prefixos El/Ur/Al da obra; o que cada feitiço faz é adaptação. Nomes dos feitiços de Água são de jogo.
  - Core puro novo: ChannelModel (capacidade 100..385, regeneração 1,5..6,25/s, custo, conjuração, potência, XP 20 níveis, exaustão 5 s),
    SpellDef, Spells (10 feitiços: 5 Fogo + 5 Água), CastRules (ordem fixa das verificações).
  - Dados: PlayerMagicData v2 (mana, channel_level, channel_xp; campos ausentes recebem padrão, então mundos da E2 continuam válidos).
  - Rede: CastSpellPayload (C2S), ManaSyncPayload e CastStatePayload (S2C); PlayerSyncPayload agora leva nível e XP.
  - Servidor: SpellService (pedido -> MagicGate.checkCast -> conjuração interrompível por dano -> efeito -> cobra mana/XP/recarga),
    SpellEffects (10 efeitos; gelo temporário e zonas de fogo limpos ao fechar o servidor), WorldLookup, MagicGate.checkCast.
  - Cliente: teclas R/Z/X, SpellHud (mana, canais, feitiço, barra de conjuração), HubScreen com abas Perfil e Magias (dados reais).
  - Executado AQUI: testes do core (55 ok, 0 falhas) e verificação estática (OK; agora checa nomes de feitiços, mensagens de CastRules
    e registro de todos os pacotes).
  - NÃO executado: compilação, jogo, efeitos reais, balanceamento, rede, persistência real.
  - Estado real: Sistema 10 (canais) e Sistema 1 (magia): PARCIAIS. Sistema 1 tem 2 de 6 afinidades (Fogo e Água, não testados);
    Sistema 10 tem nível/mana/regeneração/exaustão/eficiência/controle/potência implementados e não testados (sem a parte de
    "Gate" canônica, sem sobrecarga além da exaustão). Sistema 12: agora o bloqueio por afinidade EXISTE no servidor (CastRules),
    implementado e não testado.
  - Limitações conhecidas: sem comando de teste para pular níveis; Algoa/Elgoa usam raio instantâneo (não projétil); a Muralha de Gelo
    só entra em ar (não substitui blocos); se o jogo cair (crash) a muralha pode ficar no mundo; o reset da recarga ao reabrir é esperado.
  - APIs novas NÃO confirmadas por build: Box.raycast, world.setBlockState(pos,state), BlockState.isOf, DamageSources.onFire,
    Entity.setFireTicks, ParticleTypes.EXPLOSION_EMITTER/HEART/SPLASH/LAVA, Window.getScaledWidth/Height, ClickableWidget.visible/active,
    ServerLifecycleEvents.SERVER_STOPPING, PacketCodec.tuple de 2 e 3 campos (o de 1 campo já era risco da E1).
- E4 Feitiços de Vento, Terra, Yin e Yang: FEITA (01/11/2026). Mod 0.3.0 -> 0.4.0.
  - Core: Spells agora tem 30 feitiços (ids 0..29, 5 por afinidade). Nomes da obra usados: Dona (Terra, verificado) e Shamak (Yin,
    verificado); os demais nomes são de jogo e o que cada feitiço faz é adaptação (rotulado em Spells e nos efeitos).
  - Servidor: SpellEffects virou despachante (Fogo/Água + zonas genéricas FIRE/VORTEX/MIASMA + blocos temporários + placeWall);
    novos WindEffects, EarthEffects, YinEffects, YangEffects. Yang beneficia o conjurador e jogadores até 8 blocos.
    Dreno Vital, Maldição e Prisão de Gelo exigem alvo na mira (recusa sem gastar mana).
  - Comando de teste /rezero admin nivel_canais <1-20> (mesma trava allowAdminReset=false por padrão).
  - Executado AQUI: testes do core (56 ok, 0 falhas) e verificação estática (OK; checa nomes dos 30 feitiços).
  - NÃO executado: compilação, jogo, qualquer efeito, balanceamento.
  - Estado real: Sistema 1 (magia): as 6 afinidades têm 5 feitiços cada, IMPLEMENTADO e NÃO TESTADO; segue PARCIAL só porque as
    interações entre elementos NÃO foram implementadas (não há base canônica confirmada e não quis inventar). Sistema 10: igual à E3.
  - Limitações: Impulso de Vento depende de a velocidade do jogador sincronizar (risco); feitiços de zona mirados no céu aparecem
    longe no ar; Yang só ajuda aliados jogadores (não há aliados NPC).
  - APIs novas NÃO confirmadas: StatusEffects.STRENGTH/JUMP_BOOST/ABSORPTION/RESISTANCE/REGENERATION/HASTE/SLOW_FALLING/LEVITATION/
    WITHER/BLINDNESS, RegistryEntry<StatusEffect> como tipo de parâmetro, IntegerArgumentType, SoundEvents.BLOCK_GRAVEL_BREAK,
    ParticleTypes.HAPPY_VILLAGER/ENCHANT/WITCH (os dois últimos já compilaram no projeto antigo).
- E5 Cristais de mana (S2): FEITA (01/11/2026). Mod 0.4.0 -> 0.5.0.
  - Canon: pesquisa não achou cristais de mana como item canônico (só páginas de outros mundos). TUDO nesta etapa é adaptação de jogo.
  - Core: CrystalRarity (4 raridades: 15/40/90/200 de mana), CrystalRules (restauração, Receptor 300 de capacidade guardado no dano do
    item, Concentrador +25%, saturação 5 s direto e 3 s no saque). 17 testes novos.
  - Conteúdo: itens (4 cristais + Receptor de Mana), blocos (Minério de Cristal de Mana, Concentrador de Mana), loot tables, tags de
    mineração (picareta de pedra), 5 receitas, geração no Overworld (configured/placed feature JSON + BiomeModifications), abas do criativo.
    Texturas 16x16 PROCEDURAIS geradas por tools/gen_assets.py (simples; trocáveis por arte final mantendo os nomes).
  - Servidor: CrystalService (usar cristal, usar Receptor, usar Concentrador; exige afinidade escolhida; saturação).
  - Hub: aba "Cristais" com contagem real do inventário.
  - Executado AQUI: testes do core (73 ok, 0 falhas); verificação estática (OK; agora confere modelo/textura/definição/tradução/loot
    de cada item e bloco e valida todos os JSON).
  - NÃO executado: compilação, jogo, geração, receitas, texturas no jogo.
  - Estado real do Sistema 2: PARCIAL. Implementado e não testado: minério, 4 raridades, extração com ferramenta mínima, uso direto,
    Receptor (armazenamento), Concentrador (carrega item), saturação. NÃO implementado: consumo de cristais em fabricação de equipamentos e
    tinta de inscrição (entram em E6 com equipamentos/inscrições), raridades diferentes por bioma (só um minério gera; as raridades
    maiores só por fabricação), Fortuna/Toque Suave no minério.
  - APIs novas NÃO confirmadas por build: Blocks.register(key, factory, settings) e Items.register(key, factory, settings)/(Block),
    Item.Settings.component(DataComponentTypes.DAMAGE,...), Item.use -> ActionResult, Block.onUse público, BlockSoundGroup.AMETHYST_BLOCK,
    MapColor.STONE_GRAY/PURPLE, ItemGroupEvents (pacote net.fabricmc.fabric.api.itemgroup.v1), BiomeModifications/BiomeSelectors,
    ItemStack.getDamage/setDamage/decrement, PlayerEntity.isCreative, formato JSON de receitas 1.21.2+ (ingredientes em texto) e de worldgen.
- E6a Equipamentos (S5), parte 1: FEITA (01/11/2026). Mod 0.5.0 -> 0.6.0.
  - Canon: nada verificado sobre equipamentos; tudo adaptação de jogo.
  - Core: Catalyst (4 cajados), Charm (5 acessórios), CastModifiers, EquipmentRules (soma com limites), overloads em ChannelModel/CastRules.
    9 testes novos (82 no total).
  - Conteúdo: 6 espadas (propriedades de espada do jogo base com ToolMaterial vanilla), 4 cajados catalisadores (mão principal),
    5 acessórios (mão secundária), 15 receitas, texturas procedurais (tools/gen_assets.py), EquipmentLookup.
  - Integração: SpellService/MagicGate aplicam potência, custo, tempo de conjuração e regeneração do equipamento no SERVIDOR;
    HUD e Hub mostram os mesmos números (lidos do item na mão do cliente, só exibição). Hub ganhou a aba "Equipamento".
  - Executado AQUI: testes do core (82 ok, 0 falhas); verificação estática (OK; confere assets, receitas JSON e traduções).
  - NÃO executado: compilação, jogo, receitas, equilíbrio.
  - Estado real do Sistema 5: PARCIAL. Implementado e não testado: 6 armas corpo a corpo, 4 cajados, 5 acessórios (slot = mão secundária,
    escolha de projeto porque o jogo base não tem slot de acessório). NÃO implementado: 3 conjuntos de armadura (API de armadura do
    1.21.11 não confirmada), armas mágicas com efeito próprio, manutenção/reparo com cristal, aprimoramento por níveis.
    Meta do plano (10 armas): 6 espadas + 4 cajados = 10 implementadas.
  - APIs novas NÃO confirmadas: Item.Settings.sword(ToolMaterial, float, float), ToolMaterial.IRON/DIAMOND/NETHERITE,
    Item.Settings.maxCount, PlayerEntity.getMainHandStack/getOffHandStack, ItemGroups.COMBAT, parent item/handheld.
- E6b Vestes (S5) + Inscrições mágicas (S8): FEITA (01/11/2026). Mod 0.6.0 -> 0.7.0.
  - Canon: nada verificado; tudo adaptação de jogo.
  - Core: RobeSet/RobePiece (3 conjuntos x 4 peças, bônus por peça e de conjunto completo), Inscription (12 em 4 categorias, 3 espaços),
    InscriptionRules (gravar/remover/sanear/máscara), EquipmentRules estendido (tudo junto, com os mesmos limites). 19 testes novos
    (101 no total).
  - Conteúdo: 12 peças vestíveis (EQUIPPABLE + definição de equipamento em JSON + texturas vestidas procedurais), Tinta de Cristal,
    Mesa de Inscrição (bloco; abre o Hub na aba Marcas), receitas, tags de mineração.
  - Servidor: InscriptionService (gravar/remover exigem mesa a até 4 blocos, nível dos canais, tinta, afinidade; efeitos passivos a cada
    segundo); SpellService soma cajado + acessório + vestes + marcas. Dados: PlayerMagicData v3 (lista de marcas). Rede: InscribePayload
    (C2S), OpenHubPayload (S2C), PlayerSyncPayload com máscara das marcas.
  - Hub: abas agora são 5 (Perfil, Magias, Cristais, Equip., Marcas).
  - Executado AQUI: testes do core (101 ok, 0 falhas); verificação estática (OK; confere assets, textura vestida, equipamento JSON,
    traduções e mensagens das 12 marcas).
  - NÃO executado: compilação, jogo, vestes no corpo, receitas, equilíbrio.
  - Estado real do Sistema 5: PARCIAL. Implementado e não testado: 6 espadas, 4 cajados, 5 acessórios, 3 conjuntos de veste (SEM proteção
    física: só bônus mágico). NÃO implementado: proteção física das vestes, armas com efeito mágico próprio, reparo com cristal, aprimoramento.
  - Estado real do Sistema 8: PARCIAL. Implementado e não testado: 12 marcas, 4 categorias, mesa, tinta de cristal, custo/nível, limite de 3.
    DESVIO do plano: as marcas ficam NO JOGADOR, não em armas/armaduras (item bound exigiria registrar um componente de item novo, API não
    confirmada). NÃO implementado: combinações especiais entre marcas, marcas elementais por afinidade.
  - APIs novas NÃO confirmadas: EquippableComponent.builder(EquipmentSlot).model(RegistryKey<EquipmentAsset>).build(),
    DataComponentTypes.EQUIPPABLE, EquipmentAssetKeys.REGISTRY_KEY, pacote net.minecraft.item.equipment, LivingEntity.getEquippedStack,
    StatusEffectInstance(entry, dur, amp, ambient, particles, icon), StatusEffects.FIRE_RESISTANCE/WATER_BREATHING, ButtonWidget.setMessage,
    formato do JSON de equipamento (assets/<ns>/equipment) e caminho das texturas vestidas (textures/entity/equipment/humanoid[_leggings]/).
- E7a Treinamento e evolução (S6): FEITA (02/11/2026). Mod 0.7.0 -> 0.8.0. A E7 foi dividida: E7a = treino, E7b = técnicas de combate (S9).
  - Canon: nada verificado; é adaptação de jogo (a obra não tem atributos numéricos).
  - Core: TrainingAttribute (Vigor, Força, Agilidade, Foco, Controle de mana), TrainingModel (níveis 0-10, XP 40+30*nível, teto =
    2 + nível dos canais/2, treino ativo com rendimento decrescente e fadiga, efeitos por nível, empacotamento de rede), EquipmentRules
    com treino. 21 testes novos (122 no total).
  - Dados: PlayerMagicData v4 (níveis, XP e atributo em foco). Rede: TrainingSyncPayload (S2C), SelectTrainingPayload (C2S).
  - Servidor: TrainingService (XP por uso: correr, dano sofrido, dano corpo a corpo, pular, andar, conjurar, gastar mana; Poste de Treino com
    fadiga, fome e penalidade por exagero; modificadores de atributo do jogo para vida, ataque e velocidade).
  - Conteúdo: Poste de Treino (bloco, textura, receita, loot). Hub: aba "Treino" (agora 6 abas).
  - Executado AQUI: testes do core (122 ok, 0 falhas); verificação estática OK (inclui agora a conferência das mensagens de todos os serviços).
  - NÃO executado: compilação, jogo, efeitos reais nos atributos, equilíbrio.
  - Estado real do Sistema 6: PARCIAL. Implementado e não testado: 5 atributos, XP por uso, treino ativo, fadiga, teto, efeitos, Hub.
    NÃO implementado: teto por raça (raças ainda não existem), requisitos de equipamento por atributo, outras estações de treino, treino
    mágico além de conjurar.
  - Limites conhecidos: XP por uso pode ser "farmado" (correr, bater em mobs), mas o teto dos canais limita; a fadiga não é salva.
  - APIs novas NÃO confirmadas: ServerLivingEntityEvents.AFTER_DAMAGE (assinatura de 5 parâmetros), EntityAttributes.MAX_HEALTH/ATTACK_DAMAGE/
    MOVEMENT_SPEED, EntityAttributeInstance.getModifier/removeModifier/addTemporaryModifier, EntityAttributeModifier(Identifier, double, Operation),
    EntityAttributeModifier.Operation.ADD_VALUE/ADD_MULTIPLIED_BASE, DamageSource.getAttacker/getSource, HungerManager.addExhaustion/getFoodLevel,
    StatusEffects.SLOWNESS/WEAKNESS, SoundEvents.BLOCK_WOOD_HIT, MapColor.OAK_TAN, ServerPlayerEntity.isOnGround/isFallFlying/hasVehicle/isSpectator.
- E7b Técnicas de combate (S9): FEITA (02/11/2026). Mod 0.8.0 -> 0.9.0.
  - Canon: nada verificado; é adaptação de jogo (estilos e números são decisões minhas).
  - Core: CombatStyle (5), TechniqueDef/Techniques (15 técnicas, 3 por estilo), CombatRules (estamina, esquiva, contra-ataque, combo, pontos de
    técnica, requisitos). 16 testes novos (138 no total).
  - Dados: PlayerMagicData v5 (técnicas aprendidas). Rede: CombatActionPayload (C2S: usar, esquivar, aprender), CombatSyncPayload e
    TechniqueCooldownPayload (S2C).
  - Servidor: CombatService (estamina própria, esquiva com invulnerabilidade a ataques de criaturas, contra-ataque, combo de golpes comuns,
    técnicas com carga interrompível, flechas consumidas) e CombatEffects (o que cada técnica faz).
  - Conteúdo: Lança de Mana e Lança de Cristal (itens novos; texturas, modelos, receitas). Cliente: teclas V, G, H, J; HUD de estamina e técnicas;
    aba "Técnicas" no Hub (agora 7 abas).
  - Executado AQUI: testes do core (138 ok, 0 falhas); verificação estática OK (inclui textos das 15 técnicas, estilos, mensagens e lanças).
  - NÃO executado: compilação, jogo, equilíbrio, efeitos das técnicas, teclas.
  - Estado real do Sistema 9: PARCIAL. Implementado e não testado: 5 estilos, 15 técnicas, esquiva, contra-ataque, combo, carga, árvore com
    requisitos e pontos, integração com treino (requisitos, estamina por Vigor/Agilidade, dano por Força) e com equipamento (dano da arma).
    NÃO implementado: técnicas imbuídas com mana (integração com canais), esquecer técnicas, técnicas de arco com flecha física, ataques
    carregados por tecla segurada (a carga é um tempo fixo), especializações além da árvore de 3 tiers.
  - Limites conhecidos: golpes múltiplos e ecos esperam ~0,5 s (invulnerabilidade do alvo do jogo); o impulso da esquiva em jogadores depende do
    pacote de velocidade (o Impulso de Vento de E3 ainda usa só addVelocity e pode ter o mesmo problema).
  - APIs novas NÃO confirmadas: ServerLivingEntityEvents.ALLOW_DAMAGE (3 parâmetros, retorna boolean), EntityVelocityUpdateS2CPacket(Entity),
    ServerPlayerEntity.networkHandler, LivingEntity.getAttributeValue(entry), Vec3d.rotateY, MathHelper.wrapDegrees, Entity.getYaw/getWidth/
    squaredDistanceTo/distanceTo, StatusEffects.RESISTANCE/SPEED, ItemTags.SWORDS, ItemStack.isIn/isOf, PlayerInventory.getStack,
    GameOptions.forwardKey/leftKey/rightKey, KeyBinding.getBoundKeyLocalizedText.
- E8 Espíritos (S3): FEITA (03/11/2026). Mod 0.9.0 -> 0.10.0.
  - Canon: só 2 afirmações verificadas (existem espíritos; contrato com eles). O resto é adaptação de jogo. Nenhum personagem da obra usado.
  - Decisão R4: espírito é companheiro de partículas (sem entidade/modelo); luzes selvagens também são partículas, por jogador.
  - Core: SpiritRules (temperamento por elemento, condições de aparição, contrato, vínculo 1-5, custo de mana, potência, habilidade). 10 testes novos
    (148 no total). Dados v6 (espírito, vínculo, XP). Rede: SpiritActionPayload (C2S), SpiritSyncPayload (S2C).
  - Servidor: SpiritService (luzes, contrato, manifestar, passivas, habilidade por elemento, XP de vínculo, potência via CastModifiers).
    Conteúdo: Pedra de Contrato (item, textura, receita). Cliente: teclas B e N, HUD do espírito, aba "Espírito" no Hub (8 abas, largura dinâmica).
  - Executado AQUI: testes do core (148 ok, 0 falhas); verificação estática OK (inclui textos de 6 espíritos, resultados, item).
  - NÃO executado: compilação, jogo, equilíbrio, visual das partículas, teclas.
  - Estado real do Sistema 3: PARCIAL. Implementado e não testado: contrato, vínculo, manifestação com custo de mana, passivas, habilidade, bônus de
    potência, Hub e HUD. NÃO implementado: espírito como entidade com modelo, mais de um contrato, espíritos de outros elementos para o mesmo
    jogador (só o da sua afinidade), espíritos selvagens agressivos, interação com raças, persistência do estado manifestado.
  - APIs novas NÃO confirmadas: PlayerBlockBreakEvents.AFTER (assinatura), World.isNight(), World.isRaining(), World.NETHER/getRegistryKey(),
    isSkyVisible(BlockPos), getLightLevel(BlockPos), Entity.isTouchingWater()/getBlockPos(), StatusEffects.HASTE/NIGHT_VISION/STRENGTH/
    REGENERATION/FIRE_RESISTANCE/WATER_BREATHING/SLOW_FALLING, retorno ParticleEffect em switch.
- E9a Raças (S7): FEITA (03/11/2026). Mod 0.10.0 -> 0.11.0. A E9 foi dividida: E9a = raças, E9b = Proteções Divinas (S4).
  - Canon (Otapedia): existem humanos, meio-elfos (preconceito), demi-humanos (físico superior; fera parcial/total; agem por instinto) e oni
    (chifre reúne mana; Forma Oni aumenta a força). Tudo mais (números, vantagens/limitações) é adaptação. Sem personagens da obra.
  - Proteção Divina (pesquisa feita para a E9b): bênção do mundo recebida ao nascer; maioria nasce sem; ~1 em 1000 tem uma útil; algumas raças
    compartilham a mesma; incompatível com Fator de Bruxa; pode ser perdida temporariamente se a ligação com o Od Laguna for cortada;
    exemplos: Indicação do Vento, Linguagem das Almas, Deus da Morte, Clarividência, Reunião de Espíritos, Trissecção, Sol, Santo da Espada.
  - Core: Race (4), RaceRules (vida, ataque, velocidade, XP de treino/vínculo, efeitos na magia, transformações, recusas). EquipmentRules.combine
    ganhou o parâmetro racial. 12 testes novos (160 no total). Dados v7 (raça). Rede: ChooseRacePayload, RaceActionPayload (C2S);
    OpenRaceScreenPayload, RaceSyncPayload (S2C).
  - Servidor: RaceService (escolha única, forma, recarga, exaustão oni, bloqueio de conjuração do demi-humano), ganchos em TrainingService
    (atributos e XP), SpiritService (XP de vínculo), SpellService (modificadores e bloqueio), MagicGate (abre a tela de raça após a afinidade).
    Cliente: RaceScreen (obrigatória, com confirmação), RaceHud, tecla C, Perfil do Hub mostra raça, vantagens e limitações.
  - Executado AQUI: testes do core (160 ok, 0 falhas); verificação estática OK (inclui textos das 4 raças e mensagens).
  - NÃO executado: compilação, jogo, equilíbrio, teclas.
  - Estado real do Sistema 7: PARCIAL. Implementado e não testado: 4 raças, atributos iniciais, passivas, 2 transformações, limitações, escolha única,
    compatibilidade com espírito (vínculo) e magia (custo/regeneração). NÃO implementado: resistências/fraquezas por tipo de dano, outras raças
    (gigante, kobold...), progressão racial, comando para trocar de raça, espíritos por raça.
  - APIs novas NÃO confirmadas: EntityAttributeModifier com valor NEGATIVO (vida máxima), PlayerEntity.setHealth/getMaxHealth após mudar o modificador,
    StatusEffects.STRENGTH/SPEED/SLOWNESS/WEAKNESS com duração longa, Screen.wrapLines (já usado), ServerPlayNetworking.send de pacote sem estado.
- E9b Proteções Divinas (S4): FEITA (03/11/2026). Mod 0.11.0 -> 0.12.0.
  - Canon (Otapedia): bênção do mundo ao nascer; rara; incompatível com Fator de Bruxa; pode ser perdida se o Od Laguna for cortado.
    Nomes usados: Sol, Reunião de Espíritos, Espíritos da Terra, Indicação do Vento, Santo da Espada. Condições, números e efeitos = adaptação.
  - Core: DivineProtection (5), ProtectionRules (condições explícitas, 2 vagas, passivas, ativa, estamina reduzida). CombatRules.checkUse ganhou
    sobrecarga com redução de custo. 12 testes novos (172 no total). Dados v8 (máscara de proteções). Rede: ProtectionActionPayload (C2S: receber/usar),
    ProtectionSyncPayload (S2C).
  - Servidor: ProtectionService (receber com validação, Sol, Terra, Indicação do Vento com partículas, bônus de vínculo), ganchos em CombatService
    (estamina) e SpiritService (vínculo). Cliente: aba "Bênçãos" (9ª aba), tecla Y, ProtectionHud, custo de técnica reduzido no HUD.
  - Executado AQUI: testes do core (172 ok, 0 falhas); verificação estática OK (textos das 5 proteções e mensagens).
  - NÃO executado: compilação, jogo, equilíbrio, teclas, partículas.
  - Estado real do Sistema 4: PARCIAL. Implementado e não testado: 5 proteções (4 raras, 1 épica), condições, vagas, receber, 2 passivas de efeito,
    2 bônus, 1 ativa. NÃO implementado: Linguagem das Almas, Deus da Morte, Clarividência, Trissecção; perda temporária por Od Laguna;
    incompatibilidade com Fator de Bruxa; devolver/trocar; Hub mostrando custo reduzido nas técnicas.
  - APIs novas NÃO confirmadas: HostileEntity, World.getEntitiesByClass com Predicate, Entity.getBoundingBox().expand(double), Entity.getHeight,
    Entity.squaredDistanceTo(Entity), World.isNight, isSkyVisible, ServerPlayerEntity.isOnGround, StatusEffectInstance de 6 argumentos.
- E10 Transformações (S11): FEITA (03/11/2026). Mod 0.12.0 -> 0.13.0.
  - Canon: só as transformações raciais foram verificadas (E9a: fera dos demi-humanos, Forma Oni). Sintonia Elemental e Último Fôlego são
    invenções de jogo, marcadas "adaptação" na tela. Nenhuma cura, revive ou evita a morte.
  - Core: Transformation (4: 2 raciais, 1 espiritual, 1 emergência), TransformationRules (condições na ordem, números, efeitos na magia, soma
    com a raça, esgotamento de mana). 7 testes novos (179 no total). Nenhum dado salvo (estado temporário).
  - Servidor: TransformService (ativar, duração, fim com efeito colateral, recarga, soma dos efeitos na magia), regra de uma forma por vez
    (RaceService consulta TransformService e vice-versa), SpiritService.isSummoned. Cliente: teclas U e O, TransformHud (efeito de tela nas bordas
    e linhas de estado), aba "Formas" (10ª) com todas as 4 formas; rótulos das abas encurtados.
  - Executado AQUI: testes do core (179 ok, 0 falhas); verificação estática OK (textos das 4 formas, resultados, mensagens, tipos).
  - NÃO executado: compilação, jogo, equilíbrio, teclas, aparência do efeito de tela.
  - Estado real do Sistema 11: PARCIAL. Implementado e não testado: 4 formas (2 reaproveitadas das raças), condições, custo, duração, recarga,
    efeitos colaterais, integração com raça, magia (potência/custo/regeneração), espírito e vida. NÃO implementado: modelo visual novo do jogador,
    formas por elemento do espírito, distorção de imagem, formas ligadas a itens.
  - APIs novas NÃO confirmadas: DrawContext.fill com alfa nas bordas (fill já usado), StatusEffects.RESISTANCE com amplificador 1,
    PlayerEntity.getHealth/getMaxHealth no cliente, ParticleTypes.ENCHANT/CRIT em ServerWorld.spawnParticles (já usados).
- E11 Hub final + auditoria (03/11/2026): FEITA. Mod 0.13.0 -> 0.14.0. Relatório completo: docs/AUDITORIA_E11.md.
  - Hub: abas com rolagem (< >) quando não cabem; aba atual desativada; custo de estamina real nas técnicas.
  - Auditoria: matriz do PLANO conferida no código (LIGADO/PARCIAL/NÃO FEITO por ligação) e 4 checagens automáticas novas no check_static
    (pacotes, serviços, teclas, traduções de teclas) com prova de que detectam erro.
  - Comandos de teste novos (desligados por padrão): resetar_raca, resetar_bencaos, nivel_treino, vinculo.
  - Executado AQUI: testes do core (179 ok, 0 falhas); verificação estática OK. NÃO executado: compilação, jogo.
  - Lacunas que continuam (ver AUDITORIA_E11.md): requisitos de equipamento, reparo com cristal, tetos de treino por raça, condição de bênção por
    raça, técnicas imbuídas com mana, permissão de operador nos comandos.
  - APIs novas NÃO confirmadas: ButtonWidget.setX(int) (rolagem das abas).
- E12 Balanceamento + relatório final (04/11/2026): FEITA. Mod 0.14.0 -> 1.0.0. Relatório: docs/RELATORIO_FINAL.md (14 itens).
  - Equilíbrio: modificadores de magia em 2 camadas. Camada 1 (equipamento, robe, marcas, treino) com os tetos de antes (potência 2.0, custo 0.6,
    conjuração 0.6, regeneração 2.0). Camada 2 (espírito, raça, forma ativa) somada DEPOIS, com tetos absolutos (2.25 / 0.5 / 0.5 / 2.5).
    Motivo: com equipamento máximo o teto único anulava espírito, raça e forma.
  - Lacuna pequena resolvida: meio-elfo precisa de vínculo 3 (não 4) para Reunião de Espíritos (ProtectionRules.gatheringBond).
  - Lacunas NÃO feitas (e por quê): requisitos de equipamento, reparo com cristal, tetos de treino por raça, técnicas imbuídas com mana,
    permissão de operador nos comandos, 3 sets de armadura, inscrições em itens, interação entre elementos. Sem base canônica ou API não confirmável.
  - Executado AQUI: testes do core (185 ok, 0 falhas, inclui varredura de 640 combinações de pior caso); verificação estática OK.
  - NÃO executado: compilação, jogo, equilíbrio sentido. O projeto novo nunca foi compilado.
  - Próximo passo real: o usuário compila no GitHub e envia os erros; correções vão para 1.0.1 etc.

## Decisões do usuário
- Do zero. Uma afinidade só (sem troca no jogo normal). Português do Brasil. Alvo: singleplayer, servidor como autoridade.
- Usuário não testa entre as etapas. Esforço médio.
- Autorizou o plano; as 5 pendências do PLANO foram aceitas implicitamente por "pode seguir":
  conteúdo v1.0 (7.B), Data Attachment com plano B, espírito sem modelo próprio se o build exigir, admin reset desligado
  por padrão, raças só com fonte. Se algum for revisto, atualizar aqui.

## Compatibilidade com o GitHub do usuário
- O build.yml existente descompacta `rezero_magic.zip` e roda `gradle build` em `work/rezero_magic`. O zip novo segue esse formato.
- Mod id continua `rezero_magic`; o jar novo se chama `rezero_magic-1.0.1.jar` (E12; o projeto antigo também tinha um jar 1.0.0, apague-o). O jar antigo (1.0.0) deve ser apagado da pasta mods.

## Próxima etapa exata
- Plano concluído (E0-E12). O que falta é o primeiro build real: o usuário envia o zip ao GitHub, compila e me manda os erros (se houver).
  Depois: corrigir erros de API (lista de arquivos de risco em RELATORIO_FINAL.md item 12), jogar o roteiro de TESTES_ETAPA_12.md e ajustar números.

## Correções pós-build
- 1.0.1 (04/11/2026): 1º build real. Erro: `TrainingService.java:257 isFallFlying()` não existe no Yarn 1.21.11 -> trocado por `isGliding()`. O javac para na fase de símbolos, então podem aparecer novos erros depois deste.
