# Testes da Etapa 2 (para você fazer quando puder)

Compile no GitHub (mesmo processo). Se der X vermelho, me mande o texto do erro.
Arquivos mais prováveis de falhar (APIs de tela do 1.21.11 que não pude conferir): `client/AffinityScreen.java`,
`client/HubScreen.java`, `client/ReZeroModClient.java` (teclas e eventos de conexão) e, da E1, `data/PlayerDataStore.java`.

## Seleção de afinidade
1. Crie um mundo NOVO. Ao entrar, a tela "Escolha sua afinidade" deve abrir sozinha (pode levar um instante, depois do carregamento).
2. Aperte ESC: a tela NÃO deve fechar.
3. Clique em cada um dos 6 cartões: o cartão fica marcado com "> Nome <" e aparecem "Da obra" e "No jogo (adaptação)".
4. O botão "Escolher" só fica ativo depois de selecionar um cartão.
5. Clique em "Escolher": aparece "Você escolheu X. Esta escolha é PERMANENTE..." com "Sim, confirmar" e "Voltar".
   "Voltar" deve voltar aos cartões mantendo o escolhido.
6. Clique em "Sim, confirmar": a tela deve fechar sozinha.
7. Salve e saia, feche o jogo, abra de novo e entre no MESMO mundo: a tela NÃO deve reaparecer.
8. Crie OUTRO mundo novo: a tela deve aparecer de novo (cada mundo tem a sua escolha).

## Hub
9. Aperte K (padrão; muda em Opções > Controles > "Abrir o Hub") dentro do mundo: abre o Hub com seu nome, a afinidade
   escolhida e as duas descrições. "Fechar" fecha.
10. Em um mundo onde você ainda NÃO escolheu, K não deve abrir o Hub (a tela de afinidade tem prioridade).

## Reset de teste (opcional)
11. Em config/rezero_magic.properties troque `allowAdminReset=true`, reinicie o jogo, rode `/rezero admin resetar_afinidade`:
    a tela deve abrir de novo. Depois volte para `false`.

Ainda NÃO existem magias, então nada é bloqueado de fato nesta etapa (o bloqueio por afinidade entra com as magias, na E3).
