# Testes da Etapa 4 (para você fazer quando puder)

Compile no GitHub (mesmo processo). Versão do mod: 0.4.0 (jar `rezero_magic-0.4.0.jar`; apague o jar antigo da pasta mods).
Arquivos mais prováveis de falhar no build: `server/WindEffects.java`, `EarthEffects.java`, `YinEffects.java`, `YangEffects.java`
(nomes de efeitos como StatusEffects.STRENGTH/JUMP_BOOST/ABSORPTION/RESISTANCE/REGENERATION/HASTE/SLOW_FALLING/LEVITATION/WITHER/BLINDNESS,
RegistryEntry<StatusEffect>), `server/SpellEffects.java` e `server/AdminCommands.java` (IntegerArgumentType).

## Comando de teste (para pular níveis)
1. Em `config/rezero_magic.properties` coloque `allowAdminReset=true` e reinicie o jogo.
2. `/rezero admin nivel_canais 20` define o nível 20 (enche a mana) e libera os 5 feitiços da sua afinidade. Volte para `false` depois.
   Ainda sem checagem de operador (API de permissões 1.21.9+ não confirmada): a trava é a config.

## Feitiços novos (nível dos canais necessário)
Vento: Rajada (1) empurra em cone; Lâmina de Vento (3) corte em linha que atravessa; Impulso de Vento (6) lança VOCÊ para frente/cima
(se não mover, me avise: depende de o servidor sincronizar a velocidade do jogador); Vórtice (9) puxa para o centro por 5 s;
Tempestade (14) lança para o alto e fere em área.
Terra: Dona (1) onda de espinhos no chão; Muro de Terra (3) parede de terra que some em 20 s; Raízes (6) prende todos na área;
Pele de Pedra (9) resistência forte, mas lentidão; Terremoto (13) abala o chão ao redor.
Yin: Shamak (1) enfraquece e atrasa o alvo (sem dano); Névoa Sombria (3) área que enfraquece por 6 s; Dreno Vital (6) fere e cura você
(exige alvo na mira); Maldição (9) definhamento + fraqueza + lentidão (exige alvo); Eclipse (12) cega, enfraquece e atrasa ao redor.
Yang: Fortalecer (1) força; Agilidade (3) velocidade + pulo; Escudo Radiante (6) absorção + resistência; Bênção (9) regeneração + cura;
Zênite (12) força, velocidade, resistência e pressa. Beneficiam você e outros jogadores até 8 blocos (em singleplayer, só você).

## O que conferir
3. Em cada afinidade (mundo novo com afinidade diferente, ou reset), o HUD e a aba "Magias" do Hub listam os 5 feitiços da SUA afinidade.
4. Cada feitiço deve ter efeito visível (partículas, som) e o efeito descrito. Efeitos de poção aparecem no canto da tela.
5. Dreno Vital, Maldição (e Prisão de Gelo) sem alvo na mira: "Nenhum alvo na mira.", sem gastar mana.
6. Muro de Terra e Muralha de Gelo só ocupam ar; ao fechar o mundo os blocos temporários são removidos.
7. Zona de Fogo, Vórtice e Névoa Sombria: ficam no ponto visado (se mirar no céu, aparecem longe no ar; limitação conhecida).
8. Conjure um feitiço de outra afinidade: não existe na lista; o servidor também recusa pedidos de ids que não sejam da sua afinidade.
