# Testes da Etapa 5 (para você fazer quando puder)

Compile no GitHub (mesmo processo). Versão do mod: 0.5.0 (jar `rezero_magic-0.5.0.jar`; apague o jar antigo da pasta mods).
Esta etapa mexe com registro de itens/blocos e dados do mundo (a parte de maior risco até agora). Se o jogo NÃO abrir ou o build falhar,
me mande o texto do erro/log. Arquivos mais prováveis de falhar no build: `content/ModBlocks.java` (Blocks.register / Items.register),
`content/ModItems.java` (component DAMAGE, ItemGroupEvents), `content/ModWorldgen.java` (BiomeModifications),
`content/ManaConcentratorBlock.java` (assinatura de onUse). No jogo, erros de JSON aparecem no log como "Couldn't parse" /
"Failed to load" (receitas, loot table, worldgen).

## Itens e blocos
1. No modo criativo: aba Ingredientes tem os 4 cristais (Fragmento, Cristal, Puro, Primordial); aba Ferramentas tem o Receptor de Mana;
   aba Natureza tem o Minério de Cristal de Mana; aba Funcional tem o Concentrador de Mana. Todos devem ter textura (não roxo/preto) e nome.
2. Minério: quebre com picareta de PEDRA ou melhor (com a mão não dropa). Deve dropar 1 a 3 Fragmentos.
3. Geração: só em chunks NOVOS (crie um mundo novo). Procure entre as alturas -60 e 48; o minério brilha levemente. Se nunca aparecer,
   me avise (pode ser o JSON de geração).

## Receitas (mesa de trabalho)
4. 4 Fragmentos -> 1 Cristal. 3 Cristais -> 1 Cristal Puro. 3 Puros + 1 diamante -> 1 Primordial.
5. Receptor: Cristal + barra de ouro + garrafa de vidro (sem forma).
6. Concentrador: fileira de cima 3 Cristais; meio: Cristal, Obsidiana, Cristal; embaixo 3 Pedras.

## Usos
7. Com afinidade escolhida e mana abaixo do máximo, botão direito num cristal: restaura mana (Fragmento 15, Cristal 40, Puro 90,
   Primordial 200, limitado ao máximo) e consome 1 (no criativo não consome). Mana cheia: "Sua mana já está cheia." e não consome.
8. Saturação: usar outro cristal em menos de 5 s mostra "Saturação de mana: aguarde X s".
9. Receptor novo nasce VAZIO. Use o Concentrador: cristal na mão principal, Receptor na outra mão, botão direito no bloco:
   o Receptor ganha +25% do valor do cristal (Fragmento 19, Cristal 50, Puro 113, Primordial 250), até 300. Cheio: "O Receptor já está cheio."
10. Botão direito com o Receptor na mão: devolve a mana guardada (o que couber); a barra de durabilidade do item acompanha a carga
    (cheia = barra cheia). Vazio: mensagem de vazio. Saque tem espera de 3 s.
11. Sem afinidade escolhida, nada disso funciona (mensagem pedindo a afinidade).
12. Hub > aba "Cristais": mostra quantos de cada cristal você tem no inventário, o valor de cada um e, para os Receptores, a quantidade e a
    mana guardada somada.
