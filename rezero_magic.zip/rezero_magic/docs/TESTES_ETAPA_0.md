# Testes da Etapa 0 (para você fazer quando puder)

Esta etapa não adiciona nada visível no jogo. Ela só prepara a base e confirma que o projeto compila.

1. Envie `rezero_magic.zip` ao seu repositório do GitHub (substitui o antigo, mesmo nome).
2. Aba Actions: a execução mais recente deve ficar com check verde. Se ficar com X vermelho, me mande o texto do erro.
3. Baixe o `.jar` (o que NÃO termina em `-sources`). O nome deve ser `rezero_magic-0.1.0.jar`.
4. Na pasta `mods`, APAGUE o jar antigo (`rezero_magic-1.0.0.jar`) e coloque o novo, junto com o Fabric API 1.21.11.
5. Abra o jogo com o perfil Fabric 1.21.11. O jogo deve abrir normalmente.
6. Em "Mods" (se tiver o Mod Menu) ou no `latest.log` procure por: "Re:Zero Magia iniciado (estrutura base)."
   Se essa linha aparecer, o mod carregou.

Resultado esperado: nada novo para jogar ainda. As magias antigas NÃO existem neste projeto novo.
