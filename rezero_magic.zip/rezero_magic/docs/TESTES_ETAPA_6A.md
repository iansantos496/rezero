# Testes da Etapa 6a (para você fazer quando puder)

Compile no GitHub (mesmo processo). Versão do mod: 0.6.0 (jar `rezero_magic-0.6.0.jar`; apague o jar antigo da pasta mods).
Arquivos mais prováveis de falhar no build: `content/ModItems.java` (Item.Settings.sword(ToolMaterial.IRON/DIAMOND/NETHERITE, dano, velocidade)
e o nome ToolMaterial), `content/EquipmentLookup.java`. Se o jogo não abrir, me mande o log; erros de receita aparecem como "Couldn't parse".

## Itens (modo criativo)
1. Aba Combate: 6 espadas (Adaga de Cristal, Espada Curta de Mana, Sabre de Cristal, Espada Longa de Mana, Montante de Mana, Lâmina Primordial).
   Aba Ferramentas: 4 cajados (Aprendiz, Cristal, Puro, Primordial) e 5 acessórios (Anel da Fluência, Talismã da Concentração,
   Pingente de Cristal, Selo da Economia, Amuleto da Ressonância). Todos com textura e nome. As espadas devem se comportar como espadas
   (dano, barra de ataque, varredura, durabilidade) e segurar na mão como espada.
2. Receitas (mesa de trabalho): Adaga = Cristal sobre graveto; Espada Curta = ferro, Cristal, graveto (de cima para baixo);
   Sabre = Cristal, ferro, graveto; Espada Longa = ferro, Cristal Puro, graveto; Montante = 2 colunas (ferro + Puro) e graveto embaixo à esquerda;
   Lâmina Primordial = Primordial, diamante, graveto. Cajados = cristal da raridade em cima e 2 gravetos embaixo (Fragmento, Cristal, Puro, Primordial).
   Acessórios (sem forma): Fluência = Cristal + ouro + lazúli; Concentração = Cristal + ouro + ametista; Pingente = Puro + ouro + linha;
   Economia = Cristal + ouro + redstone; Ressonância = Puro + Cristal + ouro + diamante.

## Efeito na magia (com afinidade escolhida; use /rezero admin nivel_canais para liberar feitiços)
3. Cajado na MÃO PRINCIPAL e acessório na MÃO SECUNDÁRIA (F troca de mão). Bônus: Aprendiz +8% potência; Cristal +15%/-8% custo;
   Puro +25%/-12% custo/-10% conjuração; Primordial +40%/-18%/-20%. Fluência +35% regeneração; Concentração -15% conjuração;
   Pingente +10% potência; Economia -10% custo; Ressonância +6% potência, -5% custo, +15% regeneração. Limites: potência até +100%, custo e
   conjuração até -40%, regeneração até +100%.
4. HUD: o custo do feitiço selecionado mostra o valor JÁ com o cajado/acessório. Sem cajado, volta ao normal.
5. Compare: conjure o mesmo feitiço com e sem cajado; com cajado o dano deve ser maior, o custo menor e a barra de conjuração mais curta.
6. Hub > aba "Equipamento": mostra o cajado e o acessório em uso e os bônus totais; na aba "Magias" custo e tempo já refletem o equipamento.
7. Sem afinidade escolhida, o equipamento não faz nada (não há feitiço para melhorar).

## Fora desta etapa (E6b)
Armaduras (3 conjuntos) e inscrições mágicas não existem ainda. As espadas não têm efeito mágico próprio (são armas comuns com visual do mod).
