# Testes da Etapa 1 (para você fazer quando puder)

Esta etapa ainda não tem tela. Ela cria a base de dados, rede e validação. Os testes são pelo log e pelo comando.

1. Compile no GitHub (mesmo processo). Deve dar check verde. Se der X vermelho, me mande o texto do erro.
   Pontos que mais podem falhar (APIs que não pude conferir): `AttachmentRegistry` / `getAttachedOrCreate`
   (arquivo `data/PlayerDataStore.java`) e o registro de comandos (`server/AdminCommands.java`).
2. Abra um mundo novo. No `latest.log` procure:
   - "Dados do jogador registrados (salvos por mundo)."
   - "Re:Zero Magia iniciado (núcleo: dados por mundo, rede e MagicGate)."
3. Procure na pasta `config` o arquivo `rezero_magic.properties`. Deve ter `allowAdminReset=false`.
4. No jogo, digite `/rezero admin resetar_afinidade`. Deve aparecer a mensagem de que o reset está desligado.
5. (Opcional) Troque para `allowAdminReset=true`, reinicie o jogo e rode o comando de novo: deve aparecer "Afinidade redefinida."
   Volte para `false` depois.
6. Não há como escolher afinidade ainda (a tela é a Etapa 2).

Resultado esperado: o jogo abre sem erro, as duas linhas aparecem no log e o comando responde como descrito.
