# PROGRESSO — Mod Re:Zero (projeto novo)

Última atualização: 31/10/2026

## Estado real
- Parte 1 (planejamento): docs/PLANO.md. Usuário autorizou ("pode seguir") em 31/10/2026.
- Ritmo: UMA etapa por vez (padrão, o usuário não escolheu outro).
- Pasta do projeto: /home/claude/rezero_v2. Zip de entrega: /home/claude/rezero_magic.zip (pasta interna: rezero_magic/).
- Projeto antigo preservado em /home/claude/rezero_magic (não mexer; só a versão 1.2 teve build confirmado).

## Etapas
- E0 Estrutura: FEITA (31/10/2026).
  - Criados: build.gradle, settings.gradle, gradle.properties (versão 0.1.0), wrapper properties, fabric.mod.json,
    lang pt_br/en_us (6 afinidades), ReZeroMod (entrypoint, só log), core/Affinity, core/AffinityRules,
    tools/test_core.sh, tools/core-tests/CoreTests.java, tools/check_static.py, README, docs/TESTES_ETAPA_0.md.
  - Executado AQUI: testes do core (12 ok, 0 falhas) e verificação estática (OK).
  - NÃO executado: compilação com Minecraft (só o GitHub do usuário faz), jogo, logs.
  - Estado dos sistemas: nenhum dos 12 sistemas está implementado ainda. Só existem as regras puras da afinidade (core).
- E1 Núcleo: FEITA (31/10/2026). Mod 0.1.0 -> mesma versão no gradle (sem bump).
  - Criados: data/PlayerMagicData (Codec; só afinidade), data/PlayerDataStore (Data Attachment, ÚNICO ponto de persistência),
    net/ChooseAffinityPayload (C2S), net/PlayerSyncPayload (S2C), net/ModNetworking, server/MagicGate (porta única),
    server/PlayerSync, server/ServerEvents (JOIN e AFTER_RESPAWN), server/AdminCommands, ModConfig (config/rezero_magic.properties),
    client/ReZeroModClient, client/ClientPlayerData, core/AffinityRules.normalizeId, docs/TESTES_ETAPA_1.md.
  - Modificados: ReZeroMod (chamadas de init), fabric.mod.json (entrypoint client), lang pt_br/en_us (2 mensagens), CoreTests.
  - Executado AQUI: testes do core (15 ok, 0 falhas); verificação estática (achou 1 parêntese faltando em AdminCommands, corrigido, OK).
  - NÃO executado: compilação com Minecraft, jogo, persistência real, rede real.
  - Estado real: afinidade tem dados, rede e validação no servidor, mas AINDA NÃO há tela para escolher (E2). Nenhum dos 12 sistemas
    está completo; o Sistema 12 está parcial (regras + dados + validação; falta a tela e o bloqueio nos poderes, que só existem a partir da E3).
  - Pendências conhecidas: (a) comando admin sem checagem de operador (API de permissões 1.21.9+ não confirmada; trava = config
    allowAdminReset=false por padrão); (b) APIs não confirmadas por build: AttachmentRegistry.builder()/getAttachedOrCreate/setAttached,
    CommandRegistrationCallback v2, ClientPlayConnectionEvents.DISCONNECT, PacketCodec.tuple de 1 campo.
- E2 Seleção de afinidade + Hub esqueleto: FEITA (31/10/2026).
  - Criados: core/AffinityPicker (fluxo escolher -> confirmar -> enviar, testável), net/OpenAffinityScreenPayload (S2C),
    client/AffinityScreen (obrigatória, ESC não fecha, 6 cartões, confirmação em 2 passos), client/HubScreen (dados reais: jogador e
    afinidade), docs/TESTES_ETAPA_2.md.
  - Modificados: MagicGate (promptAffinityIfNeeded; reset admin reabre a tela), ServerEvents (JOIN abre a tela se faltar afinidade),
    ModNetworking, ClientPlayerData (pedido de abrir tela), ReZeroModClient (tecla K, abertura segura no tick, fecha ao confirmar),
    lang pt_br/en_us (descrições "Da obra" / "No jogo (adaptação)"), check_static.py (verifica chaves dinâmicas das 6 afinidades),
    PLANO.md (removida afirmação não verificada de que Yin/Yang são raros).
  - Executado AQUI: testes do core (25 ok, 0 falhas) e verificação estática (OK).
  - NÃO executado: compilação, jogo, abertura real das telas, persistência real.
  - Estado real do Sistema 12: tela obrigatória + confirmação + validação no servidor + persistência por mundo IMPLEMENTADOS, NÃO TESTADOS.
    Falta o bloqueio de poderes por afinidade, que só pode existir quando houver poderes (E3 em diante). O Hub tem só informações do jogador
    e afinidade (os demais sistemas ainda não existem, por isso não têm botão).
  - Limitações conhecidas: durante a escolha o jogo NÃO pausa (shouldPause=false) e o jogador pode ser atacado; o cliente só abre a tela
    quando não há outra tela aberta.
- E3 Canais de mana (S10) + framework de magia (S1) + Fogo e Água: FEITA (01/11/2026). Mod 0.1.0 -> 0.3.0 (gradle.properties).
  - Canon pesquisado: só o Od Lagna ("reserva de mana, coração do mundo") foi confirmado. Gate, consumo de mana, exaustão e
    regeneração NÃO foram confirmados: tudo isso é ADAPTAÇÃO de jogo (rotulado em ChannelModel e Spells). Os nomes Goa/Elgoa/Urgoa/Algoa
    seguem o padrão de prefixos El/Ur/Al da obra; o que cada feitiço faz é adaptação. Nomes dos feitiços de Água são de jogo.
  - Core puro novo: ChannelModel (capacidade 100..385, regeneração 1,5..6,25/s, custo, conjuração, potência, XP 20 níveis, exaustão 5 s),
    SpellDef, Spells (10 feitiços: 5 Fogo + 5 Água), CastRules (ordem fixa das verificações).
  - Dados: PlayerMagicData v2 (mana, channel_level, channel_xp; campos ausentes recebem padrão, então mundos da E2 continuam válidos).
  - Rede: CastSpellPayload (C2S), ManaSyncPayload e CastStatePayload (S2C); PlayerSyncPayload agora leva nível e XP.
  - Servidor: SpellService (pedido -> MagicGate.checkCast -> conjuração interrompível por dano -> efeito -> cobra mana/XP/recarga),
    SpellEffects (10 efeitos; gelo temporário e zonas de fogo limpos ao fechar o servidor), WorldLookup, MagicGate.checkCast.
  - Cliente: teclas R/Z/X, SpellHud (mana, canais, feitiço, barra de conjuração), HubScreen com abas Perfil e Magias (dados reais).
  - Executado AQUI: testes do core (55 ok, 0 falhas) e verificação estática (OK; agora checa nomes de feitiços, mensagens de CastRules
    e registro de todos os pacotes).
  - NÃO executado: compilação, jogo, efeitos reais, balanceamento, rede, persistência real.
  - Estado real: Sistema 10 (canais) e Sistema 1 (magia): PARCIAIS. Sistema 1 tem 2 de 6 afinidades (Fogo e Água, não testados);
    Sistema 10 tem nível/mana/regeneração/exaustão/eficiência/controle/potência implementados e não testados (sem a parte de
    "Gate" canônica, sem sobrecarga além da exaustão). Sistema 12: agora o bloqueio por afinidade EXISTE no servidor (CastRules),
    implementado e não testado.
  - Limitações conhecidas: sem comando de teste para pular níveis; Algoa/Elgoa usam raio instantâneo (não projétil); a Muralha de Gelo
    só entra em ar (não substitui blocos); se o jogo cair (crash) a muralha pode ficar no mundo; o reset da recarga ao reabrir é esperado.
  - APIs novas NÃO confirmadas por build: Box.raycast, world.setBlockState(pos,state), BlockState.isOf, DamageSources.onFire,
    Entity.setFireTicks, ParticleTypes.EXPLOSION_EMITTER/HEART/SPLASH/LAVA, Window.getScaledWidth/Height, ClickableWidget.visible/active,
    ServerLifecycleEvents.SERVER_STOPPING, PacketCodec.tuple de 2 e 3 campos (o de 1 campo já era risco da E1).
- E4 Feitiços de Vento, Terra, Yin e Yang: FEITA (01/11/2026). Mod 0.3.0 -> 0.4.0.
  - Core: Spells agora tem 30 feitiços (ids 0..29, 5 por afinidade). Nomes da obra usados: Dona (Terra, verificado) e Shamak (Yin,
    verificado); os demais nomes são de jogo e o que cada feitiço faz é adaptação (rotulado em Spells e nos efeitos).
  - Servidor: SpellEffects virou despachante (Fogo/Água + zonas genéricas FIRE/VORTEX/MIASMA + blocos temporários + placeWall);
    novos WindEffects, EarthEffects, YinEffects, YangEffects. Yang beneficia o conjurador e jogadores até 8 blocos.
    Dreno Vital, Maldição e Prisão de Gelo exigem alvo na mira (recusa sem gastar mana).
  - Comando de teste /rezero admin nivel_canais <1-20> (mesma trava allowAdminReset=false por padrão).
  - Executado AQUI: testes do core (56 ok, 0 falhas) e verificação estática (OK; checa nomes dos 30 feitiços).
  - NÃO executado: compilação, jogo, qualquer efeito, balanceamento.
  - Estado real: Sistema 1 (magia): as 6 afinidades têm 5 feitiços cada, IMPLEMENTADO e NÃO TESTADO; segue PARCIAL só porque as
    interações entre elementos NÃO foram implementadas (não há base canônica confirmada e não quis inventar). Sistema 10: igual à E3.
  - Limitações: Impulso de Vento depende de a velocidade do jogador sincronizar (risco); feitiços de zona mirados no céu aparecem
    longe no ar; Yang só ajuda aliados jogadores (não há aliados NPC).
  - APIs novas NÃO confirmadas: StatusEffects.STRENGTH/JUMP_BOOST/ABSORPTION/RESISTANCE/REGENERATION/HASTE/SLOW_FALLING/LEVITATION/
    WITHER/BLINDNESS, RegistryEntry<StatusEffect> como tipo de parâmetro, IntegerArgumentType, SoundEvents.BLOCK_GRAVEL_BREAK,
    ParticleTypes.HAPPY_VILLAGER/ENCHANT/WITCH (os dois últimos já compilaram no projeto antigo).
- E5 Cristais de mana (S2): FEITA (01/11/2026). Mod 0.4.0 -> 0.5.0.
  - Canon: pesquisa não achou cristais de mana como item canônico (só páginas de outros mundos). TUDO nesta etapa é adaptação de jogo.
  - Core: CrystalRarity (4 raridades: 15/40/90/200 de mana), CrystalRules (restauração, Receptor 300 de capacidade guardado no dano do
    item, Concentrador +25%, saturação 5 s direto e 3 s no saque). 17 testes novos.
  - Conteúdo: itens (4 cristais + Receptor de Mana), blocos (Minério de Cristal de Mana, Concentrador de Mana), loot tables, tags de
    mineração (picareta de pedra), 5 receitas, geração no Overworld (configured/placed feature JSON + BiomeModifications), abas do criativo.
    Texturas 16x16 PROCEDURAIS geradas por tools/gen_assets.py (simples; trocáveis por arte final mantendo os nomes).
  - Servidor: CrystalService (usar cristal, usar Receptor, usar Concentrador; exige afinidade escolhida; saturação).
  - Hub: aba "Cristais" com contagem real do inventário.
  - Executado AQUI: testes do core (73 ok, 0 falhas); verificação estática (OK; agora confere modelo/textura/definição/tradução/loot
    de cada item e bloco e valida todos os JSON).
  - NÃO executado: compilação, jogo, geração, receitas, texturas no jogo.
  - Estado real do Sistema 2: PARCIAL. Implementado e não testado: minério, 4 raridades, extração com ferramenta mínima, uso direto,
    Receptor (armazenamento), Concentrador (carrega item), saturação. NÃO implementado: consumo de cristais em fabricação de equipamentos e
    tinta de inscrição (entram em E6 com equipamentos/inscrições), raridades diferentes por bioma (só um minério gera; as raridades
    maiores só por fabricação), Fortuna/Toque Suave no minério.
  - APIs novas NÃO confirmadas por build: Blocks.register(key, factory, settings) e Items.register(key, factory, settings)/(Block),
    Item.Settings.component(DataComponentTypes.DAMAGE,...), Item.use -> ActionResult, Block.onUse público, BlockSoundGroup.AMETHYST_BLOCK,
    MapColor.STONE_GRAY/PURPLE, ItemGroupEvents (pacote net.fabricmc.fabric.api.itemgroup.v1), BiomeModifications/BiomeSelectors,
    ItemStack.getDamage/setDamage/decrement, PlayerEntity.isCreative, formato JSON de receitas 1.21.2+ (ingredientes em texto) e de worldgen.
- E6a Equipamentos (S5), parte 1: FEITA (01/11/2026). Mod 0.5.0 -> 0.6.0.
  - Canon: nada verificado sobre equipamentos; tudo adaptação de jogo.
  - Core: Catalyst (4 cajados), Charm (5 acessórios), CastModifiers, EquipmentRules (soma com limites), overloads em ChannelModel/CastRules.
    9 testes novos (82 no total).
  - Conteúdo: 6 espadas (propriedades de espada do jogo base com ToolMaterial vanilla), 4 cajados catalisadores (mão principal),
    5 acessórios (mão secundária), 15 receitas, texturas procedurais (tools/gen_assets.py), EquipmentLookup.
  - Integração: SpellService/MagicGate aplicam potência, custo, tempo de conjuração e regeneração do equipamento no SERVIDOR;
    HUD e Hub mostram os mesmos números (lidos do item na mão do cliente, só exibição). Hub ganhou a aba "Equipamento".
  - Executado AQUI: testes do core (82 ok, 0 falhas); verificação estática (OK; confere assets, receitas JSON e traduções).
  - NÃO executado: compilação, jogo, receitas, equilíbrio.
  - Estado real do Sistema 5: PARCIAL. Implementado e não testado: 6 armas corpo a corpo, 4 cajados, 5 acessórios (slot = mão secundária,
    escolha de projeto porque o jogo base não tem slot de acessório). NÃO implementado: 3 conjuntos de armadura (API de armadura do
    1.21.11 não confirmada), armas mágicas com efeito próprio, manutenção/reparo com cristal, aprimoramento por níveis.
    Meta do plano (10 armas): 6 espadas + 4 cajados = 10 implementadas.
  - APIs novas NÃO confirmadas: Item.Settings.sword(ToolMaterial, float, float), ToolMaterial.IRON/DIAMOND/NETHERITE,
    Item.Settings.maxCount, PlayerEntity.getMainHandStack/getOffHandStack, ItemGroups.COMBAT, parent item/handheld.
- E6b Vestes (S5) + Inscrições mágicas (S8): FEITA (01/11/2026). Mod 0.6.0 -> 0.7.0.
  - Canon: nada verificado; tudo adaptação de jogo.
  - Core: RobeSet/RobePiece (3 conjuntos x 4 peças, bônus por peça e de conjunto completo), Inscription (12 em 4 categorias, 3 espaços),
    InscriptionRules (gravar/remover/sanear/máscara), EquipmentRules estendido (tudo junto, com os mesmos limites). 19 testes novos
    (101 no total).
  - Conteúdo: 12 peças vestíveis (EQUIPPABLE + definição de equipamento em JSON + texturas vestidas procedurais), Tinta de Cristal,
    Mesa de Inscrição (bloco; abre o Hub na aba Marcas), receitas, tags de mineração.
  - Servidor: InscriptionService (gravar/remover exigem mesa a até 4 blocos, nível dos canais, tinta, afinidade; efeitos passivos a cada
    segundo); SpellService soma cajado + acessório + vestes + marcas. Dados: PlayerMagicData v3 (lista de marcas). Rede: InscribePayload
    (C2S), OpenHubPayload (S2C), PlayerSyncPayload com máscara das marcas.
  - Hub: abas agora são 5 (Perfil, Magias, Cristais, Equip., Marcas).
  - Executado AQUI: testes do core (101 ok, 0 falhas); verificação estática (OK; confere assets, textura vestida, equipamento JSON,
    traduções e mensagens das 12 marcas).
  - NÃO executado: compilação, jogo, vestes no corpo, receitas, equilíbrio.
  - Estado real do Sistema 5: PARCIAL. Implementado e não testado: 6 espadas, 4 cajados, 5 acessórios, 3 conjuntos de veste (SEM proteção
    física: só bônus mágico). NÃO implementado: proteção física das vestes, armas com efeito mágico próprio, reparo com cristal, aprimoramento.
  - Estado real do Sistema 8: PARCIAL. Implementado e não testado: 12 marcas, 4 categorias, mesa, tinta de cristal, custo/nível, limite de 3.
    DESVIO do plano: as marcas ficam NO JOGADOR, não em armas/armaduras (item bound exigiria registrar um componente de item novo, API não
    confirmada). NÃO implementado: combinações especiais entre marcas, marcas elementais por afinidade.
  - APIs novas NÃO confirmadas: EquippableComponent.builder(EquipmentSlot).model(RegistryKey<EquipmentAsset>).build(),
    DataComponentTypes.EQUIPPABLE, EquipmentAssetKeys.REGISTRY_KEY, pacote net.minecraft.item.equipment, LivingEntity.getEquippedStack,
    StatusEffectInstance(entry, dur, amp, ambient, particles, icon), StatusEffects.FIRE_RESISTANCE/WATER_BREATHING, ButtonWidget.setMessage,
    formato do JSON de equipamento (assets/<ns>/equipment) e caminho das texturas vestidas (textures/entity/equipment/humanoid[_leggings]/).
- E7 a E12: pendentes (ver PLANO.md seção 12).

## Decisões do usuário
- Do zero. Uma afinidade só (sem troca no jogo normal). Português do Brasil. Alvo: singleplayer, servidor como autoridade.
- Usuário não testa entre as etapas. Esforço médio.
- Autorizou o plano; as 5 pendências do PLANO foram aceitas implicitamente por "pode seguir":
  conteúdo v1.0 (7.B), Data Attachment com plano B, espírito sem modelo próprio se o build exigir, admin reset desligado
  por padrão, raças só com fonte. Se algum for revisto, atualizar aqui.

## Compatibilidade com o GitHub do usuário
- O build.yml existente descompacta `rezero_magic.zip` e roda `gradle build` em `work/rezero_magic`. O zip novo segue esse formato.
- Mod id continua `rezero_magic`; o jar novo se chama `rezero_magic-0.7.0.jar` (E6b). O jar antigo (1.0.0) deve ser apagado da pasta mods.

## Próxima etapa exata
- E7: treinamento/evolução (S6) e técnicas de combate (S9): 5 atributos de treino (ex.: Mana, Resistência, Agilidade, Força, Foco) que
  evoluem pelo USO (golpes, corrida, magia), com pontos e níveis salvos no PlayerMagicData; 15 técnicas de combate (ativas com custo de
  mana/estamina e recarga, ligadas às espadas/armas) e passivas. Mesma arquitetura: core puro testado + MagicGate + Hub. Pesquisar canon
  (Esgrima/treino de Subaru/Reinhard etc. SEM personagens jogáveis nem Retorno por Morte) antes e rotular adaptação.
