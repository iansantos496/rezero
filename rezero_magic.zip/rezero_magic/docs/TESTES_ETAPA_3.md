# Testes da Etapa 3 (para você fazer quando puder)

Compile no GitHub (mesmo processo). Versão do mod: 0.3.0 (jar `rezero_magic-0.3.0.jar`; apague o jar antigo da pasta mods).
Se der X vermelho, me mande o texto do erro. Arquivos mais prováveis de falhar (APIs que não pude conferir sem compilar):
`server/SpellEffects.java` (dano, blocos, partículas), `server/SpellService.java`, `client/SpellHud.java`, `client/HubScreen.java`,
`data/PlayerMagicData.java` (Codec com 5 campos) e, das etapas anteriores, `data/PlayerDataStore.java`.

## Teclas (Opções > Controles > "Re:Zero Magia")
R conjura o feitiço selecionado, Z feitiço anterior, X próximo feitiço, K abre o Hub.

## Mana, canais e HUD
1. Em mundo com afinidade escolhida, o canto superior esquerdo mostra: barra de mana (azul), "Mana: 100 / 100", "Canais nv 1 (0/100 XP)"
   e o feitiço selecionado com o custo.
2. Aperte R: um feitiço do nível 1 é conjurado (Fogo: Goa; Água: Lança de Gelo). A mana cai e volta devagar (1,5 por segundo no nível 1).
3. Gaste toda a mana: aparece "Mana esgotada..." e a barra fica vermelha por 5 s, sem regenerar e sem poder conjurar.
4. Cada feitiço dá XP dos canais (metade da mana gasta, mínimo 2). Ao subir de nível: mensagem, som, mais mana máxima e novos feitiços.
5. Salve, saia e entre de novo: mana, nível e XP devem continuar iguais (as recargas zeram, é esperado).

## Feitiços (nível dos canais necessário)
Fogo: Goa (1) raio de fogo; Elgoa (3) explosão em área; Urgoa (6) leque de chamas curto; Zona de Fogo (9) poça de chamas por 6 s;
Algoa (14) explosão enorme, muito cara.
Água: Lança de Gelo (1) raio + lentidão; Onda Gélida (3) anel de frio ao redor; Muralha de Gelo (6) parede de gelo que some em 15 s;
Cura Aquática (9) cura 4 corações; Prisão de Gelo (12) prende o alvo na mira.
6. Para testar feitiços de nível alto sem esperar: não há comando de teste nesta etapa (não inventei atalho). Suba jogando ou me peça um
   comando de teste restrito pela mesma config do reset.
7. Use um zumbi/vaca como alvo. Dano e fogo devem aparecer; o fogo/gelo NÃO destrói blocos (só a Muralha coloca gelo temporário).
8. Conjuração com tempo (barra laranja no centro): se você levar dano durante ela, deve aparecer "Conjuração interrompida" e nada é gasto.
9. Cura Aquática com vida cheia e Prisão de Gelo sem alvo: devem recusar sem gastar mana.

## Afinidade bloqueia poderes
10. Só aparecem na lista (HUD e Hub) os feitiços da SUA afinidade. As outras 4 afinidades ainda não têm feitiços (E4); com elas, o HUD
    mostra mana e canais, mas nenhum feitiço, e R não faz nada. Isso é esperado nesta etapa.

## Hub > aba "Magias"
11. Mostra nível dos canais, XP, mana, regeneração e bônus (custo/conjuração/potência) e os 5 feitiços da afinidade: os bloqueados
    aparecem cinza com o nível exigido; "Selecionar" só fica ativo nos liberados.
