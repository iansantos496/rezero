# PLANO TÉCNICO — Mod "Re:Zero" para Minecraft Java 1.21.11 (Fabric)

Status: PARTE 1 (planejamento). Nenhum código do projeto novo foi escrito ainda.
Decisões do usuário: projeto do zero em pasta nova; UMA afinidade por jogador; texto em português do Brasil;
alvo de testes = singleplayer (servidor continua autoridade, então multiplayer fica viável); o usuário não testa
entre as etapas (só no final ou quando puder). Conteúdo da obra limitado ao final do Arco 9.
Regras fixas: sem personagens da obra; sem Retorno da Morte nem equivalente; sem funções decorativas; sem
dados falsos no Hub; separar canon de adaptação; nunca afirmar teste/compilação que não ocorreu.

---------------------------------------------------------------------------------------------------------

## 1. Diagnóstico da estrutura atual
- Projeto NOVO (`/home/claude/rezero_v2`): só contém `docs/` com os dois prompts. Não há código.
- Projeto ANTIGO (`/home/claude/rezero_magic`) fica intocado como referência/backup. Contém 19 arquivos Java
  e se declara versão 1.4.0 no gradle.properties. Eu entreguei até a versão 1.3. A 1.4.0 foi alterada no disco
  por fora desta conversa; NÃO verifiquei se ela compila. Só a versão 1.2 teve build confirmado (usuário enviou
  o .jar gerado no GitHub; contém Progression, Fx, ManaSyncPayload).
- Não existe ambiente de build local funcional: o sandbox bloqueia Maven do Fabric, Mojang, Gradle e GitHub raw.

## 2. Tecnologias e versões (verificadas)
- Minecraft Java 1.21.11; modloader Fabric (loader 0.18.4); Fabric API 0.141.1+1.21.11;
  Loom 1.14-SNAPSHOT; mappings Yarn 1.21.11+build.4; Java 21; Gradle 9.2.1 (no GitHub Actions).
- Prova de compilação: build do GitHub Actions gerou jar para a versão 1.2 com essas versões.
- Build/entrega: o usuário envia o zip ao GitHub; workflow `build.yml` (setup-java 21 + setup-gradle 9.2.1)
  roda `gradle build` e publica o .jar como artefato.
- Dependências do mod: só Fabric Loader + Fabric API. Nada além disso.

## 3. Funcionalidades que já existem
No projeto novo: nenhuma. No antigo (referência, 1.2 confirmada): rede C2S/S2C com payloads, mana, nível/XP,
3 magias com partículas, HUD, teclas, tela com botões comuns, comando de teste. Reaproveito PADRÕES de API que
compilaram (não o código), por decisão do usuário de recomeçar.

## 4. Problemas encontrados
- Salvamento antigo era global (arquivo em config/), não por mundo -> não serve.
- Afinidade antiga era trocável por pontos -> proibido pela regra do Sistema 12.
- Comandos de teste antigos (nivel/resetar) sem restrição de permissão -> precisam ser restritos.
- Escopo antigo com 3-6 magias; o prompt exige conteúdo variado em 12 sistemas.

## 5. Limitações técnicas (honestas)
1. NÃO consigo compilar nem rodar o jogo aqui. Todo "teste de jogo" do prompt (jogo inicia, logs, telas, persistência,
   multiplayer) só pode ser feito pelo usuário. Relatórios marcarão "Implementado, não testado" até haver evidência.
2. Não tenho os fontes/mappings do Minecraft aqui: nomes de API são escritos de memória e validados só pelo build do usuário.
   Mitigação: usar apenas APIs que já compilaram; isolar o resto e listar como risco.
3. Arte: texturas/modelos finais não são possíveis. Vou gerar texturas simples por script (PNG). Isso é arte provisória
   do ponto de vista visual, mas os itens/blocos terão mecânicas reais (não é "placeholder de sistema").
4. Canon: as páginas de wiki que consegui ler cobrem pouco (ver seção 14). Só afirmo como canon o que foi confirmado.
5. Lógica de jogo "pura" (custos, progressão, validações) será escrita SEM classes do Minecraft, para poder compilar e
   testar aqui com javac. Isso é o único teste executável que existe neste ambiente.

## 6. Arquitetura recomendada
Pacotes (com.rezero.mod):
- `core/` : lógica pura (sem Minecraft) — fórmulas, regras de afinidade, progressão, custos, validadores. TESTÁVEL AQUI.
- `data/` : PlayerMagicData (um único objeto por jogador) + Codecs + registro do Data Attachment.
- `net/` : payloads C2S (intenções) e S2C (snapshots), registro e handlers.
- `server/` : MagicGate (porta única de validação), serviços de cada sistema, eventos de tick/dano.
- `client/` : teclas, HUD, telas (Hub e sub-telas), receptor de snapshots.
- `content/` : registro de itens, blocos, entidades, efeitos; definições de magias/técnicas/etc (em código, por ID estável).
- `world/` : geração dos cristais (arquivos JSON de worldgen em data/).
Decisões:
- Persistência POR MUNDO E POR JOGADOR via Fabric Data Attachment API (`AttachmentRegistry` persistente com Codec),
  anexado ao jogador, salvo junto aos dados do jogador no próprio mundo. Copiado na morte/respawn. Substitui o arquivo
  global antigo. Risco: nomes exatos da API (ver riscos). Plano B: arquivo por jogador na pasta do mundo.
- UM objeto `PlayerMagicData` com sub-blocos: afinidade, raça, nível/XP, canais de mana, treinamento, técnicas,
  espíritos/contratos, proteções, inscrições conhecidas, transformação (estado/recarga), cristais/essências.
  Cada sistema lê/escreve só o seu sub-bloco; ligações entre sistemas passam por consultas (ex.: `affinity()`),
  nunca por cópia de dados -> sem duplicação e sem conflito de salvamento.
- Servidor é a única autoridade. Cliente envia apenas INTENÇÕES (ex.: "lançar magia X"); o servidor valida tudo.
- Sincronização por SNAPSHOT por sistema, enviado só quando o dado muda (flag "sujo") e no login. Nada por tick,
  exceto mana (a cada ~10 ticks, só se mudou).
- Conteúdo definido em código por ID textual estável (ex.: `fire.goa`), com tabela de requisitos; facilita validar
  referências cruzadas por script.
- Nenhum loop global por jogador sem necessidade; efeitos contínuos (espírito, transformação) usam lista de ativos.

## 7. Os 12 sistemas — o que será implementado e como integra
Metas de conteúdo v1.0 estão na seção 7.B (precisam de autorização, pois o prompt proíbe simplificar sem aval).

### 7.A Descrição
**S1 Magia elemental.** Registro de feitiços por afinidade, com categoria (ataque / defesa / utilidade), tier,
custo de mana, tempo de conjuração (barra de canalização, interrompível por dano), alcance, área, cooldown e consequências.
Cada elemento terá identidade mecânica distinta (adaptação, baseada nos domínios que li na wiki):
Fogo = dano em área e dano ao longo do tempo; Água = controle, gelo e cura leve; Vento = deslocamento, empurrão, projéteis
rápidos e mobilidade; Terra = defesa, barreiras e armadilhas; Yin = debuffs/controle à distância (Mãos Invisíveis entra aqui);
Yang = buffs/suporte. Interações entre magias (ex.: Fogo sobre gelo derrete; Vento espalha fogo) com regras fixas.
Integra: afinidade (acesso), canais (eficiência/limite), espíritos (potencializam), inscrições (modificam), treino (nível).
**S2 Cristais de mana.** Blocos de minério (geração em cavernas/biomas por raridade), itens-cristal em 4 raridades, extração
com ferramenta mínima, armazenamento (item "recipiente de cristal" que guarda mana e recarrega o jogador), consumo em
fabricação (equipamentos, tinta de inscrição), aprimoramento e mecanismo (bloco "concentrador" que carrega itens).
Integra: inscrições (tinta), equipamentos (insumo), canais (recarga limitada, com efeito de "saturação" para evitar abuso).
**S3 Espíritos.** Tipos por elemento (6), com temperamento diferente (afeto por tipo de ação do jogador). Encontro: espíritos
selvagens (entidade/evento no mundo) e contrato via ritual (itens + condições). Compatibilidade: depende da afinidade do jogador
e do nível de canais. Um contrato por vez no v1 (limite). Vínculo evolui por tempo juntos e uso; custo contínuo de mana (reserva).
Habilidades: passivos e ativos próprios + amplificação da magia da afinidade correspondente. Representação visual: ver risco R4.
**S4 Proteções Divinas.** Conjunto de proteções com condições de aquisição explícitas (marcos, feitos, nível, raça), raridade,
passiva e/ou ativa, e limite de quantidade por jogador. Nenhuma é sorteada sem critério. Nada além de efeitos equilibrados.
Integra: combate (reação a dano/situação), sobrevivência, canais (algumas ativas gastam mana).
**S5 Equipamentos e armas especiais.** Categorias: espada, lança, adaga, arco e cajado/catalisador; armaduras (conjuntos com
bônus por peça), acessórios (slot via itens equipáveis controlados por dados do jogador). Raridades, atributos reais
(via modificadores de atributo do Minecraft), durabilidade com manutenção (reparo com cristal), aprimoramento por níveis.
Integra: inscrições (slots), técnicas (armas habilitam técnicas), cristais, canais (catalisador melhora eficiência).
**S6 Treinamento e evolução.** Atributos do jogador (Vigor, Força, Agilidade, Foco, Controle de mana) que evoluem por USO
(correr, lutar, conjurar) e por TREINO ativo (sessões em blocos/itens de treino com rendimento decrescente e fadiga).
Limite por nível/raça; treino em excesso gera fadiga (penalidade temporária). Integra: canais, técnicas, raças (tetos), equipamentos (requisitos).
**S7 Raças.** Escolha única na criação (junto à tela inicial) entre raças que eu conseguir sustentar com canon (ver seção 14).
Cada uma com atributos iniciais, vantagem, limitação e habilidade racial; compatibilidades com espíritos/afinidades.
**S8 Inscrições.** Símbolos descobertos (por estudo de item/estrutura/XP) e aprendidos; categorias (reforço, elemental, utilidade,
proteção); aplicadas em arma/armadura/acessório via mesa de inscrição (bloco) consumindo tinta de cristal; combinações com
compatibilidade e risco (falha pode danificar o item); domínio aumenta com uso. Dados guardados no próprio item (componente de dados).
Integra: equipamentos, cristais, magia (inscrição elemental ativa efeito do elemento da afinidade).
**S9 Técnicas de combate.** Estilos (arma de uma mão, lança, adaga, desarmado, arco), técnicas com custo de stamina (barra própria),
ataques carregados, esquiva (dash com janela de invulnerabilidade curta), contra-ataque (janela após bloquear/esquivar), combos
(sequência de cliques) e árvore de aprendizado com requisitos (treino, arma, nível). Integra: equipamentos, treino, canais (técnicas imbuídas).
**S10 Canais de mana.** Capacidade, regeneração, eficiência (reduz custo), controle (reduz tempo de conjuração/variação),
circulação (atividade que aumenta regen temporariamente), sobrecarga (acima do limite -> dano e bloqueio), desenvolvimento por
treino. Substitui a "mana simples" antiga. Integra: tudo que consome mana.
**S11 Transformações.** Estados temporários com condições (ex.: vida baixa, item/espírito, nível de canais), alteração de
atributos, resistências, velocidade, habilidades especiais, duração, recarga longa, efeito colateral ao terminar (exaustão).
Visual: partículas e efeito de tela; modelo do jogador não muda no v1. Integra: raças, magia, espíritos e combate.
**S12 Seleção de afinidade.** Ver seção 11.

### 7.B Metas de conteúdo v1.0 (PEDIDO DE AUTORIZAÇÃO)
Magias: 5 por afinidade (30). Cristais: 4 raridades + 3 usos de mecanismo. Espíritos: 6 tipos (1 por elemento). Proteções: 8.
Equipamentos: 10 armas (2 por categoria), 3 conjuntos de armadura, 5 acessórios. Raças: 4–5 (as sustentáveis por canon).
Inscrições: 12 símbolos em 4 categorias. Técnicas: 15 (3 por estilo). Transformações: 4. Atributos de treino: 5.
Se quiser mais conteúdo, isso entra na Etapa 13 (expansão), depois que a base compilar.

## 8. Integrações necessárias (matriz resumida)
Afinidade -> S1, S3, S10, S11, S6. Canais -> S1, S3, S8 (inscrição elemental), S9 (técnicas imbuídas), S11.
Treino -> S10, S9, S5 (requisitos), S7 (tetos). Raça -> S6, S3, S4, S11. Espíritos -> S1, S10, S11.
Cristais -> S5, S8, S10 (recarga). Inscrições -> S5 (+ afinidade). Equipamentos -> S9, S10 (catalisador).
Proteções -> S9 (reações), S10, S11. Hub -> todos (somente lê dados reais).
Regra: dependência em UMA direção (dados <- serviços <- Hub); nenhum sistema escreve em outro; eles trocam por consultas
no `PlayerMagicData` e eventos internos simples.

## 9. Planejamento do Hub
- Interface central (tecla própria), SEM construção física. Tela inicial = resumo real do jogador (nome, raça, afinidade, nível,
  mana/canais, pontos) + botões para sub-telas.
- Regra anti-decoração: um botão/aba só aparece quando o sistema correspondente está implementado e alimentado por dados reais.
  Sub-telas: Magia, Canais, Treinamento, Espíritos, Proteções, Equipamentos, Inscrições, Técnicas, Raça, Transformações, Informações.
- Tela feita com botões padrão do Minecraft e texto (sem texturas), com layout relativo ao tamanho da janela e rolagem onde necessário.
  Mouse e teclado. Escala por `width/height` para resoluções diferentes.

## 10. (reservado — ver 11)

## 11. Planejamento da seleção de afinidade (Sistema 12)
1. Dado: `affinity` (nulo até escolher) em PlayerMagicData; flag `affinityLocked` verdadeira após confirmar.
2. Login (servidor): se `affinity` é nulo -> envia OpenAffinityScreen; a tela não fecha com ESC; reenviada a cada login até confirmar.
3. Tela: 6 cartões (Fogo, Água, Vento, Terra, Yin, Yang) com descrição; selecionar + botão CONFIRMAR (confirmação obrigatória).
4. C2S `ChooseAffinity(id)`: servidor valida (id válido, ainda sem afinidade, jogador vivo e conectado) e grava. Qualquer outro caso é ignorado.
5. `MagicGate.canUse(player, ability)` é a ÚNICA porta de uso/aprendizado/ativação: recusa se a afinidade da habilidade != afinidade do jogador
   ou se ainda não escolheu. Chamada em: conjuração, aprendizado, ativação de item mágico, inscrição elemental, espírito, desbloqueio de nó.
6. Sem rota de troca no jogo normal. Redefinição administrativa só por comando restrito a operador e, por padrão, DESLIGADA em arquivo
   de configuração (`allowAdminReset=false`). Cliente nunca decide nada.
7. Persistência: Data Attachment por jogador/mundo; sobrevive a fechar/abrir o jogo; mundos diferentes = dados diferentes.
Decisão técnica documentada: afinidade única (decisão do usuário). Yin e Yang são escolhíveis como as demais (adaptação). Não verifiquei
em fonte se Yin/Yang são raros na obra, então o mod NÃO afirma isso na interface; o equilíbrio deles virá de poderes mais restritivos e custos.

## 12. Estratégia de implementação por etapas (cada etapa deixa o projeto coerente e compilável em tese)
- E0 Estrutura: gradle, fabric.mod.json, workflow build.yml, lang pt_br, módulo `core` + testes locais com javac.
- E1 Núcleo: PlayerMagicData + Attachment + payloads base + MagicGate (afinidade) + comando admin restrito.
- E2 Seleção de afinidade (tela obrigatória) + Hub esqueleto (só Informações/Afinidade com dados reais).
- E3 Canais de mana (S10) + framework de magia + Fogo e Água completos (S1 parcial).
- E4 Magia: Vento, Terra, Yin, Yang + interações entre magias.
- E5 Cristais (S2): blocos, geração, itens, recipiente, concentrador.
- E6 Equipamentos (S5) + Inscrições (S8).
- E7 Treinamento (S6) + Técnicas de combate (S9).
- E8 Espíritos (S3).
- E9 Proteções Divinas (S4) + Raças (S7).
- E10 Transformações (S11).
- E11 Hub final (todas as sub-telas) + auditoria de integrações.
- E12 Balanceamento + conteúdo restante + relatório final.
Ao fim de cada etapa: atualizo PROGRESSO.md, rodo as verificações estáticas, gero zip e envio.

## 13. Estratégia de testes
Executáveis AQUI: (a) compilar e testar o módulo `core` (fórmulas, afinidade, progressão, custos, balanceamento numérico);
(b) scripts estáticos: JSON válido, chaves de tradução, IDs referenciados existem, equilíbrio de chaves/parênteses, imports não usados,
registro duplicado de IDs, receitas apontando para itens existentes.
SÓ O USUÁRIO consegue: compilar com Minecraft (GitHub), abrir o jogo, ver logs, telas, persistência, multiplayer.
Cada etapa gera `TESTES_ETAPA_N.md` (checklist objetivo para o usuário). Nenhum item é marcado "testado" sem evidência do usuário.

## 14. Riscos e conflitos
- R1 Compilação: APIs de 1.21.9+ mudaram (input, telas, comandos/permissões). Mitigação: só APIs já compiladas; resto isolado e listado.
- R2 Data Attachment: nomes exatos da API podem diferir; plano B = arquivo por jogador na pasta do mundo.
- R3 Mundo: geração de minério via JSON de worldgen (formato 1.21.x) — erro de formato não é detectado sem o jogo.
- R4 Espíritos: entidade com modelo próprio é a parte mais arriscada. Plano: v1 usa entidade com renderizador simples ou espírito como
  "companheiro de partículas" ligado ao jogador; decisão final na E8 conforme o build. O sistema (contrato, vínculo, habilidades) é real nos dois casos.
- R5 Itens/modelos: em 1.21.4+ os modelos de item usam definição em `assets/<ns>/items/`; erro só aparece ao rodar.
- R6 Escopo: 12 sistemas + Hub é muito grande; sem teste intermediário, erros se acumulam. Mitigação: etapas coerentes, núcleo testável aqui.
- R7 Canon: informação limitada (abaixo). Evitar inventar; marcar adaptação.
- R8 Permissões: a API de permissão de comandos mudou na 1.21.9; o comando admin pode precisar de ajuste.

### Canon verificado nesta sessão (fontes lidas)
- Seis atributos: Fogo (火, incantação Goa), Água (水; domínios: vida/cura), Vento (風; Huma/Fura), Terra (土; Dona), Yin (陰; Shamak; debuffs),
  Yang (陽; buffs). Força do feitiço sobe com prefixos El, Ur, Al. Fonte: página "Magic" da Re:Zero Wiki (revisão antiga).
- O Arco 9 (web novel) = "Light of the Nameless Star" (名も無き星の光), segue o Arco 8 (Vincent Vollachia). Fonte: página "Arc 9" da wiki.
  ATENÇÃO: é um arco recente (2024–2025). Pontos do Arco 9 serão evitados; usarei o que é estabelecido bem antes.
### NÃO verificado (não afirmo como canon; vira "adaptação" até confirmar)
- Detalhes de Gate/Od/Mana, regras de contrato de espírito, lista de Proteções Divinas e suas condições, lista exata de espécies.
  As fontes que consegui abrir não cobriam isso. Antes de implementar cada sistema vou pesquisar de novo e só marcar canon com fonte.
