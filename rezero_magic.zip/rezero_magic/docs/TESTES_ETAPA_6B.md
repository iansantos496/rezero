# Testes da Etapa 6b (para você fazer quando puder)

Compile no GitHub (mesmo processo). Versão do mod: 0.7.0 (jar `rezero_magic-0.7.0.jar`; apague o jar antigo da pasta mods).
Esta etapa tem a API MENOS confirmada até agora (vestes). Arquivo mais provável de falhar no build: `content/ModItems.java`
(`EquippableComponent.builder(slot).model(chave)`, `EquipmentAssetKeys.REGISTRY_KEY`, pacote `net.minecraft.item.equipment`).
Se falhar, me mande o erro: o plano B é trocar as vestes por peças de armadura do jogo base (só com o bônus mágico por cima).
No jogo, erros de receita/JSON aparecem no log como "Couldn't parse".

## Vestes (3 conjuntos x 4 peças, sem proteção física)
1. Aba Combate do criativo: Capuz/Túnica/Calças/Botas do Aprendiz (couro), de Cristal (Fragmentos) e Puros (Cristais Puros).
   Devem ter ícone e poder ser VESTIDAS (clique direito ou arrastar no slot de armadura) e aparecer no corpo com a cor do conjunto
   (marrom, azul, roxo com listras). Se aparecerem sem textura/invisíveis no corpo, me avise (caminho das texturas vestidas).
2. Bônus (por peça / conjunto de 4): Aprendiz +5% regeneração por peça, +5% potência e +10% regen no conjunto;
   Cristal +3% potência e -2% custo por peça, -5% conjuração e +15% regen no conjunto; Puro +5% potência, -3% custo e +5% regen por peça,
   +10% potência, +10% conjuração mais rápida e +20% regen no conjunto. Peças de conjuntos diferentes não formam conjunto.
3. Hub > "Equip.": mostra o cajado, o acessório, quantas peças de cada conjunto você veste e os bônus totais (os mesmos do servidor).
   Limites: potência até +100%, custo e conjuração até -40%, regeneração até +100%.

## Mesa de Inscrição, tinta e marcas
4. Tinta de Cristal: 2 Fragmentos + saco de tinta + garrafa de vidro (sem forma). Mesa: linha de cima Cristal, Tinta, Cristal; depois duas
   linhas de tábuas de carvalho (as do meio e as de baixo, com buraco no centro da última). A mesa acende levemente.
5. Botão direito na mesa abre o Hub na aba "Marcas" (só com afinidade escolhida). Gravar e remover exigem uma mesa a até 4 blocos.
6. 12 marcas em 4 categorias (use < > para trocar de categoria): Poder (Força, Foco, Voraz), Economia (Frugalidade, Fonte, Equilíbrio),
   Defesa (Pedra, Ígnea, Vitalidade), Utilidade (Vento, Salto, Submersa). Custo de tinta 2/3/4 e nível dos canais 1/5/10 por faixa
   (use /rezero admin nivel_canais 10 com allowAdminReset=true). Máximo de 3 marcas ao mesmo tempo.
7. Gravar gasta a tinta (no criativo não gasta). Sem tinta, sem nível, sem mesa, cheio ou repetida: mensagem de recusa no HUD e nada muda.
8. Efeitos: marcas de Poder/Economia mudam os números de feitiço (veja o custo no HUD); Pedra/Ígnea/Vento/Salto/Submersa aplicam o efeito
   de poção correspondente (ícone no canto); Vitalidade só regenera quando a vida está abaixo de 40%. Ao remover, o efeito some em ~3 s.
9. As marcas ficam salvas no mundo (saia e entre de novo). Elas ficam NO JOGADOR, não no item (desvio do plano, explicado no Hub).
10. Morrer e renascer mantém as marcas (os dados são copiados na morte).
