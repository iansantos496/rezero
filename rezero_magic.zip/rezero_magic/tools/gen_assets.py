#!/usr/bin/env python3
"""Gera as texturas 16x16 (procedurais) e os JSON de assets/dados dos itens e blocos da E5.
Rode a partir da raiz do projeto: python3 tools/gen_assets.py
As texturas são simples de propósito (formas e cores geradas por código); podem ser trocadas por arte final depois,
mantendo os mesmos nomes de arquivo."""
import json
import random
from pathlib import Path

from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parent.parent
RES = ROOT / "src/main/resources"
ASSETS = RES / "assets/rezero_magic"
DATA = RES / "data/rezero_magic"
NS = "rezero_magic"

ITEMS = ["mana_crystal_fragment", "mana_crystal", "mana_crystal_pure", "mana_crystal_primordial", "mana_receptor"]
SWORDS = {  # nome: (cor da lâmina, comprimento, largura)
    "crystal_dagger": ((127, 178, 255, 255), 6, 1),
    "mana_shortsword": ((170, 190, 220, 255), 8, 2),
    "crystal_rapier": ((159, 255, 246, 255), 11, 1),
    "mana_longsword": ((200, 210, 230, 255), 11, 2),
    "mana_greatsword": ((120, 140, 190, 255), 12, 3),
    "primordial_blade": ((176, 92, 255, 255), 12, 2),
}
STAVES = {  # nome: cor do cristal
    "mana_staff_apprentice": (127, 178, 255, 255),
    "mana_staff_crystal": (58, 123, 255, 255),
    "mana_staff_pure": (159, 255, 246, 255),
    "mana_staff_primordial": (176, 92, 255, 255),
}
CHARMS = {  # nome: cor da gema
    "charm_flux": (80, 200, 255, 255),
    "charm_focus": (200, 140, 255, 255),
    "charm_crystal": (58, 123, 255, 255),
    "charm_thrift": (255, 120, 90, 255),
    "charm_resonance": (255, 211, 77, 255),
}
ROBE_SETS = {  # conjunto: (cor principal, cor de detalhe)
    "apprentice_robe": ((140, 100, 70, 255), (230, 220, 190, 255)),
    "crystal_robe": ((58, 110, 220, 255), (159, 255, 246, 255)),
    "pure_robe": ((110, 60, 190, 255), (255, 211, 77, 255)),
}
ROBE_PIECES = ["hood", "tunic", "trousers", "boots"]
ROBE_ITEMS = [f"{k}_{p}" for k in ROBE_SETS for p in ROBE_PIECES]
HANDHELD = list(SWORDS) + list(STAVES)
GENERATED = ITEMS + ["mana_ink"] + list(CHARMS) + ROBE_ITEMS
ALL_ITEMS = GENERATED + HANDHELD
BLOCKS = ["mana_crystal_ore", "mana_concentrator", "inscription_table"]


def save(img, path):
    path.parent.mkdir(parents=True, exist_ok=True)
    img.save(path)


def write(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def shade(c, f):
    return tuple(max(0, min(255, int(v * f))) for v in c[:3]) + (255,)


def crystal_icon(base, shards, sparkle=None):
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    for (cx, cy, w, h) in shards:
        pts = [(cx, cy - h), (cx + w, cy - h // 3), (cx + w - 1, cy + h // 2), (cx, cy + h), (cx - w + 1, cy + h // 2), (cx - w, cy - h // 3)]
        d.polygon(pts, fill=base, outline=shade(base, 0.55))
        d.polygon([(cx, cy - h), (cx - w, cy - h // 3), (cx - w + 1, cy + h // 2), (cx, cy + h // 2)], fill=shade(base, 1.25))
        d.line([(cx, cy - h + 1), (cx, cy + h - 1)], fill=shade(base, 0.8))
    if sparkle:
        for (x, y) in [(3, 3), (12, 4), (13, 11), (2, 12)]:
            img.putpixel((x, y), sparkle)
    return img


def receptor_icon():
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    glass = (190, 210, 230, 255)
    d.rectangle([6, 1, 9, 3], fill=(120, 90, 60, 255), outline=(70, 50, 30, 255))  # rolha
    d.rectangle([5, 4, 10, 5], fill=glass, outline=(120, 140, 160, 255))  # gargalo
    d.polygon([(4, 6), (11, 6), (13, 12), (12, 14), (3, 14), (2, 12)], fill=glass, outline=(120, 140, 160, 255))
    d.polygon([(4, 9), (11, 9), (12, 12), (11, 13), (4, 13), (3, 12)], fill=(58, 123, 255, 255))
    img.putpixel((5, 7), (255, 255, 255, 255))
    img.putpixel((5, 8), (255, 255, 255, 255))
    return img


def sword_icon(color, length, width):
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    # lâmina na diagonal, da guarda (3,12) para o canto superior direito
    for i in range(length):
        x, y = 4 + i, 11 - i
        for w in range(width):
            d.point((x + w, y), fill=color)
            d.point((x, y - w), fill=shade(color, 1.2))
        d.point((x - 1, y + 1), fill=shade(color, 0.6))
    d.line([(2, 9), (6, 13)], fill=(255, 211, 77, 255), width=1)  # guarda
    d.line([(3, 12), (1, 14)], fill=(110, 75, 40, 255), width=1)  # cabo
    img.putpixel((1, 14), (70, 45, 20, 255))
    return img


def staff_icon(gem):
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    for i in range(11):
        d.point((2 + i, 14 - i), fill=(120, 85, 50, 255))
        d.point((3 + i, 14 - i), fill=(90, 62, 36, 255))
    d.polygon([(11, 1), (14, 4), (12, 7), (9, 4)], fill=gem, outline=shade(gem, 0.5))
    d.line([(11, 2), (11, 6)], fill=shade(gem, 1.3))
    return img


def charm_icon(gem):
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.ellipse([3, 3, 12, 12], outline=(255, 211, 77, 255))  # aro dourado
    d.ellipse([4, 4, 11, 11], outline=(200, 160, 40, 255))
    d.polygon([(7, 2), (10, 5), (7, 8), (4, 5)], fill=gem, outline=shade(gem, 0.5))
    img.putpixel((6, 4), (255, 255, 255, 255))
    return img


def ink_icon():
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rectangle([6, 2, 9, 4], fill=(120, 90, 60, 255), outline=(70, 50, 30, 255))
    d.polygon([(5, 5), (10, 5), (12, 13), (3, 13)], fill=(40, 30, 90, 255), outline=(20, 15, 50, 255))
    d.polygon([(6, 8), (9, 8), (10, 12), (5, 12)], fill=(90, 130, 255, 255))
    img.putpixel((6, 6), (200, 220, 255, 255))
    return img


def robe_icon(piece, main, detail):
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    dark = shade(main, 0.6)
    if piece == "hood":
        d.polygon([(8, 2), (13, 7), (13, 13), (10, 13), (10, 9), (6, 9), (6, 13), (3, 13), (3, 7)], fill=main, outline=dark)
        d.line([(5, 8), (10, 8)], fill=detail)
    elif piece == "tunic":
        d.polygon([(5, 2), (11, 2), (14, 5), (14, 9), (12, 9), (12, 14), (4, 14), (4, 9), (2, 9), (2, 5)], fill=main, outline=dark)
        d.line([(8, 3), (8, 13)], fill=detail)
        d.line([(4, 12), (11, 12)], fill=detail)
    elif piece == "trousers":
        d.polygon([(4, 2), (12, 2), (13, 14), (9, 14), (8, 7), (7, 14), (3, 14)], fill=main, outline=dark)
        d.line([(4, 3), (11, 3)], fill=detail)
    else:
        d.polygon([(3, 7), (7, 7), (7, 11), (11, 11), (11, 13), (3, 13)], fill=main, outline=dark)
        d.polygon([(9, 7), (13, 7), (13, 13), (9, 13)], fill=main, outline=dark)
        d.line([(3, 12), (6, 12)], fill=detail)
        d.line([(9, 12), (12, 12)], fill=detail)
    return img


def worn_texture(main, detail, seed):
    """Textura 64x32 (vale para as camadas de armadura): tecido com ruído e uma barra de detalhe a cada 8 px."""
    rng = random.Random(seed)
    img = Image.new("RGBA", (64, 32), main)
    for x in range(64):
        for y in range(32):
            v = rng.randint(-10, 10)
            r, g, b, _ = main
            img.putpixel((x, y), (max(0, min(255, r + v)), max(0, min(255, g + v)), max(0, min(255, b + v)), 255))
    d = ImageDraw.Draw(img)
    for y in range(7, 32, 8):
        d.line([(0, y), (63, y)], fill=detail)
    return img


def table_block():
    rng = random.Random(11)
    img = Image.new("RGBA", (16, 16), (120, 85, 50, 255))
    for x in range(16):
        for y in range(16):
            v = rng.randint(-8, 8)
            img.putpixel((x, y), (120 + v, 85 + v, 50 + v, 255))
    d = ImageDraw.Draw(img)
    d.rectangle([0, 0, 15, 15], outline=(70, 48, 28, 255))
    d.rectangle([2, 2, 13, 13], outline=(58, 123, 255, 255))
    d.line([(8, 4), (8, 11)], fill=(159, 255, 246, 255))
    d.line([(5, 8), (11, 8)], fill=(159, 255, 246, 255))
    d.point((8, 8), fill=(255, 255, 255, 255))
    return img


def ore_block():
    rng = random.Random(7)
    img = Image.new("RGBA", (16, 16), (125, 125, 125, 255))
    for x in range(16):
        for y in range(16):
            v = rng.randint(-14, 14)
            img.putpixel((x, y), (125 + v, 125 + v, 125 + v, 255))
    d = ImageDraw.Draw(img)
    for (x, y) in [(3, 3), (10, 2), (6, 8), (12, 10), (3, 12), (9, 13)]:
        d.rectangle([x, y, x + 2, y + 2], fill=(58, 123, 255, 255), outline=(30, 70, 170, 255))
        img.putpixel((x, y), (180, 220, 255, 255))
    return img


def concentrator_block():
    img = Image.new("RGBA", (16, 16), (42, 35, 64, 255))
    d = ImageDraw.Draw(img)
    d.rectangle([0, 0, 15, 15], outline=(20, 16, 34, 255))
    d.rectangle([2, 2, 13, 13], outline=(120, 100, 190, 255))
    d.polygon([(8, 3), (12, 8), (8, 13), (4, 8)], fill=(58, 123, 255, 255), outline=(180, 220, 255, 255))
    d.line([(8, 4), (8, 12)], fill=(180, 220, 255, 255))
    for (x, y) in [(1, 1), (14, 1), (1, 14), (14, 14)]:
        img.putpixel((x, y), (255, 211, 77, 255))
    return img


def main():
    tex = ASSETS / "textures"
    save(crystal_icon((127, 178, 255, 255), [(8, 9, 3, 5)]), tex / "item/mana_crystal_fragment.png")
    save(crystal_icon((58, 123, 255, 255), [(8, 8, 4, 6), (4, 11, 2, 3)]), tex / "item/mana_crystal.png")
    save(crystal_icon((159, 255, 246, 255), [(8, 8, 4, 7), (4, 11, 2, 3), (12, 11, 2, 3)], (255, 255, 255, 255)), tex / "item/mana_crystal_pure.png")
    save(crystal_icon((176, 92, 255, 255), [(8, 8, 5, 7), (3, 11, 2, 3), (13, 11, 2, 3)], (255, 211, 77, 255)), tex / "item/mana_crystal_primordial.png")
    save(receptor_icon(), tex / "item/mana_receptor.png")
    for name, (color, length, width) in SWORDS.items():
        save(sword_icon(color, length, width), tex / f"item/{name}.png")
    for name, gem in STAVES.items():
        save(staff_icon(gem), tex / f"item/{name}.png")
    for name, gem in CHARMS.items():
        save(charm_icon(gem), tex / f"item/{name}.png")
    save(ink_icon(), tex / "item/mana_ink.png")
    for set_key, (main, detail) in ROBE_SETS.items():
        for piece in ROBE_PIECES:
            save(robe_icon(piece, main, detail), tex / f"item/{set_key}_{piece}.png")
        # modelo vestido (camadas humanoid e humanoid_leggings) + definição do equipamento
        save(worn_texture(main, detail, sum(map(ord, set_key)) % 1000), tex / f"entity/equipment/humanoid/{set_key}.png")
        save(worn_texture(shade(main, 0.9), detail, sum(map(ord, set_key)) % 1000 + 1), tex / f"entity/equipment/humanoid_leggings/{set_key}.png")
        write(ASSETS / f"equipment/{set_key}.json", {"layers": {
            "humanoid": [{"texture": f"{NS}:{set_key}"}],
            "humanoid_leggings": [{"texture": f"{NS}:{set_key}"}]}})
    save(table_block(), tex / "block/inscription_table.png")
    save(ore_block(), tex / "block/mana_crystal_ore.png")
    save(concentrator_block(), tex / "block/mana_concentrator.png")

    for name in ALL_ITEMS:
        parent = "minecraft:item/handheld" if name in HANDHELD else "minecraft:item/generated"
        write(ASSETS / f"models/item/{name}.json", {"parent": parent, "textures": {"layer0": f"{NS}:item/{name}"}})
        write(ASSETS / f"items/{name}.json", {"model": {"type": "minecraft:model", "model": f"{NS}:item/{name}"}})
    for name in BLOCKS:
        write(ASSETS / f"blockstates/{name}.json", {"variants": {"": {"model": f"{NS}:block/{name}"}}})
        write(ASSETS / f"models/block/{name}.json", {"parent": "minecraft:block/cube_all", "textures": {"all": f"{NS}:block/{name}"}})
        write(ASSETS / f"items/{name}.json", {"model": {"type": "minecraft:model", "model": f"{NS}:block/{name}"}})

    # loot tables
    write(DATA / "loot_table/blocks/mana_crystal_ore.json", {
        "type": "minecraft:block",
        "pools": [{"rolls": 1, "entries": [{
            "type": "minecraft:item", "name": f"{NS}:mana_crystal_fragment",
            "functions": [
                {"function": "minecraft:set_count", "count": {"type": "minecraft:uniform", "min": 1, "max": 3}},
                {"function": "minecraft:explosion_decay"}]}]}]})
    write(DATA / "loot_table/blocks/inscription_table.json", {
        "type": "minecraft:block",
        "pools": [{"rolls": 1, "entries": [{"type": "minecraft:item", "name": f"{NS}:inscription_table"}],
                   "conditions": [{"condition": "minecraft:survives_explosion"}]}]})
    write(RES / "data/minecraft/tags/block/mineable/axe.json", {"values": [f"{NS}:inscription_table"]})
    write(DATA / "loot_table/blocks/mana_concentrator.json", {
        "type": "minecraft:block",
        "pools": [{"rolls": 1, "entries": [{"type": "minecraft:item", "name": f"{NS}:mana_concentrator"}],
                   "conditions": [{"condition": "minecraft:survives_explosion"}]}]})

    # ferramenta mínima: picareta de pedra
    write(RES / "data/minecraft/tags/block/mineable/pickaxe.json", {"values": [f"{NS}:mana_crystal_ore", f"{NS}:mana_concentrator"]})
    write(RES / "data/minecraft/tags/block/needs_stone_tool.json", {"values": [f"{NS}:mana_crystal_ore", f"{NS}:mana_concentrator"]})

    # geração no mundo
    ore = {"state": {"Name": f"{NS}:mana_crystal_ore"}}
    write(DATA / "worldgen/configured_feature/mana_crystal_ore.json", {
        "type": "minecraft:ore",
        "config": {"discard_chance_on_air_exposure": 0.0, "size": 6, "targets": [
            {"state": ore["state"], "target": {"predicate_type": "minecraft:tag_match", "tag": "minecraft:stone_ore_replaceables"}},
            {"state": ore["state"], "target": {"predicate_type": "minecraft:tag_match", "tag": "minecraft:deepslate_ore_replaceables"}}]}})
    write(DATA / "worldgen/placed_feature/mana_crystal_ore.json", {
        "feature": f"{NS}:mana_crystal_ore",
        "placement": [
            {"type": "minecraft:count", "count": 4},
            {"type": "minecraft:in_square"},
            {"type": "minecraft:height_range", "height": {"type": "minecraft:uniform", "min_inclusive": {"absolute": -60}, "max_inclusive": {"absolute": 48}}},
            {"type": "minecraft:biome"}]})

    # receitas (1.21.2+: ingredientes como texto; resultado com "id")
    def shapeless(name, ingredients, result):
        write(DATA / f"recipe/{name}.json", {"type": "minecraft:crafting_shapeless", "category": "misc",
                                             "ingredients": ingredients, "result": {"id": f"{NS}:{result}", "count": 1}})
    shapeless("mana_crystal_from_fragments", [f"{NS}:mana_crystal_fragment"] * 4, "mana_crystal")
    shapeless("mana_crystal_pure_from_crystals", [f"{NS}:mana_crystal"] * 3, "mana_crystal_pure")
    shapeless("mana_crystal_primordial_from_pure", [f"{NS}:mana_crystal_pure"] * 3 + ["minecraft:diamond"], "mana_crystal_primordial")
    shapeless("mana_receptor", [f"{NS}:mana_crystal", "minecraft:gold_ingot", "minecraft:glass_bottle"], "mana_receptor")
    write(DATA / "recipe/mana_concentrator.json", {
        "type": "minecraft:crafting_shaped", "category": "misc",
        "pattern": ["CCC", "COC", "SSS"],
        "key": {"C": f"{NS}:mana_crystal", "O": "minecraft:obsidian", "S": "minecraft:stone"},
        "result": {"id": f"{NS}:mana_concentrator", "count": 1}})
    # equipamento: espadas e cajados (formato) e acessórios (sem forma)
    def shaped(name, pattern, key, result):
        write(DATA / f"recipe/{name}.json", {"type": "minecraft:crafting_shaped", "category": "equipment",
                                             "pattern": pattern, "key": key, "result": {"id": f"{NS}:{result}", "count": 1}})
    C, P, R, F = f"{NS}:mana_crystal", f"{NS}:mana_crystal_pure", f"{NS}:mana_crystal_primordial", f"{NS}:mana_crystal_fragment"
    I, S, D = "minecraft:iron_ingot", "minecraft:stick", "minecraft:diamond"
    shaped("crystal_dagger", ["C", "S"], {"C": C, "S": S}, "crystal_dagger")
    shaped("mana_shortsword", ["I", "C", "S"], {"I": I, "C": C, "S": S}, "mana_shortsword")
    shaped("crystal_rapier", ["C", "I", "S"], {"I": I, "C": C, "S": S}, "crystal_rapier")
    shaped("mana_longsword", ["I", "P", "S"], {"I": I, "P": P, "S": S}, "mana_longsword")
    shaped("mana_greatsword", ["IP", "IP", "S "], {"I": I, "P": P, "S": S}, "mana_greatsword")
    shaped("primordial_blade", ["R", "D", "S"], {"R": R, "D": D, "S": S}, "primordial_blade")
    shaped("mana_staff_apprentice", ["F", "S", "S"], {"F": F, "S": S}, "mana_staff_apprentice")
    shaped("mana_staff_crystal", ["C", "S", "S"], {"C": C, "S": S}, "mana_staff_crystal")
    shaped("mana_staff_pure", ["P", "S", "S"], {"P": P, "S": S}, "mana_staff_pure")
    shaped("mana_staff_primordial", ["R", "S", "S"], {"R": R, "S": S}, "mana_staff_primordial")
    shapeless("charm_flux", [C, "minecraft:gold_ingot", "minecraft:lapis_lazuli"], "charm_flux")
    shapeless("charm_focus", [C, "minecraft:gold_ingot", "minecraft:amethyst_shard"], "charm_focus")
    shapeless("charm_crystal", [P, "minecraft:gold_ingot", "minecraft:string"], "charm_crystal")
    shapeless("charm_thrift", [C, "minecraft:gold_ingot", "minecraft:redstone"], "charm_thrift")
    shapeless("charm_resonance", [P, C, "minecraft:gold_ingot", D], "charm_resonance")
    # tinta, mesa de inscrição e vestes
    shapeless("mana_ink", [F, F, "minecraft:ink_sac", "minecraft:glass_bottle"], "mana_ink")
    write(DATA / "recipe/inscription_table.json", {
        "type": "minecraft:crafting_shaped", "category": "misc",
        "pattern": ["CIC", "WWW", "W W"],
        "key": {"C": C, "I": f"{NS}:mana_ink", "W": "minecraft:oak_planks"},
        "result": {"id": f"{NS}:inscription_table", "count": 1}})
    shapes = {"hood": ["MMM", "M M"], "tunic": ["M M", "MMM", "MMM"], "trousers": ["MMM", "M M", "M M"], "boots": ["M M", "M M"]}
    materials = {"apprentice_robe": "minecraft:leather", "crystal_robe": F, "pure_robe": P}
    for set_key, material in materials.items():
        for piece, pattern in shapes.items():
            shaped(f"{set_key}_{piece}", pattern, {"M": material}, f"{set_key}_{piece}")
    print("Assets e dados gerados.")


if __name__ == "__main__":
    main()
