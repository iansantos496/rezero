#!/usr/bin/env bash
# Compila e roda os testes do código puro (pacote com.rezero.mod.core), sem precisar do Minecraft.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$(mktemp -d)"
javac -d "$OUT" "$ROOT"/src/main/java/com/rezero/mod/core/*.java "$ROOT"/tools/core-tests/CoreTests.java
java -cp "$OUT" CoreTests
