#!/usr/bin/env python3
"""Verificações estáticas do projeto (não substituem compilar com o Minecraft)."""
import json
import pathlib
import re
import sys

root = pathlib.Path(__file__).resolve().parent.parent
errors = []

# 1. JSON válido
for f in root.rglob("*.json"):
    try:
        json.loads(f.read_text(encoding="utf-8"))
    except Exception as e:  # noqa: BLE001
        errors.append(f"JSON inválido: {f.relative_to(root)}: {e}")

# 2. Java: chaves/parênteses, pacote x pasta, imports não usados
for f in (root / "src").rglob("*.java"):
    s = f.read_text(encoding="utf-8")
    t = re.sub(r'"(\\.|[^"\\])*"', '""', s)
    t = re.sub(r"//.*", "", t)
    t = re.sub(r"/\*.*?\*/", "", t, flags=re.S)
    if t.count("{") != t.count("}") or t.count("(") != t.count(")"):
        errors.append(f"Chaves ou parênteses desbalanceados: {f.relative_to(root)}")
    m = re.search(r"^package ([\w.]+);", s, flags=re.M)
    expected = ".".join(f.parent.relative_to(root / "src/main/java").parts)
    if not m or m.group(1) != expected:
        errors.append(f"Pacote não confere com a pasta: {f.relative_to(root)}")
    for imp in re.findall(r"^import [\w.]+\.(\w+);", s, flags=re.M):
        if len(re.findall(r"\b" + imp + r"\b", s)) < 2:
            errors.append(f"Import não usado ({imp}): {f.relative_to(root)}")

# 3. Chaves de tradução usadas no código existem em pt_br e en_us
lang_dir = root / "src/main/resources/assets/rezero_magic/lang"
langs = {p.name: set(json.loads(p.read_text(encoding="utf-8"))) for p in lang_dir.glob("*.json")}
if "pt_br.json" in langs and "en_us.json" in langs and langs["pt_br.json"] != langs["en_us.json"]:
    errors.append("pt_br.json e en_us.json têm chaves diferentes: " + str(langs["pt_br.json"] ^ langs["en_us.json"]))
used = set()
for f in (root / "src").rglob("*.java"):
    used |= set(re.findall(r'"((?:[a-z_]+)\.rezero_magic\.[\w.]+)"', f.read_text(encoding="utf-8")))
for key in sorted(k for k in used if not k.endswith('.') and not k.endswith('_')):
    for name, keys in langs.items():
        if key not in keys:
            errors.append(f"Chave de tradução ausente em {name}: {key}")

# 3b. Chaves dinâmicas: toda afinidade precisa de nome, .canon e .game nos dois idiomas
aff_src = (root / "src/main/java/com/rezero/mod/core/Affinity.java").read_text(encoding="utf-8")
for k in re.findall(r'\(\d+,\s*"(\w+)"\)', aff_src):
    for suffix in ("", ".canon", ".game"):
        for name, keys in langs.items():
            if f"affinity.rezero_magic.{k}{suffix}" not in keys:
                errors.append(f"Chave de afinidade ausente em {name}: affinity.rezero_magic.{k}{suffix}")


# 3c. Feitiços: nome traduzido; resultados de CastRules: mensagem traduzida
spell_src = (root / "src/main/java/com/rezero/mod/core/Spells.java").read_text(encoding="utf-8")
spell_keys = re.findall(r'new SpellDef\(\w+,\s*"(\w+)"', spell_src)
if len(spell_keys) != len(set(spell_keys)):
    errors.append("Chaves de feitiço repetidas em Spells.java")
for k in spell_keys:
    for name, keys in langs.items():
        if f"spell.rezero_magic.{k}" not in keys:
            errors.append(f"Nome de feitiço ausente em {name}: spell.rezero_magic.{k}")
rules_src = (root / "src/main/java/com/rezero/mod/core/CastRules.java").read_text(encoding="utf-8")
enum_body = re.search(r"enum Result \{(.*?)\}", rules_src, flags=re.S).group(1)
for r in re.findall(r"[A-Z_]{2,}", enum_body):
    if r == "OK":
        continue
    for name, keys in langs.items():
        if f"message.rezero_magic.cast.{r.lower()}" not in keys:
            errors.append(f"Mensagem de conjuração ausente em {name}: cast.{r.lower()}")
for extra in ("interrupted", "failed", "full_health", "no_target"):
    for name, keys in langs.items():
        if f"message.rezero_magic.cast.{extra}" not in keys:
            errors.append(f"Mensagem de conjuração ausente em {name}: cast.{extra}")

# 3d. Todo pacote (CustomPayload) é registrado em ModNetworking
net_dir = root / "src/main/java/com/rezero/mod/net"
net_src = (net_dir / "ModNetworking.java").read_text(encoding="utf-8")
for f in net_dir.glob("*Payload.java"):
    cls = f.stem
    if f"{cls}.ID" not in net_src:
        errors.append(f"Pacote não registrado em ModNetworking: {cls}")


# 3e. Todo item/bloco registrado tem modelo, textura, definição de item, tradução (e bloco: blockstate e loot table)
content = root / "src/main/java/com/rezero/mod/content"
res = root / "src/main/resources"
assets = res / "assets/rezero_magic"
reg_items = set(re.findall(r'register\("(\w+)"', (content / "ModItems.java").read_text(encoding="utf-8")))
for enum_file in ("CrystalRarity", "Catalyst", "Charm"):
    reg_items |= set(re.findall(r'\(\d+,\s*"(\w+)"', (root / f"src/main/java/com/rezero/mod/core/{enum_file}.java").read_text(encoding="utf-8")))
reg_blocks = set(re.findall(r'register\("(\w+)"', (content / "ModBlocks.java").read_text(encoding="utf-8")))
core_dir = root / "src/main/java/com/rezero/mod/core"
robe_keys = re.findall(r'\(\d+,\s*"(\w+)"', (core_dir / "RobeSet.java").read_text(encoding="utf-8"))
robe_suffixes = re.findall(r'\(\d+,\s*"(\w+)"', (core_dir / "RobePiece.java").read_text(encoding="utf-8"))
reg_items |= {f"{k}_{sfx}" for k in robe_keys for sfx in robe_suffixes}
for name in sorted(reg_items):
    for rel in (f"models/item/{name}.json", f"items/{name}.json", f"textures/item/{name}.png"):
        if not (assets / rel).exists():
            errors.append(f"Asset ausente para item {name}: {rel}")
    for lname, keys in langs.items():
        if f"item.rezero_magic.{name}" not in keys:
            errors.append(f"Tradução de item ausente em {lname}: item.rezero_magic.{name}")
for name in sorted(reg_blocks):
    for rel in (f"blockstates/{name}.json", f"models/block/{name}.json", f"items/{name}.json", f"textures/block/{name}.png"):
        if not (assets / rel).exists():
            errors.append(f"Asset ausente para bloco {name}: {rel}")
    if not (res / f"data/rezero_magic/loot_table/blocks/{name}.json").exists():
        errors.append(f"Loot table ausente para bloco {name}")
    for lname, keys in langs.items():
        if f"block.rezero_magic.{name}" not in keys:
            errors.append(f"Tradução de bloco ausente em {lname}: block.rezero_magic.{name}")
for f in res.rglob("*.json"):
    try:
        json.loads(f.read_text(encoding="utf-8"))
    except ValueError as e:
        errors.append(f"JSON inválido: {f.relative_to(root)} ({e})")
for rel in ("data/rezero_magic/worldgen/configured_feature/mana_crystal_ore.json", "data/rezero_magic/worldgen/placed_feature/mana_crystal_ore.json"):
    if not (res / rel).exists():
        errors.append(f"Geração de mundo ausente: {rel}")


# 3f. Inscrições: nome e descrição; resultados de InscriptionRules: mensagem; categorias do Hub
insc_src = (root / "src/main/java/com/rezero/mod/core/Inscription.java").read_text(encoding="utf-8")
insc_keys = re.findall(r'^\t[A-Z_]+\(\d+,\s*"(\w+)"', insc_src, flags=re.M)
if len(insc_keys) != 12:
    errors.append(f"Esperava 12 inscrições, achei {len(insc_keys)}")
for k in insc_keys:
    for name, keys in langs.items():
        for suffix in ("", ".desc"):
            if f"inscription.rezero_magic.{k}{suffix}" not in keys:
                errors.append(f"Texto de inscrição ausente em {name}: inscription.rezero_magic.{k}{suffix}")
irules = (root / "src/main/java/com/rezero/mod/core/InscriptionRules.java").read_text(encoding="utf-8")
ienum = re.search(r"enum Result \{(.*?)\}", irules, flags=re.S).group(1)
for r in re.findall(r"[A-Z_]{2,}", ienum):
    if r == "OK":
        continue
    for name, keys in langs.items():
        if f"message.rezero_magic.inscription.{r.lower()}" not in keys:
            errors.append(f"Mensagem de inscrição ausente em {name}: inscription.{r.lower()}")
for cat in ("power", "economy", "defense", "utility"):
    for name, keys in langs.items():
        if f"screen.rezero_magic.hub.category_{cat}" not in keys:
            errors.append(f"Categoria ausente em {name}: category_{cat}")
for conj in robe_keys:
    if not (assets / f"equipment/{conj}.json").exists():
        errors.append(f"Definição de equipamento (veste) ausente: equipment/{conj}.json")
    for layer in ("humanoid", "humanoid_leggings"):
        if not (assets / f"textures/entity/equipment/{layer}/{conj}.png").exists():
            errors.append(f"Textura vestida ausente: {layer}/{conj}.png")


# 3g. Treinamento: nome e descrição de cada atributo; toda mensagem enviada com message(player, "x") existe nos idiomas
train_src = (root / "src/main/java/com/rezero/mod/core/TrainingAttribute.java").read_text(encoding="utf-8")
train_keys = re.findall(r'^\t[A-Z_]+\(\d+,\s*"(\w+)"\)', train_src, flags=re.M)
if len(train_keys) != 5:
    errors.append(f"Esperava 5 atributos de treino, achei {len(train_keys)}")
for k in train_keys:
    for name, keys in langs.items():
        for suffix in ("", ".desc"):
            if f"training.rezero_magic.{k}{suffix}" not in keys:
                errors.append(f"Texto de treino ausente em {name}: training.rezero_magic.{k}{suffix}")
for f in (root / "src/main/java/com/rezero/mod/server").glob("*.java"):
    text = f.read_text(encoding="utf-8")
    # cada serviço tem o seu auxiliar message(); descobre o prefixo que ele usa (ex.: "crystal.")
    helper = re.search(r'translatable\("message\.rezero_magic\.([\w.]*)"\s*\+\s*key\)', text)
    prefix = helper.group(1) if helper else ""
    for key in re.findall(r'\bmessage\(\s*\w+,\s*"([\w.]+)"\s*\)', text):
        for name, keys in langs.items():
            if f"message.rezero_magic.{prefix}{key}" not in keys:
                errors.append(f"Mensagem ausente em {name}: message.rezero_magic.{prefix}{key} ({f.name})")


# 3h. Combate: técnicas (nome e descrição), estilos, resultados de uso/aprendizado (mensagens e motivos no Hub), lanças
tech_src = (root / "src/main/java/com/rezero/mod/core/Techniques.java").read_text(encoding="utf-8")
tech_keys = re.findall(r'new TechniqueDef\(\w+,\s*"(\w+)"', tech_src)
if len(tech_keys) != 15 or len(set(tech_keys)) != 15:
    errors.append(f"Esperava 15 técnicas únicas, achei {len(tech_keys)}")
for k in tech_keys:
    for name, keys in langs.items():
        for suffix in ("", ".desc"):
            if f"technique.rezero_magic.{k}{suffix}" not in keys:
                errors.append(f"Texto de técnica ausente em {name}: technique.rezero_magic.{k}{suffix}")
style_src = (root / "src/main/java/com/rezero/mod/core/CombatStyle.java").read_text(encoding="utf-8")
for k in re.findall(r'^\t[A-Z_]+\(\d+,\s*"(\w+)"\)', style_src, flags=re.M):
    for name, keys in langs.items():
        if f"style.rezero_magic.{k}" not in keys:
            errors.append(f"Nome de estilo ausente em {name}: style.rezero_magic.{k}")
rules_src = (root / "src/main/java/com/rezero/mod/core/CombatRules.java").read_text(encoding="utf-8")
use_enum = re.search(r"enum UseResult \{(.*?)\}", rules_src, flags=re.S).group(1)
for r in re.findall(r"[A-Z_]{2,}", use_enum):
    if r != "OK":
        for name, keys in langs.items():
            if f"message.rezero_magic.combat.{r.lower()}" not in keys:
                errors.append(f"Mensagem de combate ausente em {name}: combat.{r.lower()}")
learn_enum = re.search(r"enum LearnResult \{(.*?)\}", rules_src, flags=re.S).group(1)
for r in re.findall(r"[A-Z_]{2,}", learn_enum):
    if r != "OK":
        for name, keys in langs.items():
            for key in (f"message.rezero_magic.combat.learn_{r.lower()}", f"screen.rezero_magic.hub.learn_reason_{r.lower()}"):
                if key not in keys:
                    errors.append(f"Texto de aprendizado ausente em {name}: {key}")
for sp in ("mana_spear", "crystal_spear"):
    for rel in (f"assets/rezero_magic/textures/item/{sp}.png", f"assets/rezero_magic/models/item/{sp}.json",
                f"assets/rezero_magic/items/{sp}.json", f"data/rezero_magic/recipe/{sp}.json"):
        if not (root / "src/main/resources" / rel).exists():
            errors.append(f"Arquivo da lança ausente: {rel}")
    for name, keys in langs.items():
        if f"item.rezero_magic.{sp}" not in keys:
            errors.append(f"Nome da lança ausente em {name}: {sp}")

# 4. fabric.mod.json: entrypoint existe
mod = json.loads((root / "src/main/resources/fabric.mod.json").read_text(encoding="utf-8"))
for kind, entries in mod.get("entrypoints", {}).items():
    for cls in entries:
        path = root / "src/main/java" / (cls.replace(".", "/") + ".java")
        if not path.exists():
            errors.append(f"Entrypoint '{kind}' aponta para classe inexistente: {cls}")

if errors:
    print("PROBLEMAS ENCONTRADOS:")
    for e in errors:
        print(" -", e)
    sys.exit(1)
print("Verificação estática OK (JSON, chaves, pacotes, imports, traduções, entrypoints).")
