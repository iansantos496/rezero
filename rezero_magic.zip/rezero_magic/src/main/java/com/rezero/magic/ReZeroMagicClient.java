package com.rezero.magic;

import org.lwjgl.glfw.GLFW;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class ReZeroMagicClient implements ClientModInitializer {
	private static final String[] SPELL_KEYS = {"fireball", "ice_lance", "unseen_hand"};

	// Dados recebidos do servidor (lidos também pelo MagicScreen).
	static volatile int mana = ManaManager.MAX_MANA;
	static volatile int maxMana = ManaManager.MAX_MANA;
	static volatile int level = 1;
	static volatile int xp = 0;
	static volatile int xpNeeded = Progression.xpNeeded(1);
	static volatile int affinity = -1;
	static volatile int skillMask = 0;
	static volatile int points = 0;

	private static int selected = 0;

	private static KeyBinding castKey;
	private static KeyBinding prevKey;
	private static KeyBinding nextKey;
	private static KeyBinding menuKey;

	@Override
	public void onInitializeClient() {
		// Em 1.21.9+ a categoria de teclas é um objeto, não mais uma String.
		KeyBinding.Category category = KeyBinding.Category.create(Identifier.of(ReZeroMagic.MOD_ID, "magic"));

		castKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.rezero_magic.cast", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_R, category));
		prevKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.rezero_magic.prev_spell", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_Z, category));
		nextKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.rezero_magic.next_spell", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_X, category));
		menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.rezero_magic.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_K, category));

		ClientPlayNetworking.registerGlobalReceiver(ManaSyncPayload.ID, (payload, context) -> {
			mana = payload.mana();
			maxMana = payload.maxMana();
			level = payload.level();
			xp = payload.xp();
			xpNeeded = payload.xpNeeded();
		});

		ClientPlayNetworking.registerGlobalReceiver(ProfileSyncPayload.ID, (payload, context) -> {
			affinity = payload.affinity();
			skillMask = payload.skillMask();
			points = payload.points();
		});

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			if (client.player == null) {
				return;
			}
			while (prevKey.wasPressed()) {
				selected = (selected + SPELL_KEYS.length - 1) % SPELL_KEYS.length;
			}
			while (nextKey.wasPressed()) {
				selected = (selected + 1) % SPELL_KEYS.length;
			}
			while (castKey.wasPressed()) {
				if (client.currentScreen == null) {
					ClientPlayNetworking.send(new CastSpellPayload(selected));
				}
			}
			while (menuKey.wasPressed()) {
				if (client.currentScreen == null) {
					client.setScreen(new MagicScreen(0));
				}
			}
		});

		// HudRenderCallback está marcado como deprecated nas versões novas do Fabric API,
		// mas continua funcionando. Se for removido, troque por HudElementRegistry.
		HudRenderCallback.EVENT.register((context, tickCounter) -> {
			MinecraftClient client = MinecraftClient.getInstance();
			if (client.player == null || client.options.hudHidden) {
				return;
			}
			int x = 10;
			int y = 10;
			int width = 100;

			// barra de mana
			int filled = width * mana / Math.max(1, maxMana);
			context.fill(x - 1, y - 1, x + width + 1, y + 9, 0xAA000000);
			context.fill(x, y, x + filled, y + 8, 0xFF3A7BFF);
			context.drawTextWithShadow(client.textRenderer,
					Text.translatable("hud.rezero_magic.mana", mana, maxMana),
					x, y + 11, 0xFFFFFFFF);

			// nível e barra de XP
			int ly = y + 24;
			Text levelText = xpNeeded > 0
					? Text.translatable("hud.rezero_magic.level", level)
					: Text.translatable("hud.rezero_magic.level_max", level);
			context.drawTextWithShadow(client.textRenderer, levelText, x, ly, 0xFFFFD34D);
			int xpFilled = xpNeeded > 0 ? width * xp / Math.max(1, xpNeeded) : width;
			context.fill(x - 1, ly + 11, x + width + 1, ly + 16, 0xAA000000);
			context.fill(x, ly + 12, x + xpFilled, ly + 15, 0xFFFFD34D);

			// lista de magias: selecionada em destaque, com o custo já ajustado pela afinidade
			int sy = ly + 24;
			for (int i = 0; i < SPELL_KEYS.length; i++) {
				boolean sel = i == selected;
				int cost = MagicData.cost(MagicData.BASE_COST[i], affinity, i);
				Text name = Text.translatable("spell.rezero_magic." + SPELL_KEYS[i]);
				Text line = Text.literal(sel ? "> " : "   ").append(name).append(Text.literal(" (" + cost + ")"));
				context.drawTextWithShadow(client.textRenderer, line, x, sy + i * 11,
						sel ? 0xFFFFFFFF : 0xFF909090);
			}

			// afinidade e lembrete do menu
			int ay = sy + SPELL_KEYS.length * 11 + 4;
			Text affinityText = affinity >= 0
					? Text.translatable("hud.rezero_magic.affinity",
							Text.translatable("element.rezero_magic." + MagicData.ELEMENT_KEYS[affinity]), points)
					: Text.translatable("hud.rezero_magic.no_affinity");
			context.drawTextWithShadow(client.textRenderer, affinityText, x, ay,
					affinity >= 0 ? 0xFFB8B8D0 : 0xFFFF7070);
		});
	}
}
