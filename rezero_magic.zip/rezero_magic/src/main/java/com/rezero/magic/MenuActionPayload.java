package com.rezero.magic;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Cliente -> servidor: ação do menu. action 0 = escolher afinidade (arg = elemento), 1 = desbloquear habilidade (arg = id). */
public record MenuActionPayload(int action, int arg) implements CustomPayload {
	public static final CustomPayload.Id<MenuActionPayload> ID =
			new CustomPayload.Id<>(Identifier.of(ReZeroMagic.MOD_ID, "menu_action"));

	public static final PacketCodec<RegistryByteBuf, MenuActionPayload> CODEC =
			PacketCodec.tuple(
					PacketCodecs.VAR_INT, MenuActionPayload::action,
					PacketCodecs.VAR_INT, MenuActionPayload::arg,
					MenuActionPayload::new);

	@Override
	public CustomPayload.Id<? extends CustomPayload> getId() {
		return ID;
	}
}
