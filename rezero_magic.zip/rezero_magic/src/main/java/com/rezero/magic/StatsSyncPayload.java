package com.rezero.magic;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Servidor -> cliente: estatísticas e Essências. mostUsed = índice da magia mais usada. */
public record StatsSyncPayload(int kills, int deaths, int damage, int essence, int casts, int mostUsed)
		implements CustomPayload {
	public static final CustomPayload.Id<StatsSyncPayload> ID =
			new CustomPayload.Id<>(Identifier.of(ReZeroMagic.MOD_ID, "stats_sync"));

	public static final PacketCodec<RegistryByteBuf, StatsSyncPayload> CODEC =
			PacketCodec.tuple(
					PacketCodecs.VAR_INT, StatsSyncPayload::kills,
					PacketCodecs.VAR_INT, StatsSyncPayload::deaths,
					PacketCodecs.VAR_INT, StatsSyncPayload::damage,
					PacketCodecs.VAR_INT, StatsSyncPayload::essence,
					PacketCodecs.VAR_INT, StatsSyncPayload::casts,
					PacketCodecs.VAR_INT, StatsSyncPayload::mostUsed,
					StatsSyncPayload::new);

	@Override
	public CustomPayload.Id<? extends CustomPayload> getId() {
		return ID;
	}
}
