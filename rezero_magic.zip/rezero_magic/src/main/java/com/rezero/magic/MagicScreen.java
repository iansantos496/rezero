package com.rezero.magic;

import java.util.ArrayList;
import java.util.List;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;

/**
 * Menu de magia com três abas: Status, Afinidade e Habilidades.
 * Desenhado só com retângulos, texto e botões comuns (sem texturas).
 * Os botões e textos leem os dados mais recentes enviados pelo servidor a cada quadro.
 */
public class MagicScreen extends Screen {
	private static final int PANEL_W = 350;
	private static final int PANEL_H = 214;
	private static final int COL_W = 108;
	private static final int[] ELEMENT_COLORS = {0xFFFF8A3D, 0xFF6EC8FF, 0xFFB57BFF};

	private final int tab;
	private int left;
	private int top;
	private final List<ButtonWidget> affinityButtons = new ArrayList<>();
	private final List<ButtonWidget> skillButtons = new ArrayList<>();

	public MagicScreen(int tab) {
		super(Text.translatable("screen.rezero_magic.title"));
		this.tab = tab;
	}

	@Override
	public boolean shouldPause() {
		// Sem pausar, o servidor integrado continua processando os cliques do menu.
		return false;
	}

	@Override
	protected void init() {
		left = (width - PANEL_W) / 2;
		top = (height - PANEL_H) / 2;
		affinityButtons.clear();
		skillButtons.clear();

		// Primeiro o fundo e os textos; os botões vêm depois e ficam por cima.
		addDrawable(this::drawContent);

		for (int i = 0; i < 3; i++) {
			final int target = i;
			ButtonWidget button = ButtonWidget.builder(
					Text.translatable("screen.rezero_magic.tab." + i),
					b -> MinecraftClient.getInstance().setScreen(new MagicScreen(target)))
					.dimensions(left + 10 + i * 112, top + 8, 108, 20)
					.build();
			button.active = i != tab;
			addDrawableChild(button);
		}

		if (tab == 1) {
			for (int e = 0; e < MagicData.ELEMENTS; e++) {
				final int element = e;
				ButtonWidget button = ButtonWidget.builder(Text.empty(),
						b -> ClientPlayNetworking.send(new MenuActionPayload(0, element)))
						.dimensions(left + 14 + e * 112, top + 150, COL_W, 20)
						.build();
				affinityButtons.add(addDrawableChild(button));
			}
		} else if (tab == 2) {
			for (int e = 0; e < MagicData.ELEMENTS; e++) {
				for (int t = 0; t < 3; t++) {
					final int id = e * 3 + t;
					ButtonWidget button = ButtonWidget.builder(Text.empty(),
							b -> ClientPlayNetworking.send(new MenuActionPayload(1, id)))
							.dimensions(left + 14 + e * 112, top + 58 + t * 30, COL_W, 22)
							.build();
					skillButtons.add(addDrawableChild(button));
				}
			}
		}
	}

	// ------------------------------------------------------------ desenho

	private void drawContent(DrawContext c, int mouseX, int mouseY, float delta) {
		c.fill(left - 2, top - 2, left + PANEL_W + 2, top + PANEL_H + 2, 0xFF000000);
		c.fill(left, top, left + PANEL_W, top + PANEL_H, 0xEE1B1530);
		switch (tab) {
			case 0 -> drawStatus(c);
			case 1 -> drawAffinity(c);
			default -> drawSkills(c);
		}
	}

	private void text(DrawContext c, Text t, int x, int y, int color) {
		c.drawTextWithShadow(textRenderer, t, x, y, color);
	}

	private void wrap(DrawContext c, Text t, int x, int y, int maxWidth, int color) {
		for (OrderedText line : textRenderer.wrapLines(t, maxWidth)) {
			c.drawTextWithShadow(textRenderer, line, x, y, color);
			y += 10;
		}
	}

	private Text elementName(int element) {
		return Text.translatable("element.rezero_magic." + MagicData.ELEMENT_KEYS[element]);
	}

	private void drawStatus(DrawContext c) {
		int x = left + 16;
		int y = top + 42;
		int level = ReZeroMagicClient.level;
		int xpNeeded = ReZeroMagicClient.xpNeeded;

		text(c, Text.translatable("screen.rezero_magic.status.level", level), x, y, 0xFFFFD34D);
		y += 16;
		text(c, Text.translatable("screen.rezero_magic.status.mana",
				ReZeroMagicClient.mana, ReZeroMagicClient.maxMana), x, y, 0xFF8FB4FF);
		y += 16;
		if (xpNeeded > 0) {
			text(c, Text.translatable("screen.rezero_magic.status.xp", ReZeroMagicClient.xp, xpNeeded),
					x, y, 0xFFFFFFFF);
		} else {
			text(c, Text.translatable("screen.rezero_magic.status.xp_max"), x, y, 0xFFFFFFFF);
		}
		y += 16;
		text(c, Text.translatable("screen.rezero_magic.status.damage", (level - 1) * 6), x, y, 0xFFFFFFFF);
		y += 16;

		int aff = ReZeroMagicClient.affinity;
		if (aff >= 0) {
			text(c, Text.translatable("screen.rezero_magic.status.affinity", elementName(aff)),
					x, y, ELEMENT_COLORS[aff]);
		} else {
			text(c, Text.translatable("screen.rezero_magic.status.affinity_none"), x, y, 0xFFFF7070);
		}
		y += 16;
		text(c, Text.translatable("screen.rezero_magic.status.points", ReZeroMagicClient.points),
				x, y, 0xFFFFD34D);
		y += 16;
		text(c, Text.translatable("screen.rezero_magic.status.skills",
				Integer.bitCount(ReZeroMagicClient.skillMask), MagicData.SKILLS), x, y, 0xFFFFFFFF);

		wrap(c, Text.translatable("screen.rezero_magic.status.hint"), x, top + PANEL_H - 26, PANEL_W - 32, 0xFF9A9AB0);
	}

	private void drawAffinity(DrawContext c) {
		int current = ReZeroMagicClient.affinity;
		int points = ReZeroMagicClient.points;

		for (int e = 0; e < MagicData.ELEMENTS; e++) {
			int x = left + 14 + e * 112;
			text(c, elementName(e), x, top + 38, ELEMENT_COLORS[e]);
			wrap(c, Text.translatable("element.rezero_magic." + MagicData.ELEMENT_KEYS[e] + ".desc"),
					x, top + 52, COL_W, 0xFFDADAEA);

			ButtonWidget button = affinityButtons.get(e);
			if (current == e) {
				button.setMessage(Text.translatable("screen.rezero_magic.affinity.current"));
				button.active = false;
			} else if (current < 0) {
				button.setMessage(Text.translatable("screen.rezero_magic.affinity.choose"));
				button.active = true;
			} else {
				button.setMessage(Text.translatable("screen.rezero_magic.affinity.change"));
				button.active = points >= Progression.RESPEC_COST;
			}
		}

		wrap(c, Text.translatable("screen.rezero_magic.affinity.bonus"),
				left + 14, top + 126, PANEL_W - 28, 0xFFFFD34D);
		wrap(c, Text.translatable("screen.rezero_magic.affinity.note"),
				left + 14, top + 178, PANEL_W - 28, 0xFF9A9AB0);
		text(c, Text.translatable("screen.rezero_magic.skills.points", points),
				left + 14, top + PANEL_H - 14, 0xFFFFD34D);
	}

	private void drawSkills(DrawContext c) {
		int mask = ReZeroMagicClient.skillMask;
		int points = ReZeroMagicClient.points;
		int hovered = -1;

		for (int e = 0; e < MagicData.ELEMENTS; e++) {
			text(c, elementName(e), left + 14 + e * 112, top + 38, ELEMENT_COLORS[e]);
			for (int t = 0; t < 3; t++) {
				int id = e * 3 + t;
				ButtonWidget button = skillButtons.get(id);
				boolean unlocked = MagicData.has(mask, id);
				Text name = Text.translatable("skill.rezero_magic." + MagicData.ELEMENT_KEYS[e] + "." + t);
				button.setMessage(unlocked ? Text.literal("* ").append(name) : name);
				button.active = !unlocked && MagicData.prerequisiteMet(mask, id) && points >= 1;
				if (button.isHovered()) {
					hovered = id;
				}
			}
		}

		if (hovered >= 0) {
			int e = hovered / 3;
			int t = hovered % 3;
			String key = "skill.rezero_magic." + MagicData.ELEMENT_KEYS[e] + "." + t;
			text(c, Text.translatable(key), left + 14, top + 150, ELEMENT_COLORS[e]);
			wrap(c, Text.translatable(key + ".desc"), left + 14, top + 162, PANEL_W - 28, 0xFFDADAEA);
		} else {
			wrap(c, Text.translatable("screen.rezero_magic.skills.hint"),
					left + 14, top + 156, PANEL_W - 28, 0xFF9A9AB0);
		}
		text(c, Text.translatable("screen.rezero_magic.skills.points", points),
				left + 14, top + PANEL_H - 14, 0xFFFFD34D);
	}
}
