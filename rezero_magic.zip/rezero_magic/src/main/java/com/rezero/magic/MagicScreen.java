package com.rezero.magic;

import java.util.ArrayList;
import java.util.List;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;

/**
 * Menu de magia com quatro abas: Status, Afinidade (hexágono), Habilidades e Estatísticas.
 * Desenhado só com retângulos, texto e botões comuns (sem texturas).
 * Os botões e textos leem os dados mais recentes enviados pelo servidor a cada quadro.
 */
public class MagicScreen extends Screen {
	private static final int PANEL_W = 380;
	private static final int PANEL_H = 232;
	/** Fogo, água, terra, vento, yin, yang. */
	static final int[] COLORS = {0xFFFF8A3D, 0xFF5CB8FF, 0xFFC79A62, 0xFF9BE8C8, 0xFFB57BFF, 0xFFFFE27A};
	private static final String[] SPELL_KEYS = {"fireball", "ice_lance", "earth_spike", "wind_gust", "unseen_hand", "heal"};

	/** Elemento mostrado na aba de habilidades (guardado entre aberturas). */
	static int skillElement = 0;

	private final int tab;
	private int left;
	private int top;
	private final List<ButtonWidget> affinityButtons = new ArrayList<>();
	private final List<ButtonWidget> skillButtons = new ArrayList<>();

	public MagicScreen(int tab) {
		super(Text.translatable("screen.rezero_magic.title"));
		this.tab = tab;
	}

	@Override
	public boolean shouldPause() {
		// Sem pausar, o servidor integrado continua processando os cliques do menu.
		return false;
	}

	@Override
	protected void init() {
		left = (width - PANEL_W) / 2;
		top = (height - PANEL_H) / 2;
		affinityButtons.clear();
		skillButtons.clear();

		// Primeiro o fundo e os textos; os botões vêm depois e ficam por cima.
		addDrawable(this::drawContent);

		for (int i = 0; i < 4; i++) {
			final int target = i;
			ButtonWidget button = ButtonWidget.builder(
					Text.translatable("screen.rezero_magic.tab." + i),
					b -> MinecraftClient.getInstance().setScreen(new MagicScreen(target)))
					.dimensions(left + 10 + i * 92, top + 8, 88, 20)
					.build();
			button.active = i != tab;
			addDrawableChild(button);
		}

		if (tab == 1) {
			initAffinity();
		} else if (tab == 2) {
			initSkills();
		}
	}

	/** Seis botões dispostos em volta de um centro, como um hexágono. */
	private void initAffinity() {
		int cx = left + PANEL_W / 2;
		int cy = top + 112;
		int[][] offsets = {
				{-50, -78}, // fogo (topo)
				{60, -42},  // água (direita, em cima)
				{60, 14},   // terra (direita, embaixo)
				{-50, 50},  // vento (base)
				{-160, 14}, // yin (esquerda, embaixo)
				{-160, -42} // yang (esquerda, em cima)
		};
		for (int e = 0; e < MagicData.ELEMENTS; e++) {
			final int element = e;
			ButtonWidget button = ButtonWidget.builder(Text.empty(),
					b -> ClientPlayNetworking.send(new MenuActionPayload(0, element)))
					.dimensions(cx + offsets[e][0], cy + offsets[e][1], 100, 20)
					.build();
			affinityButtons.add(addDrawableChild(button));
		}
	}

	private void initSkills() {
		for (int e = 0; e < MagicData.ELEMENTS; e++) {
			final int element = e;
			ButtonWidget chip = ButtonWidget.builder(elementName(e), b -> {
				skillElement = element;
				MinecraftClient.getInstance().setScreen(new MagicScreen(2));
			}).dimensions(left + 10 + e * 60, top + 34, 58, 18).build();
			chip.active = e != skillElement;
			addDrawableChild(chip);
		}
		for (int t = 0; t < 3; t++) {
			final int id = skillElement * 3 + t;
			ButtonWidget button = ButtonWidget.builder(Text.empty(),
					b -> ClientPlayNetworking.send(new MenuActionPayload(1, id)))
					.dimensions(left + 14, top + 66 + t * 32, 190, 24)
					.build();
			skillButtons.add(addDrawableChild(button));
		}
	}

	// ------------------------------------------------------------ desenho

	private void drawContent(DrawContext c, int mouseX, int mouseY, float delta) {
		c.fill(left - 2, top - 2, left + PANEL_W + 2, top + PANEL_H + 2, 0xFF000000);
		c.fill(left, top, left + PANEL_W, top + PANEL_H, 0xEE1B1530);
		switch (tab) {
			case 0 -> drawStatus(c);
			case 1 -> drawAffinity(c);
			case 2 -> drawSkills(c);
			default -> drawStats(c);
		}
	}

	private void text(DrawContext c, Text t, int x, int y, int color) {
		c.drawTextWithShadow(textRenderer, t, x, y, color);
	}

	private void wrap(DrawContext c, Text t, int x, int y, int maxWidth, int color) {
		for (OrderedText line : textRenderer.wrapLines(t, maxWidth)) {
			c.drawTextWithShadow(textRenderer, line, x, y, color);
			y += 10;
		}
	}

	private Text elementName(int element) {
		return Text.translatable("element.rezero_magic." + MagicData.ELEMENT_KEYS[element]);
	}

	private Text rankName(int level) {
		return Text.translatable("rank.rezero_magic." + MagicData.rank(level));
	}

	private void drawStatus(DrawContext c) {
		int x = left + 16;
		int y = top + 42;
		int level = ReZeroMagicClient.level;
		int xpNeeded = ReZeroMagicClient.xpNeeded;

		text(c, Text.translatable("screen.rezero_magic.status.level", level, rankName(level)), x, y, 0xFFFFD34D);
		y += 16;
		text(c, Text.translatable("screen.rezero_magic.status.mana",
				ReZeroMagicClient.mana, ReZeroMagicClient.maxMana), x, y, 0xFF8FB4FF);
		y += 16;
		if (xpNeeded > 0) {
			text(c, Text.translatable("screen.rezero_magic.status.xp", ReZeroMagicClient.xp, xpNeeded),
					x, y, 0xFFFFFFFF);
		} else {
			text(c, Text.translatable("screen.rezero_magic.status.xp_max"), x, y, 0xFFFFFFFF);
		}
		y += 16;
		text(c, Text.translatable("screen.rezero_magic.status.biome", ReZeroMagicClient.biomePercent),
				x, y, 0xFF9BE8C8);
		y += 16;

		int aff = ReZeroMagicClient.affinity;
		if (aff >= 0) {
			text(c, Text.translatable("screen.rezero_magic.status.affinity", elementName(aff)),
					x, y, COLORS[aff]);
		} else {
			text(c, Text.translatable("screen.rezero_magic.status.affinity_none"), x, y, 0xFFFF7070);
		}
		y += 16;
		text(c, Text.translatable("screen.rezero_magic.status.points", ReZeroMagicClient.points),
				x, y, 0xFFFFD34D);
		y += 16;
		text(c, Text.translatable("screen.rezero_magic.status.skills",
				Integer.bitCount(ReZeroMagicClient.skillMask), MagicData.SKILLS), x, y, 0xFFFFFFFF);
		y += 16;
		text(c, Text.translatable("screen.rezero_magic.status.essence", ReZeroMagicClient.essence),
				x, y, 0xFFE8B8FF);

		wrap(c, Text.translatable("screen.rezero_magic.status.hint"), x, top + PANEL_H - 26, PANEL_W - 32, 0xFF9A9AB0);
	}

	private void drawAffinity(DrawContext c) {
		int current = ReZeroMagicClient.affinity;
		int essence = ReZeroMagicClient.essence;
		int cost = MagicConfig.affinityChangeCost();
		int hovered = -1;

		for (int e = 0; e < MagicData.ELEMENTS; e++) {
			ButtonWidget button = affinityButtons.get(e);
			if (current == e) {
				button.setMessage(Text.literal("* ").append(elementName(e)));
				button.active = false;
			} else {
				button.setMessage(elementName(e));
				button.active = current < 0 || essence >= cost;
			}
			if (button.isHovered()) {
				hovered = e;
			}
		}

		// descrição do elemento sob o mouse, no centro do hexágono
		int cx = left + PANEL_W / 2;
		if (hovered >= 0) {
			text(c, elementName(hovered), cx - 52, top + 62, COLORS[hovered]);
			wrap(c, Text.translatable("element.rezero_magic." + MagicData.ELEMENT_KEYS[hovered] + ".desc"),
					cx - 52, top + 76, 104, 0xFFDADAEA);
		} else {
			wrap(c, Text.translatable("screen.rezero_magic.affinity.hint"), cx - 52, top + 66, 104, 0xFF9A9AB0);
		}

		wrap(c, Text.translatable("screen.rezero_magic.affinity.bonus"),
				left + 14, top + 188, PANEL_W - 28, 0xFFFFD34D);
		Text costLine = current < 0
				? Text.translatable("screen.rezero_magic.affinity.first_free")
				: Text.translatable("screen.rezero_magic.affinity.cost", cost, essence);
		text(c, costLine, left + 14, top + PANEL_H - 14, 0xFFE8B8FF);
	}

	private void drawSkills(DrawContext c) {
		int mask = ReZeroMagicClient.skillMask;
		int points = ReZeroMagicClient.points;
		int e = skillElement;
		int hovered = -1;

		text(c, Text.translatable("screen.rezero_magic.skills.branch", elementName(e)),
				left + 14, top + 56, COLORS[e]);

		for (int t = 0; t < 3; t++) {
			int id = e * 3 + t;
			ButtonWidget button = skillButtons.get(t);
			boolean unlocked = MagicData.has(mask, id);
			Text name = Text.translatable("skill.rezero_magic." + MagicData.ELEMENT_KEYS[e] + "." + t);
			button.setMessage(unlocked ? Text.literal("* ").append(name) : name);
			button.active = !unlocked && MagicData.prerequisiteMet(mask, id) && points >= 1;
			if (button.isHovered()) {
				hovered = t;
			}
		}

		// linhas ligando as habilidades da coluna
		for (int t = 0; t < 2; t++) {
			boolean open = MagicData.has(mask, e * 3 + t);
			c.fill(left + 108, top + 90 + t * 32, left + 110, top + 98 + t * 32, open ? COLORS[e] : 0xFF55556A);
		}

		int infoX = left + 216;
		if (hovered >= 0) {
			String key = "skill.rezero_magic." + MagicData.ELEMENT_KEYS[e] + "." + hovered;
			text(c, Text.translatable(key), infoX, top + 58, COLORS[e]);
			wrap(c, Text.translatable(key + ".desc"), infoX, top + 72, PANEL_W - 216 - 14, 0xFFDADAEA);
		} else {
			wrap(c, Text.translatable("screen.rezero_magic.skills.hint"), infoX, top + 58, PANEL_W - 216 - 14, 0xFF9A9AB0);
		}
		text(c, Text.translatable("screen.rezero_magic.skills.points", points),
				left + 14, top + PANEL_H - 14, 0xFFFFD34D);
	}

	private void drawStats(DrawContext c) {
		int x = left + 16;
		int y = top + 42;
		text(c, Text.translatable("screen.rezero_magic.stats.kills", ReZeroMagicClient.kills), x, y, 0xFFFFFFFF);
		y += 16;
		text(c, Text.translatable("screen.rezero_magic.stats.deaths", ReZeroMagicClient.deaths), x, y, 0xFFFFFFFF);
		y += 16;
		text(c, Text.translatable("screen.rezero_magic.stats.damage", ReZeroMagicClient.damageDealt), x, y, 0xFFFFFFFF);
		y += 16;
		text(c, Text.translatable("screen.rezero_magic.stats.casts", ReZeroMagicClient.casts), x, y, 0xFFFFFFFF);
		y += 16;
		if (ReZeroMagicClient.casts > 0) {
			int fav = ReZeroMagicClient.mostUsed;
			text(c, Text.translatable("screen.rezero_magic.stats.favorite",
					Text.translatable("spell.rezero_magic." + SPELL_KEYS[Math.max(0, Math.min(5, fav))])),
					x, y, COLORS[Math.max(0, Math.min(5, fav))]);
		} else {
			text(c, Text.translatable("screen.rezero_magic.stats.favorite_none"), x, y, 0xFF9A9AB0);
		}
		y += 16;
		text(c, Text.translatable("screen.rezero_magic.status.essence", ReZeroMagicClient.essence),
				x, y, 0xFFE8B8FF);
		wrap(c, Text.translatable("screen.rezero_magic.stats.hint"),
				x, top + PANEL_H - 36, PANEL_W - 32, 0xFF9A9AB0);
	}
}
