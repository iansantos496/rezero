package com.rezero.magic;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Servidor -> cliente: afinidade (-1 = nenhuma), habilidades desbloqueadas (máscara de bits) e pontos livres. */
public record ProfileSyncPayload(int affinity, int skillMask, int points) implements CustomPayload {
	public static final CustomPayload.Id<ProfileSyncPayload> ID =
			new CustomPayload.Id<>(Identifier.of(ReZeroMagic.MOD_ID, "profile_sync"));

	public static final PacketCodec<RegistryByteBuf, ProfileSyncPayload> CODEC =
			PacketCodec.tuple(
					PacketCodecs.VAR_INT, ProfileSyncPayload::affinity,
					PacketCodecs.VAR_INT, ProfileSyncPayload::skillMask,
					PacketCodecs.VAR_INT, ProfileSyncPayload::points,
					ProfileSyncPayload::new);

	@Override
	public CustomPayload.Id<? extends CustomPayload> getId() {
		return ID;
	}
}
