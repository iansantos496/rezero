package com.rezero.magic;

import net.fabricmc.api.ModInitializer;

public class ReZeroMagic implements ModInitializer {
	public static final String MOD_ID = "rezero_magic";

	@Override
	public void onInitialize() {
		ModNetworking.registerCommon();
		Progression.init();
		TestCommands.init();
		ManaManager.init();
		SpellCaster.init();
	}
}
