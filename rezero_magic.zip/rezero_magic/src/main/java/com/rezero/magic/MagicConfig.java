package com.rezero.magic;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import net.fabricmc.loader.api.FabricLoader;

/**
 * Configuração em arquivo: config/rezero_magic.properties.
 * O arquivo é criado com os valores padrão na primeira execução; edite e reinicie o jogo para aplicar.
 */
public final class MagicConfig {
	static final String[] SPELLS = {"fireball", "ice_lance", "earth_spike", "wind_gust", "unseen_hand", "heal"};

	private static final int[] COST = {25, 15, 20, 18, 20, 30};
	private static final int[] COOLDOWN = {20, 8, 24, 16, 10, 40};
	private static final double[] DAMAGE = {1.0, 1.0, 1.0, 1.0, 1.0, 1.0};
	private static final int[] XP = {10, 8, 10, 9, 12, 8};

	private static int manaBase = 100;
	private static int manaPerLevel = 10;
	private static int regenInterval = 6;
	private static int xpBase = 40;
	private static int xpPerLevel = 20;
	private static double levelDamage = 0.06;
	private static int affinityChangeCost = 60;
	private static int killsPerEssence = 5;
	private static int essenceMilestone = 10;

	private static final Map<String, Double> BIOMES = new HashMap<>();

	static {
		BIOMES.put("forest", 1.5);
		BIOMES.put("jungle", 1.75);
		BIOMES.put("mountain", 1.5);
		BIOMES.put("ocean", 1.25);
		BIOMES.put("badlands", 0.75);
		BIOMES.put("nether", 0.75);
		BIOMES.put("end", 2.0);
	}

	private MagicConfig() {}

	private static Path file() {
		return FabricLoader.getInstance().getConfigDir().resolve("rezero_magic.properties");
	}

	public static void load() {
		Path path = file();
		boolean existed = Files.exists(path);
		Properties props = new Properties();
		if (existed) {
			try (InputStream in = Files.newInputStream(path)) {
				props.load(in);
			} catch (IOException e) {
				return;
			}
		}

		manaBase = Math.max(1, geti(props, "mana.base", manaBase));
		manaPerLevel = Math.max(0, geti(props, "mana.per_level", manaPerLevel));
		regenInterval = Math.max(1, geti(props, "mana.regen_interval_ticks", regenInterval));
		xpBase = Math.max(1, geti(props, "xp.base", xpBase));
		xpPerLevel = Math.max(0, geti(props, "xp.per_level", xpPerLevel));
		levelDamage = Math.max(0.0, getd(props, "damage.per_level", levelDamage));
		affinityChangeCost = Math.max(0, geti(props, "essence.affinity_change_cost", affinityChangeCost));
		killsPerEssence = Math.max(1, geti(props, "essence.kills_per_essence", killsPerEssence));
		essenceMilestone = Math.max(0, geti(props, "essence.level_milestone", essenceMilestone));

		for (int i = 0; i < SPELLS.length; i++) {
			String p = "spell." + SPELLS[i] + ".";
			COST[i] = Math.max(0, geti(props, p + "cost", COST[i]));
			COOLDOWN[i] = Math.max(0, geti(props, p + "cooldown_ticks", COOLDOWN[i]));
			DAMAGE[i] = Math.max(0.0, getd(props, p + "power", DAMAGE[i]));
			XP[i] = Math.max(0, geti(props, p + "xp", XP[i]));
		}
		for (String biome : BIOMES.keySet().toArray(new String[0])) {
			BIOMES.put(biome, Math.max(0.0, getd(props, "biome." + biome, BIOMES.get(biome))));
		}

		if (!existed) {
			writeDefaults(path);
		}
	}

	private static int geti(Properties p, String key, int def) {
		try {
			return Integer.parseInt(p.getProperty(key, Integer.toString(def)).trim());
		} catch (NumberFormatException e) {
			return def;
		}
	}

	private static double getd(Properties p, String key, double def) {
		try {
			return Double.parseDouble(p.getProperty(key, Double.toString(def)).trim());
		} catch (NumberFormatException e) {
			return def;
		}
	}

	private static void writeDefaults(Path path) {
		StringBuilder sb = new StringBuilder();
		sb.append("# Re:Zero Magic - configuracao (edite e reinicie o jogo)\n");
		sb.append("# 20 ticks = 1 segundo. power = multiplicador de dano/cura da magia (1.0 = padrao).\n\n");
		sb.append("mana.base=").append(manaBase).append('\n');
		sb.append("mana.per_level=").append(manaPerLevel).append('\n');
		sb.append("mana.regen_interval_ticks=").append(regenInterval).append('\n');
		sb.append("xp.base=").append(xpBase).append('\n');
		sb.append("xp.per_level=").append(xpPerLevel).append('\n');
		sb.append("damage.per_level=").append(levelDamage).append('\n');
		sb.append("essence.affinity_change_cost=").append(affinityChangeCost).append('\n');
		sb.append("essence.kills_per_essence=").append(killsPerEssence).append('\n');
		sb.append("essence.level_milestone=").append(essenceMilestone).append("\n\n");
		for (int i = 0; i < SPELLS.length; i++) {
			String p = "spell." + SPELLS[i] + ".";
			sb.append(p).append("cost=").append(COST[i]).append('\n');
			sb.append(p).append("cooldown_ticks=").append(COOLDOWN[i]).append('\n');
			sb.append(p).append("power=").append(DAMAGE[i]).append('\n');
			sb.append(p).append("xp=").append(XP[i]).append("\n\n");
		}
		sb.append("# multiplicador da regeneracao de mana por bioma\n");
		for (Map.Entry<String, Double> e : BIOMES.entrySet()) {
			sb.append("biome.").append(e.getKey()).append('=').append(e.getValue()).append('\n');
		}
		try {
			Files.writeString(path, sb.toString(), StandardCharsets.UTF_8);
		} catch (IOException ignored) {
			// sem permissão: segue com os valores padrão
		}
	}

	public static int cost(int spell) {
		return COST[spell];
	}

	public static int cooldown(int spell) {
		return COOLDOWN[spell];
	}

	public static float power(int spell) {
		return (float) DAMAGE[spell];
	}

	public static int xp(int spell) {
		return XP[spell];
	}

	public static int manaBase() {
		return manaBase;
	}

	public static int manaPerLevel() {
		return manaPerLevel;
	}

	public static int regenInterval() {
		return regenInterval;
	}

	public static int xpBase() {
		return xpBase;
	}

	public static int xpPerLevel() {
		return xpPerLevel;
	}

	public static float levelDamage() {
		return (float) levelDamage;
	}

	public static int affinityChangeCost() {
		return affinityChangeCost;
	}

	public static int killsPerEssence() {
		return killsPerEssence;
	}

	public static int essenceMilestone() {
		return essenceMilestone;
	}

	public static double biome(String name) {
		return BIOMES.getOrDefault(name, 1.0);
	}
}
