package com.rezero.magic;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.registry.tag.BiomeTags;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;

/**
 * Mana por jogador (em memória; volta a encher ao entrar no mundo).
 * O máximo cresce com o nível e a regeneração varia conforme o bioma.
 */
public final class ManaManager {
	/** Mana máxima padrão no nível 1 (o valor real vem da configuração). */
	public static final int MAX_MANA = 100;

	private static final Map<UUID, Integer> MANA = new HashMap<>();
	private static final Map<UUID, Double> REGEN_ACC = new HashMap<>();
	private static final Map<UUID, Integer> BIOME_PERCENT = new HashMap<>();

	private ManaManager() {}

	public static int max(ServerPlayerEntity player) {
		return Progression.maxMana(player);
	}

	public static int get(ServerPlayerEntity player) {
		return Math.min(MANA.getOrDefault(player.getUuid(), max(player)), max(player));
	}

	public static boolean consume(ServerPlayerEntity player, int amount) {
		int current = get(player);
		if (current < amount) {
			return false;
		}
		MANA.put(player.getUuid(), current - amount);
		sync(player);
		return true;
	}

	public static void refill(ServerPlayerEntity player) {
		MANA.put(player.getUuid(), max(player));
		sync(player);
	}

	public static void sync(ServerPlayerEntity player) {
		int level = Progression.level(player);
		ServerPlayNetworking.send(player, new ManaSyncPayload(
				get(player), max(player), level, Progression.xp(player), Progression.xpNeeded(level),
				BIOME_PERCENT.getOrDefault(player.getUuid(), 100)));
		ServerPlayNetworking.send(player, new ProfileSyncPayload(
				Progression.affinity(player), Progression.skillMask(player), Progression.points(player)));
		ServerPlayNetworking.send(player, new StatsSyncPayload(
				Progression.kills(player), Progression.deaths(player), Progression.damageDealt(player),
				Progression.essence(player), Progression.castsTotal(player), Progression.mostUsed(player)));
	}

	/** Multiplicador de regeneração conforme o bioma onde o jogador está. */
	private static double biomeMultiplier(ServerWorld world, ServerPlayerEntity player) {
		var biome = world.getBiome(player.getBlockPos());
		if (biome.isIn(BiomeTags.IS_END)) {
			return MagicConfig.biome("end");
		}
		if (biome.isIn(BiomeTags.IS_NETHER)) {
			return MagicConfig.biome("nether");
		}
		if (biome.isIn(BiomeTags.IS_JUNGLE)) {
			return MagicConfig.biome("jungle");
		}
		if (biome.isIn(BiomeTags.IS_FOREST)) {
			return MagicConfig.biome("forest");
		}
		if (biome.isIn(BiomeTags.IS_MOUNTAIN)) {
			return MagicConfig.biome("mountain");
		}
		if (biome.isIn(BiomeTags.IS_OCEAN)) {
			return MagicConfig.biome("ocean");
		}
		if (biome.isIn(BiomeTags.IS_BADLANDS)) {
			return MagicConfig.biome("badlands");
		}
		return 1.0;
	}

	public static void init() {
		ServerTickEvents.END_SERVER_TICK.register(server -> {
			if (server.getTicks() % MagicConfig.regenInterval() != 0) {
				return;
			}
			for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
				UUID id = player.getUuid();
				ServerWorld world = Compat.worldOf(server, player);
				double mult = world == null ? 1.0 : biomeMultiplier(world, player);
				BIOME_PERCENT.put(id, (int) Math.round(mult * 100.0));

				int current = get(player);
				int max = max(player);
				if (current < max) {
					double acc = REGEN_ACC.getOrDefault(id, 0.0) + Progression.regenAmount(player) * mult;
					int whole = (int) acc;
					REGEN_ACC.put(id, acc - whole);
					if (whole > 0) {
						MANA.put(id, Math.min(max, current + whole));
						sync(player);
					}
				}
			}
		});

		ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
			ServerPlayerEntity player = handler.getPlayer();
			refill(player);
			// Sem afinidade escolhida: pede ao cliente para abrir o menu na aba de Afinidade.
			if (Progression.affinity(player) < 0) {
				ServerPlayNetworking.send(player, new OpenMenuPayload(1));
			}
		});

		ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> refill(newPlayer));

		ServerLifecycleEvents.SERVER_STOPPED.register(server -> {
			MANA.clear();
			REGEN_ACC.clear();
			BIOME_PERCENT.clear();
		});
	}
}
