package com.rezero.magic;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

/** Mana por jogador (em memória; volta a encher ao entrar no mundo). O máximo cresce com o nível. */
public final class ManaManager {
	/** Mana máxima no nível 1. */
	public static final int MAX_MANA = 100;
	/** Regenera a cada N ticks (20 ticks = 1 segundo). */
	private static final int REGEN_INTERVAL_TICKS = 6;

	private static final Map<UUID, Integer> MANA = new HashMap<>();

	private ManaManager() {}

	public static int max(ServerPlayerEntity player) {
		return Progression.maxMana(player);
	}

	public static int get(ServerPlayerEntity player) {
		return Math.min(MANA.getOrDefault(player.getUuid(), max(player)), max(player));
	}

	public static boolean consume(ServerPlayerEntity player, int amount) {
		int current = get(player);
		if (current < amount) {
			return false;
		}
		MANA.put(player.getUuid(), current - amount);
		sync(player);
		return true;
	}

	public static void refill(ServerPlayerEntity player) {
		MANA.put(player.getUuid(), max(player));
		sync(player);
	}

	public static void sync(ServerPlayerEntity player) {
		int level = Progression.level(player);
		ServerPlayNetworking.send(player, new ManaSyncPayload(
				get(player), max(player), level, Progression.xp(player), Progression.xpNeeded(level)));
		ServerPlayNetworking.send(player, new ProfileSyncPayload(
				Progression.affinity(player), Progression.skillMask(player), Progression.points(player)));
	}

	public static void init() {
		ServerTickEvents.END_SERVER_TICK.register(server -> {
			if (server.getTicks() % REGEN_INTERVAL_TICKS != 0) {
				return;
			}
			for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
				int current = get(player);
				int max = max(player);
				if (current < max) {
					MANA.put(player.getUuid(), Math.min(max, current + Progression.regenAmount(player)));
					sync(player);
				}
			}
		});

		ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
			ServerPlayerEntity player = handler.getPlayer();
			refill(player);
			if (Progression.affinity(player) < 0) {
				player.sendMessage(Text.translatable("message.rezero_magic.choose_affinity"), false);
			}
		});

		ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> refill(newPlayer));

		ServerLifecycleEvents.SERVER_STOPPED.register(server -> MANA.clear());
	}
}
