package com.rezero.magic;

import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;

/** Efeitos visuais (só partículas) usados pelas magias. */
final class Fx {
	private Fx() {}

	static void circle(ServerWorld w, ParticleEffect p, double x, double y, double z, double r, int n) {
		for (int i = 0; i < n; i++) {
			double a = 2 * Math.PI * i / n;
			w.spawnParticles(p, x + Math.cos(a) * r, y, z + Math.sin(a) * r, 1, 0.0, 0.0, 0.0, 0.0);
		}
	}

	static void line(ServerWorld w, ParticleEffect p, Vec3d a, Vec3d b, int n) {
		for (int i = 0; i <= n; i++) {
			Vec3d q = a.lerp(b, i / (double) n);
			w.spawnParticles(p, q.x, q.y, q.z, 1, 0.0, 0.0, 0.0, 0.0);
		}
	}

	/** Círculo mágico no chão: dois anéis e uma estrela de seis pontas. */
	static void magicCircle(ServerWorld w, ParticleEffect outer, ParticleEffect inner,
			double x, double y, double z, double r) {
		circle(w, outer, x, y, z, r, 28);
		circle(w, inner, x, y, z, r * 0.62, 18);
		for (int tri = 0; tri < 2; tri++) {
			Vec3d[] v = new Vec3d[3];
			for (int k = 0; k < 3; k++) {
				double a = Math.PI * 2 * k / 3 + tri * Math.PI / 3;
				v[k] = new Vec3d(x + Math.cos(a) * r * 0.9, y, z + Math.sin(a) * r * 0.9);
			}
			line(w, inner, v[0], v[1], 6);
			line(w, inner, v[1], v[2], 6);
			line(w, inner, v[2], v[0], 6);
		}
	}

	/** Anel de partículas que se expande na horizontal. */
	static void burst(ServerWorld w, ParticleEffect p, Vec3d at, int n, double speed) {
		for (int i = 0; i < n; i++) {
			double a = 2 * Math.PI * i / n;
			// count = 0: dx/dy/dz viram a direção da partícula e speed a velocidade
			w.spawnParticles(p, at.x, at.y, at.z, 0, Math.cos(a), 0.05, Math.sin(a), speed);
		}
	}

	/** Espiral em volta de um projétil que se move na direção dir. */
	static void spiral(ServerWorld w, ParticleEffect p, Vec3d pos, Vec3d dir, int age, double r) {
		Vec3d d = dir.normalize();
		Vec3d right = d.crossProduct(new Vec3d(0.0, 1.0, 0.0));
		if (right.lengthSquared() < 1.0E-4) {
			right = new Vec3d(1.0, 0.0, 0.0);
		}
		right = right.normalize();
		Vec3d up = right.crossProduct(d).normalize();
		for (int s = 0; s < 2; s++) {
			Vec3d center = pos.subtract(dir.multiply(s * 0.5));
			for (int k = 0; k < 2; k++) {
				double a = (age + s * 0.5) * 0.9 + k * Math.PI;
				Vec3d off = right.multiply(Math.cos(a) * r).add(up.multiply(Math.sin(a) * r));
				w.spawnParticles(p, center.x + off.x, center.y + off.y, center.z + off.z,
						1, 0.0, 0.0, 0.0, 0.0);
			}
		}
	}

	/** Cristais de gelo que surgem do chão em volta do ponto de impacto. */
	static void icePillars(ServerWorld w, Vec3d at) {
		int count = 6;
		for (int i = 0; i < count; i++) {
			double a = 2 * Math.PI * i / count + Math.random() * 0.6;
			double dist = 0.8 + Math.random() * 1.2;
			double bx = at.x + Math.cos(a) * dist;
			double bz = at.z + Math.sin(a) * dist;
			double height = 1.2 + Math.random() * 1.4;
			for (double h = 0.0; h <= height; h += 0.25) {
				w.spawnParticles(ParticleTypes.END_ROD, bx, at.y - 0.4 + h, bz, 1, 0.03, 0.0, 0.03, 0.0);
				w.spawnParticles(ParticleTypes.SNOWFLAKE, bx, at.y - 0.4 + h, bz, 1, 0.08, 0.0, 0.08, 0.0);
			}
			w.spawnParticles(ParticleTypes.END_ROD, bx, at.y - 0.4 + height + 0.15, bz, 2, 0.05, 0.05, 0.05, 0.0);
		}
	}

	/** Várias "mãos" escuras ondulando do peito do jogador até o alvo. */
	static void hands(ServerWorld w, Vec3d from, Vec3d to, int age) {
		Vec3d dir = to.subtract(from);
		if (dir.lengthSquared() < 0.01) {
			return;
		}
		Vec3d d = dir.normalize();
		Vec3d right = d.crossProduct(new Vec3d(0.0, 1.0, 0.0));
		if (right.lengthSquared() < 1.0E-4) {
			right = new Vec3d(1.0, 0.0, 0.0);
		}
		right = right.normalize();
		Vec3d up = right.crossProduct(d).normalize();

		int hands = 4;
		int steps = 10;
		for (int h = 0; h < hands; h++) {
			double phase = age * 0.25 + h * (Math.PI * 2 / hands);
			for (int i = 1; i <= steps; i++) {
				double t = i / (double) steps;
				double amp = 0.55 * Math.sin(t * Math.PI);
				Vec3d p = from.lerp(to, t)
						.add(right.multiply(Math.cos(phase + t * 4.0) * amp))
						.add(up.multiply(Math.sin(phase + t * 4.0) * amp));
				w.spawnParticles(ParticleTypes.WITCH, p.x, p.y, p.z, 1, 0.0, 0.0, 0.0, 0.0);
				if (i % 3 == 0) {
					w.spawnParticles(ParticleTypes.SQUID_INK, p.x, p.y, p.z, 1, 0.02, 0.02, 0.02, 0.0);
				}
			}
			// "dedos" na ponta, junto do alvo
			double fa = phase;
			w.spawnParticles(ParticleTypes.SQUID_INK,
					to.x + Math.cos(fa) * 0.5, to.y + Math.sin(fa * 1.3) * 0.4, to.z + Math.sin(fa) * 0.5,
					1, 0.0, 0.0, 0.0, 0.0);
		}

		// pulso de energia viajando do jogador até o alvo
		double pulse = (age % 12) / 12.0;
		Vec3d pp = from.lerp(to, pulse);
		w.spawnParticles(ParticleTypes.ENCHANT, pp.x, pp.y, pp.z, 4, 0.1, 0.1, 0.1, 0.02);
	}
}
