package com.rezero.magic;

/**
 * Dados compartilhados entre cliente e servidor.
 * Elemento = índice da magia: 0 fogo, 1 água (gelo), 2 terra, 3 vento, 4 yin, 5 yang.
 * Habilidade: id = elemento * 3 + nível (0, 1, 2); cada uma exige a anterior do mesmo elemento.
 */
public final class MagicData {
	public static final int ELEMENTS = 6;
	public static final int SKILLS = 18;
	public static final String[] ELEMENT_KEYS = {"fire", "water", "earth", "wind", "yin", "yang"};

	private MagicData() {}

	public static boolean has(int mask, int id) {
		return id >= 0 && id < SKILLS && ((mask >> id) & 1) != 0;
	}

	public static boolean prerequisiteMet(int mask, int id) {
		return id % 3 == 0 || has(mask, id - 1);
	}

	/** Custo de mana: -20% na afinidade principal, +20% nas outras (sem afinidade, custo base). */
	public static int cost(int base, int affinity, int spell) {
		if (affinity < 0) {
			return base;
		}
		double factor = affinity == spell ? 0.8 : 1.2;
		return Math.max(1, (int) Math.round(base * factor));
	}

	/** Rank de mago pelo nível: 0 Aprendiz, 1 Mago, 2 Mago Superior, 3 Mestre, 4 Arquimago. */
	public static int rank(int level) {
		if (level >= 20) {
			return 4;
		}
		if (level >= 15) {
			return 3;
		}
		if (level >= 10) {
			return 2;
		}
		return level >= 5 ? 1 : 0;
	}
}
