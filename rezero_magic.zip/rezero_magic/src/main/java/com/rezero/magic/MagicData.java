package com.rezero.magic;

/**
 * Dados compartilhados entre cliente e servidor.
 * Elemento = índice da magia: 0 fogo (Bola de Fogo), 1 gelo (Lança de Gelo), 2 yin (Mãos Invisíveis).
 * Habilidade: id = elemento * 3 + nível (0, 1, 2); cada uma exige a anterior do mesmo elemento.
 */
public final class MagicData {
	public static final int ELEMENTS = 3;
	public static final int SKILLS = 9;
	public static final String[] ELEMENT_KEYS = {"fire", "ice", "yin"};
	public static final int[] BASE_COST = {25, 15, 20};

	private MagicData() {}

	public static boolean has(int mask, int id) {
		return id >= 0 && id < SKILLS && ((mask >> id) & 1) != 0;
	}

	public static boolean prerequisiteMet(int mask, int id) {
		return id % 3 == 0 || has(mask, id - 1);
	}

	/** Custo de mana: -20% na afinidade principal, +20% nas outras (sem afinidade, custo base). */
	public static int cost(int base, int affinity, int spell) {
		if (affinity < 0) {
			return base;
		}
		double factor = affinity == spell ? 0.8 : 1.2;
		return Math.max(1, (int) Math.round(base * factor));
	}
}
