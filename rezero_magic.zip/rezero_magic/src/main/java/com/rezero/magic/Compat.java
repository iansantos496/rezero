package com.rezero.magic;

import net.minecraft.entity.Entity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.world.ServerWorld;

/**
 * Funções que dependem de nomes de API que mudam entre versões do Minecraft ficam aqui,
 * para que um eventual ajuste seja feito em um único lugar.
 */
final class Compat {
	private Compat() {}

	/** Descobre em qual ServerWorld a entidade está, sem depender de getWorld()/getEntityWorld(). */
	static ServerWorld worldOf(MinecraftServer server, Entity entity) {
		for (ServerWorld world : server.getWorlds()) {
			if (world.getEntity(entity.getUuid()) == entity) {
				return world;
			}
		}
		return null;
	}
}
