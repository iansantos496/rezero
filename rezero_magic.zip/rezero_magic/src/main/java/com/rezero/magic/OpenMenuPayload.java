package com.rezero.magic;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Servidor -> cliente: abre o menu de magia na aba indicada (usado para escolher a afinidade ao entrar). */
public record OpenMenuPayload(int tab) implements CustomPayload {
	public static final CustomPayload.Id<OpenMenuPayload> ID =
			new CustomPayload.Id<>(Identifier.of(ReZeroMagic.MOD_ID, "open_menu"));

	public static final PacketCodec<RegistryByteBuf, OpenMenuPayload> CODEC =
			PacketCodec.tuple(PacketCodecs.VAR_INT, OpenMenuPayload::tab, OpenMenuPayload::new);

	@Override
	public CustomPayload.Id<? extends CustomPayload> getId() {
		return ID;
	}
}
