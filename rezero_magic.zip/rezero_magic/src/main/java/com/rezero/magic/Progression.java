package com.rezero.magic;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;

/**
 * Nível, XP, afinidade e habilidades por jogador. Cada magia lançada dá XP; cada nível dá 1 ponto.
 * O progresso é salvo em config/rezero_magic_progress.properties (vale para todos os mundos).
 */
public final class Progression {
	public static final int MAX_LEVEL = 20;
	/** Custo, em pontos, de trocar de afinidade depois da primeira escolha. */
	public static final int RESPEC_COST = 2;

	private static final int LEVEL = 0;
	private static final int XP = 1;
	private static final int AFFINITY = 2;
	private static final int SKILL_MASK = 3;
	private static final int RESPEC_SPENT = 4;

	private static final Map<UUID, int[]> DATA = new HashMap<>();

	private Progression() {}

	private static int[] fresh() {
		return new int[] {1, 0, -1, 0, 0};
	}

	private static Path file() {
		return FabricLoader.getInstance().getConfigDir().resolve("rezero_magic_progress.properties");
	}

	public static void init() {
		ServerLifecycleEvents.SERVER_STARTED.register(server -> load());
		ServerLifecycleEvents.SERVER_STOPPING.register(server -> save());
	}

	private static void load() {
		DATA.clear();
		Path path = file();
		if (!Files.exists(path)) {
			return;
		}
		Properties props = new Properties();
		try (InputStream in = Files.newInputStream(path)) {
			props.load(in);
		} catch (IOException e) {
			return;
		}
		for (String key : props.stringPropertyNames()) {
			if (!key.endsWith(".level")) {
				continue;
			}
			try {
				String id = key.substring(0, key.length() - ".level".length());
				UUID uuid = UUID.fromString(id);
				int level = Integer.parseInt(props.getProperty(key));
				int[] d = fresh();
				d[LEVEL] = Math.max(1, Math.min(MAX_LEVEL, level));
				d[XP] = Math.max(0, Integer.parseInt(props.getProperty(id + ".xp", "0")));
				int aff = Integer.parseInt(props.getProperty(id + ".affinity", "-1"));
				d[AFFINITY] = aff >= 0 && aff < MagicData.ELEMENTS ? aff : -1;
				d[SKILL_MASK] = Integer.parseInt(props.getProperty(id + ".skills", "0")) & ((1 << MagicData.SKILLS) - 1);
				d[RESPEC_SPENT] = Math.max(0, Integer.parseInt(props.getProperty(id + ".respec", "0")));
				DATA.put(uuid, d);
			} catch (IllegalArgumentException ignored) {
				// linha inválida: ignora
			}
		}
	}

	public static void save() {
		Properties props = new Properties();
		for (Map.Entry<UUID, int[]> e : DATA.entrySet()) {
			String id = e.getKey().toString();
			int[] d = e.getValue();
			props.setProperty(id + ".level", Integer.toString(d[LEVEL]));
			props.setProperty(id + ".xp", Integer.toString(d[XP]));
			props.setProperty(id + ".affinity", Integer.toString(d[AFFINITY]));
			props.setProperty(id + ".skills", Integer.toString(d[SKILL_MASK]));
			props.setProperty(id + ".respec", Integer.toString(d[RESPEC_SPENT]));
		}
		try (OutputStream out = Files.newOutputStream(file())) {
			props.store(out, "Re:Zero Magic - progresso dos jogadores");
		} catch (IOException ignored) {
			// sem permissão de escrita: o progresso só vale nesta sessão
		}
	}

	private static int[] data(ServerPlayerEntity player) {
		return DATA.computeIfAbsent(player.getUuid(), k -> fresh());
	}

	// ------------------------------------------------------------ consultas

	public static int level(ServerPlayerEntity player) {
		return data(player)[LEVEL];
	}

	public static int xp(ServerPlayerEntity player) {
		return data(player)[XP];
	}

	public static int affinity(ServerPlayerEntity player) {
		return data(player)[AFFINITY];
	}

	public static int skillMask(ServerPlayerEntity player) {
		return data(player)[SKILL_MASK];
	}

	public static boolean hasSkill(ServerPlayerEntity player, int id) {
		return MagicData.has(skillMask(player), id);
	}

	/** Pontos de habilidade livres: 1 por nível, menos o que já foi gasto. */
	public static int points(ServerPlayerEntity player) {
		int[] d = data(player);
		return Math.max(0, d[LEVEL] - 1 - Integer.bitCount(d[SKILL_MASK]) - d[RESPEC_SPENT]);
	}

	/** XP necessário para sair deste nível (0 no nível máximo). */
	public static int xpNeeded(int level) {
		return level >= MAX_LEVEL ? 0 : 40 + level * 20;
	}

	public static int maxMana(ServerPlayerEntity player) {
		return ManaManager.MAX_MANA + (level(player) - 1) * 10;
	}

	/** Bônus de dano só por nível. */
	public static float damageMultiplier(ServerPlayerEntity player) {
		return 1.0f + (level(player) - 1) * 0.06f;
	}

	/** Dano total de uma magia: nível x afinidade (+25% na principal, -10% nas outras). */
	public static float spellMultiplier(ServerPlayerEntity player, int spell) {
		int aff = affinity(player);
		float factor = aff < 0 ? 1.0f : (aff == spell ? 1.25f : 0.9f);
		return damageMultiplier(player) * factor;
	}

	/** Quanto de mana volta a cada intervalo de regeneração. */
	public static int regenAmount(ServerPlayerEntity player) {
		return 1 + (level(player) - 1) / 7;
	}

	// ------------------------------------------------------------- ações

	public static boolean chooseAffinity(ServerPlayerEntity player, int element) {
		if (element < 0 || element >= MagicData.ELEMENTS) {
			return false;
		}
		int[] d = data(player);
		if (d[AFFINITY] == element) {
			return false;
		}
		if (d[AFFINITY] >= 0) {
			if (points(player) < RESPEC_COST) {
				return false;
			}
			d[RESPEC_SPENT] += RESPEC_COST;
		}
		d[AFFINITY] = element;
		save();
		ManaManager.sync(player);
		return true;
	}

	public static boolean unlockSkill(ServerPlayerEntity player, int id) {
		if (id < 0 || id >= MagicData.SKILLS) {
			return false;
		}
		int[] d = data(player);
		if (MagicData.has(d[SKILL_MASK], id)
				|| !MagicData.prerequisiteMet(d[SKILL_MASK], id)
				|| points(player) < 1) {
			return false;
		}
		d[SKILL_MASK] |= 1 << id;
		save();
		ManaManager.sync(player);
		return true;
	}

	/** Para testes: define o nível diretamente (zera o XP). Se faltarem pontos, as habilidades são devolvidas. */
	public static void setLevel(ServerPlayerEntity player, int level) {
		int[] d = data(player);
		d[LEVEL] = Math.max(1, Math.min(MAX_LEVEL, level));
		d[XP] = 0;
		if (Integer.bitCount(d[SKILL_MASK]) + d[RESPEC_SPENT] > d[LEVEL] - 1) {
			d[SKILL_MASK] = 0;
			d[RESPEC_SPENT] = 0;
		}
		save();
		ManaManager.refill(player);
	}

	/** Para testes: apaga todo o progresso do jogador. */
	public static void reset(ServerPlayerEntity player) {
		DATA.put(player.getUuid(), fresh());
		save();
		ManaManager.refill(player);
	}

	public static void addXp(ServerWorld world, ServerPlayerEntity player, int amount) {
		int[] d = data(player);
		if (d[LEVEL] >= MAX_LEVEL) {
			return;
		}
		d[XP] += amount;
		boolean levelUp = false;
		while (d[LEVEL] < MAX_LEVEL && d[XP] >= xpNeeded(d[LEVEL])) {
			d[XP] -= xpNeeded(d[LEVEL]);
			d[LEVEL]++;
			levelUp = true;
		}
		if (d[LEVEL] >= MAX_LEVEL) {
			d[XP] = 0;
		}

		if (levelUp) {
			player.sendMessage(Text.translatable("message.rezero_magic.level_up", d[LEVEL]), false);
			world.playSound(null, player.getX(), player.getY(), player.getZ(),
					SoundEvents.ENTITY_PLAYER_LEVELUP, SoundCategory.PLAYERS, 1.0f, 1.0f);
			Fx.magicCircle(world, ParticleTypes.END_ROD, ParticleTypes.ENCHANT,
					player.getX(), player.getY() + 0.1, player.getZ(), 1.8);
			world.spawnParticles(ParticleTypes.ENCHANT, player.getX(), player.getY() + 1.0, player.getZ(),
					40, 0.6, 0.8, 0.6, 0.5);
			save();
			ManaManager.refill(player);
		} else {
			ManaManager.sync(player);
		}
	}
}
