package com.rezero.magic;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;

/**
 * Nível, XP, afinidade, habilidades, Essências e estatísticas por jogador.
 * Cada magia lançada dá XP; cada nível dá 1 ponto de habilidade.
 * A troca de afinidade custa Essências (config), ganhas por marcos de nível e por abates.
 * O progresso é salvo em config/rezero_magic_progress.properties (vale para todos os mundos).
 */
public final class Progression {
	public static final int MAX_LEVEL = 20;

	private static final int LEVEL = 0;
	private static final int XP = 1;
	private static final int AFFINITY = 2;
	private static final int SKILL_MASK = 3;
	private static final int KILLS = 4;
	private static final int DEATHS = 5;
	private static final int DAMAGE = 6;
	private static final int ESSENCE = 7;
	private static final int CASTS = 8; // 6 posições: uma por magia
	private static final int SIZE = CASTS + MagicConfig.SPELLS.length;

	private static final Map<UUID, int[]> DATA = new HashMap<>();

	private Progression() {}

	private static int[] fresh() {
		int[] d = new int[SIZE];
		d[LEVEL] = 1;
		d[AFFINITY] = -1;
		return d;
	}

	private static Path file() {
		return FabricLoader.getInstance().getConfigDir().resolve("rezero_magic_progress.properties");
	}

	public static void init() {
		ServerLifecycleEvents.SERVER_STARTED.register(server -> load());
		ServerLifecycleEvents.SERVER_STOPPING.register(server -> save());

		ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
			if (entity instanceof ServerPlayerEntity dead) {
				data(dead)[DEATHS]++;
				ManaManager.sync(dead);
			} else if (source.getAttacker() instanceof ServerPlayerEntity killer) {
				addKill(killer);
			}
		});
	}

	// ---------------------------------------------------------- arquivo

	private static void load() {
		DATA.clear();
		Path path = file();
		if (!Files.exists(path)) {
			return;
		}
		Properties props = new Properties();
		try (InputStream in = Files.newInputStream(path)) {
			props.load(in);
		} catch (IOException e) {
			return;
		}
		for (String key : props.stringPropertyNames()) {
			if (!key.endsWith(".level")) {
				continue;
			}
			try {
				String id = key.substring(0, key.length() - ".level".length());
				UUID uuid = UUID.fromString(id);
				int[] d = fresh();
				d[LEVEL] = Math.max(1, Math.min(MAX_LEVEL, Integer.parseInt(props.getProperty(key))));
				d[XP] = Math.max(0, Integer.parseInt(props.getProperty(id + ".xp", "0")));
				int aff = Integer.parseInt(props.getProperty(id + ".affinity", "-1"));
				d[AFFINITY] = aff >= 0 && aff < MagicData.ELEMENTS ? aff : -1;
				d[SKILL_MASK] = Integer.parseInt(props.getProperty(id + ".skills", "0")) & ((1 << MagicData.SKILLS) - 1);
				d[KILLS] = Math.max(0, Integer.parseInt(props.getProperty(id + ".kills", "0")));
				d[DEATHS] = Math.max(0, Integer.parseInt(props.getProperty(id + ".deaths", "0")));
				d[DAMAGE] = Math.max(0, Integer.parseInt(props.getProperty(id + ".damage", "0")));
				d[ESSENCE] = Math.max(0, Integer.parseInt(props.getProperty(id + ".essence", "0")));
				String[] casts = props.getProperty(id + ".casts", "").split(",");
				for (int i = 0; i < casts.length && i < MagicConfig.SPELLS.length; i++) {
					d[CASTS + i] = Math.max(0, Integer.parseInt(casts[i].trim()));
				}
				// ids de habilidade que não cabem nos pontos do nível: devolve tudo
				if (Integer.bitCount(d[SKILL_MASK]) > d[LEVEL] - 1) {
					d[SKILL_MASK] = 0;
				}
				DATA.put(uuid, d);
			} catch (IllegalArgumentException ignored) {
				// linha inválida: ignora
			}
		}
	}

	public static void save() {
		Properties props = new Properties();
		for (Map.Entry<UUID, int[]> e : DATA.entrySet()) {
			String id = e.getKey().toString();
			int[] d = e.getValue();
			props.setProperty(id + ".level", Integer.toString(d[LEVEL]));
			props.setProperty(id + ".xp", Integer.toString(d[XP]));
			props.setProperty(id + ".affinity", Integer.toString(d[AFFINITY]));
			props.setProperty(id + ".skills", Integer.toString(d[SKILL_MASK]));
			props.setProperty(id + ".kills", Integer.toString(d[KILLS]));
			props.setProperty(id + ".deaths", Integer.toString(d[DEATHS]));
			props.setProperty(id + ".damage", Integer.toString(d[DAMAGE]));
			props.setProperty(id + ".essence", Integer.toString(d[ESSENCE]));
			StringBuilder casts = new StringBuilder();
			for (int i = 0; i < MagicConfig.SPELLS.length; i++) {
				if (i > 0) {
					casts.append(',');
				}
				casts.append(d[CASTS + i]);
			}
			props.setProperty(id + ".casts", casts.toString());
		}
		try (OutputStream out = Files.newOutputStream(file())) {
			props.store(out, "Re:Zero Magic - progresso dos jogadores");
		} catch (IOException ignored) {
			// sem permissão de escrita: o progresso só vale nesta sessão
		}
	}

	private static int[] data(ServerPlayerEntity player) {
		return DATA.computeIfAbsent(player.getUuid(), k -> fresh());
	}

	// ------------------------------------------------------------ consultas

	public static int level(ServerPlayerEntity player) {
		return data(player)[LEVEL];
	}

	public static int xp(ServerPlayerEntity player) {
		return data(player)[XP];
	}

	public static int affinity(ServerPlayerEntity player) {
		return data(player)[AFFINITY];
	}

	public static int skillMask(ServerPlayerEntity player) {
		return data(player)[SKILL_MASK];
	}

	public static boolean hasSkill(ServerPlayerEntity player, int id) {
		return MagicData.has(skillMask(player), id);
	}

	public static int essence(ServerPlayerEntity player) {
		return data(player)[ESSENCE];
	}

	public static int kills(ServerPlayerEntity player) {
		return data(player)[KILLS];
	}

	public static int deaths(ServerPlayerEntity player) {
		return data(player)[DEATHS];
	}

	public static int damageDealt(ServerPlayerEntity player) {
		return data(player)[DAMAGE];
	}

	public static int castsTotal(ServerPlayerEntity player) {
		int[] d = data(player);
		int total = 0;
		for (int i = 0; i < MagicConfig.SPELLS.length; i++) {
			total += d[CASTS + i];
		}
		return total;
	}

	public static int mostUsed(ServerPlayerEntity player) {
		int[] d = data(player);
		int best = 0;
		for (int i = 1; i < MagicConfig.SPELLS.length; i++) {
			if (d[CASTS + i] > d[CASTS + best]) {
				best = i;
			}
		}
		return best;
	}

	/** Pontos de habilidade livres: 1 por nível, menos o que já foi gasto. */
	public static int points(ServerPlayerEntity player) {
		int[] d = data(player);
		return Math.max(0, d[LEVEL] - 1 - Integer.bitCount(d[SKILL_MASK]));
	}

	/** XP necessário para sair deste nível (0 no nível máximo). */
	public static int xpNeeded(int level) {
		return level >= MAX_LEVEL ? 0 : MagicConfig.xpBase() + level * MagicConfig.xpPerLevel();
	}

	public static int maxMana(ServerPlayerEntity player) {
		return MagicConfig.manaBase() + (level(player) - 1) * MagicConfig.manaPerLevel();
	}

	/** Bônus de dano só por nível. */
	public static float damageMultiplier(ServerPlayerEntity player) {
		return 1.0f + (level(player) - 1) * MagicConfig.levelDamage();
	}

	/** Poder total de uma magia: nível x afinidade (+25% na principal, -10% nas outras) x config. */
	public static float spellMultiplier(ServerPlayerEntity player, int spell) {
		int aff = affinity(player);
		float factor = aff < 0 ? 1.0f : (aff == spell ? 1.25f : 0.9f);
		return damageMultiplier(player) * factor * MagicConfig.power(spell);
	}

	/** Quanto de mana volta a cada intervalo de regeneração. */
	public static int regenAmount(ServerPlayerEntity player) {
		return 1 + (level(player) - 1) / 7;
	}

	// ------------------------------------------------------------- ações

	public static boolean chooseAffinity(ServerPlayerEntity player, int element) {
		if (element < 0 || element >= MagicData.ELEMENTS) {
			return false;
		}
		int[] d = data(player);
		if (d[AFFINITY] == element) {
			return false;
		}
		if (d[AFFINITY] >= 0) {
			int cost = MagicConfig.affinityChangeCost();
			if (d[ESSENCE] < cost) {
				return false;
			}
			d[ESSENCE] -= cost;
		}
		d[AFFINITY] = element;
		save();
		ManaManager.sync(player);
		return true;
	}

	public static boolean unlockSkill(ServerPlayerEntity player, int id) {
		if (id < 0 || id >= MagicData.SKILLS) {
			return false;
		}
		int[] d = data(player);
		if (MagicData.has(d[SKILL_MASK], id)
				|| !MagicData.prerequisiteMet(d[SKILL_MASK], id)
				|| points(player) < 1) {
			return false;
		}
		d[SKILL_MASK] |= 1 << id;
		save();
		ManaManager.sync(player);
		return true;
	}

	public static void addEssence(ServerPlayerEntity player, int amount) {
		int[] d = data(player);
		d[ESSENCE] = Math.max(0, d[ESSENCE] + amount);
		save();
		ManaManager.sync(player);
	}

	public static void addCast(ServerPlayerEntity player, int spell) {
		data(player)[CASTS + spell]++;
	}

	public static void addDamage(ServerPlayerEntity player, float amount) {
		data(player)[DAMAGE] += Math.round(amount);
	}

	private static void addKill(ServerPlayerEntity player) {
		int[] d = data(player);
		d[KILLS]++;
		if (d[KILLS] % MagicConfig.killsPerEssence() == 0) {
			d[ESSENCE]++;
		}
		ManaManager.sync(player);
	}

	/** Para testes: define o nível diretamente (zera o XP). Se faltarem pontos, as habilidades são devolvidas. */
	public static void setLevel(ServerPlayerEntity player, int level) {
		int[] d = data(player);
		d[LEVEL] = Math.max(1, Math.min(MAX_LEVEL, level));
		d[XP] = 0;
		if (Integer.bitCount(d[SKILL_MASK]) > d[LEVEL] - 1) {
			d[SKILL_MASK] = 0;
		}
		save();
		ManaManager.refill(player);
	}

	/** Para testes: apaga todo o progresso do jogador. */
	public static void reset(ServerPlayerEntity player) {
		DATA.put(player.getUuid(), fresh());
		save();
		ManaManager.refill(player);
	}

	public static void addXp(ServerWorld world, ServerPlayerEntity player, int amount) {
		int[] d = data(player);
		if (d[LEVEL] >= MAX_LEVEL) {
			return;
		}
		d[XP] += amount;
		boolean levelUp = false;
		while (d[LEVEL] < MAX_LEVEL && d[XP] >= xpNeeded(d[LEVEL])) {
			d[XP] -= xpNeeded(d[LEVEL]);
			d[LEVEL]++;
			levelUp = true;
			if (d[LEVEL] % 5 == 0) {
				d[ESSENCE] += MagicConfig.essenceMilestone();
			}
		}
		if (d[LEVEL] >= MAX_LEVEL) {
			d[XP] = 0;
		}

		if (levelUp) {
			player.sendMessage(Text.translatable("message.rezero_magic.level_up", d[LEVEL]), false);
			world.playSound(null, player.getX(), player.getY(), player.getZ(),
					SoundEvents.ENTITY_PLAYER_LEVELUP, SoundCategory.PLAYERS, 1.0f, 1.0f);
			Fx.magicCircle(world, ParticleTypes.END_ROD, ParticleTypes.ENCHANT,
					player.getX(), player.getY() + 0.1, player.getZ(), 1.8);
			world.spawnParticles(ParticleTypes.ENCHANT, player.getX(), player.getY() + 1.0, player.getZ(),
					40, 0.6, 0.8, 0.6, 0.5);
			save();
			ManaManager.refill(player);
		} else {
			ManaManager.sync(player);
		}
	}
}
