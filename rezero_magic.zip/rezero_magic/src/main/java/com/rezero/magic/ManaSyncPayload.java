package com.rezero.magic;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Servidor -> cliente: mana, nível e XP, para o HUD. xpNeeded = 0 no nível máximo. */
public record ManaSyncPayload(int mana, int maxMana, int level, int xp, int xpNeeded) implements CustomPayload {
	public static final CustomPayload.Id<ManaSyncPayload> ID =
			new CustomPayload.Id<>(Identifier.of(ReZeroMagic.MOD_ID, "mana_sync"));

	public static final PacketCodec<RegistryByteBuf, ManaSyncPayload> CODEC =
			PacketCodec.tuple(
					PacketCodecs.VAR_INT, ManaSyncPayload::mana,
					PacketCodecs.VAR_INT, ManaSyncPayload::maxMana,
					PacketCodecs.VAR_INT, ManaSyncPayload::level,
					PacketCodecs.VAR_INT, ManaSyncPayload::xp,
					PacketCodecs.VAR_INT, ManaSyncPayload::xpNeeded,
					ManaSyncPayload::new);

	@Override
	public CustomPayload.Id<? extends CustomPayload> getId() {
		return ID;
	}
}
