package com.rezero.magic;

import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.network.ServerPlayerEntity;

public final class ModNetworking {
	private ModNetworking() {}

	public static void registerCommon() {
		PayloadTypeRegistry.playC2S().register(CastSpellPayload.ID, CastSpellPayload.CODEC);
		PayloadTypeRegistry.playC2S().register(MenuActionPayload.ID, MenuActionPayload.CODEC);
		PayloadTypeRegistry.playS2C().register(ManaSyncPayload.ID, ManaSyncPayload.CODEC);
		PayloadTypeRegistry.playS2C().register(ProfileSyncPayload.ID, ProfileSyncPayload.CODEC);

		ServerPlayNetworking.registerGlobalReceiver(CastSpellPayload.ID, (payload, context) ->
				SpellCaster.cast(context.server(), context.player(), payload.spell()));

		ServerPlayNetworking.registerGlobalReceiver(MenuActionPayload.ID, (payload, context) -> {
			ServerPlayerEntity player = context.player();
			if (payload.action() == 0) {
				Progression.chooseAffinity(player, payload.arg());
			} else if (payload.action() == 1) {
				Progression.unlockSkill(player, payload.arg());
			}
		});
	}
}
