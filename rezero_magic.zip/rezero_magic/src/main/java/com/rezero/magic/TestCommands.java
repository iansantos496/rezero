package com.rezero.magic;

import com.mojang.brigadier.arguments.IntegerArgumentType;

import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

/** Comandos de teste: /rezero nivel <1-20>, /rezero essencia <n> e /rezero resetar. */
final class TestCommands {
	private TestCommands() {}

	static void init() {
		CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
				dispatcher.register(CommandManager.literal("rezero")
						.then(CommandManager.literal("nivel")
								.then(CommandManager.argument("valor", IntegerArgumentType.integer(1, Progression.MAX_LEVEL))
										.executes(ctx -> {
											ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
											int level = IntegerArgumentType.getInteger(ctx, "valor");
											Progression.setLevel(player, level);
											ctx.getSource().sendFeedback(
													() -> Text.literal("Nível definido para " + level), false);
											return 1;
										})))
						.then(CommandManager.literal("essencia")
								.then(CommandManager.argument("valor", IntegerArgumentType.integer(0, 1000))
										.executes(ctx -> {
											ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
											int amount = IntegerArgumentType.getInteger(ctx, "valor");
											Progression.addEssence(player, amount);
											ctx.getSource().sendFeedback(
													() -> Text.literal("+" + amount + " Essências"), false);
											return 1;
										})))
						.then(CommandManager.literal("resetar")
								.executes(ctx -> {
									ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
									Progression.reset(player);
									ctx.getSource().sendFeedback(
											() -> Text.literal("Progresso apagado."), false);
									return 1;
								}))));
	}
}
