package com.rezero.magic;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

/**
 * Toda a lógica das magias roda no servidor (o servidor integrado, no singleplayer).
 * Os projéteis e ondas são simulados aqui mesmo, sem entidades novas.
 * Índice da magia = índice do elemento (ver MagicData).
 */
public final class SpellCaster {
	public static final int FIREBALL = 0;
	public static final int ICE_LANCE = 1;
	public static final int EARTH_SPIKE = 2;
	public static final int WIND_GUST = 3;
	public static final int UNSEEN_HAND = 4;
	public static final int HEAL = 5;
	public static final int SPELLS = 6;

	private static final double HAND_RANGE = 24.0;
	private static final int HAND_MAX_TICKS = 200; // 10 segundos

	private static final List<Bolt> BOLTS = new ArrayList<>();
	private static final List<Wave> WAVES = new ArrayList<>();
	private static final Map<UUID, Held> HELD = new HashMap<>();
	private static final Map<UUID, int[]> NEXT_USE = new HashMap<>();

	private SpellCaster() {}

	private static final class Bolt {
		final ServerWorld world;
		final ServerPlayerEntity owner;
		final boolean fire;
		final Vec3d velocity;
		final int maxAge;
		Vec3d pos;
		int age;

		Bolt(ServerWorld world, ServerPlayerEntity owner, boolean fire, Vec3d pos, Vec3d velocity, int maxAge) {
			this.world = world;
			this.owner = owner;
			this.fire = fire;
			this.pos = pos;
			this.velocity = velocity;
			this.maxAge = maxAge;
		}
	}

	/** Onda de espinhos de terra que avança em linha reta, um passo a cada 2 ticks. */
	private static final class Wave {
		final ServerWorld world;
		final ServerPlayerEntity owner;
		final Vec3d origin;
		final Vec3d dir;
		final int steps;
		final double radius;
		final float damage;
		final Set<UUID> hit = new HashSet<>();
		int age;
		int step;

		Wave(ServerWorld world, ServerPlayerEntity owner, Vec3d origin, Vec3d dir, int steps, double radius, float damage) {
			this.world = world;
			this.owner = owner;
			this.origin = origin;
			this.dir = dir;
			this.steps = steps;
			this.radius = radius;
			this.damage = damage;
		}
	}

	private static final class Held {
		final ServerWorld world;
		final ServerPlayerEntity owner;
		final LivingEntity target;
		final double distance;
		int age;

		Held(ServerWorld world, ServerPlayerEntity owner, LivingEntity target, double distance) {
			this.world = world;
			this.owner = owner;
			this.target = target;
			this.distance = distance;
		}
	}

	public static void init() {
		ServerTickEvents.END_SERVER_TICK.register(server -> {
			tickBolts();
			tickWaves();
			tickHands();
		});
		ServerLifecycleEvents.SERVER_STOPPED.register(server -> {
			BOLTS.clear();
			WAVES.clear();
			HELD.clear();
			NEXT_USE.clear();
		});
	}

	// ------------------------------------------------------------------ entrada

	public static void cast(MinecraftServer server, ServerPlayerEntity player, int spell) {
		if (spell < 0 || spell >= SPELLS) {
			return;
		}
		ServerWorld world = Compat.worldOf(server, player);
		if (world == null) {
			return;
		}

		// Segurando um alvo com as Mãos Invisíveis: qualquer tecla de conjurar o arremessa.
		if (HELD.containsKey(player.getUuid())) {
			spell = UNSEEN_HAND;
		}

		int now = server.getTicks();
		int[] next = NEXT_USE.computeIfAbsent(player.getUuid(), k -> new int[SPELLS]);
		if (now < next[spell]) {
			return;
		}

		boolean ok = switch (spell) {
			case FIREBALL -> castBolt(world, player, true);
			case ICE_LANCE -> castBolt(world, player, false);
			case EARTH_SPIKE -> castEarth(world, player);
			case WIND_GUST -> castWind(world, player);
			case UNSEEN_HAND -> castUnseenHand(world, player);
			case HEAL -> castHeal(world, player);
			default -> false;
		};
		if (!ok) {
			return;
		}

		next[spell] = now + MagicConfig.cooldown(spell);
		Progression.addCast(player, spell);
		Progression.addXp(world, player, MagicConfig.xp(spell));
	}

	/** Cobra a mana da magia (já ajustada pela afinidade). */
	private static boolean pay(ServerPlayerEntity player, int spell) {
		int cost = MagicData.cost(MagicConfig.cost(spell), Progression.affinity(player), spell);
		if (ManaManager.consume(player, cost)) {
			return true;
		}
		player.sendMessage(Text.translatable("message.rezero_magic.no_mana"), true);
		return false;
	}

	/** Causa dano como se fosse do jogador e soma nas estatísticas. */
	private static void hurt(ServerWorld world, ServerPlayerEntity owner, LivingEntity target, float amount) {
		target.damage(world, world.getDamageSources().playerAttack(owner), amount);
		Progression.addDamage(owner, amount);
	}

	// ------------------------------------------------------- bola de fogo / gelo

	private static boolean castBolt(ServerWorld world, ServerPlayerEntity player, boolean fire) {
		if (!pay(player, fire ? FIREBALL : ICE_LANCE)) {
			return false;
		}
		launchBolt(world, player, fire);
		return true;
	}

	private static void launchBolt(ServerWorld world, ServerPlayerEntity player, boolean fire) {
		Vec3d look = player.getRotationVec(1.0f);
		Vec3d start = player.getEyePos().add(look.multiply(1.0)).add(0.0, -0.15, 0.0);
		double speed = fire ? 1.1 : 2.4;
		int maxAge = fire ? 120 : 60;
		BOLTS.add(new Bolt(world, player, fire, start, look.multiply(speed), maxAge));

		// círculo mágico aos pés do jogador
		if (fire) {
			Fx.magicCircle(world, ParticleTypes.FLAME, ParticleTypes.SOUL_FIRE_FLAME,
					player.getX(), player.getY() + 0.1, player.getZ(), 1.6);
		} else {
			Fx.magicCircle(world, ParticleTypes.SNOWFLAKE, ParticleTypes.END_ROD,
					player.getX(), player.getY() + 0.1, player.getZ(), 1.6);
		}
		world.playSound(null, player.getX(), player.getY(), player.getZ(),
				SoundEvents.ENTITY_EVOKER_CAST_SPELL, SoundCategory.PLAYERS, 0.7f, 0.5f);

		if (fire) {
			world.playSound(null, player.getX(), player.getY(), player.getZ(),
					SoundEvents.ENTITY_BLAZE_SHOOT, SoundCategory.PLAYERS, 1.0f, 0.8f);
		} else {
			world.playSound(null, player.getX(), player.getY(), player.getZ(),
					SoundEvents.BLOCK_GLASS_BREAK, SoundCategory.PLAYERS, 0.8f, 1.6f);
		}
	}

	private static void tickBolts() {
		Iterator<Bolt> it = BOLTS.iterator();
		while (it.hasNext()) {
			Bolt bolt = it.next();
			if (bolt.owner.isRemoved() || bolt.age++ > bolt.maxAge) {
				it.remove();
				continue;
			}

			Vec3d next = bolt.pos.add(bolt.velocity);
			BlockHitResult blockHit = bolt.world.raycast(new RaycastContext(
					bolt.pos, next,
					RaycastContext.ShapeType.COLLIDER,
					RaycastContext.FluidHandling.NONE,
					bolt.owner));
			boolean hitBlock = blockHit.getType() != HitResult.Type.MISS;
			Vec3d end = hitBlock ? blockHit.getPos() : next;

			LivingEntity hitEntity = findTarget(bolt.world, bolt.owner, bolt.pos, end, 0.35);
			if (hitEntity != null || hitBlock) {
				Vec3d at = hitEntity != null
						? new Vec3d(hitEntity.getX(), hitEntity.getBodyY(0.5), hitEntity.getZ())
						: blockHit.getPos();
				if (bolt.fire) {
					fireImpact(bolt, at);
				} else {
					iceImpact(bolt, at, hitEntity);
				}
				it.remove();
				continue;
			}

			if (bolt.fire) {
				// núcleo brilhante + chamas em volta + fumaça
				bolt.world.spawnParticles(ParticleTypes.LAVA, next.x, next.y, next.z, 1, 0.1, 0.1, 0.1, 0.0);
				bolt.world.spawnParticles(ParticleTypes.FLAME, next.x, next.y, next.z, 8, 0.2, 0.2, 0.2, 0.02);
				bolt.world.spawnParticles(ParticleTypes.SOUL_FIRE_FLAME, next.x, next.y, next.z, 2, 0.1, 0.1, 0.1, 0.0);
				bolt.world.spawnParticles(ParticleTypes.SMOKE, next.x, next.y, next.z, 2, 0.15, 0.15, 0.15, 0.0);
			} else {
				// espiral de gelo + ponta brilhante
				Fx.spiral(bolt.world, ParticleTypes.SNOWFLAKE, next, bolt.velocity, bolt.age, 0.35);
				bolt.world.spawnParticles(ParticleTypes.END_ROD, next.x, next.y, next.z, 2, 0.0, 0.0, 0.0, 0.0);
				bolt.world.spawnParticles(ParticleTypes.SNOWFLAKE, next.x, next.y, next.z, 3, 0.05, 0.05, 0.05, 0.01);
			}
			bolt.pos = next;
		}
	}

	private static void fireImpact(Bolt bolt, Vec3d at) {
		ServerWorld world = bolt.world;
		world.spawnParticles(ParticleTypes.EXPLOSION, at.x, at.y, at.z, 2, 0.4, 0.4, 0.4, 0.0);
		world.spawnParticles(ParticleTypes.FLAME, at.x, at.y, at.z, 60, 0.8, 0.6, 0.8, 0.08);
		world.spawnParticles(ParticleTypes.LARGE_SMOKE, at.x, at.y, at.z, 20, 0.7, 0.5, 0.7, 0.05);
		world.playSound(null, at.x, at.y, at.z,
				SoundEvents.ENTITY_DRAGON_FIREBALL_EXPLODE, SoundCategory.PLAYERS, 1.2f, 1.0f);
		// anéis de fogo expandindo
		Fx.burst(world, ParticleTypes.FLAME, at, 28, 0.35);
		Fx.burst(world, ParticleTypes.SOUL_FIRE_FLAME, at.add(0.0, 0.2, 0.0), 18, 0.2);
		Fx.circle(world, ParticleTypes.FLAME, at.x, at.y + 0.1, at.z, 3.0, 30);

		double radius = Progression.hasSkill(bolt.owner, 0) ? 5.0 : 3.5; // Explosão Maior
		Box area = new Box(at.x - radius, at.y - radius, at.z - radius, at.x + radius, at.y + radius, at.z + radius);
		for (LivingEntity entity : world.getEntitiesByClass(LivingEntity.class, area,
				e -> e != bolt.owner && e.isAlive() && !e.isSpectator())) {
			double dist = Math.sqrt(entity.squaredDistanceTo(at.x, at.y, at.z));
			if (dist > radius) {
				continue;
			}
			float damage = (3.0f + (float) (10.0 * (1.0 - dist / radius)))
					* Progression.spellMultiplier(bolt.owner, FIREBALL)
					* (Progression.hasSkill(bolt.owner, 2) ? 1.4f : 1.0f); // Núcleo Volátil
			hurt(world, bolt.owner, entity, damage);
			entity.setOnFireFor(Progression.hasSkill(bolt.owner, 1) ? 14 : 6); // Fogo Eterno

			double dx = entity.getX() - at.x;
			double dz = entity.getZ() - at.z;
			double len = Math.sqrt(dx * dx + dz * dz);
			if (len > 0.01) {
				entity.addVelocity(dx / len * 0.6, 0.35, dz / len * 0.6);
			}
		}
	}

	private static void iceImpact(Bolt bolt, Vec3d at, LivingEntity direct) {
		ServerWorld world = bolt.world;
		world.spawnParticles(ParticleTypes.SNOWFLAKE, at.x, at.y, at.z, 50, 0.6, 0.6, 0.6, 0.1);
		world.spawnParticles(ParticleTypes.END_ROD, at.x, at.y, at.z, 15, 0.4, 0.4, 0.4, 0.05);
		world.playSound(null, at.x, at.y, at.z,
				SoundEvents.BLOCK_GLASS_BREAK, SoundCategory.PLAYERS, 1.0f, 0.7f);
		// pilares de gelo e anel de neve
		Fx.icePillars(world, at);
		Fx.burst(world, ParticleTypes.SNOWFLAKE, at, 24, 0.25);

		double radius = Progression.hasSkill(bolt.owner, 4) ? 3.2 : 2.0; // Geada Ampla
		Box area = new Box(at.x - radius, at.y - radius, at.z - radius, at.x + radius, at.y + radius, at.z + radius);
		for (LivingEntity entity : world.getEntitiesByClass(LivingEntity.class, area,
				e -> e != bolt.owner && e.isAlive() && !e.isSpectator())) {
			if (Math.sqrt(entity.squaredDistanceTo(at.x, at.y, at.z)) > radius) {
				continue;
			}
			boolean freeze = Progression.hasSkill(bolt.owner, 3); // Congelar
			boolean zero = Progression.hasSkill(bolt.owner, 5); // Zero Absoluto
			float base = entity == direct
					? (zero ? 12.0f : 8.0f)
					: (Progression.hasSkill(bolt.owner, 4) ? 6.0f : 3.0f);
			hurt(world, bolt.owner, entity, base * Progression.spellMultiplier(bolt.owner, ICE_LANCE));
			entity.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, freeze ? 240 : 120, freeze ? 4 : 3));
			entity.setFrozenTicks(freeze ? 400 : 260);
			if (zero) {
				entity.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 200, 1));
			}
		}
	}

	// ------------------------------------------------------------ terra

	private static boolean castEarth(ServerWorld world, ServerPlayerEntity player) {
		if (!pay(player, EARTH_SPIKE)) {
			return false;
		}
		Vec3d look = player.getRotationVec(1.0f);
		Vec3d dir = new Vec3d(look.x, 0.0, look.z);
		dir = dir.lengthSquared() < 0.0001 ? new Vec3d(0.0, 0.0, 1.0) : dir.normalize();

		int steps = Progression.hasSkill(player, 7) ? 14 : 8; // Onda Longa
		double radius = Progression.hasSkill(player, 6) ? 2.2 : 1.4; // Espinhos Largos
		float damage = 6.0f
				* Progression.spellMultiplier(player, EARTH_SPIKE)
				* (Progression.hasSkill(player, 8) ? 1.5f : 1.0f); // Abalo
		Vec3d origin = new Vec3d(player.getX(), player.getY(), player.getZ());
		WAVES.add(new Wave(world, player, origin, dir, steps, radius, damage));

		Fx.magicCircle(world, ParticleTypes.CRIT, ParticleTypes.POOF,
				player.getX(), player.getY() + 0.1, player.getZ(), 1.5);
		world.playSound(null, player.getX(), player.getY(), player.getZ(),
				SoundEvents.ENTITY_EVOKER_CAST_SPELL, SoundCategory.PLAYERS, 0.7f, 0.5f);
		return true;
	}

	private static void tickWaves() {
		Iterator<Wave> it = WAVES.iterator();
		while (it.hasNext()) {
			Wave w = it.next();
			if (w.owner.isRemoved() || w.step >= w.steps) {
				it.remove();
				continue;
			}
			if (w.age++ % 2 != 0) {
				continue;
			}
			Vec3d p = w.origin.add(w.dir.multiply(1.5 + w.step * 1.3));
			w.step++;
			erupt(w, p);
		}
	}

	private static void erupt(Wave w, Vec3d p) {
		ServerWorld world = w.world;
		world.spawnParticles(ParticleTypes.POOF, p.x, p.y + 0.2, p.z, 10, 0.5, 0.1, 0.5, 0.05);
		for (double h = 0.0; h <= 1.8; h += 0.3) {
			world.spawnParticles(ParticleTypes.CRIT, p.x, p.y + h, p.z, 3, 0.25, 0.0, 0.25, 0.05);
		}
		world.spawnParticles(ParticleTypes.SMOKE, p.x, p.y + 0.5, p.z, 3, 0.3, 0.3, 0.3, 0.01);
		world.playSound(null, p.x, p.y, p.z, SoundEvents.BLOCK_STONE_BREAK, SoundCategory.PLAYERS, 0.8f, 0.7f);

		double r = w.radius;
		Box area = new Box(p.x - r, p.y - 1.0, p.z - r, p.x + r, p.y + 2.5, p.z + r);
		for (LivingEntity entity : world.getEntitiesByClass(LivingEntity.class, area,
				e -> e != w.owner && e.isAlive() && !e.isSpectator() && !w.hit.contains(e.getUuid()))) {
			w.hit.add(entity.getUuid());
			hurt(world, w.owner, entity, w.damage);
			entity.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 60, 1));
			entity.addVelocity(0.0, 0.65, 0.0);
		}
	}

	// ------------------------------------------------------------ vento

	private static boolean castWind(ServerWorld world, ServerPlayerEntity player) {
		if (!pay(player, WIND_GUST)) {
			return false;
		}
		boolean longRange = Progression.hasSkill(player, 9); // Rajada Longa
		boolean hurricane = Progression.hasSkill(player, 10); // Furacão
		boolean blade = Progression.hasSkill(player, 11); // Lâmina de Vento

		double range = longRange ? 20.0 : 12.0;
		double minDot = hurricane ? 0.5 : 0.7;
		double push = hurricane ? 2.4 : 1.6;
		float damage = 3.0f * (blade ? 2.0f : 1.0f) * Progression.spellMultiplier(player, WIND_GUST);

		Vec3d eye = player.getEyePos();
		Vec3d look = player.getRotationVec(1.0f);
		Box area = new Box(eye.x - range, eye.y - range, eye.z - range, eye.x + range, eye.y + range, eye.z + range);
		for (LivingEntity entity : world.getEntitiesByClass(LivingEntity.class, area,
				e -> e != player && e.isAlive() && !e.isSpectator())) {
			Vec3d to = new Vec3d(entity.getX() - eye.x, entity.getBodyY(0.5) - eye.y, entity.getZ() - eye.z);
			double dist = to.length();
			if (dist > range || dist < 0.01) {
				continue;
			}
			if (look.dotProduct(to.multiply(1.0 / dist)) < minDot) {
				continue;
			}
			hurt(world, player, entity, damage);
			entity.addVelocity(look.x * push, look.y * push * 0.5 + 0.35, look.z * push);
		}

		for (double d = 1.0; d <= range; d += 1.0) {
			Vec3d p = eye.add(look.multiply(d));
			double spread = 0.15 + d * 0.06;
			world.spawnParticles(ParticleTypes.CLOUD, p.x, p.y - 0.2, p.z, 2, spread, spread, spread, 0.02);
			if (blade && ((int) d) % 3 == 0) {
				world.spawnParticles(ParticleTypes.SWEEP_ATTACK, p.x, p.y - 0.2, p.z, 1, 0.0, 0.0, 0.0, 0.0);
			}
		}
		world.playSound(null, player.getX(), player.getY(), player.getZ(),
				SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, SoundCategory.PLAYERS, 1.0f, 0.6f);
		return true;
	}

	// ------------------------------------------------------------ yang

	private static boolean castHeal(ServerWorld world, ServerPlayerEntity player) {
		if (player.getHealth() >= player.getMaxHealth()) {
			player.sendMessage(Text.translatable("message.rezero_magic.full_health"), true);
			return false;
		}
		if (!pay(player, HEAL)) {
			return false;
		}
		float amount = (Progression.hasSkill(player, 15) ? 10.0f : 6.0f) // Cura Maior
				* Progression.spellMultiplier(player, HEAL);
		player.heal(amount);
		if (Progression.hasSkill(player, 16)) { // Regeneração
			player.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 160, 1));
		}
		if (Progression.hasSkill(player, 17)) { // Bênção
			player.addStatusEffect(new StatusEffectInstance(StatusEffects.ABSORPTION, 600, 1));
		}

		Fx.magicCircle(world, ParticleTypes.HAPPY_VILLAGER, ParticleTypes.END_ROD,
				player.getX(), player.getY() + 0.1, player.getZ(), 1.5);
		world.spawnParticles(ParticleTypes.HEART, player.getX(), player.getY() + 1.2, player.getZ(),
				8, 0.5, 0.6, 0.5, 0.0);
		world.playSound(null, player.getX(), player.getY(), player.getZ(),
				SoundEvents.ENTITY_PLAYER_LEVELUP, SoundCategory.PLAYERS, 0.6f, 1.6f);
		return true;
	}

	// --------------------------------------------------------- mãos invisíveis

	/** @return true se algo aconteceu (agarrou ou arremessou), para aplicar o cooldown. */
	private static boolean castUnseenHand(ServerWorld world, ServerPlayerEntity player) {
		Held held = HELD.remove(player.getUuid());
		if (held != null) {
			throwHeld(held);
			return true;
		}

		Vec3d eye = player.getEyePos();
		Vec3d look = player.getRotationVec(1.0f);
		double range = Progression.hasSkill(player, 13) ? 40.0 : HAND_RANGE; // Longo Alcance
		Vec3d far = eye.add(look.multiply(range));
		BlockHitResult blockHit = world.raycast(new RaycastContext(
				eye, far,
				RaycastContext.ShapeType.COLLIDER,
				RaycastContext.FluidHandling.NONE,
				player));
		Vec3d end = blockHit.getType() == HitResult.Type.MISS ? far : blockHit.getPos();

		LivingEntity target = findTarget(world, player, eye, end, 0.6);
		if (target == null) {
			player.sendMessage(Text.translatable("message.rezero_magic.no_target"), true);
			return false;
		}
		if (!pay(player, UNSEEN_HAND)) {
			return false;
		}

		double dist = MathHelper.clamp(Math.sqrt(player.squaredDistanceTo(target)), 3.0, 8.0);
		HELD.put(player.getUuid(), new Held(world, player, target, dist));
		Fx.magicCircle(world, ParticleTypes.WITCH, ParticleTypes.ENCHANT,
				player.getX(), player.getY() + 0.1, player.getZ(), 1.4);
		Fx.burst(world, ParticleTypes.WITCH,
				new Vec3d(target.getX(), target.getBodyY(0.5), target.getZ()), 20, 0.2);
		world.playSound(null, player.getX(), player.getY(), player.getZ(),
				SoundEvents.ENTITY_EVOKER_CAST_SPELL, SoundCategory.PLAYERS, 1.0f, 0.6f);
		return true;
	}

	private static void tickHands() {
		Iterator<Map.Entry<UUID, Held>> it = HELD.entrySet().iterator();
		while (it.hasNext()) {
			Held held = it.next().getValue();
			LivingEntity target = held.target;

			boolean invalid = held.owner.isRemoved()
					|| target.isRemoved()
					|| !target.isAlive()
					|| held.age++ > (Progression.hasSkill(held.owner, 12) ? HAND_MAX_TICKS * 2 : HAND_MAX_TICKS) // Mãos Firmes
					|| held.owner.squaredDistanceTo(target) > 40.0 * 40.0;
			if (invalid) {
				if (target.isAlive() && !target.isRemoved()) {
					// evita dano de queda ao soltar de longe
					target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOW_FALLING, 60, 0));
				}
				it.remove();
				continue;
			}

			Vec3d eye = held.owner.getEyePos();
			Vec3d look = held.owner.getRotationVec(1.0f);
			Vec3d want = eye.add(look.multiply(held.distance));
			Vec3d have = new Vec3d(target.getX(), target.getBodyY(0.5), target.getZ());

			Vec3d delta = want.subtract(have);
			double len = delta.length();
			if (len > 2.0) {
				delta = delta.multiply(2.0 / len);
			}
			target.setVelocity(0.0, 0.0, 0.0);
			target.addVelocity(delta.x * 0.5, delta.y * 0.5, delta.z * 0.5);

			// várias "mãos" escuras ondulando do peito do jogador até o alvo
			Vec3d chest = new Vec3d(held.owner.getX(), held.owner.getBodyY(0.7), held.owner.getZ());
			Fx.hands(held.world, chest, have, held.age);
			held.world.spawnParticles(ParticleTypes.SMOKE, have.x, have.y, have.z, 3, 0.3, 0.4, 0.3, 0.01);
		}
	}

	private static void throwHeld(Held held) {
		LivingEntity target = held.target;
		if (target.isRemoved() || !target.isAlive()) {
			return;
		}
		Vec3d look = held.owner.getRotationVec(1.0f);
		target.setVelocity(0.0, 0.0, 0.0);
		target.addVelocity(look.x * 2.4, look.y * 2.4 + 0.25, look.z * 2.4);
		hurt(held.world, held.owner, target,
				(Progression.hasSkill(held.owner, 14) ? 10.0f : 4.0f) // Esmagar
						* Progression.spellMultiplier(held.owner, UNSEEN_HAND));

		Vec3d from = new Vec3d(held.owner.getX(), held.owner.getBodyY(0.7), held.owner.getZ());
		Vec3d to = new Vec3d(target.getX(), target.getBodyY(0.5), target.getZ());
		Fx.line(held.world, ParticleTypes.ENCHANT, from, to, 16);
		Fx.burst(held.world, ParticleTypes.WITCH, to, 28, 0.4);
		held.world.spawnParticles(ParticleTypes.WITCH, to.x, to.y, to.z, 25, 0.4, 0.5, 0.4, 0.1);
		held.world.playSound(null, target.getX(), target.getY(), target.getZ(),
				SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, SoundCategory.PLAYERS, 1.0f, 0.7f);
	}

	// ------------------------------------------------------------------ util

	/** Primeira entidade viva cruzada pelo segmento a->b (com margem extra de hitbox). */
	private static LivingEntity findTarget(ServerWorld world, ServerPlayerEntity owner, Vec3d a, Vec3d b, double grow) {
		Box search = new Box(a, b).expand(grow + 0.5);
		LivingEntity best = null;
		double bestDist = Double.MAX_VALUE;
		for (LivingEntity entity : world.getEntitiesByClass(LivingEntity.class, search,
				e -> e != owner && e.isAlive() && !e.isSpectator())) {
			Optional<Vec3d> hit = entity.getBoundingBox().expand(grow).raycast(a, b);
			if (hit.isPresent()) {
				double d = a.squaredDistanceTo(hit.get());
				if (d < bestDist) {
					bestDist = d;
					best = entity;
				}
			}
		}
		return best;
	}
}
