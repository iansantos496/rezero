package com.rezero.mod.core;

/**
 * Acessórios (aneis, amuletos, selos). Funcionam enquanto estiverem na mão SECUNDÁRIA (o jogo base não tem
 * espaço de acessório, e esta escolha evita depender de APIs não confirmadas). ADAPTAÇÃO de jogo.
 * Os ids e as chaves nunca devem mudar (a chave é o caminho do item registrado).
 */
public enum Charm {
	FLUX(0, "charm_flux", 0, 0, 0, 35),
	FOCUS(1, "charm_focus", 0, 0, 15, 0),
	CRYSTAL(2, "charm_crystal", 10, 0, 0, 0),
	THRIFT(3, "charm_thrift", 0, 10, 0, 0),
	RESONANCE(4, "charm_resonance", 6, 5, 0, 15);

	private final int id;
	private final String key;
	private final int powerPct;
	private final int costReductionPct;
	private final int castReductionPct;
	private final int regenPct;

	Charm(int id, String key, int powerPct, int costReductionPct, int castReductionPct, int regenPct) {
		this.id = id;
		this.key = key;
		this.powerPct = powerPct;
		this.costReductionPct = costReductionPct;
		this.castReductionPct = castReductionPct;
		this.regenPct = regenPct;
	}

	public int id() {
		return id;
	}

	public String key() {
		return key;
	}

	public int powerPct() {
		return powerPct;
	}

	public int costReductionPct() {
		return costReductionPct;
	}

	public int castReductionPct() {
		return castReductionPct;
	}

	/** Aumento da regeneração de mana, em %. */
	public int regenPct() {
		return regenPct;
	}
}
