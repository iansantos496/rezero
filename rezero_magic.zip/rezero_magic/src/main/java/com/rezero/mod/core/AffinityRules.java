package com.rezero.mod.core;

/**
 * Regras da afinidade (Sistema 12). É a decisão final do servidor; a interface só reflete o resultado.
 * Regra da obra do projeto: UMA afinidade por jogador, escolhida uma única vez.
 */
public final class AffinityRules {
	private AffinityRules() {}

	/**
	 * A escolha só é aceita se o pedido for válido e o jogador ainda não tiver afinidade.
	 * Depois de escolhida, não há como trocar pelo jogo normal.
	 */
	public static boolean canChoose(Affinity current, Affinity wanted) {
		return current == null && wanted != null;
	}

	/** Id salvo/recebido -> id seguro: qualquer valor que não seja uma afinidade vira -1 (sem afinidade). */
	public static int normalizeId(int id) {
		return Affinity.fromId(id) == null ? -1 : id;
	}

	/**
	 * Um poder só pode ser aprendido ou usado se o jogador já escolheu e se o poder
	 * pertence exatamente à afinidade escolhida.
	 */
	public static boolean canUse(Affinity chosen, Affinity required) {
		return chosen != null && required != null && chosen == required;
	}
}
