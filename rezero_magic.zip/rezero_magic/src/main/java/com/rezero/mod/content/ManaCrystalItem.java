package com.rezero.mod.content;

import com.rezero.mod.core.CrystalRarity;
import com.rezero.mod.server.CrystalService;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.world.World;

/** Cristal de mana (uma classe para as 4 raridades). Usar (botão direito) restaura mana. Lógica no servidor. */
public class ManaCrystalItem extends Item {
	private final CrystalRarity rarity;

	public ManaCrystalItem(Settings settings, CrystalRarity rarity) {
		super(settings);
		this.rarity = rarity;
	}

	public CrystalRarity rarity() {
		return rarity;
	}

	@Override
	public ActionResult use(World world, PlayerEntity user, Hand hand) {
		// no cliente só balança a mão; quem decide é o servidor
		if (world instanceof ServerWorld serverWorld && user instanceof ServerPlayerEntity player) {
			ItemStack stack = user.getStackInHand(hand);
			CrystalService.useCrystal(serverWorld, player, stack, rarity);
		}
		return ActionResult.SUCCESS;
	}
}
