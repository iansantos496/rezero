package com.rezero.mod.content;

import com.rezero.mod.core.Catalyst;

import net.minecraft.item.Item;

/** Cajado catalisador: segurado na mão principal, melhora os feitiços (ver core/Catalyst). Sem lógica própria: o SpellService lê o item. */
public class CatalystItem extends Item {
	private final Catalyst catalyst;

	public CatalystItem(Settings settings, Catalyst catalyst) {
		super(settings);
		this.catalyst = catalyst;
	}

	public Catalyst catalyst() {
		return catalyst;
	}
}
