package com.rezero.mod.net;

import com.rezero.mod.ReZeroMod;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Servidor -> cliente: mana atual e se o jogador está exausto (1) ou não (0). Enviado só quando muda. */
public record ManaSyncPayload(int mana, int exhausted) implements CustomPayload {
	public static final CustomPayload.Id<ManaSyncPayload> ID =
			new CustomPayload.Id<>(Identifier.of(ReZeroMod.MOD_ID, "mana_sync"));

	public static final PacketCodec<RegistryByteBuf, ManaSyncPayload> CODEC = PacketCodec.tuple(
			PacketCodecs.VAR_INT, ManaSyncPayload::mana,
			PacketCodecs.VAR_INT, ManaSyncPayload::exhausted,
			ManaSyncPayload::new);

	@Override
	public CustomPayload.Id<? extends CustomPayload> getId() {
		return ID;
	}
}
