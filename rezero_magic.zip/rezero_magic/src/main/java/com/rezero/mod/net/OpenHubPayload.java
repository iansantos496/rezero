package com.rezero.mod.net;

import com.rezero.mod.ReZeroMod;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Servidor -> cliente: abra o Hub na aba indicada (usado pela Mesa de Inscrição). */
public record OpenHubPayload(int tab) implements CustomPayload {
	public static final CustomPayload.Id<OpenHubPayload> ID =
			new CustomPayload.Id<>(Identifier.of(ReZeroMod.MOD_ID, "open_hub"));

	public static final PacketCodec<RegistryByteBuf, OpenHubPayload> CODEC =
			PacketCodec.tuple(PacketCodecs.VAR_INT, OpenHubPayload::tab, OpenHubPayload::new);

	@Override
	public CustomPayload.Id<? extends CustomPayload> getId() {
		return ID;
	}
}
