package com.rezero.mod.core;

/** As 4 peças de uma veste. O sufixo forma a chave do item: <conjunto>_<sufixo>. */
public enum RobePiece {
	HOOD(0, "hood"),
	TUNIC(1, "tunic"),
	TROUSERS(2, "trousers"),
	BOOTS(3, "boots");

	private final int id;
	private final String suffix;

	RobePiece(int id, String suffix) {
		this.id = id;
		this.suffix = suffix;
	}

	public int id() {
		return id;
	}

	public String suffix() {
		return suffix;
	}
}
