package com.rezero.mod.content;

import com.rezero.mod.server.CrystalService;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.ActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/**
 * Concentrador de Mana: com um cristal na mão principal e um Receptor de Mana na outra mão,
 * clique com o botão direito para carregar o Receptor com +25% de eficiência.
 */
public class ManaConcentratorBlock extends Block {
	public ManaConcentratorBlock(Settings settings) {
		super(settings);
	}

	@Override
	public ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, BlockHitResult hit) {
		if (world instanceof ServerWorld serverWorld && player instanceof ServerPlayerEntity serverPlayer) {
			CrystalService.useConcentrator(serverWorld, serverPlayer, pos);
		}
		return ActionResult.SUCCESS;
	}
}
