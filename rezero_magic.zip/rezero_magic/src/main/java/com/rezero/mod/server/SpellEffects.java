package com.rezero.mod.server;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import com.rezero.mod.core.Spells;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

/**
 * Efeitos no mundo dos 10 feitiços (Fogo e Água). SÓ roda no servidor, depois que o SpellService
 * já aprovou afinidade, nível, mana e recarga. Os números são adaptação de jogo (não são canônicos).
 * Nada aqui usa entidades novas: raios instantâneos, áreas e blocos temporários.
 */
final class SpellEffects {
	private static final List<Zone> ZONES = new ArrayList<>();
	private static final List<TempBlock> TEMP = new ArrayList<>();

	enum ZoneKind { FIRE, VORTEX, MIASMA }

	private static final class Zone {
		final ServerWorld world;
		final Vec3d center;
		final UUID owner;
		final float damage;
		final ZoneKind kind;
		int ticksLeft;

		Zone(ServerWorld world, Vec3d center, UUID owner, float damage, int ticksLeft, ZoneKind kind) {
			this.world = world;
			this.center = center;
			this.owner = owner;
			this.damage = damage;
			this.ticksLeft = ticksLeft;
			this.kind = kind;
		}

		double radius() {
			return switch (kind) {
				case FIRE -> 3.0;
				case VORTEX -> 5.0;
				case MIASMA -> 4.0;
			};
		}
	}

	private static final class TempBlock {
		final ServerWorld world;
		final BlockPos pos;
		final Block block;
		int ticksLeft;

		TempBlock(ServerWorld world, BlockPos pos, Block block, int ticksLeft) {
			this.world = world;
			this.pos = pos;
			this.block = block;
			this.ticksLeft = ticksLeft;
		}
	}

	private SpellEffects() {}

	// ------------------------------------------------------------------ verificação prévia

	/**
	 * Pré-condições específicas de cada feitiço (alvo existente, vida não cheia).
	 * @return null se pode conjurar, ou o nome da chave de mensagem (message.rezero_magic.cast.<nome>).
	 */
	static String precondition(ServerWorld world, ServerPlayerEntity player, int spellId, int range) {
		if (spellId == Spells.AQUA_HEAL && player.getHealth() >= player.getMaxHealth()) {
			return "full_health";
		}
		boolean needsTarget = spellId == Spells.ICE_PRISON || spellId == Spells.LIFE_DRAIN || spellId == Spells.CURSE;
		if (needsTarget && aimedTarget(world, player, range) == null) {
			return "no_target";
		}
		return null;
	}

	// ------------------------------------------------------------------ execução

	/** @return true se o feitiço teve efeito (então o serviço cobra a mana e inicia a recarga). */
	static boolean execute(ServerWorld world, ServerPlayerEntity player, int spellId, int range, double power) {
		switch (spellId) {
			case Spells.GOA:
				return goa(world, player, range, power);
			case Spells.ELGOA:
				return elgoa(world, player, range, power);
			case Spells.URGOA:
				return urgoa(world, player, range, power);
			case Spells.FIRE_ZONE:
				return fireZone(world, player, range, power);
			case Spells.ALGOA:
				return algoa(world, player, range, power);
			case Spells.ICE_LANCE:
				return iceLance(world, player, range, power);
			case Spells.FROST_WAVE:
				return frostWave(world, player, range, power);
			case Spells.ICE_WALL:
				return iceWall(world, player, power);
			case Spells.AQUA_HEAL:
				return aquaHeal(world, player, power);
			case Spells.ICE_PRISON:
				return icePrison(world, player, range, power);
			case Spells.WIND_GUST: case Spells.WIND_BLADE: case Spells.WIND_LEAP: case Spells.WIND_VORTEX: case Spells.WIND_STORM:
				return WindEffects.execute(world, player, spellId, range, power);
			case Spells.EARTH_SPIKE: case Spells.EARTH_WALL: case Spells.EARTH_ROOT: case Spells.STONE_SKIN: case Spells.EARTHQUAKE:
				return EarthEffects.execute(world, player, spellId, range, power);
			case Spells.SHAMAK: case Spells.MIASMA: case Spells.LIFE_DRAIN: case Spells.CURSE: case Spells.ECLIPSE:
				return YinEffects.execute(world, player, spellId, range, power);
			case Spells.STRENGTHEN: case Spells.AGILITY: case Spells.RADIANT_SHIELD: case Spells.BLESSING: case Spells.ZENITH:
				return YangEffects.execute(world, player, spellId, range, power);
			default:
				return false;
		}
	}

	// ------------------------------------------------------------------ Fogo

	/** Goa: raio de fogo rápido, alvo único. */
	private static boolean goa(ServerWorld world, ServerPlayerEntity p, int range, double power) {
		Vec3d[] ray = ray(world, p, range);
		LivingEntity target = findTarget(world, p, ray[0], ray[1], 0.35);
		Vec3d at = target != null ? bodyPos(target) : ray[1];
		trail(world, ParticleTypes.FLAME, ray[0], at);
		world.spawnParticles(ParticleTypes.FLAME, at.x, at.y, at.z, 18, 0.25, 0.25, 0.25, 0.04);
		world.spawnParticles(ParticleTypes.SMOKE, at.x, at.y, at.z, 4, 0.2, 0.2, 0.2, 0.01);
		sound(world, p.getX(), p.getY(), p.getZ(), SoundEvents.ENTITY_BLAZE_SHOOT, 0.8f, 1.2f);
		if (target != null) {
			hurt(world, p, target, (float) (6.0 * power));
			target.setOnFireFor(4.0f);
		}
		return true;
	}

	/** Elgoa: explosão de fogo em área no ponto visado (não destrói blocos). */
	private static boolean elgoa(ServerWorld world, ServerPlayerEntity p, int range, double power) {
		Vec3d[] ray = ray(world, p, range);
		LivingEntity direct = findTarget(world, p, ray[0], ray[1], 0.4);
		Vec3d at = direct != null ? bodyPos(direct) : ray[1];
		trail(world, ParticleTypes.FLAME, ray[0], at);
		blast(world, p, at, 3.5, 4.0, 10.0, power, 5.0f, 0.6);
		world.spawnParticles(ParticleTypes.EXPLOSION, at.x, at.y, at.z, 2, 0.4, 0.4, 0.4, 0.0);
		world.spawnParticles(ParticleTypes.FLAME, at.x, at.y, at.z, 60, 0.8, 0.6, 0.8, 0.08);
		world.spawnParticles(ParticleTypes.LARGE_SMOKE, at.x, at.y, at.z, 15, 0.6, 0.5, 0.6, 0.04);
		sound(world, at.x, at.y, at.z, SoundEvents.ENTITY_DRAGON_FIREBALL_EXPLODE, 1.2f, 1.0f);
		return true;
	}

	/** Urgoa: leque de chamas à frente, curto alcance, atinge todos no cone. */
	private static boolean urgoa(ServerWorld world, ServerPlayerEntity p, int range, double power) {
		Vec3d eye = p.getEyePos();
		Vec3d look = p.getRotationVec(1.0f).normalize();
		Box area = new Box(eye, eye.add(look.multiply(range))).expand(range * 0.5);
		for (LivingEntity e : world.getEntitiesByClass(LivingEntity.class, area,
				x -> x != p && x.isAlive() && !x.isSpectator())) {
			Vec3d to = bodyPos(e).subtract(eye);
			double dist = to.length();
			if (dist > range || dist < 0.01) {
				continue;
			}
			if (to.multiply(1.0 / dist).dotProduct(look) < 0.65) {
				continue;
			}
			hurt(world, p, e, (float) (5.0 * power));
			e.setOnFireFor(6.0f);
		}
		for (int i = 1; i <= range; i++) {
			Vec3d c = eye.add(look.multiply(i));
			double spread = 0.12 * i;
			world.spawnParticles(ParticleTypes.FLAME, c.x, c.y - 0.2, c.z, 6, spread, spread, spread, 0.02);
			if (i % 3 == 0) {
				world.spawnParticles(ParticleTypes.SMOKE, c.x, c.y - 0.2, c.z, 2, spread, spread, spread, 0.01);
			}
		}
		sound(world, p.getX(), p.getY(), p.getZ(), SoundEvents.ITEM_FIRECHARGE_USE, 1.0f, 0.8f);
		return true;
	}

	/** Zona de fogo: cria uma poça de chamas temporária que fere quem ficar dentro. */
	private static boolean fireZone(ServerWorld world, ServerPlayerEntity p, int range, double power) {
		Vec3d[] ray = ray(world, p, range);
		Vec3d at = ray[1];
		addZone(world, at, p.getUuid(), (float) (2.0 * power), 120, ZoneKind.FIRE);
		trail(world, ParticleTypes.FLAME, ray[0], at);
		sound(world, at.x, at.y, at.z, SoundEvents.ITEM_FIRECHARGE_USE, 1.0f, 0.6f);
		return true;
	}

	/** Algoa: o feitiço de fogo mais forte; explosão grande e muito cara, com longo tempo de recarga. */
	private static boolean algoa(ServerWorld world, ServerPlayerEntity p, int range, double power) {
		Vec3d[] ray = ray(world, p, range);
		LivingEntity direct = findTarget(world, p, ray[0], ray[1], 0.5);
		Vec3d at = direct != null ? bodyPos(direct) : ray[1];
		trail(world, ParticleTypes.LAVA, ray[0], at);
		blast(world, p, at, 7.0, 7.0, 13.0, power, 9.0f, 1.0);
		world.spawnParticles(ParticleTypes.EXPLOSION_EMITTER, at.x, at.y, at.z, 1, 0.0, 0.0, 0.0, 0.0);
		world.spawnParticles(ParticleTypes.FLAME, at.x, at.y, at.z, 200, 3.0, 1.5, 3.0, 0.12);
		world.spawnParticles(ParticleTypes.LARGE_SMOKE, at.x, at.y, at.z, 60, 2.5, 1.5, 2.5, 0.06);
		ring(world, ParticleTypes.FLAME, at, 7.0, 48);
		sound(world, at.x, at.y, at.z, SoundEvents.ENTITY_DRAGON_FIREBALL_EXPLODE, 2.0f, 0.6f);
		return true;
	}

	/** Dano em área com queda por distância, fogo e empurrão. Não destrói blocos. */
	private static void blast(ServerWorld world, ServerPlayerEntity owner, Vec3d at, double radius,
			double minDamage, double extraDamage, double power, float fireSeconds, double knockback) {
		Box area = new Box(at.x - radius, at.y - radius, at.z - radius, at.x + radius, at.y + radius, at.z + radius);
		for (LivingEntity e : world.getEntitiesByClass(LivingEntity.class, area,
				x -> x != owner && x.isAlive() && !x.isSpectator())) {
			double dist = Math.sqrt(e.squaredDistanceTo(at.x, at.y, at.z));
			if (dist > radius) {
				continue;
			}
			float damage = (float) ((minDamage + extraDamage * (1.0 - dist / radius)) * power);
			hurt(world, owner, e, damage);
			e.setOnFireFor(fireSeconds);
			double dx = e.getX() - at.x;
			double dz = e.getZ() - at.z;
			double len = Math.sqrt(dx * dx + dz * dz);
			if (len > 0.01) {
				e.addVelocity(dx / len * knockback, 0.35, dz / len * knockback);
			}
		}
	}

	// ------------------------------------------------------------------ Água

	/** Lança de Gelo: raio de gelo de alvo único, que também deixa o alvo lento e congelado. */
	private static boolean iceLance(ServerWorld world, ServerPlayerEntity p, int range, double power) {
		Vec3d[] ray = ray(world, p, range);
		LivingEntity target = findTarget(world, p, ray[0], ray[1], 0.35);
		Vec3d at = target != null ? bodyPos(target) : ray[1];
		trail(world, ParticleTypes.SNOWFLAKE, ray[0], at);
		trail(world, ParticleTypes.END_ROD, ray[0], at);
		world.spawnParticles(ParticleTypes.SNOWFLAKE, at.x, at.y, at.z, 30, 0.4, 0.4, 0.4, 0.08);
		sound(world, at.x, at.y, at.z, SoundEvents.BLOCK_GLASS_BREAK, 1.0f, 1.4f);
		if (target != null) {
			hurt(world, p, target, (float) (7.0 * power));
			target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 80, 2));
			target.setFrozenTicks(200);
		}
		return true;
	}

	/** Onda Gélida: anel de frio ao redor do conjurador, atinge todos próximos. */
	private static boolean frostWave(ServerWorld world, ServerPlayerEntity p, int range, double power) {
		Vec3d c = new Vec3d(p.getX(), p.getY(), p.getZ());
		return frostWaveAt(world, p, c, range, power);
	}

	private static boolean frostWaveAt(ServerWorld world, ServerPlayerEntity p, Vec3d c, int range, double power) {
		Box area = new Box(c.x - range, c.y - 2, c.z - range, c.x + range, c.y + 3, c.z + range);
		for (LivingEntity e : world.getEntitiesByClass(LivingEntity.class, area,
				x -> x != p && x.isAlive() && !x.isSpectator())) {
			if (Math.sqrt(e.squaredDistanceTo(c.x, c.y, c.z)) > range) {
				continue;
			}
			hurt(world, p, e, (float) (3.0 * power));
			e.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 100, 2));
			e.setFrozenTicks(240);
		}
		for (double r = 1.5; r <= range; r += 1.5) {
			ring(world, ParticleTypes.SNOWFLAKE, c.add(0.0, 0.2, 0.0), r, (int) (r * 6));
		}
		sound(world, c.x, c.y, c.z, SoundEvents.BLOCK_GLASS_BREAK, 1.0f, 0.6f);
		return true;
	}

	/** Muralha de Gelo: parede temporária de gelo compactado à frente (some sozinha). */
	private static boolean iceWall(ServerWorld world, ServerPlayerEntity p, double power) {
		int placed = placeWall(world, p, Blocks.PACKED_ICE, (int) Math.round(300 * power));
		sound(world, p.getX(), p.getY(), p.getZ(), SoundEvents.BLOCK_GLASS_BREAK, 1.0f, 0.5f);
		return placed > 0;
	}

	/** Parede temporária 5 de largura por 3 de altura, 3 blocos à frente; só ocupa blocos de ar. */
	static int placeWall(ServerWorld world, ServerPlayerEntity p, Block block, int lifetimeTicks) {
		Vec3d look = p.getRotationVec(1.0f);
		double fx = look.x;
		double fz = look.z;
		double len = Math.sqrt(fx * fx + fz * fz);
		if (len < 0.0001) {
			fx = 0.0;
			fz = 1.0;
		} else {
			fx /= len;
			fz /= len;
		}
		double cx = p.getX() + fx * 3.0;
		double cz = p.getZ() + fz * 3.0;
		double rx = -fz;
		double rz = fx;
		int baseY = MathHelper.floor(p.getY());
		int placed = 0;
		for (int i = -2; i <= 2; i++) {
			for (int h = 0; h <= 2; h++) {
				BlockPos pos = new BlockPos(MathHelper.floor(cx + rx * i), baseY + h, MathHelper.floor(cz + rz * i));
				if (world.getBlockState(pos).isAir()) {
					addTempBlock(world, pos, block, lifetimeTicks);
					placed++;
				}
			}
		}
		world.spawnParticles(ParticleTypes.POOF, cx, baseY + 1.5, cz, 30, 2.0, 1.0, 0.3, 0.05);
		return placed;
	}

	/** Cura Aquática: recupera vida do conjurador e apaga o fogo. */
	private static boolean aquaHeal(ServerWorld world, ServerPlayerEntity p, double power) {
		p.heal((float) (8.0 * power));
		p.setFireTicks(0);
		world.spawnParticles(ParticleTypes.HEART, p.getX(), p.getY() + 1.2, p.getZ(), 6, 0.4, 0.4, 0.4, 0.02);
		world.spawnParticles(ParticleTypes.SPLASH, p.getX(), p.getY() + 1.0, p.getZ(), 30, 0.5, 0.6, 0.5, 0.1);
		sound(world, p.getX(), p.getY(), p.getZ(), SoundEvents.ENTITY_GENERIC_EXTINGUISH_FIRE, 0.8f, 1.5f);
		return true;
	}

	/** Prisão de Gelo: prende o alvo visado no lugar por alguns segundos. */
	private static boolean icePrison(ServerWorld world, ServerPlayerEntity p, int range, double power) {
		LivingEntity target = aimedTarget(world, p, range);
		if (target == null) {
			return false;
		}
		int ticks = (int) Math.round(80 * power);
		target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, ticks, 6));
		target.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, ticks, 1));
		target.setFrozenTicks(ticks + 100);
		hurt(world, p, target, (float) (3.0 * power));
		Vec3d c = bodyPos(target);
		for (double h = -0.8; h <= 0.8; h += 0.4) {
			ring(world, ParticleTypes.SNOWFLAKE, c.add(0.0, h, 0.0), 0.9, 14);
		}
		world.spawnParticles(ParticleTypes.END_ROD, c.x, c.y, c.z, 20, 0.5, 0.7, 0.5, 0.02);
		sound(world, c.x, c.y, c.z, SoundEvents.BLOCK_GLASS_BREAK, 1.0f, 0.8f);
		return true;
	}

	// ------------------------------------------------------------------ efeitos contínuos

	static void addZone(ServerWorld world, Vec3d center, UUID owner, float damage, int ticks, ZoneKind kind) {
		synchronized (ZONES) {
			ZONES.add(new Zone(world, center, owner, damage, ticks, kind));
		}
	}

	/** Bloco temporário: colocado só em ar e removido sozinho (ou ao fechar o servidor). */
	static void addTempBlock(ServerWorld world, BlockPos pos, Block block, int ticks) {
		world.setBlockState(pos, block.getDefaultState());
		synchronized (TEMP) {
			TEMP.add(new TempBlock(world, pos, block, ticks));
		}
	}

	static void tick(MinecraftServer server) {
		synchronized (ZONES) {
			Iterator<Zone> it = ZONES.iterator();
			while (it.hasNext()) {
				Zone z = it.next();
				z.ticksLeft--;
				if (z.ticksLeft <= 0) {
					it.remove();
					continue;
				}
				tickZone(server, z);
			}
		}
		synchronized (TEMP) {
			Iterator<TempBlock> it = TEMP.iterator();
			while (it.hasNext()) {
				TempBlock b = it.next();
				b.ticksLeft--;
				if (b.ticksLeft <= 0) {
					removeTemp(b);
					it.remove();
				}
			}
		}
	}

	private static void tickZone(MinecraftServer server, Zone z) {
		double r = z.radius();
		Vec3d c = z.center;
		switch (z.kind) {
			case FIRE -> {
				if (z.ticksLeft % 4 == 0) {
					z.world.spawnParticles(ParticleTypes.FLAME, c.x, c.y + 0.1, c.z, 14, 1.6, 0.1, 1.6, 0.02);
					z.world.spawnParticles(ParticleTypes.SMOKE, c.x, c.y + 0.5, c.z, 2, 1.4, 0.2, 1.4, 0.01);
				}
			}
			case VORTEX -> {
				if (z.ticksLeft % 2 == 0) {
					z.world.spawnParticles(ParticleTypes.CLOUD, c.x, c.y + 0.3, c.z, 10, 2.2, 0.8, 2.2, 0.15);
					ring(z.world, ParticleTypes.CLOUD, c.add(0.0, 0.5 + (z.ticksLeft % 10) * 0.2, 0.0), r, 20);
				}
			}
			case MIASMA -> {
				if (z.ticksLeft % 4 == 0) {
					z.world.spawnParticles(ParticleTypes.SQUID_INK, c.x, c.y + 0.4, c.z, 8, 1.8, 0.3, 1.8, 0.01);
					z.world.spawnParticles(ParticleTypes.WITCH, c.x, c.y + 0.6, c.z, 6, 1.8, 0.4, 1.8, 0.02);
				}
			}
		}
		boolean pull = z.kind == ZoneKind.VORTEX && z.ticksLeft % 2 == 0;
		boolean hit = z.ticksLeft % 10 == 0;
		if (!pull && !hit) {
			return;
		}
		ServerPlayerEntity owner = server.getPlayerManager().getPlayer(z.owner);
		Box area = new Box(c.x - r, c.y - 1, c.z - r, c.x + r, c.y + 3, c.z + r);
		for (LivingEntity e : z.world.getEntitiesByClass(LivingEntity.class, area,
				x -> x.isAlive() && !x.isSpectator() && !x.getUuid().equals(z.owner))) {
			if (Math.sqrt(e.squaredDistanceTo(c.x, c.y, c.z)) > r) {
				continue;
			}
			if (pull) {
				double dx = c.x - e.getX();
				double dz = c.z - e.getZ();
				double len = Math.sqrt(dx * dx + dz * dz);
				if (len > 0.3) {
					e.addVelocity(dx / len * 0.14, 0.02, dz / len * 0.14);
				}
			}
			if (hit) {
				if (owner != null) {
					hurt(z.world, owner, e, z.damage);
				} else {
					e.damage(z.world, z.world.getDamageSources().onFire(), z.damage);
				}
				switch (z.kind) {
					case FIRE -> e.setOnFireFor(3.0f);
					case MIASMA -> {
						e.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 40, 0));
						e.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 60, 0));
					}
					default -> { }
				}
			}
		}
	}

	private static void removeTemp(TempBlock b) {
		if (b.world.getBlockState(b.pos).isOf(b.block)) {
			b.world.setBlockState(b.pos, Blocks.AIR.getDefaultState());
			b.world.spawnParticles(ParticleTypes.POOF, b.pos.getX() + 0.5, b.pos.getY() + 0.5, b.pos.getZ() + 0.5,
					3, 0.3, 0.3, 0.3, 0.02);
		}
	}

	/** Ao fechar o servidor: remove todo bloco temporário para não deixar blocos permanentes no mundo. */
	static void clearAll() {
		synchronized (TEMP) {
			for (TempBlock b : TEMP) {
				removeTemp(b);
			}
			TEMP.clear();
		}
		synchronized (ZONES) {
			ZONES.clear();
		}
	}

	// ------------------------------------------------------------------ utilidades

	static void hurt(ServerWorld world, ServerPlayerEntity owner, LivingEntity target, float amount) {
		target.damage(world, world.getDamageSources().playerAttack(owner), amount);
	}

	static Vec3d bodyPos(LivingEntity e) {
		return new Vec3d(e.getX(), e.getBodyY(0.5), e.getZ());
	}

	/** @return {início, fim}: do olho do jogador até o primeiro bloco no caminho (ou o alcance máximo). */
	static Vec3d[] ray(ServerWorld world, ServerPlayerEntity p, int range) {
		Vec3d eye = p.getEyePos();
		Vec3d far = eye.add(p.getRotationVec(1.0f).multiply(range));
		BlockHitResult hit = world.raycast(new RaycastContext(eye, far, RaycastContext.ShapeType.COLLIDER,
				RaycastContext.FluidHandling.NONE, p));
		Vec3d end = hit.getType() != HitResult.Type.MISS ? hit.getPos() : far;
		return new Vec3d[] {eye.add(0.0, -0.15, 0.0), end};
	}

	/** Onde o jogador mira: no alvo (corpo) se houver, senão no fim do raio (bloco ou alcance máximo). */
	static Vec3d aimPoint(ServerWorld world, ServerPlayerEntity p, int range) {
		Vec3d[] ray = ray(world, p, range);
		LivingEntity target = findTarget(world, p, ray[0], ray[1], 0.5);
		return target != null ? bodyPos(target) : ray[1];
	}

	static LivingEntity aimedTarget(ServerWorld world, ServerPlayerEntity p, int range) {
		Vec3d[] ray = ray(world, p, range);
		return findTarget(world, p, ray[0], ray[1], 0.5);
	}

	static LivingEntity findTarget(ServerWorld world, ServerPlayerEntity owner, Vec3d a, Vec3d b, double grow) {
		Box search = new Box(a, b).expand(grow + 0.5);
		LivingEntity best = null;
		double bestDist = Double.MAX_VALUE;
		for (LivingEntity e : world.getEntitiesByClass(LivingEntity.class, search,
				x -> x != owner && x.isAlive() && !x.isSpectator())) {
			Optional<Vec3d> hit = e.getBoundingBox().expand(grow).raycast(a, b);
			if (hit.isPresent()) {
				double d = a.squaredDistanceTo(hit.get());
				if (d < bestDist) {
					bestDist = d;
					best = e;
				}
			}
		}
		return best;
	}

	static void trail(ServerWorld world, ParticleEffect particle, Vec3d from, Vec3d to) {
		Vec3d d = to.subtract(from);
		double len = d.length();
		if (len < 0.5) {
			return;
		}
		Vec3d step = d.multiply(1.0 / len);
		for (double t = 1.0; t < len; t += 0.6) {
			Vec3d q = from.add(step.multiply(t));
			world.spawnParticles(particle, q.x, q.y, q.z, 1, 0.03, 0.03, 0.03, 0.0);
		}
	}

	static void ring(ServerWorld world, ParticleEffect particle, Vec3d c, double radius, int points) {
		for (int i = 0; i < points; i++) {
			double a = 2.0 * Math.PI * i / points;
			world.spawnParticles(particle, c.x + Math.cos(a) * radius, c.y, c.z + Math.sin(a) * radius,
					1, 0.0, 0.0, 0.0, 0.0);
		}
	}

	static void sound(ServerWorld world, double x, double y, double z, SoundEvent s, float volume, float pitch) {
		world.playSound(null, x, y, z, s, SoundCategory.PLAYERS, volume, pitch);
	}
}
