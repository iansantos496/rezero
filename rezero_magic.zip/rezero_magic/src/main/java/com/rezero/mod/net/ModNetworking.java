package com.rezero.mod.net;

import com.rezero.mod.server.InscriptionService;
import com.rezero.mod.server.MagicGate;
import com.rezero.mod.server.SpellService;

import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;

/** Registro dos pacotes e dos receptores do SERVIDOR. Todo pedido do cliente passa pelo MagicGate. */
public final class ModNetworking {
	private ModNetworking() {}

	public static void registerCommon() {
		PayloadTypeRegistry.playC2S().register(ChooseAffinityPayload.ID, ChooseAffinityPayload.CODEC);
		PayloadTypeRegistry.playC2S().register(CastSpellPayload.ID, CastSpellPayload.CODEC);
		PayloadTypeRegistry.playC2S().register(InscribePayload.ID, InscribePayload.CODEC);
		PayloadTypeRegistry.playS2C().register(OpenHubPayload.ID, OpenHubPayload.CODEC);
		PayloadTypeRegistry.playS2C().register(PlayerSyncPayload.ID, PlayerSyncPayload.CODEC);
		PayloadTypeRegistry.playS2C().register(OpenAffinityScreenPayload.ID, OpenAffinityScreenPayload.CODEC);
		PayloadTypeRegistry.playS2C().register(ManaSyncPayload.ID, ManaSyncPayload.CODEC);
		PayloadTypeRegistry.playS2C().register(CastStatePayload.ID, CastStatePayload.CODEC);

		ServerPlayNetworking.registerGlobalReceiver(ChooseAffinityPayload.ID, (payload, context) ->
				MagicGate.tryChooseAffinity(context.player(), payload.affinityId()));
		ServerPlayNetworking.registerGlobalReceiver(CastSpellPayload.ID, (payload, context) ->
				SpellService.requestCast(context.server(), context.player(), payload.spellId()));
		ServerPlayNetworking.registerGlobalReceiver(InscribePayload.ID, (payload, context) ->
				InscriptionService.request(context.server(), context.player(), payload.inscriptionId(), payload.remove() != 0));
	}
}
