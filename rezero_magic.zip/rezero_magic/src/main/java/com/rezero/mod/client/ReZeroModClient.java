package com.rezero.mod.client;

import org.lwjgl.glfw.GLFW;

import com.rezero.mod.ReZeroMod;
import com.rezero.mod.core.SpellDef;
import com.rezero.mod.net.CastSpellPayload;
import com.rezero.mod.net.CombatActionPayload;
import com.rezero.mod.net.CombatSyncPayload;
import com.rezero.mod.net.CastStatePayload;
import com.rezero.mod.net.ManaSyncPayload;
import com.rezero.mod.net.OpenAffinityScreenPayload;
import com.rezero.mod.net.OpenHubPayload;
import com.rezero.mod.net.PlayerSyncPayload;
import com.rezero.mod.net.TechniqueCooldownPayload;
import com.rezero.mod.net.TrainingSyncPayload;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/** Lado do cliente: recebe os retratos do servidor, abre a tela de afinidade e o Hub, mostra o HUD. */
public class ReZeroModClient implements ClientModInitializer {
	private static KeyBinding hubKey;
	private static KeyBinding castKey;
	private static KeyBinding prevKey;
	private static KeyBinding nextKey;
	private static KeyBinding dodgeKey;
	private static final KeyBinding[] SLOT_KEYS = new KeyBinding[3];

	/** Nome da tecla de técnica do espaço 0 a 2, como o jogador configurou (para o HUD). */
	public static Text slotKeyName(int slot) {
		return slot >= 0 && slot < SLOT_KEYS.length && SLOT_KEYS[slot] != null
				? SLOT_KEYS[slot].getBoundKeyLocalizedText() : Text.literal("?");
	}

	@Override
	public void onInitializeClient() {
		// Em 1.21.9+ a categoria de teclas é um objeto, não mais uma String.
		KeyBinding.Category category = KeyBinding.Category.create(Identifier.of(ReZeroMod.MOD_ID, "hub"));
		hubKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.rezero_magic.hub", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_K, category));
		castKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.rezero_magic.cast", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_R, category));
		prevKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.rezero_magic.prev_spell", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_Z, category));
		nextKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.rezero_magic.next_spell", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_X, category));
		dodgeKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.rezero_magic.dodge", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_V, category));
		int[] slotDefaults = {GLFW.GLFW_KEY_G, GLFW.GLFW_KEY_H, GLFW.GLFW_KEY_J};
		for (int i = 0; i < SLOT_KEYS.length; i++) {
			SLOT_KEYS[i] = KeyBindingHelper.registerKeyBinding(new KeyBinding(
					"key.rezero_magic.technique_" + (i + 1), InputUtil.Type.KEYSYM, slotDefaults[i], category));
		}

		ClientPlayNetworking.registerGlobalReceiver(PlayerSyncPayload.ID, (payload, context) -> {
			ClientPlayerData.update(payload.affinityId(), payload.channelLevel(), payload.channelXp(), payload.marksMask());
			// o servidor confirmou a escolha: a tela obrigatória pode fechar
			MinecraftClient client = MinecraftClient.getInstance();
			if (ClientPlayerData.affinity() != null && client.currentScreen instanceof AffinityScreen) {
				client.setScreen(null);
			}
		});

		ClientPlayNetworking.registerGlobalReceiver(TrainingSyncPayload.ID, (payload, context) ->
				ClientPlayerData.updateTraining(payload.levelsPack(), payload.xpA(), payload.xpB(), payload.focus(), payload.fatigue()));

		ClientPlayNetworking.registerGlobalReceiver(CombatSyncPayload.ID, (payload, context) ->
				ClientPlayerData.updateCombat(payload.techniqueMask(), payload.stamina(), payload.maxStamina()));

		ClientPlayNetworking.registerGlobalReceiver(TechniqueCooldownPayload.ID, (payload, context) ->
				ClientPlayerData.onTechniqueCooldown(payload.techniqueId(), payload.ticks()));

		ClientPlayNetworking.registerGlobalReceiver(ManaSyncPayload.ID, (payload, context) ->
				ClientPlayerData.updateMana(payload.mana(), payload.exhausted() != 0));

		ClientPlayNetworking.registerGlobalReceiver(CastStatePayload.ID, (payload, context) ->
				ClientPlayerData.onCastState(payload.spellId(), payload.castTicks(), payload.cooldownTicks()));

		ClientPlayNetworking.registerGlobalReceiver(OpenHubPayload.ID, (payload, context) ->
				ClientPlayerData.requestHubTab(payload.tab()));

		ClientPlayNetworking.registerGlobalReceiver(OpenAffinityScreenPayload.ID, (payload, context) ->
				ClientPlayerData.requestAffinityScreen());

		// HudRenderCallback está marcado como deprecated nas versões novas do Fabric API,
		// mas continua funcionando (compilou no projeto antigo). Se for removido, troque por HudElementRegistry.
		HudRenderCallback.EVENT.register((context, tickCounter) -> {
			SpellHud.render(context);
			CombatHud.render(context);
		});

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			ClientPlayerData.tick();
			if (client.player == null) {
				return;
			}
			// abre a tela quando o jogo estiver livre (ex.: depois da tela de carregamento do mundo)
			if (ClientPlayerData.affinityScreenRequested() && client.currentScreen == null) {
				ClientPlayerData.clearAffinityScreenRequest();
				client.setScreen(new AffinityScreen());
				return;
			}
			if (client.currentScreen == null && ClientPlayerData.affinity() != null) {
				int requested = ClientPlayerData.takeHubTabRequest();
				if (requested >= 0) {
					client.setScreen(new HubScreen(requested));
					return;
				}
			}
			while (hubKey.wasPressed()) {
				// o Hub só abre depois da escolha de afinidade (antes disso a tela obrigatória tem prioridade)
				if (client.currentScreen == null && ClientPlayerData.affinity() != null) {
					client.setScreen(new HubScreen(0));
				}
			}
			while (prevKey.wasPressed()) {
				if (client.currentScreen == null) {
					ClientPlayerData.cycleSpell(-1);
				}
			}
			while (nextKey.wasPressed()) {
				if (client.currentScreen == null) {
					ClientPlayerData.cycleSpell(1);
				}
			}
			// combate: só PEDIDOS; o servidor confere arma, aprendizado, estamina e recarga
			while (dodgeKey.wasPressed()) {
				if (client.currentScreen == null) {
					int dir = client.options.forwardKey.isPressed() ? 0
							: client.options.leftKey.isPressed() ? 2
							: client.options.rightKey.isPressed() ? 3 : 1;
					ClientPlayNetworking.send(new CombatActionPayload(CombatActionPayload.DODGE, dir));
				}
			}
			for (int i = 0; i < SLOT_KEYS.length; i++) {
				while (SLOT_KEYS[i].wasPressed()) {
					if (client.currentScreen == null) {
						ClientPlayNetworking.send(new CombatActionPayload(CombatActionPayload.USE, i));
					}
				}
			}
			while (castKey.wasPressed()) {
				SpellDef spell = ClientPlayerData.selectedSpell();
				// só um PEDIDO: o servidor confere afinidade, nível, mana e recarga
				if (client.currentScreen == null && spell != null) {
					ClientPlayNetworking.send(new CastSpellPayload(spell.id()));
				}
			}
		});

		// ao sair do mundo, esquece os dados para não "vazar" para o próximo mundo
		ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> ClientPlayerData.clear());
	}
}
