package com.rezero.mod.core;

import java.util.ArrayList;
import java.util.List;

/** Regras puras de gravar e remover marcas. O servidor chama isto; o cliente só envia pedidos. */
public final class InscriptionRules {
	/** Os nomes (em minúsculas) viram chaves de tradução: message.rezero_magic.inscription.<nome>. */
	public enum Result { OK, UNKNOWN, NO_AFFINITY, NO_TABLE, LEVEL, ALREADY, FULL, NO_INK, NOT_ENGRAVED }

	private InscriptionRules() {}

	public static Result checkEngrave(Affinity affinity, List<Integer> current, Inscription ins, int channelLevel,
			int ink, boolean nearTable) {
		if (ins == null) {
			return Result.UNKNOWN;
		}
		if (affinity == null) {
			return Result.NO_AFFINITY;
		}
		if (!nearTable) {
			return Result.NO_TABLE;
		}
		if (current.contains(ins.id())) {
			return Result.ALREADY;
		}
		if (ChannelModel.clampLevel(channelLevel) < ins.unlockLevel()) {
			return Result.LEVEL;
		}
		if (current.size() >= Inscription.SLOTS) {
			return Result.FULL;
		}
		if (ink < ins.inkCost()) {
			return Result.NO_INK;
		}
		return Result.OK;
	}

	public static Result checkRemove(List<Integer> current, Inscription ins, boolean nearTable) {
		if (ins == null) {
			return Result.UNKNOWN;
		}
		if (!nearTable) {
			return Result.NO_TABLE;
		}
		return current.contains(ins.id()) ? Result.OK : Result.NOT_ENGRAVED;
	}

	/** Limpa uma lista salva: remove ids inválidos e repetidos e corta no máximo de espaços. */
	public static List<Integer> sanitize(List<Integer> raw) {
		List<Integer> out = new ArrayList<>();
		if (raw == null) {
			return out;
		}
		for (Integer id : raw) {
			if (id != null && Inscription.fromId(id) != null && !out.contains(id) && out.size() < Inscription.SLOTS) {
				out.add(id);
			}
		}
		return out;
	}

	public static int toMask(List<Integer> ids) {
		int mask = 0;
		for (int id : sanitize(ids)) {
			mask |= 1 << id;
		}
		return mask;
	}

	public static List<Inscription> fromMask(int mask) {
		List<Inscription> out = new ArrayList<>();
		for (Inscription i : Inscription.values()) {
			if ((mask & i.bit()) != 0 && out.size() < Inscription.SLOTS) {
				out.add(i);
			}
		}
		return out;
	}
}
