package com.rezero.mod.data;

import com.rezero.mod.ReZeroMod;

import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;

/**
 * ÚNICO ponto que sabe COMO os dados do jogador são guardados.
 * Usa o Data Attachment do Fabric API: o dado fica anexado ao jogador e é salvo junto com os dados
 * do jogador DENTRO do mundo (cada mundo tem os seus). Se essa API falhar no build, só esta classe
 * precisa ser trocada (plano B: arquivo por jogador na pasta do mundo).
 */
public final class PlayerDataStore {
	public static final AttachmentType<PlayerMagicData> TYPE = AttachmentRegistry.<PlayerMagicData>builder()
			.persistent(PlayerMagicData.CODEC)
			.initializer(PlayerMagicData::new)
			.copyOnDeath()
			.buildAndRegister(Identifier.of(ReZeroMod.MOD_ID, "player_data"));

	private PlayerDataStore() {}

	/** Força o registro do tipo durante a inicialização do mod. */
	public static void init() {
		ReZeroMod.LOGGER.info("Dados do jogador registrados (salvos por mundo).");
	}

	public static PlayerMagicData get(ServerPlayerEntity player) {
		return player.getAttachedOrCreate(TYPE);
	}

	public static void save(ServerPlayerEntity player, PlayerMagicData data) {
		player.setAttached(TYPE, data);
	}
}
