package com.rezero.mod.content;

import java.util.function.Function;

import com.rezero.mod.ReZeroMod;
import com.rezero.mod.core.Catalyst;
import com.rezero.mod.core.Charm;
import com.rezero.mod.core.CrystalRarity;
import com.rezero.mod.core.CrystalRules;
import com.rezero.mod.core.RobePiece;
import com.rezero.mod.core.RobeSet;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.EquippableComponent;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.Items;
import net.minecraft.item.equipment.EquipmentAsset;
import net.minecraft.item.equipment.EquipmentAssetKeys;
import net.minecraft.item.ToolMaterial;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;
import net.minecraft.util.Rarity;

/** Itens do mod. Cada item precisa de: modelo, textura, item model definition e tradução. */
public final class ModItems {
	public static final Item MANA_CRYSTAL_FRAGMENT = crystal(CrystalRarity.FRAGMENT, Rarity.COMMON);
	public static final Item MANA_CRYSTAL = crystal(CrystalRarity.CRYSTAL, Rarity.UNCOMMON);
	public static final Item MANA_CRYSTAL_PURE = crystal(CrystalRarity.PURE, Rarity.RARE);
	public static final Item MANA_CRYSTAL_PRIMORDIAL = crystal(CrystalRarity.PRIMORDIAL, Rarity.EPIC);

	// o Receptor nasce VAZIO: dano inicial = capacidade (guardado = capacidade - dano)
	public static final Item MANA_RECEPTOR = register("mana_receptor", ManaReceptorItem::new,
			new Item.Settings().maxDamage(CrystalRules.RECEPTOR_MAX_DAMAGE)
					.component(DataComponentTypes.DAMAGE, CrystalRules.RECEPTOR_CAPACITY).rarity(Rarity.UNCOMMON));

	// espadas (usam as propriedades de espada do jogo base: dano, velocidade, durabilidade e reparo do material)
	public static final Item CRYSTAL_DAGGER = register("crystal_dagger", Item::new,
			new Item.Settings().sword(ToolMaterial.IRON, 1.0f, -1.6f).rarity(Rarity.UNCOMMON));
	public static final Item MANA_SHORTSWORD = register("mana_shortsword", Item::new,
			new Item.Settings().sword(ToolMaterial.IRON, 2.0f, -2.2f).rarity(Rarity.UNCOMMON));
	public static final Item CRYSTAL_RAPIER = register("crystal_rapier", Item::new,
			new Item.Settings().sword(ToolMaterial.IRON, 2.5f, -1.4f).rarity(Rarity.UNCOMMON));
	public static final Item MANA_LONGSWORD = register("mana_longsword", Item::new,
			new Item.Settings().sword(ToolMaterial.IRON, 3.5f, -2.6f).rarity(Rarity.RARE));
	public static final Item MANA_GREATSWORD = register("mana_greatsword", Item::new,
			new Item.Settings().sword(ToolMaterial.DIAMOND, 4.0f, -3.0f).rarity(Rarity.RARE));
	public static final Item PRIMORDIAL_BLADE = register("primordial_blade", Item::new,
			new Item.Settings().sword(ToolMaterial.NETHERITE, 4.0f, -2.4f).rarity(Rarity.EPIC));

	// lanças (mesmas propriedades de arma do jogo base; o estilo "lança" do combate reconhece estas e o tridente)
	public static final Item MANA_SPEAR = register("mana_spear", Item::new,
			new Item.Settings().sword(ToolMaterial.IRON, 3.0f, -2.4f).rarity(Rarity.UNCOMMON));
	public static final Item CRYSTAL_SPEAR = register("crystal_spear", Item::new,
			new Item.Settings().sword(ToolMaterial.DIAMOND, 3.5f, -2.4f).rarity(Rarity.RARE));

	// cajados catalisadores (mão principal) e acessórios (mão secundária)
	public static final Item MANA_STAFF_APPRENTICE = catalyst(Catalyst.APPRENTICE, Rarity.COMMON);
	public static final Item MANA_STAFF_CRYSTAL = catalyst(Catalyst.CRYSTAL, Rarity.UNCOMMON);
	public static final Item MANA_STAFF_PURE = catalyst(Catalyst.PURE, Rarity.RARE);
	public static final Item MANA_STAFF_PRIMORDIAL = catalyst(Catalyst.PRIMORDIAL, Rarity.EPIC);
	public static final Item CHARM_FLUX = charm(Charm.FLUX, Rarity.UNCOMMON);
	public static final Item CHARM_FOCUS = charm(Charm.FOCUS, Rarity.UNCOMMON);
	public static final Item CHARM_CRYSTAL = charm(Charm.CRYSTAL, Rarity.UNCOMMON);
	public static final Item CHARM_THRIFT = charm(Charm.THRIFT, Rarity.UNCOMMON);
	public static final Item CHARM_RESONANCE = charm(Charm.RESONANCE, Rarity.RARE);

	// tinta de cristal (gasta ao gravar marcas na Mesa de Inscrição)
	public static final Item MANA_INK = register("mana_ink", Item::new, new Item.Settings().rarity(Rarity.UNCOMMON));

	// vestes: ROBES[conjunto][peça]
	public static final Item[][] ROBES = buildRobes();

	private ModItems() {}

	private static Item[][] buildRobes() {
		Item[][] all = new Item[RobeSet.values().length][RobePiece.values().length];
		for (RobeSet set : RobeSet.values()) {
			RegistryKey<EquipmentAsset> asset = RegistryKey.of(EquipmentAssetKeys.REGISTRY_KEY, Identifier.of(ReZeroMod.MOD_ID, set.key()));
			Rarity rarity = set == RobeSet.APPRENTICE ? Rarity.COMMON : set == RobeSet.CRYSTAL ? Rarity.UNCOMMON : Rarity.RARE;
			for (RobePiece piece : RobePiece.values()) {
				EquipmentSlot slot = switch (piece) {
					case HOOD -> EquipmentSlot.HEAD;
					case TUNIC -> EquipmentSlot.CHEST;
					case TROUSERS -> EquipmentSlot.LEGS;
					case BOOTS -> EquipmentSlot.FEET;
				};
				// peça vestível (modelo do equipamento em assets/rezero_magic/equipment/<conjunto>.json); sem proteção física
				Item.Settings settings = new Item.Settings().maxCount(1).rarity(rarity)
						.component(DataComponentTypes.EQUIPPABLE, EquippableComponent.builder(slot).model(asset).build());
				all[set.id()][piece.id()] = register(set.itemKey(piece), s -> new RobeItem(s, set, piece, slot), settings);
			}
		}
		return all;
	}

	private static Item catalyst(Catalyst c, Rarity rarity) {
		return register(c.key(), settings -> new CatalystItem(settings, c), new Item.Settings().maxCount(1).rarity(rarity));
	}

	private static Item charm(Charm c, Rarity rarity) {
		return register(c.key(), settings -> new CharmItem(settings, c), new Item.Settings().maxCount(1).rarity(rarity));
	}

	private static Item crystal(CrystalRarity rarity, Rarity itemRarity) {
		return register(rarity.key(), settings -> new ManaCrystalItem(settings, rarity),
				new Item.Settings().rarity(itemRarity));
	}

	private static Item register(String path, Function<Item.Settings, Item> factory, Item.Settings settings) {
		RegistryKey<Item> key = RegistryKey.of(RegistryKeys.ITEM, Identifier.of(ReZeroMod.MOD_ID, path));
		return Items.register(key, factory, settings);
	}

	/** O cristal de uma raridade (usado pela interface e pelo servidor). */
	public static Item crystalItem(CrystalRarity rarity) {
		return switch (rarity) {
			case FRAGMENT -> MANA_CRYSTAL_FRAGMENT;
			case CRYSTAL -> MANA_CRYSTAL;
			case PURE -> MANA_CRYSTAL_PURE;
			case PRIMORDIAL -> MANA_CRYSTAL_PRIMORDIAL;
		};
	}

	/** Força o registro e coloca tudo nas abas do modo criativo. */
	public static void init() {
		ItemGroupEvents.modifyEntriesEvent(ItemGroups.INGREDIENTS).register(entries -> {
			entries.add(MANA_CRYSTAL_FRAGMENT);
			entries.add(MANA_CRYSTAL);
			entries.add(MANA_CRYSTAL_PURE);
			entries.add(MANA_CRYSTAL_PRIMORDIAL);
		});
		ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(entries -> {
			entries.add(MANA_RECEPTOR);
			entries.add(MANA_INK);
			entries.add(MANA_STAFF_APPRENTICE);
			entries.add(MANA_STAFF_CRYSTAL);
			entries.add(MANA_STAFF_PURE);
			entries.add(MANA_STAFF_PRIMORDIAL);
			entries.add(CHARM_FLUX);
			entries.add(CHARM_FOCUS);
			entries.add(CHARM_CRYSTAL);
			entries.add(CHARM_THRIFT);
			entries.add(CHARM_RESONANCE);
		});
		ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(entries -> {
			for (Item[] set : ROBES) {
				for (Item piece : set) {
					entries.add(piece);
				}
			}
			entries.add(CRYSTAL_DAGGER);
			entries.add(MANA_SHORTSWORD);
			entries.add(CRYSTAL_RAPIER);
			entries.add(MANA_LONGSWORD);
			entries.add(MANA_GREATSWORD);
			entries.add(PRIMORDIAL_BLADE);
			entries.add(MANA_SPEAR);
			entries.add(CRYSTAL_SPEAR);
		});
		ItemGroupEvents.modifyEntriesEvent(ItemGroups.NATURAL).register(entries -> entries.add(ModBlocks.MANA_CRYSTAL_ORE));
		ItemGroupEvents.modifyEntriesEvent(ItemGroups.FUNCTIONAL).register(entries -> {
			entries.add(ModBlocks.MANA_CONCENTRATOR);
			entries.add(ModBlocks.INSCRIPTION_TABLE);
		});
		ReZeroMod.LOGGER.info("Itens registrados: cristais, Receptor, tinta, 6 espadas, 2 lanças, 4 cajados, 5 acessórios e 12 peças de veste.");
	}
}
