package com.rezero.mod.net;

import com.rezero.mod.ReZeroMod;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Cliente -> servidor: "quero gravar (remove = 0) ou remover (remove = 1) a marca X". É só um pedido. */
public record InscribePayload(int inscriptionId, int remove) implements CustomPayload {
	public static final CustomPayload.Id<InscribePayload> ID =
			new CustomPayload.Id<>(Identifier.of(ReZeroMod.MOD_ID, "inscribe"));

	public static final PacketCodec<RegistryByteBuf, InscribePayload> CODEC = PacketCodec.tuple(
			PacketCodecs.VAR_INT, InscribePayload::inscriptionId,
			PacketCodecs.VAR_INT, InscribePayload::remove,
			InscribePayload::new);

	@Override
	public CustomPayload.Id<? extends CustomPayload> getId() {
		return ID;
	}
}
