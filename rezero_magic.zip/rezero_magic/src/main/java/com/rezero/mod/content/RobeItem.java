package com.rezero.mod.content;

import com.rezero.mod.core.RobePiece;
import com.rezero.mod.core.RobeSet;

import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.Item;

/** Peça de veste mágica (vestível). Sem lógica própria: o SpellService conta as peças vestidas (ver core/RobeSet). */
public class RobeItem extends Item {
	private final RobeSet set;
	private final RobePiece piece;
	private final EquipmentSlot slot;

	public RobeItem(Settings settings, RobeSet set, RobePiece piece, EquipmentSlot slot) {
		super(settings);
		this.set = set;
		this.piece = piece;
		this.slot = slot;
	}

	public RobeSet set() {
		return set;
	}

	public RobePiece piece() {
		return piece;
	}

	public EquipmentSlot slot() {
		return slot;
	}
}
