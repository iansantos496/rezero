package com.rezero.mod.client;

import java.util.ArrayList;
import java.util.List;

import com.rezero.mod.core.Affinity;
import com.rezero.mod.content.EquipmentLookup;
import com.rezero.mod.content.ModItems;
import com.rezero.mod.core.CastModifiers;
import com.rezero.mod.core.CombatRules;
import com.rezero.mod.core.CombatStyle;
import com.rezero.mod.core.TechniqueDef;
import com.rezero.mod.core.Techniques;
import com.rezero.mod.core.Catalyst;
import com.rezero.mod.core.ChannelModel;
import com.rezero.mod.core.Charm;
import com.rezero.mod.core.CrystalRarity;
import com.rezero.mod.core.CrystalRules;
import com.rezero.mod.core.Inscription;
import com.rezero.mod.core.RobeSet;
import com.rezero.mod.core.SpellDef;
import com.rezero.mod.core.Spells;
import com.rezero.mod.core.TrainingAttribute;
import com.rezero.mod.core.TrainingModel;
import com.rezero.mod.net.CombatActionPayload;
import com.rezero.mod.net.InscribePayload;
import com.rezero.mod.net.SelectTrainingPayload;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;

/**
 * Hub: interface central do mod. Mostra SOMENTE dados reais enviados pelo servidor.
 * Regra do projeto: um sistema só ganha aba/botão aqui depois de estar implementado.
 * Hoje: aba "Perfil" (jogador e afinidade), "Magias" (canais de mana e feitiços da afinidade) e "Cristais" (inventário) e "Equipamento" (cajado, acessório e vestes em uso) e "Marcas" (inscrições) "Treino" (atributos de treino) e "Técnicas" (combate).
 */
public class HubScreen extends Screen {
	private static final int ROW_H = 22;
	private static final int TAB_COUNT = 7;
	private static final int MARK_ROW_H = 30;

	private int left;
	private int top;
	private int panelW;
	private int panelH;
	private int tab = 0;
	private final List<ButtonWidget> selectButtons = new ArrayList<>();
	private final List<SpellDef> rowSpells = new ArrayList<>();
	private final List<ButtonWidget> markButtons = new ArrayList<>();
	private final List<ButtonWidget> pageButtons = new ArrayList<>();
	private int markPage = 0;
	private final List<ButtonWidget> trainButtons = new ArrayList<>();
	private final List<ButtonWidget> learnButtons = new ArrayList<>();
	private final List<ButtonWidget> stylePageButtons = new ArrayList<>();
	private int stylePage = 0;

	public HubScreen(int initialTab) {
		super(Text.translatable("screen.rezero_magic.hub.title"));
		this.tab = Math.max(0, Math.min(TAB_COUNT - 1, initialTab));
	}

	@Override
	public boolean shouldPause() {
		return false;
	}

	@Override
	protected void init() {
		panelW = Math.min(width - 16, 360);
		panelH = Math.min(height - 16, 250);
		left = (width - panelW) / 2;
		top = (height - panelH) / 2;
		selectButtons.clear();
		rowSpells.clear();
		markButtons.clear();
		pageButtons.clear();
		trainButtons.clear();
		learnButtons.clear();
		stylePageButtons.clear();

		addDrawable(this::drawContent);

		String[] tabKeys = {"tab_profile", "tab_spells", "tab_crystals", "tab_equipment", "tab_marks", "tab_training", "tab_combat"};
		for (int t = 0; t < TAB_COUNT; t++) {
			final int target = t;
			addDrawableChild(ButtonWidget.builder(Text.translatable("screen.rezero_magic.hub." + tabKeys[t]), b -> setTab(target))
					.dimensions(left + 8 + t * 50, top + 26, 49, 18).build());
		}

		Affinity a = ClientPlayerData.affinity();
		if (a != null) {
			int row = 0;
			for (SpellDef spell : Spells.forAffinity(a)) {
				final SpellDef s = spell;
				ButtonWidget b = ButtonWidget.builder(Text.translatable("screen.rezero_magic.hub.select"),
						btn -> ClientPlayerData.selectSpell(s.id()))
						.dimensions(left + panelW - 84, rowY(row) - 3, 70, 16).build();
				addDrawableChild(b);
				selectButtons.add(b);
				rowSpells.add(s);
				row++;
			}
		}
		// aba Marcas: 3 linhas (uma categoria por página) e botões de página
		for (int row = 0; row < 3; row++) {
			final int r = row;
			ButtonWidget b = ButtonWidget.builder(Text.translatable("screen.rezero_magic.hub.engrave"), btn -> onMarkClick(r))
					.dimensions(left + panelW - 84, markY(row) - 2, 70, 16).build();
			addDrawableChild(b);
			markButtons.add(b);
		}
		ButtonWidget prev = ButtonWidget.builder(Text.literal("<"), b -> changeMarkPage(-1))
				.dimensions(left + panelW - 68, top + 47, 24, 16).build();
		ButtonWidget next = ButtonWidget.builder(Text.literal(">"), b -> changeMarkPage(1))
				.dimensions(left + panelW - 40, top + 47, 24, 16).build();
		addDrawableChild(prev);
		addDrawableChild(next);
		pageButtons.add(prev);
		pageButtons.add(next);

		// aba Treino: um botão por atributo (só um PEDIDO; o servidor valida)
		for (TrainingAttribute attr : TrainingAttribute.values()) {
			final TrainingAttribute target = attr;
			ButtonWidget b = ButtonWidget.builder(Text.translatable("screen.rezero_magic.hub.train"),
					btn -> ClientPlayNetworking.send(new SelectTrainingPayload(target.id())))
					.dimensions(left + panelW - 84, trainY(attr.id()) - 2, 70, 16).build();
			addDrawableChild(b);
			trainButtons.add(b);
		}

		// aba Técnicas: um botão "Aprender" por técnica do estilo e botões de página (só PEDIDOS; o servidor valida)
		for (int row = 0; row < 3; row++) {
			final int r = row;
			ButtonWidget b = ButtonWidget.builder(Text.translatable("screen.rezero_magic.hub.learn"), btn -> onLearnClick(r))
					.dimensions(left + panelW - 84, techY(row) - 4, 70, 14).build();
			addDrawableChild(b);
			learnButtons.add(b);
		}
		ButtonWidget stylePrev = ButtonWidget.builder(Text.literal("<"), b -> changeStylePage(-1))
				.dimensions(left + panelW - 68, top + 47, 24, 16).build();
		ButtonWidget styleNext = ButtonWidget.builder(Text.literal(">"), b -> changeStylePage(1))
				.dimensions(left + panelW - 40, top + 47, 24, 16).build();
		addDrawableChild(stylePrev);
		addDrawableChild(styleNext);
		stylePageButtons.add(stylePrev);
		stylePageButtons.add(styleNext);

		addDrawableChild(ButtonWidget.builder(Text.translatable("screen.rezero_magic.hub.close"),
				b -> MinecraftClient.getInstance().setScreen(null))
				.dimensions(left + panelW / 2 - 50, top + panelH - 26, 100, 20).build());
		refreshButtons();
	}

	private int markY(int row) {
		return top + 100 + row * MARK_ROW_H;
	}

	private int techY(int row) {
		return top + 80 + row * 46;
	}

	private void changeStylePage(int delta) {
		stylePage = Math.floorMod(stylePage + delta, CombatStyle.values().length);
	}

	private TechniqueDef pageTechnique(int row) {
		return Techniques.slot(CombatStyle.values()[stylePage], row);
	}

	private void onLearnClick(int row) {
		TechniqueDef tech = pageTechnique(row);
		if (tech != null) {
			ClientPlayNetworking.send(new CombatActionPayload(CombatActionPayload.LEARN, tech.id()));
		}
	}

	private int trainY(int index) {
		return top + 90 + index * 20;
	}

	private void changeMarkPage(int delta) {
		markPage = Math.floorMod(markPage + delta, Inscription.Category.values().length);
	}

	/** As inscrições da página atual (uma categoria), na ordem do enum. */
	private List<Inscription> pageMarks() {
		List<Inscription> out = new ArrayList<>();
		Inscription.Category cat = Inscription.Category.values()[markPage];
		for (Inscription i : Inscription.values()) {
			if (i.category() == cat) {
				out.add(i);
			}
		}
		return out;
	}

	private void onMarkClick(int row) {
		List<Inscription> list = pageMarks();
		if (row >= list.size()) {
			return;
		}
		Inscription ins = list.get(row);
		boolean engraved = ClientPlayerData.marks().contains(ins);
		// só um PEDIDO: o servidor confere a mesa, o nível, a tinta e os espaços
		ClientPlayNetworking.send(new InscribePayload(ins.id(), engraved ? 1 : 0));
	}

	private int rowY(int row) {
		return top + 104 + row * ROW_H;
	}

	private void setTab(int t) {
		tab = t;
		refreshButtons();
	}

	private void refreshMarkButtons() {
		List<Inscription> list = pageMarks();
		List<Inscription> engraved = ClientPlayerData.marks();
		for (int i = 0; i < markButtons.size(); i++) {
			ButtonWidget b = markButtons.get(i);
			b.visible = tab == 4 && i < list.size();
			if (i < list.size()) {
				boolean has = engraved.contains(list.get(i));
				b.setMessage(Text.translatable(has ? "screen.rezero_magic.hub.remove" : "screen.rezero_magic.hub.engrave"));
				b.active = has || (engraved.size() < Inscription.SLOTS && list.get(i).unlockLevel() <= ClientPlayerData.channelLevel());
			}
		}
		for (ButtonWidget b : pageButtons) {
			b.visible = tab == 4;
		}
	}

	private void refreshTrainButtons() {
		TrainingAttribute focus = ClientPlayerData.trainingFocus();
		for (int i = 0; i < trainButtons.size(); i++) {
			ButtonWidget b = trainButtons.get(i);
			boolean selected = focus != null && focus.id() == i;
			b.visible = tab == 5;
			b.active = !selected;
			b.setMessage(Text.translatable(selected ? "screen.rezero_magic.hub.training_selected" : "screen.rezero_magic.hub.train"));
		}
	}

	private void refreshCombatButtons() {
		for (int i = 0; i < learnButtons.size(); i++) {
			ButtonWidget b = learnButtons.get(i);
			TechniqueDef tech = pageTechnique(i);
			b.visible = tab == 6 && tech != null;
			if (tech != null) {
				boolean learned = (ClientPlayerData.techniqueMask() & CombatRules.bit(tech.id())) != 0;
				b.active = !learned && CombatRules.checkLearn(ClientPlayerData.techniqueMask(), tech,
						ClientPlayerData.trainingLevels()) == CombatRules.LearnResult.OK;
				b.setMessage(Text.translatable(learned ? "screen.rezero_magic.hub.technique_learned"
						: "screen.rezero_magic.hub.learn"));
			}
		}
		for (ButtonWidget b : stylePageButtons) {
			b.visible = tab == 6;
		}
	}

	private void refreshButtons() {
		refreshMarkButtons();
		refreshTrainButtons();
		refreshCombatButtons();
		for (int i = 0; i < selectButtons.size(); i++) {
			ButtonWidget b = selectButtons.get(i);
			boolean unlocked = rowSpells.get(i).unlockLevel() <= ClientPlayerData.channelLevel();
			b.visible = tab == 1;
			b.active = unlocked;
		}
	}

	private void drawContent(DrawContext c, int mouseX, int mouseY, float delta) {
		c.fill(left - 2, top - 2, left + panelW + 2, top + panelH + 2, 0xFF000000);
		c.fill(left, top, left + panelW, top + panelH, 0xEE1B1530);

		Text title = Text.translatable("screen.rezero_magic.hub.title");
		c.drawTextWithShadow(textRenderer, title, left + (panelW - textRenderer.getWidth(title)) / 2, top + 8, 0xFFFFD34D);

		if (tab == 0) {
			drawProfile(c);
		} else if (tab == 1) {
			drawSpells(c);
		} else if (tab == 2) {
			drawCrystals(c);
		} else if (tab == 3) {
			drawEquipment(c);
		} else if (tab == 4) {
			refreshMarkButtons();
			drawMarks(c);
		} else if (tab == 5) {
			refreshTrainButtons();
			drawTraining(c);
		} else {
			refreshCombatButtons();
			drawCombat(c);
		}
	}

	private void drawProfile(DrawContext c) {
		int x = left + 14;
		int y = top + 54;
		MinecraftClient client = MinecraftClient.getInstance();
		String playerName = client.player == null ? "?" : client.player.getName().getString();
		c.drawTextWithShadow(textRenderer, Text.translatable("screen.rezero_magic.hub.player", playerName), x, y, 0xFFFFFFFF);
		y += 16;

		Affinity affinity = ClientPlayerData.affinity();
		if (affinity == null) {
			wrap(c, Text.translatable("screen.rezero_magic.hub.affinity_none"), x, y, panelW - 28, 0xFFFF7070);
			return;
		}
		Text name = Text.translatable("affinity.rezero_magic." + affinity.key());
		c.drawTextWithShadow(textRenderer, Text.translatable("screen.rezero_magic.hub.affinity", name), x, y, 0xFFB8D8FF);
		y += 16;
		y = wrap(c, Text.translatable("affinity.rezero_magic." + affinity.key() + ".canon"), x, y, panelW - 28, 0xFFDADAEA);
		y += 4;
		wrap(c, Text.translatable("affinity.rezero_magic." + affinity.key() + ".game"), x, y, panelW - 28, 0xFFFFFFFF);
	}

	private void drawSpells(DrawContext c) {
		int x = left + 14;
		int y = top + 52;
		Affinity affinity = ClientPlayerData.affinity();
		if (affinity == null) {
			wrap(c, Text.translatable("screen.rezero_magic.hub.affinity_none"), x, y, panelW - 28, 0xFFFF7070);
			return;
		}
		int level = ClientPlayerData.channelLevel();
		int needed = ChannelModel.xpNeeded(level);
		Text lv = needed > 0
				? Text.translatable("screen.rezero_magic.hub.channel_level", level, ChannelModel.MAX_LEVEL,
						ClientPlayerData.channelXp(), needed)
				: Text.translatable("screen.rezero_magic.hub.channel_level_max", level, ChannelModel.MAX_LEVEL);
		c.drawTextWithShadow(textRenderer, lv, x, y, 0xFFFFD34D);
		y += 12;
		c.drawTextWithShadow(textRenderer, Text.translatable("screen.rezero_magic.hub.channel_stats",
				ClientPlayerData.mana(), ClientPlayerData.maxMana(),
				String.format("%.2f", ChannelModel.regenPerSecond(level))), x, y, 0xFFB8D8FF);
		y += 12;
		c.drawTextWithShadow(textRenderer, Text.translatable("screen.rezero_magic.hub.channel_bonus",
				Math.round((1.0 - ChannelModel.costMultiplier(level)) * 100),
				Math.round((1.0 - ChannelModel.castTimeMultiplier(level)) * 100),
				Math.round((ChannelModel.powerMultiplier(level) - 1.0) * 100)), x, y, 0xFFDADAEA);

		SpellDef selected = ClientPlayerData.selectedSpell();
		CastModifiers mods = clientMods();
		for (int i = 0; i < rowSpells.size(); i++) {
			SpellDef s = rowSpells.get(i);
			int ry = rowY(i);
			boolean unlocked = s.unlockLevel() <= level;
			boolean isSel = selected != null && selected.id() == s.id();
			if (isSel) {
				c.fill(x - 3, ry - 4, left + panelW - 88, ry + 17, 0x66FFD34D);
			}
			Text name = Text.translatable("spell.rezero_magic." + s.key());
			c.drawTextWithShadow(textRenderer, name, x, ry, unlocked ? 0xFFFFFFFF : 0xFF777777);
			Text info = unlocked
					? Text.translatable("screen.rezero_magic.hub.spell_info",
							ChannelModel.effectiveCost(s.baseCost(), level, mods.cost()),
							String.format("%.1f", ChannelModel.effectiveCastTicks(s.baseCastTicks(), level, mods.cast()) / 20.0),
							String.format("%.1f", s.cooldownTicks() / 20.0))
					: Text.translatable("screen.rezero_magic.hub.spell_locked", s.unlockLevel());
			c.drawTextWithShadow(textRenderer, info, x, ry + 10, unlocked ? 0xFFB8D8FF : 0xFF777777);
		}
	}

	private static CastModifiers clientMods() {
		MinecraftClient client = MinecraftClient.getInstance();
		return client.player == null ? CastModifiers.NONE : EquipmentLookup.modifiersOf(client.player, ClientPlayerData.marks(), ClientPlayerData.trainingLevels());
	}

	/** Equipamento: o que você está segurando AGORA e os bônus resultantes (os mesmos que o servidor aplica). */
	private void drawEquipment(DrawContext c) {
		int x = left + 14;
		int y = top + 52;
		MinecraftClient client = MinecraftClient.getInstance();
		if (client.player == null) {
			return;
		}
		y = wrap(c, Text.translatable("screen.rezero_magic.hub.equipment_intro"), x, y, panelW - 28, 0xFFDADAEA);
		y += 6;
		Catalyst staff = EquipmentLookup.staffOf(client.player);
		Charm charm = EquipmentLookup.charmOf(client.player);
		Text none = Text.translatable("screen.rezero_magic.hub.equipment_none");
		c.drawTextWithShadow(textRenderer, Text.translatable("screen.rezero_magic.hub.equipment_staff",
				staff == null ? none : Text.translatable("item.rezero_magic." + staff.key())), x, y, 0xFFB8D8FF);
		y += 12;
		c.drawTextWithShadow(textRenderer, Text.translatable("screen.rezero_magic.hub.equipment_charm",
				charm == null ? none : Text.translatable("item.rezero_magic." + charm.key())), x, y, 0xFFB8D8FF);
		y += 12;
		int[] robes = EquipmentLookup.robePieces(client.player);
		c.drawTextWithShadow(textRenderer, Text.translatable("screen.rezero_magic.hub.equipment_robes",
				robes[RobeSet.APPRENTICE.id()], robes[RobeSet.CRYSTAL.id()], robes[RobeSet.PURE.id()]), x, y, 0xFFB8D8FF);
		y += 16;
		CastModifiers m = EquipmentLookup.modifiersOf(client.player, ClientPlayerData.marks(), ClientPlayerData.trainingLevels());
		c.drawTextWithShadow(textRenderer, Text.translatable("screen.rezero_magic.hub.equipment_total",
				Math.round((m.power() - 1.0) * 100), Math.round((1.0 - m.cost()) * 100),
				Math.round((1.0 - m.cast()) * 100), Math.round((m.regen() - 1.0) * 100)), x, y, 0xFFFFD34D);
	}

	/** Técnicas: as 3 do estilo da página, com números reais, requisitos, pontos e estado de aprendizado. */
	private void drawCombat(DrawContext c) {
		int x = left + 14;
		CombatStyle style = CombatStyle.values()[stylePage];
		int[] levels = ClientPlayerData.trainingLevels();
		int mask = ClientPlayerData.techniqueMask();
		c.drawTextWithShadow(textRenderer, Text.translatable("screen.rezero_magic.hub.combat_header",
				Text.translatable("style.rezero_magic." + style.key()), stylePage + 1, CombatStyle.values().length,
				CombatRules.availablePoints(levels, mask)), x, top + 50, 0xFFFFD34D);
		c.drawTextWithShadow(textRenderer, Text.translatable("screen.rezero_magic.hub.combat_stamina",
				ClientPlayerData.stamina(), ClientPlayerData.maxStamina(), CombatRules.DODGE_COST), x, top + 62, 0xFFB8D8FF);
		for (int row = 0; row < 3; row++) {
			TechniqueDef tech = pageTechnique(row);
			if (tech == null) {
				continue;
			}
			int ry = techY(row);
			boolean learned = (mask & CombatRules.bit(tech.id())) != 0;
			CombatRules.LearnResult result = CombatRules.checkLearn(mask, tech, levels);
			c.drawTextWithShadow(textRenderer, Text.translatable("technique.rezero_magic." + tech.key()), x, ry,
					learned ? 0xFF7CFF9A : 0xFFFFFFFF);
			c.drawTextWithShadow(textRenderer, Text.translatable("technique.rezero_magic." + tech.key() + ".desc"), x, ry + 10, 0xFFDADAEA);
			Text info;
			if (tech.damagePct() > 0) {
				info = Text.translatable(tech.windupTicks() > 0 ? "screen.rezero_magic.hub.technique_info_windup" : "screen.rezero_magic.hub.technique_info",
						tech.damagePct(), String.format("%.1f", tech.range()), tech.staminaCost(),
						String.format("%.1f", tech.cooldownTicks() / 20.0), String.format("%.1f", tech.windupTicks() / 20.0));
			} else {
				info = Text.translatable(tech.windupTicks() > 0 ? "screen.rezero_magic.hub.technique_info_nodmg_windup" : "screen.rezero_magic.hub.technique_info_nodmg",
						tech.staminaCost(), String.format("%.1f", tech.cooldownTicks() / 20.0), String.format("%.1f", tech.windupTicks() / 20.0));
			}
			c.drawTextWithShadow(textRenderer, info, x, ry + 20, 0xFFB8D8FF);
			Text req;
			int color;
			if (learned) {
				req = Text.translatable("screen.rezero_magic.hub.technique_learned");
				color = 0xFF7CFF9A;
			} else if (result == CombatRules.LearnResult.OK) {
				req = Text.translatable("screen.rezero_magic.hub.technique_can_learn", tech.pointCost());
				color = 0xFFFFD34D;
			} else {
				req = Text.translatable("screen.rezero_magic.hub.technique_req",
						Text.translatable("training.rezero_magic." + tech.attribute().key()), tech.minLevel(), tech.pointCost(),
						Text.translatable("screen.rezero_magic.hub.learn_reason_" + result.name().toLowerCase()));
				color = 0xFFFF9090;
			}
			c.drawTextWithShadow(textRenderer, req, x, ry + 30, color);
		}
	}

	/** Treino: nível, XP e efeito reais de cada atributo, teto atual, fadiga e o atributo exercitado pelo Poste de Treino. */
	private void drawTraining(DrawContext c) {
		int x = left + 14;
		wrap(c, Text.translatable("screen.rezero_magic.hub.training_intro"), x, top + 44, panelW - 28, 0xFFDADAEA);
		c.drawTextWithShadow(textRenderer, Text.translatable("screen.rezero_magic.hub.training_cap",
				TrainingModel.levelCap(ClientPlayerData.channelLevel()), ClientPlayerData.fatigue()), x, top + 76, 0xFFFFD34D);
		int cap = TrainingModel.levelCap(ClientPlayerData.channelLevel());
		TrainingAttribute focus = ClientPlayerData.trainingFocus();
		for (TrainingAttribute attr : TrainingAttribute.values()) {
			int ry = trainY(attr.id());
			int level = ClientPlayerData.trainingLevel(attr);
			int needed = TrainingModel.xpNeeded(level);
			Text name = Text.translatable("training.rezero_magic." + attr.key());
			Text row;
			if (level >= TrainingModel.MAX_LEVEL) {
				row = Text.translatable("screen.rezero_magic.hub.training_row_max", name, level);
			} else if (level >= cap) {
				row = Text.translatable("screen.rezero_magic.hub.training_row_capped", name, level);
			} else {
				row = Text.translatable("screen.rezero_magic.hub.training_row", name, level, ClientPlayerData.trainingXp(attr), needed);
			}
			boolean isFocus = focus != null && focus.id() == attr.id();
			if (isFocus) {
				c.fill(x - 3, ry - 4, left + panelW - 88, ry + 20, 0x66FFD34D);
			}
			c.drawTextWithShadow(textRenderer, row, x, ry, 0xFFFFFFFF);
			c.drawTextWithShadow(textRenderer, Text.translatable("training.rezero_magic." + attr.key() + ".desc"),
					x, ry + 10, 0xFFB8D8FF);
		}
		int[] lv = ClientPlayerData.trainingLevels();
		wrap(c, Text.translatable("screen.rezero_magic.hub.training_effects",
				String.format("%.1f", TrainingModel.maxHealthBonus(lv[TrainingAttribute.VIGOR.id()])),
				String.format("%.1f", TrainingModel.attackBonus(lv[TrainingAttribute.STRENGTH.id()])),
				String.format("%.1f", TrainingModel.speedFraction(lv[TrainingAttribute.AGILITY.id()]) * 100.0),
				TrainingModel.castReductionPct(lv[TrainingAttribute.FOCUS.id()]),
				TrainingModel.costReductionPct(lv[TrainingAttribute.CONTROL.id()]),
				TrainingModel.regenPct(lv[TrainingAttribute.CONTROL.id()])), x, top + 194, panelW - 28, 0xFF7CFF9A);
	}

	/** Marcas: as 3 da categoria atual, com custo de tinta, nível e efeito; mostra espaços e tinta REAIS. */
	private void drawMarks(DrawContext c) {
		int x = left + 14;
		int y = top + 50;
		Inscription.Category cat = Inscription.Category.values()[markPage];
		c.drawTextWithShadow(textRenderer, Text.translatable("screen.rezero_magic.hub.marks_category",
				Text.translatable("screen.rezero_magic.hub.category_" + cat.name().toLowerCase()), markPage + 1,
				Inscription.Category.values().length), x, y, 0xFFFFD34D);
		y += 14;
		MinecraftClient client = MinecraftClient.getInstance();
		int ink = 0;
		if (client.player != null) {
			PlayerInventory inv = client.player.getInventory();
			for (int i = 0; i < inv.size(); i++) {
				ItemStack st = inv.getStack(i);
				if (st.getItem() == ModItems.MANA_INK) {
					ink += st.getCount();
				}
			}
		}
		c.drawTextWithShadow(textRenderer, Text.translatable("screen.rezero_magic.hub.marks_status",
				ClientPlayerData.marks().size(), Inscription.SLOTS, ink), x, y, 0xFFB8D8FF);
		y += 12;
		wrap(c, Text.translatable("screen.rezero_magic.hub.marks_hint"), x, y, panelW - 28, 0xFFDADAEA);
		List<Inscription> list = pageMarks();
		List<Inscription> engraved = ClientPlayerData.marks();
		for (int i = 0; i < list.size(); i++) {
			Inscription ins = list.get(i);
			int ry = markY(i);
			boolean has = engraved.contains(ins);
			boolean unlocked = ins.unlockLevel() <= ClientPlayerData.channelLevel();
			int nameColor = has ? 0xFF7CFF9A : unlocked ? 0xFFFFFFFF : 0xFF777777;
			c.drawTextWithShadow(textRenderer, Text.translatable("inscription.rezero_magic." + ins.key()), x, ry, nameColor);
			c.drawTextWithShadow(textRenderer, Text.translatable("screen.rezero_magic.hub.mark_info", ins.inkCost(), ins.unlockLevel()),
					x, ry + 10, unlocked ? 0xFFB8D8FF : 0xFF777777);
			c.drawTextWithShadow(textRenderer, Text.translatable("inscription.rezero_magic." + ins.key() + ".desc"),
					x, ry + 20, 0xFFDADAEA);
		}
	}

	/** Cristais: contagem REAL do inventário do jogador e o valor de cada raridade. */
	private void drawCrystals(DrawContext c) {
		int x = left + 14;
		int y = top + 52;
		y = wrap(c, Text.translatable("screen.rezero_magic.hub.crystals_intro"), x, y, panelW - 28, 0xFFDADAEA);
		y += 6;
		MinecraftClient client = MinecraftClient.getInstance();
		if (client.player == null) {
			return;
		}
		PlayerInventory inv = client.player.getInventory();
		for (CrystalRarity r : CrystalRarity.values()) {
			int count = 0;
			for (int i = 0; i < inv.size(); i++) {
				ItemStack st = inv.getStack(i);
				if (st.getItem() == ModItems.crystalItem(r)) {
					count += st.getCount();
				}
			}
			c.drawTextWithShadow(textRenderer, Text.translatable("screen.rezero_magic.hub.crystal_row",
					Text.translatable("item.rezero_magic." + r.key()), count, r.mana()), x, y, 0xFFB8D8FF);
			y += 12;
		}
		int receptors = 0;
		int stored = 0;
		for (int i = 0; i < inv.size(); i++) {
			ItemStack st = inv.getStack(i);
			if (st.getItem() == ModItems.MANA_RECEPTOR) {
				receptors += st.getCount();
				stored += CrystalRules.storedFromDamage(st.getDamage());
			}
		}
		y += 4;
		c.drawTextWithShadow(textRenderer, Text.translatable("screen.rezero_magic.hub.receptors", receptors, stored),
				x, y, 0xFFFFD34D);
	}

	private int wrap(DrawContext c, Text t, int x, int y, int maxWidth, int color) {
		for (OrderedText line : textRenderer.wrapLines(t, maxWidth)) {
			c.drawTextWithShadow(textRenderer, line, x, y, color);
			y += 10;
		}
		return y;
	}
}
