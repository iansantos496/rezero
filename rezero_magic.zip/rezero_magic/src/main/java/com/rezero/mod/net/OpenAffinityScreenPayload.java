package com.rezero.mod.net;

import com.rezero.mod.ReZeroMod;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/**
 * Servidor -> cliente: "abra a tela de afinidade". Enviado quando o jogador entra no mundo sem afinidade
 * (reason 0) e após um reset administrativo (reason 1).
 */
public record OpenAffinityScreenPayload(int reason) implements CustomPayload {
	public static final CustomPayload.Id<OpenAffinityScreenPayload> ID =
			new CustomPayload.Id<>(Identifier.of(ReZeroMod.MOD_ID, "open_affinity_screen"));

	public static final PacketCodec<RegistryByteBuf, OpenAffinityScreenPayload> CODEC =
			PacketCodec.tuple(PacketCodecs.VAR_INT, OpenAffinityScreenPayload::reason, OpenAffinityScreenPayload::new);

	@Override
	public CustomPayload.Id<? extends CustomPayload> getId() {
		return ID;
	}
}
