package com.rezero.mod.client;

import com.rezero.mod.content.EquipmentLookup;
import com.rezero.mod.core.ChannelModel;
import com.rezero.mod.core.SpellDef;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

/** HUD: barra de mana, feitiço selecionado e barra de conjuração. Só desenha dados reais do servidor. */
final class SpellHud {
	private SpellHud() {}

	static void render(DrawContext context) {
		MinecraftClient client = MinecraftClient.getInstance();
		if (client.player == null || client.options.hudHidden || ClientPlayerData.affinity() == null) {
			return;
		}
		int x = 10;
		int y = 10;
		int width = 100;
		int mana = ClientPlayerData.mana();
		int max = ClientPlayerData.maxMana();

		int filled = width * Math.min(mana, max) / Math.max(1, max);
		context.fill(x - 1, y - 1, x + width + 1, y + 9, 0xAA000000);
		context.fill(x, y, x + filled, y + 8, ClientPlayerData.exhausted() ? 0xFF8A3A3A : 0xFF3A7BFF);
		context.drawTextWithShadow(client.textRenderer,
				Text.translatable("hud.rezero_magic.mana", mana, max), x, y + 11, 0xFFFFFFFF);

		int level = ClientPlayerData.channelLevel();
		int needed = ChannelModel.xpNeeded(level);
		Text levelText = needed > 0
				? Text.translatable("hud.rezero_magic.channel", level, ClientPlayerData.channelXp(), needed)
				: Text.translatable("hud.rezero_magic.channel_max", level);
		context.drawTextWithShadow(client.textRenderer, levelText, x, y + 24, 0xFFFFD34D);

		SpellDef spell = ClientPlayerData.selectedSpell();
		if (spell != null) {
			int cost = ChannelModel.effectiveCost(spell.baseCost(), level, EquipmentLookup.modifiersOf(client.player, ClientPlayerData.marks()).cost());
			int cd = ClientPlayerData.cooldownLeft(spell.id());
			Text name = Text.translatable("spell.rezero_magic." + spell.key());
			Text line = cd > 0
					? Text.translatable("hud.rezero_magic.spell_cd", name, cost, String.format("%.1f", cd / 20.0))
					: Text.translatable("hud.rezero_magic.spell", name, cost);
			context.drawTextWithShadow(client.textRenderer, line, x, y + 38, cd > 0 ? 0xFFAAAAAA : 0xFFFFFFFF);
		}

		float progress = ClientPlayerData.castProgress();
		if (progress >= 0.0f) {
			int w = client.getWindow().getScaledWidth();
			int h = client.getWindow().getScaledHeight();
			int bw = 80;
			int bx = (w - bw) / 2;
			int by = h / 2 + 20;
			context.fill(bx - 1, by - 1, bx + bw + 1, by + 5, 0xAA000000);
			context.fill(bx, by, bx + (int) (bw * progress), by + 4, 0xFFFFA030);
		}
	}
}
