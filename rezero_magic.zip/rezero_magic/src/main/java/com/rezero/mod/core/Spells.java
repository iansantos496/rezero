package com.rezero.mod.core;

import java.util.ArrayList;
import java.util.List;

/**
 * Registro de feitiços (Sistema 1). Cada afinidade terá 5 feitiços com mecânicas diferentes.
 * Todas as 6 afinidades têm 5 feitiços (30 no total).
 * Os nomes Goa/Elgoa/Urgoa/Algoa (Fogo), Dona (Terra) e Shamak (Yin) vêm da obra; o que cada
 * feitiço FAZ no jogo é adaptação, e os demais nomes são de jogo.
 */
public final class Spells {
	public static final int GOA = 0;
	public static final int ELGOA = 1;
	public static final int URGOA = 2;
	public static final int FIRE_ZONE = 3;
	public static final int ALGOA = 4;
	public static final int ICE_LANCE = 5;
	public static final int FROST_WAVE = 6;
	public static final int ICE_WALL = 7;
	public static final int AQUA_HEAL = 8;
	public static final int ICE_PRISON = 9;
	public static final int WIND_GUST = 10;
	public static final int WIND_BLADE = 11;
	public static final int WIND_LEAP = 12;
	public static final int WIND_VORTEX = 13;
	public static final int WIND_STORM = 14;
	public static final int EARTH_SPIKE = 15;
	public static final int EARTH_WALL = 16;
	public static final int EARTH_ROOT = 17;
	public static final int STONE_SKIN = 18;
	public static final int EARTHQUAKE = 19;
	public static final int SHAMAK = 20;
	public static final int MIASMA = 21;
	public static final int LIFE_DRAIN = 22;
	public static final int CURSE = 23;
	public static final int ECLIPSE = 24;
	public static final int STRENGTHEN = 25;
	public static final int AGILITY = 26;
	public static final int RADIANT_SHIELD = 27;
	public static final int BLESSING = 28;
	public static final int ZENITH = 29;

	private static final List<SpellDef> ALL = List.of(
			// id, chave, afinidade, tipo, custo, conjuração(ticks), recarga(ticks), nível dos canais, alcance
			new SpellDef(GOA, "goa", Affinity.FIRE, SpellDef.Kind.OFFENSIVE, 12, 6, 20, 1, 24),
			new SpellDef(ELGOA, "elgoa", Affinity.FIRE, SpellDef.Kind.OFFENSIVE, 28, 16, 70, 3, 28),
			new SpellDef(URGOA, "urgoa", Affinity.FIRE, SpellDef.Kind.OFFENSIVE, 22, 12, 60, 6, 9),
			new SpellDef(FIRE_ZONE, "fire_zone", Affinity.FIRE, SpellDef.Kind.OFFENSIVE, 35, 20, 160, 9, 20),
			new SpellDef(ALGOA, "algoa", Affinity.FIRE, SpellDef.Kind.OFFENSIVE, 75, 45, 500, 14, 32),
			new SpellDef(ICE_LANCE, "ice_lance", Affinity.WATER, SpellDef.Kind.OFFENSIVE, 12, 6, 18, 1, 28),
			new SpellDef(FROST_WAVE, "frost_wave", Affinity.WATER, SpellDef.Kind.OFFENSIVE, 20, 10, 50, 3, 8),
			new SpellDef(ICE_WALL, "ice_wall", Affinity.WATER, SpellDef.Kind.DEFENSIVE, 30, 14, 140, 6, 5),
			new SpellDef(AQUA_HEAL, "aqua_heal", Affinity.WATER, SpellDef.Kind.UTILITY, 32, 24, 200, 9, 0),
			new SpellDef(ICE_PRISON, "ice_prison", Affinity.WATER, SpellDef.Kind.OFFENSIVE, 40, 20, 240, 12, 16),
			new SpellDef(WIND_GUST, "wind_gust", Affinity.WIND, SpellDef.Kind.OFFENSIVE, 10, 4, 20, 1, 9),
			new SpellDef(WIND_BLADE, "wind_blade", Affinity.WIND, SpellDef.Kind.OFFENSIVE, 18, 8, 40, 3, 22),
			new SpellDef(WIND_LEAP, "wind_leap", Affinity.WIND, SpellDef.Kind.UTILITY, 14, 0, 60, 6, 0),
			new SpellDef(WIND_VORTEX, "wind_vortex", Affinity.WIND, SpellDef.Kind.OFFENSIVE, 32, 16, 160, 9, 18),
			new SpellDef(WIND_STORM, "wind_storm", Affinity.WIND, SpellDef.Kind.OFFENSIVE, 70, 40, 450, 14, 24),
			new SpellDef(EARTH_SPIKE, "earth_spike", Affinity.EARTH, SpellDef.Kind.OFFENSIVE, 12, 6, 22, 1, 10),
			new SpellDef(EARTH_WALL, "earth_wall", Affinity.EARTH, SpellDef.Kind.DEFENSIVE, 26, 12, 140, 3, 5),
			new SpellDef(EARTH_ROOT, "earth_root", Affinity.EARTH, SpellDef.Kind.OFFENSIVE, 24, 14, 110, 6, 16),
			new SpellDef(STONE_SKIN, "stone_skin", Affinity.EARTH, SpellDef.Kind.DEFENSIVE, 30, 12, 260, 9, 0),
			new SpellDef(EARTHQUAKE, "earthquake", Affinity.EARTH, SpellDef.Kind.OFFENSIVE, 65, 40, 420, 13, 8),
			new SpellDef(SHAMAK, "shamak", Affinity.YIN, SpellDef.Kind.OFFENSIVE, 10, 6, 24, 1, 24),
			new SpellDef(MIASMA, "miasma", Affinity.YIN, SpellDef.Kind.OFFENSIVE, 28, 14, 130, 3, 18),
			new SpellDef(LIFE_DRAIN, "life_drain", Affinity.YIN, SpellDef.Kind.OFFENSIVE, 26, 12, 90, 6, 16),
			new SpellDef(CURSE, "curse", Affinity.YIN, SpellDef.Kind.OFFENSIVE, 36, 20, 200, 9, 18),
			new SpellDef(ECLIPSE, "eclipse", Affinity.YIN, SpellDef.Kind.OFFENSIVE, 60, 36, 400, 12, 10),
			new SpellDef(STRENGTHEN, "strengthen", Affinity.YANG, SpellDef.Kind.UTILITY, 14, 10, 200, 1, 8),
			new SpellDef(AGILITY, "agility", Affinity.YANG, SpellDef.Kind.UTILITY, 16, 8, 200, 3, 8),
			new SpellDef(RADIANT_SHIELD, "radiant_shield", Affinity.YANG, SpellDef.Kind.DEFENSIVE, 30, 14, 260, 6, 8),
			new SpellDef(BLESSING, "blessing", Affinity.YANG, SpellDef.Kind.UTILITY, 38, 24, 300, 9, 8),
			new SpellDef(ZENITH, "zenith", Affinity.YANG, SpellDef.Kind.UTILITY, 60, 30, 600, 12, 8));

	private Spells() {}

	public static List<SpellDef> all() {
		return ALL;
	}

	/** @return o feitiço com esse id, ou null (por exemplo, id vindo de um pacote adulterado). */
	public static SpellDef byId(int id) {
		for (SpellDef s : ALL) {
			if (s.id() == id) {
				return s;
			}
		}
		return null;
	}

	/** Feitiços da afinidade, do primeiro a desbloquear para o último. */
	public static List<SpellDef> forAffinity(Affinity affinity) {
		List<SpellDef> out = new ArrayList<>();
		for (SpellDef s : ALL) {
			if (s.affinity() == affinity) {
				out.add(s);
			}
		}
		out.sort((a, b) -> Integer.compare(a.unlockLevel(), b.unlockLevel()));
		return out;
	}
}
