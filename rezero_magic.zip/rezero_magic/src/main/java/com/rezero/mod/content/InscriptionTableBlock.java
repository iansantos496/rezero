package com.rezero.mod.content;

import com.rezero.mod.net.OpenHubPayload;

import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/**
 * Mesa de Inscrição: abre o Hub na aba "Marcas". Gravar e remover marcas só funciona com uma mesa por perto
 * (o servidor confere); a tela em si não decide nada.
 */
public class InscriptionTableBlock extends Block {
	/** Índice da aba "Marcas" no Hub. */
	public static final int HUB_TAB = 4;

	public InscriptionTableBlock(Settings settings) {
		super(settings);
	}

	@Override
	public ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, BlockHitResult hit) {
		if (player instanceof ServerPlayerEntity serverPlayer) {
			ServerPlayNetworking.send(serverPlayer, new OpenHubPayload(HUB_TAB));
		}
		return ActionResult.SUCCESS;
	}
}
