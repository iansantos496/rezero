package com.rezero.mod.server;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import com.rezero.mod.core.Spells;

import net.minecraft.block.Blocks;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/** Feitiços de Terra. Roda só no servidor, depois da aprovação do SpellService. Números são adaptação. */
final class EarthEffects {
	private EarthEffects() {}

	static boolean execute(ServerWorld world, ServerPlayerEntity p, int spellId, int range, double power) {
		switch (spellId) {
			case Spells.EARTH_SPIKE:
				return spike(world, p, range, power);
			case Spells.EARTH_WALL:
				return wall(world, p, power);
			case Spells.EARTH_ROOT:
				return root(world, p, range, power);
			case Spells.STONE_SKIN:
				return stoneSkin(world, p, power);
			case Spells.EARTHQUAKE:
				return quake(world, p, range, power);
			default:
				return false;
		}
	}

	/** Dona: onda de espinhos que corre pelo chão à frente, fere e lança para cima. */
	private static boolean spike(ServerWorld world, ServerPlayerEntity p, int range, double power) {
		Vec3d look = p.getRotationVec(1.0f);
		Vec3d dir = new Vec3d(look.x, 0.0, look.z);
		dir = dir.lengthSquared() < 0.0001 ? new Vec3d(0.0, 0.0, 1.0) : dir.normalize();
		Set<UUID> hit = new HashSet<>();
		for (int i = 1; i <= range; i++) {
			Vec3d c = new Vec3d(p.getX(), p.getY(), p.getZ()).add(dir.multiply(i));
			world.spawnParticles(ParticleTypes.POOF, c.x, c.y + 0.2, c.z, 5, 0.3, 0.1, 0.3, 0.04);
			world.spawnParticles(ParticleTypes.CRIT, c.x, c.y + 0.6, c.z, 4, 0.2, 0.4, 0.2, 0.05);
			Box area = new Box(c.x - 1.0, c.y - 1.0, c.z - 1.0, c.x + 1.0, c.y + 2.0, c.z + 1.0);
			for (LivingEntity e : world.getEntitiesByClass(LivingEntity.class, area,
					x -> x != p && x.isAlive() && !x.isSpectator())) {
				if (hit.add(e.getUuid())) {
					SpellEffects.hurt(world, p, e, (float) (5.0 * power));
					e.addVelocity(0.0, 0.7, 0.0);
					e.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 40, 1));
				}
			}
		}
		SpellEffects.sound(world, p.getX(), p.getY(), p.getZ(), SoundEvents.BLOCK_GRAVEL_BREAK, 1.2f, 0.6f);
		return true;
	}

	/** Muro de Terra: parede temporária de terra à frente (some em 20 s). */
	private static boolean wall(ServerWorld world, ServerPlayerEntity p, double power) {
		int placed = SpellEffects.placeWall(world, p, Blocks.DIRT, (int) Math.round(400 * power));
		SpellEffects.sound(world, p.getX(), p.getY(), p.getZ(), SoundEvents.BLOCK_GRAVEL_BREAK, 1.0f, 0.5f);
		return placed > 0;
	}

	/** Raízes: prende no lugar todos na área do ponto visado. */
	private static boolean root(ServerWorld world, ServerPlayerEntity p, int range, double power) {
		Vec3d at = SpellEffects.aimPoint(world, p, range);
		double radius = 3.0;
		int ticks = (int) Math.round(100 * power);
		Box area = new Box(at.x - radius, at.y - 2, at.z - radius, at.x + radius, at.y + 3, at.z + radius);
		for (LivingEntity e : world.getEntitiesByClass(LivingEntity.class, area,
				x -> x != p && x.isAlive() && !x.isSpectator())) {
			if (Math.sqrt(e.squaredDistanceTo(at.x, at.y, at.z)) > radius) {
				continue;
			}
			e.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, ticks, 6));
			SpellEffects.hurt(world, p, e, (float) (2.0 * power));
		}
		SpellEffects.ring(world, ParticleTypes.HAPPY_VILLAGER, at.add(0.0, 0.2, 0.0), radius, 30);
		world.spawnParticles(ParticleTypes.POOF, at.x, at.y + 0.3, at.z, 20, 1.5, 0.2, 1.5, 0.03);
		SpellEffects.sound(world, at.x, at.y, at.z, SoundEvents.BLOCK_GRAVEL_BREAK, 1.0f, 0.4f);
		return true;
	}

	/** Pele de Pedra: defesa forte, mas deixa o conjurador mais lento. */
	private static boolean stoneSkin(ServerWorld world, ServerPlayerEntity p, double power) {
		int ticks = (int) Math.round(240 * power);
		p.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, ticks, 1));
		p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, ticks, 0));
		world.spawnParticles(ParticleTypes.POOF, p.getX(), p.getY() + 1.0, p.getZ(), 25, 0.5, 0.7, 0.5, 0.03);
		SpellEffects.sound(world, p.getX(), p.getY(), p.getZ(), SoundEvents.BLOCK_GRAVEL_BREAK, 1.0f, 0.8f);
		return true;
	}

	/** Terremoto: o feitiço de Terra mais forte; abala o chão ao redor, fere, lança para cima e deixa lento. */
	private static boolean quake(ServerWorld world, ServerPlayerEntity p, int range, double power) {
		Vec3d c = new Vec3d(p.getX(), p.getY(), p.getZ());
		Box area = new Box(c.x - range, c.y - 2, c.z - range, c.x + range, c.y + 3, c.z + range);
		for (LivingEntity e : world.getEntitiesByClass(LivingEntity.class, area,
				x -> x != p && x.isAlive() && !x.isSpectator())) {
			double dist = Math.sqrt(e.squaredDistanceTo(c.x, c.y, c.z));
			if (dist > range) {
				continue;
			}
			SpellEffects.hurt(world, p, e, (float) ((4.0 + 6.0 * (1.0 - dist / range)) * power));
			e.addVelocity(0.0, 0.9, 0.0);
			e.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 60, 2));
		}
		for (double r = 1.5; r <= range; r += 1.5) {
			SpellEffects.ring(world, ParticleTypes.POOF, c.add(0.0, 0.2, 0.0), r, (int) (r * 6));
		}
		SpellEffects.sound(world, c.x, c.y, c.z, SoundEvents.ENTITY_DRAGON_FIREBALL_EXPLODE, 1.5f, 0.5f);
		return true;
	}
}
