package com.rezero.mod.server;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

import com.rezero.mod.content.EquipmentLookup;
import com.rezero.mod.core.Affinity;
import com.rezero.mod.core.CastModifiers;
import com.rezero.mod.core.CastRules;
import com.rezero.mod.core.ChannelModel;
import com.rezero.mod.core.InscriptionRules;
import com.rezero.mod.core.SpellDef;
import com.rezero.mod.core.Spells;
import com.rezero.mod.data.PlayerDataStore;
import com.rezero.mod.data.PlayerMagicData;
import com.rezero.mod.net.CastStatePayload;
import com.rezero.mod.net.ManaSyncPayload;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;

/**
 * Serviço de conjuração (servidor). Fluxo: pedido do cliente -> CastRules (afinidade, nível, mana,
 * recarga) -> tempo de conjuração (interrompido se o jogador levar dano) -> efeito -> cobra mana,
 * dá XP aos canais e inicia a recarga. O cliente nunca decide nada.
 * Estado temporário (recargas, conjuração em andamento, exaustão) fica só em memória: ao fechar o
 * jogo, recargas zeram; mana, nível e XP são salvos em PlayerMagicData.
 */
public final class SpellService {
	private static final int SYNC_INTERVAL = 10;

	private static final class PlayerRuntime {
		final int[] cooldown = new int[Spells.all().size() + 8];
		SpellDef casting;
		int castLeft;
		float startHealth;
		int exhaustLeft;
		double regenAcc;
		int lastSentMana = -1;
		boolean lastSentExhausted;
	}

	private static final Map<UUID, PlayerRuntime> STATE = new HashMap<>();

	private SpellService() {}

	public static void init() {
		ServerTickEvents.END_SERVER_TICK.register(SpellService::tick);
		ServerLifecycleEvents.SERVER_STOPPING.register(server -> SpellEffects.clearAll());
		ServerLifecycleEvents.SERVER_STOPPED.register(server -> {
			SpellEffects.clearAll();
			STATE.clear();
		});
	}

	/** Bônus de equipamento (cajado, acessório, vestes), marcas gravadas e treino, lidos no servidor. */
	private static CastModifiers modifiersOf(ServerPlayerEntity player) {
		PlayerMagicData data = PlayerDataStore.get(player);
		return EquipmentLookup.modifiersOf(player, InscriptionRules.fromMask(data.inscriptionMask()), data.trainingLevels());
	}

	private static PlayerRuntime runtime(ServerPlayerEntity player) {
		return STATE.computeIfAbsent(player.getUuid(), k -> new PlayerRuntime());
	}

	/** Chamado ao entrar, respawnar ou sair: limpa a conjuração em andamento. */
	public static void reset(ServerPlayerEntity player) {
		PlayerRuntime rt = STATE.get(player.getUuid());
		if (rt != null) {
			rt.casting = null;
			rt.castLeft = 0;
		}
	}

	/** Pedido de conjuração vindo do cliente. */
	public static void requestCast(MinecraftServer server, ServerPlayerEntity player, int spellId) {
		ServerWorld world = WorldLookup.of(server, player);
		if (world == null || !player.isAlive()) {
			return;
		}
		SpellDef spell = Spells.byId(spellId);
		PlayerMagicData data = PlayerDataStore.get(player);
		PlayerRuntime rt = runtime(player);
		int cd = spell == null ? 0 : rt.cooldown[spell.id()];
		CastModifiers mods = modifiersOf(player);
		CastRules.Result result = MagicGate.checkCast(player, spell, cd, rt.exhaustLeft > 0, rt.casting != null, mods.cost());
		if (result != CastRules.Result.OK) {
			message(player, "cast." + result.name().toLowerCase());
			return;
		}
		String why = SpellEffects.precondition(world, player, spell.id(), spell.range());
		if (why != null) {
			message(player, "cast." + why);
			return;
		}
		int ticks = ChannelModel.effectiveCastTicks(spell.baseCastTicks(), data.channelLevel(), mods.cast());
		if (ticks <= 0) {
			finish(server, world, player, data, rt, spell);
			return;
		}
		rt.casting = spell;
		rt.castLeft = ticks;
		rt.startHealth = player.getHealth();
		ServerPlayNetworking.send(player, new CastStatePayload(spell.id(), ticks, 0));
	}

	private static void tick(MinecraftServer server) {
		SpellEffects.tick(server);
		boolean sync = server.getTicks() % SYNC_INTERVAL == 0;

		for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
			PlayerRuntime rt = runtime(player);
			PlayerMagicData data = PlayerDataStore.get(player);

			for (int i = 0; i < rt.cooldown.length; i++) {
				if (rt.cooldown[i] > 0) {
					rt.cooldown[i]--;
				}
			}
			if (rt.exhaustLeft > 0) {
				rt.exhaustLeft--;
			}

			// regeneração (parada durante a exaustão e enquanto conjura)
			int max = data.maxMana();
			if (rt.exhaustLeft <= 0 && rt.casting == null && data.mana() < max && data.affinity() != null) {
				rt.regenAcc += ChannelModel.regenPerSecond(data.channelLevel()) * modifiersOf(player).regen() / 20.0;
				int whole = (int) rt.regenAcc;
				if (whole > 0) {
					rt.regenAcc -= whole;
					data.setMana(data.mana() + whole);
					PlayerDataStore.save(player, data);
				}
			}

			if (rt.casting != null) {
				ServerWorld world = WorldLookup.of(server, player);
				if (!player.isAlive() || world == null || player.getHealth() < rt.startHealth) {
					interrupt(player, rt);
				} else {
					rt.castLeft--;
					world.spawnParticles(rt.casting.affinity() == Affinity.FIRE
							? ParticleTypes.FLAME : ParticleTypes.SNOWFLAKE,
							player.getX(), player.getY() + 1.0, player.getZ(), 2, 0.4, 0.5, 0.4, 0.01);
					if (rt.castLeft <= 0) {
						SpellDef spell = rt.casting;
						rt.casting = null;
						finish(server, world, player, data, rt, spell);
					}
				}
			}

			if (sync) {
				sendMana(player, false);
			}
		}

		// limpa o estado de quem saiu
		Iterator<UUID> it = STATE.keySet().iterator();
		while (it.hasNext()) {
			UUID id = it.next();
			if (server.getPlayerManager().getPlayer(id) == null) {
				it.remove();
			}
		}
	}

	private static void interrupt(ServerPlayerEntity player, PlayerRuntime rt) {
		if (rt.casting == null) {
			return;
		}
		int id = rt.casting.id();
		rt.casting = null;
		rt.castLeft = 0;
		ServerPlayNetworking.send(player, new CastStatePayload(id, 0, 0));
		message(player, "cast.interrupted");
	}

	/** Executa o efeito; só cobra mana, dá XP e inicia a recarga se o feitiço de fato teve efeito. */
	private static void finish(MinecraftServer server, ServerWorld world, ServerPlayerEntity player,
			PlayerMagicData data, PlayerRuntime rt, SpellDef spell) {
		// reconfere tudo no momento do efeito (a mana ou a afinidade podem ter mudado durante a conjuração)
		CastModifiers mods = modifiersOf(player);
		CastRules.Result result = MagicGate.checkCast(player, spell, 0, rt.exhaustLeft > 0, false, mods.cost());
		if (result != CastRules.Result.OK) {
			ServerPlayNetworking.send(player, new CastStatePayload(spell.id(), 0, 0));
			message(player, "cast." + result.name().toLowerCase());
			return;
		}
		double power = ChannelModel.powerMultiplier(data.channelLevel()) * mods.power();
		boolean worked = SpellEffects.execute(world, player, spell.id(), spell.range(), power);
		if (!worked) {
			ServerPlayNetworking.send(player, new CastStatePayload(spell.id(), 0, 0));
			message(player, "cast.failed");
			return;
		}

		int cost = ChannelModel.effectiveCost(spell.baseCost(), data.channelLevel(), mods.cost());
		data.setMana(data.mana() - cost);
		boolean levelUp = data.addChannelXp(ChannelModel.xpForCast(cost));
		PlayerDataStore.save(player, data);
		TrainingService.onSpellCast(player, spell, cost);
		if (data.mana() <= 0) {
			rt.exhaustLeft = ChannelModel.EXHAUSTION_TICKS;
			message(player, "exhausted");
		}
		rt.cooldown[spell.id()] = spell.cooldownTicks();
		ServerPlayNetworking.send(player, new CastStatePayload(spell.id(), 0, spell.cooldownTicks()));
		if (levelUp) {
			world.playSound(null, player.getX(), player.getY(), player.getZ(),
					SoundEvents.ENTITY_PLAYER_LEVELUP, SoundCategory.PLAYERS, 0.8f, 1.2f);
			player.sendMessage(Text.translatable("message.rezero_magic.channel_up", data.channelLevel()), false);
			PlayerSync.send(player);
		} else {
			PlayerSync.send(player);
		}
	}

	/** Envia a mana atual ao cliente. Sem {@code force}, só quando o valor ou a exaustão mudou. */
	public static void sendMana(ServerPlayerEntity player, boolean force) {
		PlayerRuntime rt = runtime(player);
		PlayerMagicData data = PlayerDataStore.get(player);
		boolean exhausted = rt.exhaustLeft > 0;
		if (!force && rt.lastSentMana == data.mana() && rt.lastSentExhausted == exhausted) {
			return;
		}
		rt.lastSentMana = data.mana();
		rt.lastSentExhausted = exhausted;
		ServerPlayNetworking.send(player, new ManaSyncPayload(data.mana(), exhausted ? 1 : 0));
	}

	private static void message(ServerPlayerEntity player, String key) {
		player.sendMessage(Text.translatable("message.rezero_magic." + key), true);
	}
}
