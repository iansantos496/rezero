package com.rezero.mod.server;

import java.util.Optional;

import com.rezero.mod.core.Spells;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/** Feitiços de Vento. Roda só no servidor, depois da aprovação do SpellService. Números são adaptação. */
final class WindEffects {
	private WindEffects() {}

	static boolean execute(ServerWorld world, ServerPlayerEntity p, int spellId, int range, double power) {
		switch (spellId) {
			case Spells.WIND_GUST:
				return gust(world, p, range, power);
			case Spells.WIND_BLADE:
				return blade(world, p, range, power);
			case Spells.WIND_LEAP:
				return leap(world, p, power);
			case Spells.WIND_VORTEX:
				return vortex(world, p, range, power);
			case Spells.WIND_STORM:
				return storm(world, p, range, power);
			default:
				return false;
		}
	}

	/** Rajada: empurra para longe todos no cone à frente. */
	private static boolean gust(ServerWorld world, ServerPlayerEntity p, int range, double power) {
		Vec3d eye = p.getEyePos();
		Vec3d look = p.getRotationVec(1.0f).normalize();
		Box area = new Box(eye, eye.add(look.multiply(range))).expand(range * 0.5);
		for (LivingEntity e : world.getEntitiesByClass(LivingEntity.class, area,
				x -> x != p && x.isAlive() && !x.isSpectator())) {
			Vec3d to = SpellEffects.bodyPos(e).subtract(eye);
			double dist = to.length();
			if (dist > range || dist < 0.01 || to.multiply(1.0 / dist).dotProduct(look) < 0.5) {
				continue;
			}
			SpellEffects.hurt(world, p, e, (float) (2.0 * power));
			e.addVelocity(look.x * 1.3, 0.45, look.z * 1.3);
		}
		for (int i = 1; i <= range; i++) {
			Vec3d c = eye.add(look.multiply(i));
			double spread = 0.1 * i;
			world.spawnParticles(ParticleTypes.CLOUD, c.x, c.y - 0.2, c.z, 3, spread, spread, spread, 0.04);
		}
		SpellEffects.sound(world, p.getX(), p.getY(), p.getZ(), SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, 1.0f, 0.7f);
		return true;
	}

	/** Lâmina de Vento: corte em linha que atravessa e fere todos no caminho. */
	private static boolean blade(ServerWorld world, ServerPlayerEntity p, int range, double power) {
		Vec3d[] ray = SpellEffects.ray(world, p, range);
		Box search = new Box(ray[0], ray[1]).expand(1.0);
		for (LivingEntity e : world.getEntitiesByClass(LivingEntity.class, search,
				x -> x != p && x.isAlive() && !x.isSpectator())) {
			Optional<Vec3d> hit = e.getBoundingBox().expand(0.4).raycast(ray[0], ray[1]);
			if (hit.isPresent()) {
				SpellEffects.hurt(world, p, e, (float) (5.0 * power));
			}
		}
		SpellEffects.trail(world, ParticleTypes.CLOUD, ray[0], ray[1]);
		SpellEffects.trail(world, ParticleTypes.SWEEP_ATTACK, ray[0], ray[1]);
		SpellEffects.sound(world, p.getX(), p.getY(), p.getZ(), SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, 1.0f, 1.3f);
		return true;
	}

	/** Impulso de Vento: lança o conjurador para a frente e para cima e suaviza a queda. */
	private static boolean leap(ServerWorld world, ServerPlayerEntity p, double power) {
		Vec3d look = p.getRotationVec(1.0f);
		double len = Math.sqrt(look.x * look.x + look.z * look.z);
		double fx = len < 0.001 ? 0.0 : look.x / len;
		double fz = len < 0.001 ? 0.0 : look.z / len;
		double boost = 1.1 * Math.min(1.3, power);
		p.addVelocity(fx * boost, 0.75, fz * boost);
		p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOW_FALLING, 100, 0));
		world.spawnParticles(ParticleTypes.CLOUD, p.getX(), p.getY() + 0.2, p.getZ(), 25, 0.4, 0.1, 0.4, 0.08);
		SpellEffects.sound(world, p.getX(), p.getY(), p.getZ(), SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, 1.0f, 0.5f);
		return true;
	}

	/** Vórtice: puxa para o centro quem estiver na área por 5 s e fere de leve. */
	private static boolean vortex(ServerWorld world, ServerPlayerEntity p, int range, double power) {
		Vec3d at = SpellEffects.aimPoint(world, p, range);
		SpellEffects.addZone(world, at, p.getUuid(), (float) (1.5 * power), 100, SpellEffects.ZoneKind.VORTEX);
		SpellEffects.trail(world, ParticleTypes.CLOUD, p.getEyePos(), at);
		SpellEffects.sound(world, at.x, at.y, at.z, SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, 1.2f, 0.4f);
		return true;
	}

	/** Tempestade: o feitiço de Vento mais forte; arremessa para o alto e fere todos na área. */
	private static boolean storm(ServerWorld world, ServerPlayerEntity p, int range, double power) {
		Vec3d at = SpellEffects.aimPoint(world, p, range);
		double radius = 6.0;
		Box area = new Box(at.x - radius, at.y - 3, at.z - radius, at.x + radius, at.y + 5, at.z + radius);
		for (LivingEntity e : world.getEntitiesByClass(LivingEntity.class, area,
				x -> x != p && x.isAlive() && !x.isSpectator())) {
			double dist = Math.sqrt(e.squaredDistanceTo(at.x, at.y, at.z));
			if (dist > radius) {
				continue;
			}
			SpellEffects.hurt(world, p, e, (float) ((5.0 + 8.0 * (1.0 - dist / radius)) * power));
			e.addVelocity(0.0, 1.1, 0.0);
			e.addStatusEffect(new StatusEffectInstance(StatusEffects.LEVITATION, 30, 1));
		}
		for (int h = 0; h < 5; h++) {
			SpellEffects.ring(world, ParticleTypes.CLOUD, at.add(0.0, h * 0.8, 0.0), radius - h, 36);
		}
		world.spawnParticles(ParticleTypes.SWEEP_ATTACK, at.x, at.y + 1.0, at.z, 12, 3.0, 1.0, 3.0, 0.0);
		SpellEffects.trail(world, ParticleTypes.CLOUD, p.getEyePos(), at);
		SpellEffects.sound(world, at.x, at.y, at.z, SoundEvents.ENTITY_DRAGON_FIREBALL_EXPLODE, 1.5f, 1.4f);
		return true;
	}
}
