package com.rezero.mod.server;

import java.util.List;

import com.rezero.mod.content.ModBlocks;
import com.rezero.mod.content.ModItems;
import com.rezero.mod.core.Inscription;
import com.rezero.mod.core.InscriptionRules;
import com.rezero.mod.data.PlayerDataStore;
import com.rezero.mod.data.PlayerMagicData;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;

/**
 * Marcas (inscrições mágicas), no servidor: gravar e remover (exige Mesa de Inscrição por perto, nível dos canais e tinta de cristal)
 * e aplicar os efeitos passivos de defesa/utilidade a cada segundo. Os bônus de magia (potência, custo, conjuração, regeneração)
 * entram pelo EquipmentRules, lidos pelo SpellService.
 */
public final class InscriptionService {
	private static final int TABLE_RADIUS = 4;
	private static final int PASSIVE_PERIOD = 20;
	private static final int PASSIVE_DURATION = 60;

	private InscriptionService() {}

	public static void init() {
		ServerTickEvents.END_SERVER_TICK.register(server -> {
			if (server.getTicks() % PASSIVE_PERIOD == 0) {
				for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
					applyPassives(player);
				}
			}
		});
	}

	/** Pedido do cliente: gravar ({@code remove} falso) ou remover a marca. */
	public static void request(MinecraftServer server, ServerPlayerEntity player, int inscriptionId, boolean remove) {
		ServerWorld world = WorldLookup.of(server, player);
		if (world == null || !player.isAlive()) {
			return;
		}
		Inscription ins = Inscription.fromId(inscriptionId);
		PlayerMagicData data = PlayerDataStore.get(player);
		boolean nearTable = hasTableNear(world, player);
		List<Integer> current = data.inscriptions();

		if (remove) {
			InscriptionRules.Result r = InscriptionRules.checkRemove(current, ins, nearTable);
			if (r != InscriptionRules.Result.OK) {
				message(player, r.name().toLowerCase());
				return;
			}
			data.removeInscription(ins.id());
			PlayerDataStore.save(player, data);
			PlayerSync.send(player);
			player.sendMessage(Text.translatable("message.rezero_magic.inscription.removed",
					Text.translatable("inscription.rezero_magic." + ins.key())), true);
			return;
		}

		int ink = player.isCreative() ? 999 : countInk(player);
		InscriptionRules.Result r = InscriptionRules.checkEngrave(data.affinity(), current, ins, data.channelLevel(), ink, nearTable);
		if (r != InscriptionRules.Result.OK) {
			message(player, r.name().toLowerCase());
			return;
		}
		if (!player.isCreative()) {
			consumeInk(player, ins.inkCost());
		}
		data.addInscription(ins.id());
		PlayerDataStore.save(player, data);
		PlayerSync.send(player);
		world.spawnParticles(ParticleTypes.ENCHANT, player.getX(), player.getY() + 1.2, player.getZ(), 30, 0.5, 0.6, 0.5, 0.5);
		world.playSound(null, player.getX(), player.getY(), player.getZ(),
				SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME, SoundCategory.PLAYERS, 1.0f, 0.8f);
		player.sendMessage(Text.translatable("message.rezero_magic.inscription.engraved",
				Text.translatable("inscription.rezero_magic." + ins.key())), true);
	}

	private static boolean hasTableNear(ServerWorld world, ServerPlayerEntity player) {
		int px = (int) Math.floor(player.getX());
		int py = (int) Math.floor(player.getY());
		int pz = (int) Math.floor(player.getZ());
		for (int dx = -TABLE_RADIUS; dx <= TABLE_RADIUS; dx++) {
			for (int dy = -2; dy <= 2; dy++) {
				for (int dz = -TABLE_RADIUS; dz <= TABLE_RADIUS; dz++) {
					if (world.getBlockState(new BlockPos(px + dx, py + dy, pz + dz)).isOf(ModBlocks.INSCRIPTION_TABLE)) {
						return true;
					}
				}
			}
		}
		return false;
	}

	private static int countInk(ServerPlayerEntity player) {
		PlayerInventory inv = player.getInventory();
		int total = 0;
		for (int i = 0; i < inv.size(); i++) {
			ItemStack stack = inv.getStack(i);
			if (stack.getItem() == ModItems.MANA_INK) {
				total += stack.getCount();
			}
		}
		return total;
	}

	private static void consumeInk(ServerPlayerEntity player, int amount) {
		PlayerInventory inv = player.getInventory();
		int left = amount;
		for (int i = 0; i < inv.size() && left > 0; i++) {
			ItemStack stack = inv.getStack(i);
			if (stack.getItem() == ModItems.MANA_INK) {
				int take = Math.min(left, stack.getCount());
				stack.decrement(take);
				left -= take;
			}
		}
	}

	/** Efeitos passivos das marcas de defesa e utilidade. Curtos e renovados a cada segundo (somem logo ao remover a marca). */
	private static void applyPassives(ServerPlayerEntity player) {
		PlayerMagicData data = PlayerDataStore.get(player);
		for (int id : data.inscriptions()) {
			Inscription ins = Inscription.fromId(id);
			if (ins == null) {
				continue;
			}
			switch (ins.passive()) {
				case RESISTANCE -> give(player, StatusEffects.RESISTANCE);
				case FIRE_RESISTANCE -> give(player, StatusEffects.FIRE_RESISTANCE);
				case REGEN_LOW_HEALTH -> {
					if (player.getHealth() < player.getMaxHealth() * 0.4f) {
						give(player, StatusEffects.REGENERATION);
					}
				}
				case SPEED -> give(player, StatusEffects.SPEED);
				case JUMP -> give(player, StatusEffects.JUMP_BOOST);
				case WATER_BREATHING -> give(player, StatusEffects.WATER_BREATHING);
				default -> { }
			}
		}
	}

	private static void give(ServerPlayerEntity player, RegistryEntry<StatusEffect> effect) {
		player.addStatusEffect(new StatusEffectInstance(effect, PASSIVE_DURATION, 0, true, false, true));
	}

	private static void message(ServerPlayerEntity player, String key) {
		player.sendMessage(Text.translatable("message.rezero_magic.inscription." + key), true);
	}
}
