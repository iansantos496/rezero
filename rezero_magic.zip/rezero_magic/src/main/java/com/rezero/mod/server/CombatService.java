package com.rezero.mod.server;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import com.rezero.mod.content.CombatStyles;
import com.rezero.mod.core.CombatRules;
import com.rezero.mod.core.CombatStyle;
import com.rezero.mod.core.TechniqueDef;
import com.rezero.mod.core.Techniques;
import com.rezero.mod.core.TrainingAttribute;
import com.rezero.mod.data.PlayerDataStore;
import com.rezero.mod.data.PlayerMagicData;
import com.rezero.mod.net.CombatActionPayload;
import com.rezero.mod.net.CombatSyncPayload;
import com.rezero.mod.net.TechniqueCooldownPayload;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;

/**
 * Técnicas de combate (Sistema 9), no servidor: estamina própria, esquiva com janela de invulnerabilidade, contra-ataque,
 * combo de golpes comuns, aprender e usar as 15 técnicas. O cliente só envia PEDIDOS (CombatActionPayload); tudo é conferido aqui.
 * Estado temporário (estamina, recargas, combo) fica só em memória e zera ao entrar; as técnicas aprendidas são salvas.
 */
public final class CombatService {
	private static final int SYNC_PERIOD = 10;
	private static final double DODGE_SPEED = 0.9;

	/** Verdadeiro enquanto uma técnica causa dano: esse dano não forma combo (mas treina Força, como qualquer golpe). */
	static boolean techniqueDamage = false;

	private static final class Runtime {
		double stamina = -1.0;
		int regenDelay;
		final int[] cooldown = new int[Techniques.COUNT];
		int dodgeCooldown;
		int invulnerableLeft;
		int counterLeft;
		int stanceLeft;
		float stanceDamage;
		TechniqueDef pending;
		int pendingLeft;
		float pendingHealth;
		int comboHits;
		int comboLeft;
		int lastSentStamina = -1;
		int lastSentMax = -1;
		int lastSentMask = -1;
	}

	private interface Task {
		void run(MinecraftServer server);
	}

	private static final class Scheduled {
		final int due;
		final Task task;

		Scheduled(int due, Task task) {
			this.due = due;
			this.task = task;
		}
	}

	private static final Map<UUID, Runtime> STATE = new HashMap<>();
	private static final List<Scheduled> SCHEDULED = new ArrayList<>();
	private static MinecraftServer server;

	private CombatService() {}

	public static void init() {
		ServerTickEvents.END_SERVER_TICK.register(CombatService::tick);
		ServerLifecycleEvents.SERVER_STARTED.register(started -> server = started);
		ServerLifecycleEvents.SERVER_STOPPED.register(stopped -> {
			server = null;
			STATE.clear();
			SCHEDULED.clear();
		});

		// golpes comuns: combo e contra-ataque (o bônus chega como "eco" depois da invulnerabilidade do alvo)
		ServerLivingEntityEvents.AFTER_DAMAGE.register((entity, source, baseDamageTaken, damageTaken, blocked) -> {
			if (techniqueDamage || TrainingService.spellDamage || damageTaken <= 0.0f || server == null) {
				return;
			}
			if (!(source.getAttacker() instanceof ServerPlayerEntity attacker) || source.getSource() != attacker || entity == attacker) {
				return;
			}
			Runtime rt = runtime(attacker);
			rt.comboHits = rt.comboLeft > 0 ? rt.comboHits + 1 : 1;
			rt.comboLeft = CombatRules.COMBO_WINDOW_TICKS;
			boolean finisher = CombatRules.isFinisher(rt.comboHits);
			boolean counter = rt.counterLeft > 0;
			if (finisher) {
				rt.comboHits = 0;
			}
			if (counter) {
				rt.counterLeft = 0;
			}
			int pct = CombatRules.echoBonusPct(finisher, counter);
			if (pct > 0) {
				hitLater(CombatRules.ECHO_DELAY_TICKS, attacker.getUuid(), entity.getUuid(), damageTaken * pct / 100.0f);
				message(attacker, counter ? "combat.counter" : "combat.combo");
			}
		});

		// esquiva (invulnerabilidade a ataques de criaturas) e postura de contra-golpe
		ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
			if (!(entity instanceof ServerPlayerEntity victim) || source.getAttacker() == null) {
				return true; // queda, fogo, vazio etc. nunca são evitados
			}
			Runtime rt = STATE.get(victim.getUuid());
			if (rt == null) {
				return true;
			}
			if (rt.invulnerableLeft > 0) {
				return false;
			}
			if (rt.stanceLeft > 0) {
				rt.stanceLeft = 0;
				if (source.getAttacker() instanceof LivingEntity attacker && attacker != victim && server != null
						&& victim.distanceTo(attacker) <= 6.0f) {
					ServerWorld world = WorldLookup.of(server, victim);
					if (world != null) {
						techHurt(world, victim, attacker, rt.stanceDamage);
						CombatEffects.hitEffect(world, attacker);
					}
				}
				message(victim, "combat.riposte");
				return false;
			}
			return true;
		});
	}

	private static Runtime runtime(ServerPlayerEntity player) {
		return STATE.computeIfAbsent(player.getUuid(), k -> new Runtime());
	}

	/** Ao entrar ou renascer: estamina cheia, sem recargas, e o retrato é enviado. */
	public static void reset(ServerPlayerEntity player) {
		STATE.put(player.getUuid(), new Runtime());
		sync(player, true);
	}

	// ------------------------------------------------------------------ pedidos do cliente

	public static void request(MinecraftServer current, ServerPlayerEntity player, int action, int arg) {
		if (!player.isAlive() || player.isSpectator()) {
			return;
		}
		switch (action) {
			case CombatActionPayload.USE -> useSlot(current, player, arg);
			case CombatActionPayload.DODGE -> dodge(current, player, arg);
			case CombatActionPayload.LEARN -> learn(player, arg);
			default -> {
				// ação desconhecida (pacote adulterado): ignora
			}
		}
	}

	private static void learn(ServerPlayerEntity player, int techniqueId) {
		TechniqueDef tech = Techniques.byId(techniqueId);
		PlayerMagicData data = PlayerDataStore.get(player);
		CombatRules.LearnResult result = CombatRules.checkLearn(data.techniqueMask(), tech, data.trainingLevels());
		if (result != CombatRules.LearnResult.OK) {
			message(player, "combat.learn_" + result.name().toLowerCase());
			return;
		}
		data.learnTechnique(techniqueId);
		PlayerDataStore.save(player, data);
		sync(player, true);
		player.sendMessage(Text.translatable("message.rezero_magic.combat.learned",
				Text.translatable("technique.rezero_magic." + tech.key())), false);
	}

	private static void useSlot(MinecraftServer current, ServerPlayerEntity player, int slot) {
		CombatStyle style = CombatStyles.styleOf(player.getMainHandStack());
		TechniqueDef tech = Techniques.slot(style, slot);
		PlayerMagicData data = PlayerDataStore.get(player);
		Runtime rt = runtime(player);
		ensureStamina(player, rt, data);
		int cd = tech == null ? 0 : rt.cooldown[tech.id()];
		CombatRules.UseResult result = CombatRules.checkUse(data.techniqueMask(), tech, cd, rt.stamina, rt.pending != null);
		if (result != CombatRules.UseResult.OK) {
			message(player, "combat." + result.name().toLowerCase());
			return;
		}
		if (tech.style() == CombatStyle.BOW && !hasArrow(player)) {
			message(player, "combat.no_arrow");
			return;
		}
		ServerWorld world = WorldLookup.of(current, player);
		if (world == null) {
			return;
		}
		// confirmado: cobra a estamina, inicia a recarga e gasta a flecha
		spend(rt, tech.staminaCost());
		rt.cooldown[tech.id()] = tech.cooldownTicks();
		ServerPlayNetworking.send(player, new TechniqueCooldownPayload(tech.id(), tech.cooldownTicks()));
		if (tech.style() == CombatStyle.BOW) {
			consumeArrow(player);
		}
		if (tech.windupTicks() > 0) {
			rt.pending = tech;
			rt.pendingLeft = tech.windupTicks();
			rt.pendingHealth = player.getHealth();
			CombatEffects.sound(world, player, SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, 0.8f, 0.6f);
		} else {
			CombatEffects.run(current, world, player, tech);
		}
	}

	private static void dodge(MinecraftServer current, ServerPlayerEntity player, int direction) {
		PlayerMagicData data = PlayerDataStore.get(player);
		Runtime rt = runtime(player);
		ensureStamina(player, rt, data);
		CombatRules.UseResult result = CombatRules.checkDodge(rt.dodgeCooldown, rt.stamina, rt.pending != null);
		if (result != CombatRules.UseResult.OK) {
			message(player, "combat." + result.name().toLowerCase());
			return;
		}
		ServerWorld world = WorldLookup.of(current, player);
		if (world == null) {
			return;
		}
		spend(rt, CombatRules.DODGE_COST);
		rt.dodgeCooldown = CombatRules.DODGE_COOLDOWN_TICKS;
		rt.invulnerableLeft = CombatRules.DODGE_INVULNERABLE_TICKS;
		rt.counterLeft = CombatRules.COUNTER_WINDOW_TICKS;
		ServerPlayNetworking.send(player, new TechniqueCooldownPayload(-1, CombatRules.DODGE_COOLDOWN_TICKS));
		double yaw = Math.toRadians(player.getYaw());
		double fx = -Math.sin(yaw);
		double fz = Math.cos(yaw);
		double dx;
		double dz;
		switch (direction) {
			case 0 -> {
				dx = fx;
				dz = fz;
			}
			case 2 -> { // esquerda
				dx = Math.cos(yaw);
				dz = Math.sin(yaw);
			}
			case 3 -> { // direita
				dx = -Math.cos(yaw);
				dz = -Math.sin(yaw);
			}
			default -> { // trás
				dx = -fx;
				dz = -fz;
			}
		}
		push(player, dx * DODGE_SPEED, 0.1, dz * DODGE_SPEED);
		world.spawnParticles(ParticleTypes.CLOUD, player.getX(), player.getY() + 0.2, player.getZ(), 10, 0.3, 0.1, 0.3, 0.05);
		CombatEffects.sound(world, player, SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, 0.7f, 1.6f);
		message(player, "combat.dodged");
	}

	// ------------------------------------------------------------------ usados pelos efeitos

	/** Empurra o jogador e avisa o cliente (o movimento do jogador é decidido no cliente). */
	static void push(ServerPlayerEntity player, double x, double y, double z) {
		player.addVelocity(x, y, z);
		player.networkHandler.sendPacket(new EntityVelocityUpdateS2CPacket(player));
	}

	static void beginRiposte(ServerPlayerEntity player, float counterDamage) {
		Runtime rt = runtime(player);
		rt.stanceLeft = CombatRules.RIPOSTE_STANCE_TICKS;
		rt.stanceDamage = counterDamage;
	}

	static void beginInvulnerable(ServerPlayerEntity player, int ticks) {
		Runtime rt = runtime(player);
		rt.invulnerableLeft = Math.max(rt.invulnerableLeft, ticks);
	}

	/** Dano de técnica: marcado para não formar combo. Respeita a invulnerabilidade do alvo (por isso os golpes múltiplos têm intervalo). */
	static void techHurt(ServerWorld world, ServerPlayerEntity owner, LivingEntity target, float amount) {
		boolean previous = techniqueDamage;
		techniqueDamage = true;
		try {
			target.damage(world, world.getDamageSources().playerAttack(owner), amount);
		} finally {
			techniqueDamage = previous;
		}
	}

	/** Golpe adiado (rajadas e ecos). Se o alvo ou o jogador sumiram ou morreram até lá, não faz nada. */
	static void hitLater(int delayTicks, UUID playerId, UUID targetId, float amount) {
		if (server == null) {
			return;
		}
		later(delayTicks, current -> {
			ServerPlayerEntity player = current.getPlayerManager().getPlayer(playerId);
			if (player == null || !player.isAlive()) {
				return;
			}
			ServerWorld world = WorldLookup.of(current, player);
			if (world == null) {
				return;
			}
			Entity target = world.getEntity(targetId);
			if (target instanceof LivingEntity living && living.isAlive()) {
				techHurt(world, player, living, amount);
				CombatEffects.hitEffect(world, living);
			}
		});
	}

	static void later(int delayTicks, Task task) {
		if (server != null) {
			SCHEDULED.add(new Scheduled(server.getTicks() + Math.max(1, delayTicks), task));
		}
	}

	/** Tarefa adiada com acesso ao servidor (usada pela Investida). */
	static void laterPlayer(int delayTicks, UUID playerId, java.util.function.BiConsumer<ServerWorld, ServerPlayerEntity> action) {
		later(delayTicks, current -> {
			ServerPlayerEntity player = current.getPlayerManager().getPlayer(playerId);
			if (player == null || !player.isAlive()) {
				return;
			}
			ServerWorld world = WorldLookup.of(current, player);
			if (world != null) {
				action.accept(world, player);
			}
		});
	}

	// ------------------------------------------------------------------ estamina e tick

	private static void ensureStamina(ServerPlayerEntity player, Runtime rt, PlayerMagicData data) {
		if (rt.stamina < 0.0) {
			rt.stamina = CombatRules.maxStamina(data.trainingLevel(TrainingAttribute.VIGOR));
		}
	}

	private static void spend(Runtime rt, int cost) {
		rt.stamina = Math.max(0.0, rt.stamina - cost);
		rt.regenDelay = CombatRules.REGEN_DELAY_TICKS;
	}

	private static void tick(MinecraftServer current) {
		boolean doSync = current.getTicks() % SYNC_PERIOD == 0;
		for (ServerPlayerEntity player : current.getPlayerManager().getPlayerList()) {
			Runtime rt = runtime(player);
			PlayerMagicData data = PlayerDataStore.get(player);
			ensureStamina(player, rt, data);
			int max = CombatRules.maxStamina(data.trainingLevel(TrainingAttribute.VIGOR));
			for (int i = 0; i < rt.cooldown.length; i++) {
				if (rt.cooldown[i] > 0) {
					rt.cooldown[i]--;
				}
			}
			if (rt.dodgeCooldown > 0) {
				rt.dodgeCooldown--;
			}
			if (rt.invulnerableLeft > 0) {
				rt.invulnerableLeft--;
			}
			if (rt.counterLeft > 0) {
				rt.counterLeft--;
			}
			if (rt.stanceLeft > 0) {
				rt.stanceLeft--;
			}
			if (rt.comboLeft > 0 && --rt.comboLeft == 0) {
				rt.comboHits = 0;
			}
			if (rt.regenDelay > 0) {
				rt.regenDelay--;
			} else if (rt.stamina < max) {
				rt.stamina = Math.min(max,
						rt.stamina + CombatRules.regenPerSecond(data.trainingLevel(TrainingAttribute.AGILITY)) / 20.0);
			}
			if (rt.stamina > max) {
				rt.stamina = max;
			}
			if (rt.pending != null) {
				tickPending(current, player, rt);
			}
			if (doSync) {
				sync(player, false);
			}
		}

		if (!SCHEDULED.isEmpty()) {
			List<Scheduled> due = new ArrayList<>();
			Iterator<Scheduled> it = SCHEDULED.iterator();
			while (it.hasNext()) {
				Scheduled s = it.next();
				if (s.due <= current.getTicks()) {
					due.add(s);
					it.remove();
				}
			}
			for (Scheduled s : due) {
				s.task.run(current);
			}
		}

		Iterator<UUID> ids = STATE.keySet().iterator();
		while (ids.hasNext()) {
			if (current.getPlayerManager().getPlayer(ids.next()) == null) {
				ids.remove();
			}
		}
	}

	/** Técnica carregada: interrompida por dano ou por trocar de arma; senão executa ao fim da carga. */
	private static void tickPending(MinecraftServer current, ServerPlayerEntity player, Runtime rt) {
		TechniqueDef tech = rt.pending;
		ServerWorld world = WorldLookup.of(current, player);
		if (!player.isAlive() || world == null || player.getHealth() < rt.pendingHealth) {
			rt.pending = null;
			message(player, "combat.interrupted");
			return;
		}
		if (CombatStyles.styleOf(player.getMainHandStack()) != tech.style()) {
			rt.pending = null;
			message(player, "combat.fizzled");
			return;
		}
		world.spawnParticles(ParticleTypes.CRIT, player.getX(), player.getY() + 1.0, player.getZ(), 2, 0.4, 0.5, 0.4, 0.05);
		if (--rt.pendingLeft <= 0) {
			rt.pending = null;
			CombatEffects.run(current, world, player, tech);
		}
	}

	// ------------------------------------------------------------------ flechas

	private static boolean hasArrow(ServerPlayerEntity player) {
		if (player.isCreative()) {
			return true;
		}
		PlayerInventory inv = player.getInventory();
		for (int i = 0; i < inv.size(); i++) {
			if (inv.getStack(i).isOf(Items.ARROW)) {
				return true;
			}
		}
		return false;
	}

	private static void consumeArrow(ServerPlayerEntity player) {
		if (player.isCreative()) {
			return;
		}
		PlayerInventory inv = player.getInventory();
		for (int i = 0; i < inv.size(); i++) {
			ItemStack stack = inv.getStack(i);
			if (stack.isOf(Items.ARROW)) {
				stack.decrement(1);
				return;
			}
		}
	}

	// ------------------------------------------------------------------ rede

	public static void sync(ServerPlayerEntity player, boolean force) {
		Runtime rt = runtime(player);
		PlayerMagicData data = PlayerDataStore.get(player);
		ensureStamina(player, rt, data);
		int max = CombatRules.maxStamina(data.trainingLevel(TrainingAttribute.VIGOR));
		int stamina = (int) Math.floor(rt.stamina);
		int mask = data.techniqueMask();
		if (!force && stamina == rt.lastSentStamina && max == rt.lastSentMax && mask == rt.lastSentMask) {
			return;
		}
		rt.lastSentStamina = stamina;
		rt.lastSentMax = max;
		rt.lastSentMask = mask;
		ServerPlayNetworking.send(player, new CombatSyncPayload(mask, stamina, max));
	}

	private static void message(ServerPlayerEntity player, String key) {
		player.sendMessage(Text.translatable("message.rezero_magic." + key), true);
	}

	static Vec3d horizontalLook(ServerPlayerEntity player) {
		Vec3d look = player.getRotationVec(1.0f);
		double len = Math.sqrt(look.x * look.x + look.z * look.z);
		return len < 0.001 ? new Vec3d(0.0, 0.0, 1.0) : new Vec3d(look.x / len, 0.0, look.z / len);
	}
}
