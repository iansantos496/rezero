package com.rezero.mod.core;

/**
 * Soma os bônus do equipamento (cajado na mão principal + acessório na mão secundária) com limites,
 * para que nenhuma combinação deixe a magia grátis ou instantânea. Código puro, testado fora do jogo.
 */
public final class EquipmentRules {
	public static final double MAX_POWER = 2.0;
	public static final double MIN_COST = 0.6;
	public static final double MIN_CAST = 0.6;
	public static final double MAX_REGEN = 2.0;

	private EquipmentRules() {}

	private static int level(int[] training, TrainingAttribute a) {
		return a.id() < training.length ? training[a.id()] : 0;
	}

	/** Qualquer argumento pode ser null (nada equipado ali). */
	public static CastModifiers combine(Catalyst staff, Charm charm) {
		return combine(staff, charm, null, null);
	}

	/**
	 * Tudo junto: cajado, acessório, vestes e marcas.
	 * @param robePieces peças vestidas de cada conjunto, indexadas por RobeSet.id() (null = nenhuma)
	 * @param marks marcas gravadas (null = nenhuma)
	 */
	public static CastModifiers combine(Catalyst staff, Charm charm, int[] robePieces, java.util.List<Inscription> marks) {
		return combine(staff, charm, robePieces, marks, null);
	}

	/**
	 * Tudo junto, mais o treinamento.
	 * @param training níveis dos atributos de treino indexados por TrainingAttribute.id() (null = nenhum)
	 */
	public static CastModifiers combine(Catalyst staff, Charm charm, int[] robePieces, java.util.List<Inscription> marks,
			int[] training) {
		int power = 0;
		int cost = 0;
		int cast = 0;
		int regen = 0;
		if (training != null) {
			cast += TrainingModel.castReductionPct(level(training, TrainingAttribute.FOCUS));
			cost += TrainingModel.costReductionPct(level(training, TrainingAttribute.CONTROL));
			regen += TrainingModel.regenPct(level(training, TrainingAttribute.CONTROL));
		}
		if (robePieces != null) {
			for (RobeSet set : RobeSet.values()) {
				int n = set.id() < robePieces.length ? Math.max(0, Math.min(RobePiece.values().length, robePieces[set.id()])) : 0;
				power += set.piecePowerPct() * n;
				cost += set.pieceCostReductionPct() * n;
				cast += set.pieceCastReductionPct() * n;
				regen += set.pieceRegenPct() * n;
				if (n == RobePiece.values().length) {
					power += set.setPowerPct();
					cost += set.setCostReductionPct();
					cast += set.setCastReductionPct();
					regen += set.setRegenPct();
				}
			}
		}
		if (marks != null) {
			for (Inscription m : marks) {
				power += m.powerPct();
				cost += m.costReductionPct();
				cast += m.castReductionPct();
				regen += m.regenPct();
			}
		}
		if (staff != null) {
			power += staff.powerPct();
			cost += staff.costReductionPct();
			cast += staff.castReductionPct();
		}
		if (charm != null) {
			power += charm.powerPct();
			cost += charm.costReductionPct();
			cast += charm.castReductionPct();
			regen += charm.regenPct();
		}
		return new CastModifiers(
				Math.min(MAX_POWER, 1.0 + power / 100.0),
				Math.max(MIN_COST, 1.0 - cost / 100.0),
				Math.max(MIN_CAST, 1.0 - cast / 100.0),
				Math.min(MAX_REGEN, 1.0 + regen / 100.0));
	}
}
