package com.rezero.mod.server;

import com.rezero.mod.core.Spells;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/**
 * Feitiços de Yin (enfraquecimentos). Roda só no servidor, depois da aprovação do SpellService.
 * Da obra: Yin é a afinidade de enfraquecimentos e Shamak é um feitiço Yin. O que cada feitiço faz é adaptação.
 */
final class YinEffects {
	private YinEffects() {}

	static boolean execute(ServerWorld world, ServerPlayerEntity p, int spellId, int range, double power) {
		switch (spellId) {
			case Spells.SHAMAK:
				return shamak(world, p, range, power);
			case Spells.MIASMA:
				return miasma(world, p, range, power);
			case Spells.LIFE_DRAIN:
				return lifeDrain(world, p, range, power);
			case Spells.CURSE:
				return curse(world, p, range, power);
			case Spells.ECLIPSE:
				return eclipse(world, p, range, power);
			default:
				return false;
		}
	}

	/** Shamak: raio sombrio que enfraquece e deixa lento o alvo (não causa dano). */
	private static boolean shamak(ServerWorld world, ServerPlayerEntity p, int range, double power) {
		Vec3d[] ray = SpellEffects.ray(world, p, range);
		LivingEntity target = SpellEffects.findTarget(world, p, ray[0], ray[1], 0.4);
		Vec3d at = target != null ? SpellEffects.bodyPos(target) : ray[1];
		SpellEffects.trail(world, ParticleTypes.SQUID_INK, ray[0], at);
		SpellEffects.trail(world, ParticleTypes.WITCH, ray[0], at);
		world.spawnParticles(ParticleTypes.WITCH, at.x, at.y, at.z, 20, 0.4, 0.4, 0.4, 0.05);
		SpellEffects.sound(world, at.x, at.y, at.z, SoundEvents.ENTITY_PLAYER_LEVELUP, 0.6f, 0.5f);
		if (target != null) {
			target.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, (int) Math.round(200 * power), 1));
			target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, (int) Math.round(100 * power), 0));
		}
		return true;
	}

	/** Névoa Sombria: área que enfraquece e atrasa quem ficar dentro por 6 s. */
	private static boolean miasma(ServerWorld world, ServerPlayerEntity p, int range, double power) {
		Vec3d at = SpellEffects.aimPoint(world, p, range);
		SpellEffects.addZone(world, at, p.getUuid(), (float) (1.0 * power), 120, SpellEffects.ZoneKind.MIASMA);
		SpellEffects.trail(world, ParticleTypes.SQUID_INK, p.getEyePos(), at);
		SpellEffects.sound(world, at.x, at.y, at.z, SoundEvents.ENTITY_PLAYER_LEVELUP, 0.6f, 0.4f);
		return true;
	}

	/** Dreno Vital: fere o alvo e devolve parte do dano como vida ao conjurador. Exige alvo na mira. */
	private static boolean lifeDrain(ServerWorld world, ServerPlayerEntity p, int range, double power) {
		LivingEntity target = SpellEffects.aimedTarget(world, p, range);
		if (target == null) {
			return false;
		}
		SpellEffects.hurt(world, p, target, (float) (5.0 * power));
		p.heal((float) (3.0 * power));
		Vec3d from = SpellEffects.bodyPos(target);
		SpellEffects.trail(world, ParticleTypes.WITCH, from, p.getEyePos());
		world.spawnParticles(ParticleTypes.SQUID_INK, from.x, from.y, from.z, 12, 0.3, 0.4, 0.3, 0.02);
		world.spawnParticles(ParticleTypes.HEART, p.getX(), p.getY() + 1.4, p.getZ(), 3, 0.3, 0.3, 0.3, 0.0);
		SpellEffects.sound(world, from.x, from.y, from.z, SoundEvents.ENTITY_PLAYER_LEVELUP, 0.6f, 0.3f);
		return true;
	}

	/** Maldição: veneno de definhamento, fraqueza e lentidão no alvo. Exige alvo na mira. */
	private static boolean curse(ServerWorld world, ServerPlayerEntity p, int range, double power) {
		LivingEntity target = SpellEffects.aimedTarget(world, p, range);
		if (target == null) {
			return false;
		}
		target.addStatusEffect(new StatusEffectInstance(StatusEffects.WITHER, (int) Math.round(100 * power), 1));
		target.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, (int) Math.round(300 * power), 1));
		target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, (int) Math.round(200 * power), 0));
		Vec3d at = SpellEffects.bodyPos(target);
		SpellEffects.trail(world, ParticleTypes.SQUID_INK, p.getEyePos(), at);
		world.spawnParticles(ParticleTypes.WITCH, at.x, at.y, at.z, 30, 0.5, 0.7, 0.5, 0.05);
		SpellEffects.sound(world, at.x, at.y, at.z, SoundEvents.ENTITY_PLAYER_LEVELUP, 0.6f, 0.2f);
		return true;
	}

	/** Eclipse: o feitiço de Yin mais forte; cega, enfraquece e atrasa todos ao redor do conjurador. */
	private static boolean eclipse(ServerWorld world, ServerPlayerEntity p, int range, double power) {
		Vec3d c = new Vec3d(p.getX(), p.getY(), p.getZ());
		Box area = new Box(c.x - range, c.y - 3, c.z - range, c.x + range, c.y + 4, c.z + range);
		for (LivingEntity e : world.getEntitiesByClass(LivingEntity.class, area,
				x -> x != p && x.isAlive() && !x.isSpectator())) {
			if (Math.sqrt(e.squaredDistanceTo(c.x, c.y, c.z)) > range) {
				continue;
			}
			SpellEffects.hurt(world, p, e, (float) (3.0 * power));
			e.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, (int) Math.round(100 * power), 0));
			e.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, (int) Math.round(200 * power), 1));
			e.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, (int) Math.round(100 * power), 1));
		}
		for (double r = 1.5; r <= range; r += 1.5) {
			SpellEffects.ring(world, ParticleTypes.SQUID_INK, c.add(0.0, 1.0, 0.0), r, (int) (r * 6));
		}
		world.spawnParticles(ParticleTypes.WITCH, c.x, c.y + 1.0, c.z, 60, range / 2.0, 1.0, range / 2.0, 0.05);
		SpellEffects.sound(world, c.x, c.y, c.z, SoundEvents.ENTITY_DRAGON_FIREBALL_EXPLODE, 1.2f, 0.3f);
		return true;
	}
}
