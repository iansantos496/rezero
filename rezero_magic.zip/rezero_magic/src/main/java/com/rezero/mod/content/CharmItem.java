package com.rezero.mod.content;

import com.rezero.mod.core.Charm;

import net.minecraft.item.Item;

/** Acessório: funciona na mão secundária (ver core/Charm). Sem lógica própria: o SpellService lê o item. */
public class CharmItem extends Item {
	private final Charm charm;

	public CharmItem(Settings settings, Charm charm) {
		super(settings);
		this.charm = charm;
	}

	public Charm charm() {
		return charm;
	}
}
