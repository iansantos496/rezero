package com.rezero.mod.server;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.rezero.mod.ModConfig;
import com.rezero.mod.core.ChannelModel;

import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

/**
 * Comandos administrativos para testes: /rezero admin resetar_afinidade e /rezero admin nivel_canais <1-20>
 * Fica DESLIGADO por padrão (config/rezero_magic.properties: allowAdminReset=false) e, mesmo ligado,
 * só afeta o próprio jogador que o executa. Não existe nenhuma troca de afinidade no jogo normal.
 * Pendência conhecida: checar também permissão de operador (a API de permissões mudou na 1.21.9
 * e eu não consegui confirmar os nomes sem compilar). Até lá, a trava é a configuração.
 */
public final class AdminCommands {
	private AdminCommands() {}

	public static void init() {
		CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
				dispatcher.register(CommandManager.literal("rezero")
						.then(CommandManager.literal("admin")
								.then(CommandManager.literal("resetar_afinidade")
										.executes(ctx -> {
											ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
											if (!ModConfig.allowAdminReset()) {
												ctx.getSource().sendError(
														Text.translatable("message.rezero_magic.admin_reset_disabled"));
												return 0;
											}
											MagicGate.adminResetAffinity(player);
											ctx.getSource().sendFeedback(
													() -> Text.translatable("message.rezero_magic.admin_reset_done"), false);
											return 1;
										}))
								.then(CommandManager.literal("nivel_canais")
										.then(CommandManager.argument("nivel", IntegerArgumentType.integer(1, ChannelModel.MAX_LEVEL))
												.executes(ctx -> {
													ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
													if (!ModConfig.allowAdminReset()) {
														ctx.getSource().sendError(
																Text.translatable("message.rezero_magic.admin_reset_disabled"));
														return 0;
													}
													int level = IntegerArgumentType.getInteger(ctx, "nivel");
													MagicGate.adminSetChannelLevel(player, level);
													ctx.getSource().sendFeedback(
															() -> Text.translatable("message.rezero_magic.admin_level_done", level), false);
													return 1;
												}))))));
	}
}
