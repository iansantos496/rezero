package com.rezero.mod.core;

/** Multiplicadores vindos do equipamento. 1.0 = sem efeito. Sempre dentro dos limites de EquipmentRules. */
public record CastModifiers(double power, double cost, double cast, double regen) {
	public static final CastModifiers NONE = new CastModifiers(1.0, 1.0, 1.0, 1.0);
}
