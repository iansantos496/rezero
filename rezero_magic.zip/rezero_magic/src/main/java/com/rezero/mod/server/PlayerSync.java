package com.rezero.mod.server;

import com.rezero.mod.data.PlayerDataStore;
import com.rezero.mod.data.PlayerMagicData;
import com.rezero.mod.net.PlayerSyncPayload;

import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.network.ServerPlayerEntity;

/** Envia ao cliente o retrato atual dos dados do jogador. Chamado só quando algo muda ou no login. */
public final class PlayerSync {
	private PlayerSync() {}

	public static void send(ServerPlayerEntity player) {
		PlayerMagicData d = PlayerDataStore.get(player);
		ServerPlayNetworking.send(player, new PlayerSyncPayload(d.affinityId(), d.channelLevel(), d.channelXp(), d.inscriptionMask()));
		SpellService.sendMana(player, true);
	}
}
