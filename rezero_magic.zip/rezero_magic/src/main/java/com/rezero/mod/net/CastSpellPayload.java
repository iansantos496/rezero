package com.rezero.mod.net;

import com.rezero.mod.ReZeroMod;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Cliente -> servidor: "quero conjurar o feitiço X". É só um pedido; o servidor decide tudo. */
public record CastSpellPayload(int spellId) implements CustomPayload {
	public static final CustomPayload.Id<CastSpellPayload> ID =
			new CustomPayload.Id<>(Identifier.of(ReZeroMod.MOD_ID, "cast_spell"));

	public static final PacketCodec<RegistryByteBuf, CastSpellPayload> CODEC =
			PacketCodec.tuple(PacketCodecs.VAR_INT, CastSpellPayload::spellId, CastSpellPayload::new);

	@Override
	public CustomPayload.Id<? extends CustomPayload> getId() {
		return ID;
	}
}
