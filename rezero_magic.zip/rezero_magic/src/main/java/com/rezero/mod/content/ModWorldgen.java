package com.rezero.mod.content;

import com.rezero.mod.ReZeroMod;

import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;
import net.minecraft.world.gen.GenerationStep;
import net.minecraft.world.gen.feature.PlacedFeature;

/**
 * Geração do minério de cristal de mana no Overworld. As formas da geração ficam em JSON:
 * data/rezero_magic/worldgen/configured_feature/mana_crystal_ore.json e placed_feature/mana_crystal_ore.json.
 * Só vale para chunks gerados DEPOIS de instalar o mod (use um mundo novo ou explore terreno novo).
 */
public final class ModWorldgen {
	public static final RegistryKey<PlacedFeature> MANA_CRYSTAL_ORE =
			RegistryKey.of(RegistryKeys.PLACED_FEATURE, Identifier.of(ReZeroMod.MOD_ID, "mana_crystal_ore"));

	private ModWorldgen() {}

	public static void init() {
		BiomeModifications.addFeature(BiomeSelectors.foundInOverworld(),
				GenerationStep.Feature.UNDERGROUND_ORES, MANA_CRYSTAL_ORE);
	}
}
