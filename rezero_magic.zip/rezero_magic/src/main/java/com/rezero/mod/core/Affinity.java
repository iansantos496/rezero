package com.rezero.mod.core;

/**
 * As seis afinidades. Código puro, sem classes do Minecraft, para ser testável fora do jogo.
 * A ordem (id) NUNCA deve mudar depois de lançada, pois é o valor salvo nos dados do jogador.
 */
public enum Affinity {
	FIRE(0, "fire"),
	WATER(1, "water"),
	WIND(2, "wind"),
	EARTH(3, "earth"),
	YIN(4, "yin"),
	YANG(5, "yang");

	private final int id;
	private final String key;

	Affinity(int id, String key) {
		this.id = id;
		this.key = key;
	}

	public int id() {
		return id;
	}

	/** Parte final da chave de tradução: affinity.rezero_magic.<key> */
	public String key() {
		return key;
	}

	/** @return a afinidade com esse id, ou null se o id for inválido (por exemplo, vindo de um pacote adulterado). */
	public static Affinity fromId(int id) {
		for (Affinity a : values()) {
			if (a.id == id) {
				return a;
			}
		}
		return null;
	}
}
