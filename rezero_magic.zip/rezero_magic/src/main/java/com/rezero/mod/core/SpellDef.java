package com.rezero.mod.core;

/**
 * Definição de um feitiço. Os ids são salvos/enviados pela rede e NUNCA devem mudar depois de lançados.
 * baseCastTicks e cooldownTicks em ticks (20 por segundo); range em blocos.
 */
public record SpellDef(
		int id,
		String key,
		Affinity affinity,
		Kind kind,
		int baseCost,
		int baseCastTicks,
		int cooldownTicks,
		int unlockLevel,
		int range) {

	public enum Kind { OFFENSIVE, DEFENSIVE, UTILITY }
}
