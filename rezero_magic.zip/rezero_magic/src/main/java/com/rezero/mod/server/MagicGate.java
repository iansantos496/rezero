package com.rezero.mod.server;

import com.rezero.mod.ReZeroMod;
import com.rezero.mod.core.Affinity;
import com.rezero.mod.core.AffinityRules;
import com.rezero.mod.core.CastRules;
import com.rezero.mod.core.SpellDef;
import com.rezero.mod.data.PlayerDataStore;
import com.rezero.mod.data.PlayerMagicData;
import com.rezero.mod.net.OpenAffinityScreenPayload;

import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.network.ServerPlayerEntity;

/**
 * PORTA ÚNICA de permissões mágicas no servidor.
 * Aprender, conjurar, ativar item, inscrição elemental, espírito e desbloqueio de nó vão chamar
 * {@link #canUse} antes de qualquer efeito. A interface do cliente nunca decide nada.
 */
public final class MagicGate {
	private MagicGate() {}

	/** O jogador pode aprender/usar um poder que exige a afinidade {@code required}? */
	public static boolean canUse(ServerPlayerEntity player, Affinity required) {
		return AffinityRules.canUse(PlayerDataStore.get(player).affinity(), required);
	}

	/** @return a afinidade do jogador, ou null se ainda não escolheu. */
	public static Affinity affinityOf(ServerPlayerEntity player) {
		return PlayerDataStore.get(player).affinity();
	}

	/**
	 * Pedido de escolha de afinidade vindo do cliente. Só é aceito se o id for válido e o jogador
	 * ainda não tiver afinidade. Qualquer outro caso (id adulterado, tentativa de troca) é recusado.
	 */
	public static boolean tryChooseAffinity(ServerPlayerEntity player, int affinityId) {
		Affinity wanted = Affinity.fromId(affinityId);
		PlayerMagicData data = PlayerDataStore.get(player);
		if (!AffinityRules.canChoose(data.affinity(), wanted)) {
			ReZeroMod.LOGGER.warn("Pedido de afinidade recusado para {} (id {}, atual {}).",
					player.getName().getString(), affinityId, data.affinity());
			return false;
		}
		data.setAffinity(wanted);
		PlayerDataStore.save(player, data);
		PlayerSync.send(player);
		ReZeroMod.LOGGER.info("{} escolheu a afinidade {}.", player.getName().getString(), wanted.key());
		return true;
	}

	/**
	 * Porta de conjuração: afinidade, nível dos canais, estado (conjurando/exausto), recarga e mana,
	 * sempre pelos dados do SERVIDOR. Chamada ao pedir e de novo ao concluir a conjuração.
	 */
	public static CastRules.Result checkCast(ServerPlayerEntity player, SpellDef spell, int cooldownTicksLeft,
			boolean exhausted, boolean casting, double equipmentCost) {
		PlayerMagicData d = PlayerDataStore.get(player);
		return CastRules.check(d.affinity(), d.channelLevel(), d.mana(), cooldownTicksLeft, exhausted, casting, spell,
				equipmentCost);
	}

	/** Se o jogador ainda não tem afinidade, manda o cliente abrir a tela obrigatória. */
	public static void promptAffinityIfNeeded(ServerPlayerEntity player, int reason) {
		if (PlayerDataStore.get(player).affinity() == null) {
			ServerPlayNetworking.send(player, new OpenAffinityScreenPayload(reason));
		}
	}

	/** Reset administrativo. Só é chamado pelo comando restrito (ver AdminCommands). */
	public static void adminResetAffinity(ServerPlayerEntity player) {
		PlayerMagicData data = PlayerDataStore.get(player);
		data.setAffinity(null);
		PlayerDataStore.save(player, data);
		PlayerSync.send(player);
		promptAffinityIfNeeded(player, 1);
		ReZeroMod.LOGGER.warn("Afinidade de {} redefinida por comando administrativo.", player.getName().getString());
	}

	/** Comando de teste restrito (ver AdminCommands): define o nível dos canais do próprio jogador. */
	public static void adminSetChannelLevel(ServerPlayerEntity player, int level) {
		PlayerMagicData data = PlayerDataStore.get(player);
		data.setChannelLevel(level);
		PlayerDataStore.save(player, data);
		PlayerSync.send(player);
		ReZeroMod.LOGGER.warn("Nível dos canais de {} definido por comando administrativo: {}.",
				player.getName().getString(), data.channelLevel());
	}
}
