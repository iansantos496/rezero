package com.rezero.mod.core;

/**
 * Vestes mágicas (3 conjuntos de 4 peças). ADAPTAÇÃO de jogo: dão bônus de magia, não proteção física.
 * Cada peça dá o bônus "por peça"; usar as 4 peças do MESMO conjunto soma também o bônus de conjunto.
 * Os ids e as chaves nunca devem mudar (a chave + "_" + sufixo da peça é o caminho do item registrado).
 */
public enum RobeSet {
	APPRENTICE(0, "apprentice_robe", 0, 0, 0, 5, 5, 0, 0, 10),
	CRYSTAL(1, "crystal_robe", 3, 2, 0, 0, 0, 5, 5, 15),
	PURE(2, "pure_robe", 5, 3, 0, 5, 10, 0, 10, 20);

	private final int id;
	private final String key;
	private final int piecePower;
	private final int pieceCost;
	private final int pieceCast;
	private final int pieceRegen;
	private final int setPower;
	private final int setCost;
	private final int setCast;
	private final int setRegen;

	RobeSet(int id, String key, int piecePower, int pieceCost, int pieceCast, int pieceRegen,
			int setPower, int setCost, int setCast, int setRegen) {
		this.id = id;
		this.key = key;
		this.piecePower = piecePower;
		this.pieceCost = pieceCost;
		this.pieceCast = pieceCast;
		this.pieceRegen = pieceRegen;
		this.setPower = setPower;
		this.setCost = setCost;
		this.setCast = setCast;
		this.setRegen = setRegen;
	}

	public int id() {
		return id;
	}

	public String key() {
		return key;
	}

	/** Chave do item de uma peça deste conjunto. */
	public String itemKey(RobePiece piece) {
		return key + "_" + piece.suffix();
	}

	/** Bônus POR PEÇA em %: potência. */
	public int piecePowerPct() {
		return piecePower;
	}

	public int pieceCostReductionPct() {
		return pieceCost;
	}

	public int pieceCastReductionPct() {
		return pieceCast;
	}

	public int pieceRegenPct() {
		return pieceRegen;
	}

	/** Bônus de CONJUNTO completo em %. */
	public int setPowerPct() {
		return setPower;
	}

	public int setCostReductionPct() {
		return setCost;
	}

	public int setCastReductionPct() {
		return setCast;
	}

	public int setRegenPct() {
		return setRegen;
	}
}
