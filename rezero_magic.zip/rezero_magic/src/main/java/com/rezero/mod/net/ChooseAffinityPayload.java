package com.rezero.mod.net;

import com.rezero.mod.ReZeroMod;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Cliente -> servidor: "quero a afinidade X". É só um pedido; o servidor decide. */
public record ChooseAffinityPayload(int affinityId) implements CustomPayload {
	public static final CustomPayload.Id<ChooseAffinityPayload> ID =
			new CustomPayload.Id<>(Identifier.of(ReZeroMod.MOD_ID, "choose_affinity"));

	public static final PacketCodec<RegistryByteBuf, ChooseAffinityPayload> CODEC =
			PacketCodec.tuple(PacketCodecs.VAR_INT, ChooseAffinityPayload::affinityId, ChooseAffinityPayload::new);

	@Override
	public CustomPayload.Id<? extends CustomPayload> getId() {
		return ID;
	}
}
