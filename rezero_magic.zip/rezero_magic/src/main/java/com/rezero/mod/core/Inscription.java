package com.rezero.mod.core;

/**
 * Inscrições mágicas ("marcas"): 12 em 4 categorias, gravadas NO JOGADOR (até 3 por vez) numa Mesa de Inscrição, com tinta de cristal.
 * DESVIO do plano: o plano previa gravar em armas/armaduras; isso exige um tipo novo de componente de item (API não confirmada),
 * então aqui a marca fica no jogador. ADAPTAÇÃO de jogo: efeitos são decisões de jogo, não canon.
 * Os ids e as chaves nunca devem mudar (a chave forma a tradução inscription.rezero_magic.<chave>).
 */
public enum Inscription {
	// id, chave, categoria, nível (1..3), potência%, redução de custo% (negativo = mais caro), redução de conjuração%, regeneração%, passivo
	FORCE(0, "force", Category.POWER, 1, 8, 0, 0, 0, Passive.NONE),
	FOCUS(1, "focus", Category.POWER, 2, 0, 0, 8, 0, Passive.NONE),
	GREEDY(2, "greedy", Category.POWER, 3, 15, -10, 0, 0, Passive.NONE),
	THRIFT(3, "thrift", Category.ECONOMY, 1, 0, 8, 0, 0, Passive.NONE),
	SPRING(4, "spring", Category.ECONOMY, 2, 0, 0, 0, 20, Passive.NONE),
	BALANCE(5, "balance", Category.ECONOMY, 3, 5, 5, 0, 0, Passive.NONE),
	STONE(6, "stone", Category.DEFENSE, 1, 0, 0, 0, 0, Passive.RESISTANCE),
	EMBER(7, "ember", Category.DEFENSE, 2, 0, 0, 0, 0, Passive.FIRE_RESISTANCE),
	VITALITY(8, "vitality", Category.DEFENSE, 3, 0, 0, 0, 0, Passive.REGEN_LOW_HEALTH),
	WIND(9, "wind", Category.UTILITY, 1, 0, 0, 0, 0, Passive.SPEED),
	LEAP(10, "leap", Category.UTILITY, 2, 0, 0, 0, 0, Passive.JUMP),
	DIVER(11, "diver", Category.UTILITY, 3, 0, 0, 0, 0, Passive.WATER_BREATHING);

	public enum Category { POWER, ECONOMY, DEFENSE, UTILITY }

	/** Efeito passivo aplicado pelo servidor a cada segundo enquanto a marca estiver gravada. */
	public enum Passive { NONE, RESISTANCE, FIRE_RESISTANCE, REGEN_LOW_HEALTH, SPEED, JUMP, WATER_BREATHING }

	public static final int SLOTS = 3;
	private static final int[] UNLOCK_LEVEL = {1, 5, 10};

	private final int id;
	private final String key;
	private final Category category;
	private final int tier;
	private final int powerPct;
	private final int costReductionPct;
	private final int castReductionPct;
	private final int regenPct;
	private final Passive passive;

	Inscription(int id, String key, Category category, int tier, int powerPct, int costReductionPct,
			int castReductionPct, int regenPct, Passive passive) {
		this.id = id;
		this.key = key;
		this.category = category;
		this.tier = tier;
		this.powerPct = powerPct;
		this.costReductionPct = costReductionPct;
		this.castReductionPct = castReductionPct;
		this.regenPct = regenPct;
		this.passive = passive;
	}

	public int id() {
		return id;
	}

	public String key() {
		return key;
	}

	public Category category() {
		return category;
	}

	public int tier() {
		return tier;
	}

	/** Tinta de cristal gasta ao gravar: 2, 3 ou 4. */
	public int inkCost() {
		return tier + 1;
	}

	/** Nível mínimo dos canais de mana para gravar: 1, 5 ou 10. */
	public int unlockLevel() {
		return UNLOCK_LEVEL[tier - 1];
	}

	public int powerPct() {
		return powerPct;
	}

	public int costReductionPct() {
		return costReductionPct;
	}

	public int castReductionPct() {
		return castReductionPct;
	}

	public int regenPct() {
		return regenPct;
	}

	public Passive passive() {
		return passive;
	}

	/** @return a inscrição com esse id, ou null. */
	public static Inscription fromId(int id) {
		for (Inscription i : values()) {
			if (i.id == id) {
				return i;
			}
		}
		return null;
	}

	/** Bit desta inscrição na máscara enviada ao cliente. */
	public int bit() {
		return 1 << id;
	}
}
