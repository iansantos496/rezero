package com.rezero.mod.content;

import java.util.function.Function;

import com.rezero.mod.ReZeroMod;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.MapColor;
import net.minecraft.item.Items;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.util.Identifier;

/** Blocos do mod. Cada bloco precisa de: blockstate, modelo, textura, item model definition, loot table e tradução. */
public final class ModBlocks {
	public static final Block MANA_CRYSTAL_ORE = register("mana_crystal_ore", Block::new,
			AbstractBlock.Settings.create().mapColor(MapColor.STONE_GRAY).strength(3.0f, 3.0f).requiresTool()
					.sounds(BlockSoundGroup.AMETHYST_BLOCK).luminance(state -> 4));

	public static final Block MANA_CONCENTRATOR = register("mana_concentrator", ManaConcentratorBlock::new,
			AbstractBlock.Settings.create().mapColor(MapColor.PURPLE).strength(3.5f, 6.0f).requiresTool()
					.sounds(BlockSoundGroup.AMETHYST_BLOCK).luminance(state -> 8));

	public static final Block INSCRIPTION_TABLE = register("inscription_table", InscriptionTableBlock::new,
			AbstractBlock.Settings.create().mapColor(MapColor.BROWN).strength(2.5f).sounds(BlockSoundGroup.WOOD)
					.luminance(state -> 6));

	private ModBlocks() {}

	private static Block register(String path, Function<AbstractBlock.Settings, Block> factory,
			AbstractBlock.Settings settings) {
		RegistryKey<Block> key = RegistryKey.of(RegistryKeys.BLOCK, Identifier.of(ReZeroMod.MOD_ID, path));
		Block block = Blocks.register(key, factory, settings);
		Items.register(block); // item do bloco, com o mesmo id
		return block;
	}

	/** Força o registro durante a inicialização do mod. */
	public static void init() {
		ReZeroMod.LOGGER.info("Blocos registrados: minério de cristal de mana, concentrador e mesa de inscrição.");
	}
}
