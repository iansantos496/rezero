package com.rezero.mod.core;

/**
 * Canais de mana (Sistema 10), em código puro. Todas as fórmulas ficam aqui para serem testadas fora do jogo.
 * ADAPTAÇÃO para o Minecraft: as fontes consultadas não detalham o consumo de mana nem o Gate; os números abaixo
 * são decisões de jogo, não informação canônica.
 * O nível dos canais (1 a 20) sobe pelo USO (mana gasta em feitiços) e melhora capacidade, regeneração,
 * eficiência (custo), controle (tempo de conjuração) e potência.
 */
public final class ChannelModel {
	public static final int MAX_LEVEL = 20;
	/** Ao zerar a mana: sem regeneração e sem conjurar por este tempo (5 s). */
	public static final int EXHAUSTION_TICKS = 100;

	private ChannelModel() {}

	public static int clampLevel(int level) {
		return Math.max(1, Math.min(MAX_LEVEL, level));
	}

	/** Capacidade: 100 no nível 1, +15 por nível (385 no nível 20). */
	public static int maxMana(int level) {
		return 100 + 15 * (clampLevel(level) - 1);
	}

	public static int clampMana(int mana, int level) {
		return Math.max(0, Math.min(maxMana(level), mana));
	}

	/** Regeneração em mana por segundo: 1,5 no nível 1 até 6,25 no nível 20. */
	public static double regenPerSecond(int level) {
		return 1.5 + 0.25 * (clampLevel(level) - 1);
	}

	/** Eficiência: multiplicador do custo, de 1,0 (nível 1) a 0,7625 (nível 20). */
	public static double costMultiplier(int level) {
		return 1.0 - 0.0125 * (clampLevel(level) - 1);
	}

	/** Controle: multiplicador do tempo de conjuração, de 1,0 a 0,715. */
	public static double castTimeMultiplier(int level) {
		return 1.0 - 0.015 * (clampLevel(level) - 1);
	}

	/** Potência: multiplicador do dano/efeito dos feitiços, de 1,0 a 1,38. */
	public static double powerMultiplier(int level) {
		return 1.0 + 0.02 * (clampLevel(level) - 1);
	}

	public static int effectiveCost(int baseCost, int level) {
		return effectiveCost(baseCost, level, 1.0);
	}

	/** {@code equipment}: multiplicador de custo vindo do equipamento (CastModifiers.cost). */
	public static int effectiveCost(int baseCost, int level, double equipment) {
		return Math.max(1, (int) Math.round(baseCost * costMultiplier(level) * equipment));
	}

	public static int effectiveCastTicks(int baseTicks, int level) {
		return effectiveCastTicks(baseTicks, level, 1.0);
	}

	/** {@code equipment}: multiplicador de tempo vindo do equipamento (CastModifiers.cast). */
	public static int effectiveCastTicks(int baseTicks, int level, double equipment) {
		return baseTicks <= 0 ? 0 : Math.max(1, (int) Math.round(baseTicks * castTimeMultiplier(level) * equipment));
	}

	/** XP para sair deste nível (0 no nível máximo). */
	public static int xpNeeded(int level) {
		int l = clampLevel(level);
		return l >= MAX_LEVEL ? 0 : 60 + 40 * l;
	}

	/** XP dos canais por feitiço: metade da mana gasta, no mínimo 2. */
	public static int xpForCast(int spentMana) {
		return Math.max(2, spentMana / 2);
	}

	/** Aplica XP ganho. @return {novo nível, novo xp}. */
	public static int[] applyXp(int level, int xp, int gained) {
		int l = clampLevel(level);
		int x = Math.max(0, xp) + Math.max(0, gained);
		while (l < MAX_LEVEL && x >= xpNeeded(l)) {
			x -= xpNeeded(l);
			l++;
		}
		if (l >= MAX_LEVEL) {
			x = 0;
		}
		return new int[] {l, x};
	}
}
