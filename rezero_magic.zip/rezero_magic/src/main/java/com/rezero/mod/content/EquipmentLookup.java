package com.rezero.mod.content;

import java.util.List;

import com.rezero.mod.core.CastModifiers;
import com.rezero.mod.core.Catalyst;
import com.rezero.mod.core.Charm;
import com.rezero.mod.core.EquipmentRules;
import com.rezero.mod.core.Inscription;
import com.rezero.mod.core.RobeSet;

import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;

/**
 * Lê o equipamento mágico do jogador: cajado na mão principal, acessório na mão secundária e vestes nos slots de armadura.
 * As marcas gravadas vêm de fora (servidor: dados do jogador; cliente: último retrato recebido).
 * Funciona no servidor (decisão) e no cliente (só para mostrar números na tela).
 */
public final class EquipmentLookup {
	private static final EquipmentSlot[] ARMOR_SLOTS = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

	private EquipmentLookup() {}

	public static Catalyst staffOf(PlayerEntity player) {
		Item item = player.getMainHandStack().getItem();
		return item instanceof CatalystItem c ? c.catalyst() : null;
	}

	public static Charm charmOf(PlayerEntity player) {
		Item item = player.getOffHandStack().getItem();
		return item instanceof CharmItem c ? c.charm() : null;
	}

	/** Peças vestidas de cada conjunto, indexadas por RobeSet.id(). Só conta a peça no slot certo. */
	public static int[] robePieces(PlayerEntity player) {
		int[] count = new int[RobeSet.values().length];
		for (EquipmentSlot slot : ARMOR_SLOTS) {
			Item item = player.getEquippedStack(slot).getItem();
			if (item instanceof RobeItem robe && robe.slot() == slot) {
				count[robe.set().id()]++;
			}
		}
		return count;
	}

	public static CastModifiers modifiersOf(PlayerEntity player, List<Inscription> marks) {
		return EquipmentRules.combine(staffOf(player), charmOf(player), robePieces(player), marks);
	}
}
