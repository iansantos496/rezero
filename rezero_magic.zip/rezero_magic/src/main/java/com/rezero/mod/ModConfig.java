package com.rezero.mod;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

import net.fabricmc.loader.api.FabricLoader;

/** Configuração em config/rezero_magic.properties (criada com valores seguros se não existir). */
public final class ModConfig {
	private static boolean allowAdminReset = false;

	private ModConfig() {}

	private static Path file() {
		return FabricLoader.getInstance().getConfigDir().resolve("rezero_magic.properties");
	}

	/** Se verdadeiro, os comandos de teste /rezero admin ... funcionam. Padrão: falso. */
	public static boolean allowAdminReset() {
		return allowAdminReset;
	}

	public static void load() {
		Path path = file();
		Properties props = new Properties();
		if (Files.exists(path)) {
			try (InputStream in = Files.newInputStream(path)) {
				props.load(in);
			} catch (IOException e) {
				ReZeroMod.LOGGER.warn("Não foi possível ler {}: {}", path, e.getMessage());
			}
		}
		allowAdminReset = Boolean.parseBoolean(props.getProperty("allowAdminReset", "false"));

		// grava o arquivo com todas as opções, para o usuário ver o que existe
		props.setProperty("allowAdminReset", Boolean.toString(allowAdminReset));
		try (OutputStream out = Files.newOutputStream(path)) {
			props.store(out, "Re:Zero Magia. allowAdminReset=true libera os comandos de teste /rezero admin resetar_afinidade e /rezero admin nivel_canais (so para testes).");
		} catch (IOException e) {
			ReZeroMod.LOGGER.warn("Não foi possível gravar {}: {}", path, e.getMessage());
		}
	}
}
