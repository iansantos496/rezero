package com.rezero.mod.client;

import com.rezero.mod.core.Affinity;
import com.rezero.mod.core.AffinityPicker;
import com.rezero.mod.net.ChooseAffinityPayload;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;

/**
 * Tela OBRIGATÓRIA de seleção de afinidade. Não fecha com ESC; fecha sozinha quando o servidor
 * confirma a escolha (ver ReZeroModClient). A tela só envia um PEDIDO: quem valida é o servidor.
 * Fluxo: escolher um cartão -> "Escolher" -> confirmação "Tem certeza?" -> "Sim, confirmar".
 */
public class AffinityScreen extends Screen {
	private static final int[] COLORS = {0xFFFF8A3D, 0xFF6EC8FF, 0xFFB8F0C8, 0xFFD2A679, 0xFFB57BFF, 0xFFFFE680};

	private final AffinityPicker picker;
	private int left;
	private int top;
	private int panelW;
	private int panelH;

	public AffinityScreen() {
		this(new AffinityPicker());
	}

	private AffinityScreen(AffinityPicker picker) {
		super(Text.translatable("screen.rezero_magic.affinity.title"));
		this.picker = picker;
	}

	@Override
	public boolean shouldCloseOnEsc() {
		return false;
	}

	@Override
	public boolean shouldPause() {
		// Sem pausar, o servidor integrado continua processando o pedido de escolha.
		return false;
	}

	@Override
	protected void init() {
		panelW = Math.min(width - 16, 360);
		panelH = Math.min(height - 16, 236);
		left = (width - panelW) / 2;
		top = (height - panelH) / 2;

		// primeiro o fundo e os textos; os botões vêm depois e ficam por cima
		addDrawable(this::drawContent);

		if (picker.confirming()) {
			int bw = Math.min(150, (panelW - 30) / 2);
			addDrawableChild(ButtonWidget.builder(
					Text.translatable("screen.rezero_magic.affinity.confirm_yes"),
					b -> ClientPlayNetworking.send(new ChooseAffinityPayload(picker.choiceToSend().id())))
					.dimensions(left + panelW / 2 - bw - 5, top + panelH - 34, bw, 20).build());
			addDrawableChild(ButtonWidget.builder(
					Text.translatable("screen.rezero_magic.affinity.confirm_back"),
					b -> MinecraftClient.getInstance().setScreen(new AffinityScreen(picker.back())))
					.dimensions(left + panelW / 2 + 5, top + panelH - 34, bw, 20).build());
			return;
		}

		int gap = 6;
		int bw = (panelW - 20 - 2 * gap) / 3;
		Affinity[] all = Affinity.values();
		for (int i = 0; i < all.length; i++) {
			final Affinity affinity = all[i];
			Text name = Text.translatable("affinity.rezero_magic." + affinity.key());
			Text label = affinity == picker.selected()
					? Text.literal("> ").append(name).append(Text.literal(" <"))
					: name;
			int x = left + 10 + (i % 3) * (bw + gap);
			int y = top + 32 + (i / 3) * 24;
			addDrawableChild(ButtonWidget.builder(label,
					b -> MinecraftClient.getInstance().setScreen(new AffinityScreen(picker.select(affinity))))
					.dimensions(x, y, bw, 20).build());
		}

		ButtonWidget choose = ButtonWidget.builder(
				Text.translatable("screen.rezero_magic.affinity.choose"),
				b -> MinecraftClient.getInstance().setScreen(new AffinityScreen(picker.requestConfirm())))
				.dimensions(left + panelW / 2 - 70, top + panelH - 30, 140, 20).build();
		choose.active = picker.selected() != null;
		addDrawableChild(choose);
	}

	private void drawContent(DrawContext c, int mouseX, int mouseY, float delta) {
		c.fill(left - 2, top - 2, left + panelW + 2, top + panelH + 2, 0xFF000000);
		c.fill(left, top, left + panelW, top + panelH, 0xEE1B1530);

		Text title = Text.translatable("screen.rezero_magic.affinity.title");
		c.drawTextWithShadow(textRenderer, title, left + (panelW - textRenderer.getWidth(title)) / 2, top + 10, 0xFFFFD34D);

		Affinity selected = picker.selected();
		if (picker.confirming() && selected != null) {
			Text name = Text.translatable("affinity.rezero_magic." + selected.key());
			c.drawTextWithShadow(textRenderer, name, left + 14, top + 34, COLORS[selected.id()]);
			wrap(c, Text.translatable("screen.rezero_magic.affinity.confirm_text", name), left + 14, top + 52,
					panelW - 28, 0xFFFFFFFF);
			return;
		}

		if (selected == null) {
			wrap(c, Text.translatable("screen.rezero_magic.affinity.intro"), left + 14, top + 92, panelW - 28, 0xFFDADAEA);
			return;
		}

		int y = top + 92;
		c.drawTextWithShadow(textRenderer, Text.translatable("affinity.rezero_magic." + selected.key()),
				left + 14, y, COLORS[selected.id()]);
		y += 14;
		y = wrap(c, Text.translatable("affinity.rezero_magic." + selected.key() + ".canon"), left + 14, y, panelW - 28, 0xFFDADAEA);
		y += 4;
		wrap(c, Text.translatable("affinity.rezero_magic." + selected.key() + ".game"), left + 14, y, panelW - 28, 0xFFFFFFFF);
	}

	/** Escreve o texto quebrando linhas; devolve o y logo abaixo da última linha. */
	private int wrap(DrawContext c, Text t, int x, int y, int maxWidth, int color) {
		for (OrderedText line : textRenderer.wrapLines(t, maxWidth)) {
			c.drawTextWithShadow(textRenderer, line, x, y, color);
			y += 10;
		}
		return y;
	}
}
