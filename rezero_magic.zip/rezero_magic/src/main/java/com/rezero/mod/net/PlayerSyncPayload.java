package com.rezero.mod.net;

import com.rezero.mod.ReZeroMod;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/**
 * Servidor -> cliente: retrato dos dados do jogador (afinidade, -1 = ainda não escolheu; nível e XP dos canais; máscara de bits das marcas gravadas).
 * O cliente só usa isto para mostrar informação; nunca para decidir permissões.
 */
public record PlayerSyncPayload(int affinityId, int channelLevel, int channelXp, int marksMask) implements CustomPayload {
	public static final CustomPayload.Id<PlayerSyncPayload> ID =
			new CustomPayload.Id<>(Identifier.of(ReZeroMod.MOD_ID, "player_sync"));

	public static final PacketCodec<RegistryByteBuf, PlayerSyncPayload> CODEC = PacketCodec.tuple(
			PacketCodecs.VAR_INT, PlayerSyncPayload::affinityId,
			PacketCodecs.VAR_INT, PlayerSyncPayload::channelLevel,
			PacketCodecs.VAR_INT, PlayerSyncPayload::channelXp,
			PacketCodecs.VAR_INT, PlayerSyncPayload::marksMask,
			PlayerSyncPayload::new);

	@Override
	public CustomPayload.Id<? extends CustomPayload> getId() {
		return ID;
	}
}
