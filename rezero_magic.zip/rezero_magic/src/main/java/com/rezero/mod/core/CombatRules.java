package com.rezero.mod.core;

import java.util.List;

/**
 * Regras do combate (Sistema 9), em código puro e testadas fora do jogo. ADAPTAÇÃO: nenhum número vem da obra.
 * Estamina própria, esquiva com janela de invulnerabilidade, contra-ataque, combo, pontos e requisitos de aprendizado.
 */
public final class CombatRules {
	public static final int STAMINA_BASE = 100;
	public static final int STAMINA_PER_VIGOR = 6;
	public static final double REGEN_BASE = 10.0;
	public static final double REGEN_PER_AGILITY = 0.5;
	/** Depois de gastar estamina, ela só volta a regenerar após 1 s. */
	public static final int REGEN_DELAY_TICKS = 20;

	public static final int DODGE_COST = 20;
	public static final int DODGE_COOLDOWN_TICKS = 30;
	public static final int DODGE_INVULNERABLE_TICKS = 8;
	/** Depois de esquivar, o próximo golpe corpo a corpo em 1,5 s ganha o bônus de contra-ataque. */
	public static final int COUNTER_WINDOW_TICKS = 30;
	public static final int COUNTER_BONUS_PCT = 50;

	public static final int COMBO_WINDOW_TICKS = 25;
	public static final int COMBO_FINISHER_HITS = 3;
	public static final int COMBO_BONUS_PCT = 25;

	public static final int RIPOSTE_STANCE_TICKS = 20;
	public static final int GUARD_STANCE_TICKS = 40;
	/** Ecos (golpes extras) esperam o fim da invulnerabilidade do alvo, senão o jogo ignora o dano. */
	public static final int ECHO_DELAY_TICKS = 11;

	public static final double UNARMED_BASE_DAMAGE = 5.0;
	public static final double BOW_BASE_DAMAGE = 7.0;

	public enum UseResult { OK, NOT_LEARNED, NO_WEAPON, ON_COOLDOWN, NO_STAMINA, BUSY }

	public enum LearnResult { OK, UNKNOWN, ALREADY, NO_PREREQ, LEVEL, NO_POINTS }

	private CombatRules() {}

	// ---- estamina ----

	public static int maxStamina(int vigorLevel) {
		return STAMINA_BASE + STAMINA_PER_VIGOR * TrainingModel.clampLevel(vigorLevel);
	}

	public static double regenPerSecond(int agilityLevel) {
		return REGEN_BASE + REGEN_PER_AGILITY * TrainingModel.clampLevel(agilityLevel);
	}

	// ---- uso e esquiva ----

	/** @param tech a técnica do espaço escolhido na arma atual (null = nenhuma arma de estilo conhecido) */
	public static UseResult checkUse(int learnedMask, TechniqueDef tech, int cooldownLeft, double stamina, boolean busy) {
		if (tech == null) {
			return UseResult.NO_WEAPON;
		}
		if ((learnedMask & bit(tech.id())) == 0) {
			return UseResult.NOT_LEARNED;
		}
		if (busy) {
			return UseResult.BUSY;
		}
		if (cooldownLeft > 0) {
			return UseResult.ON_COOLDOWN;
		}
		if (stamina < tech.staminaCost()) {
			return UseResult.NO_STAMINA;
		}
		return UseResult.OK;
	}

	public static UseResult checkDodge(int cooldownLeft, double stamina, boolean busy) {
		if (busy) {
			return UseResult.BUSY;
		}
		if (cooldownLeft > 0) {
			return UseResult.ON_COOLDOWN;
		}
		if (stamina < DODGE_COST) {
			return UseResult.NO_STAMINA;
		}
		return UseResult.OK;
	}

	// ---- combo ----

	/** @return true se o golpe de número {@code hits} (1, 2, 3...) da sequência é o golpe final do combo. */
	public static boolean isFinisher(int hits) {
		return hits >= COMBO_FINISHER_HITS;
	}

	/** Dano extra (eco) de um golpe: combo final e/ou contra-ataque, em porcentagem do dano causado. */
	public static int echoBonusPct(boolean finisher, boolean counter) {
		return (finisher ? COMBO_BONUS_PCT : 0) + (counter ? COUNTER_BONUS_PCT : 0);
	}

	// ---- aprendizado ----

	public static int bit(int techniqueId) {
		return 1 << techniqueId;
	}

	/** Só os 15 bits válidos. */
	public static int sanitizeMask(int mask) {
		return mask & ((1 << Techniques.COUNT) - 1);
	}

	public static int sumLevels(int[] levels) {
		int sum = 0;
		if (levels != null) {
			for (int l : levels) {
				sum += TrainingModel.clampLevel(l);
			}
		}
		return sum;
	}

	/** Pontos gastos = soma dos custos das técnicas aprendidas. */
	public static int spentPoints(int learnedMask) {
		int spent = 0;
		for (TechniqueDef t : Techniques.all()) {
			if ((learnedMask & bit(t.id())) != 0) {
				spent += t.pointCost();
			}
		}
		return spent;
	}

	/** Pontos disponíveis = soma dos níveis de treino menos os pontos já gastos (nunca negativo). */
	public static int availablePoints(int[] trainingLevels, int learnedMask) {
		return Math.max(0, sumLevels(trainingLevels) - spentPoints(learnedMask));
	}

	/** Técnica anterior (tier - 1) do mesmo estilo, ou null para o tier 1. */
	public static TechniqueDef prerequisite(TechniqueDef tech) {
		if (tech == null || tech.tier() <= 1) {
			return null;
		}
		List<TechniqueDef> list = Techniques.forStyle(tech.style());
		return list.get(tech.tier() - 2);
	}

	public static LearnResult checkLearn(int learnedMask, TechniqueDef tech, int[] trainingLevels) {
		if (tech == null) {
			return LearnResult.UNKNOWN;
		}
		if ((learnedMask & bit(tech.id())) != 0) {
			return LearnResult.ALREADY;
		}
		TechniqueDef pre = prerequisite(tech);
		if (pre != null && (learnedMask & bit(pre.id())) == 0) {
			return LearnResult.NO_PREREQ;
		}
		int level = trainingLevels != null && tech.attribute().id() < trainingLevels.length
				? TrainingModel.clampLevel(trainingLevels[tech.attribute().id()]) : 0;
		if (level < tech.minLevel()) {
			return LearnResult.LEVEL;
		}
		if (availablePoints(trainingLevels, learnedMask) < tech.pointCost()) {
			return LearnResult.NO_POINTS;
		}
		return LearnResult.OK;
	}
}
