package com.rezero.mod.core;

/**
 * As 4 raridades de cristal de mana (Sistema 2). ADAPTAÇÃO: cristais de mana como itens não foram
 * confirmados no canon pelas fontes consultadas; nomes e valores são decisões de jogo.
 * A chave é o caminho do item registrado (item.rezero_magic.<chave>); os ids nunca devem mudar.
 */
public enum CrystalRarity {
	FRAGMENT(0, "mana_crystal_fragment", 15),
	CRYSTAL(1, "mana_crystal", 40),
	PURE(2, "mana_crystal_pure", 90),
	PRIMORDIAL(3, "mana_crystal_primordial", 200);

	private final int id;
	private final String key;
	private final int mana;

	CrystalRarity(int id, String key, int mana) {
		this.id = id;
		this.key = key;
		this.mana = mana;
	}

	public int id() {
		return id;
	}

	public String key() {
		return key;
	}

	/** Mana que o cristal restaura ao ser usado, e também a carga que ele coloca num Receptor (sem bônus). */
	public int mana() {
		return mana;
	}
}
