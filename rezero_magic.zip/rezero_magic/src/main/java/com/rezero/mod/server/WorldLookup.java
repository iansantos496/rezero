package com.rezero.mod.server;

import net.minecraft.entity.Entity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.world.ServerWorld;

/**
 * Descobre em qual mundo a entidade está sem depender de getWorld()/getEntityWorld(), cujo nome mudou
 * entre versões do Minecraft (padrão já compilado no projeto antigo). Se um dia o nome for estável,
 * só esta classe precisa mudar.
 */
final class WorldLookup {
	private WorldLookup() {}

	static ServerWorld of(MinecraftServer server, Entity entity) {
		for (ServerWorld world : server.getWorlds()) {
			if (world.getEntity(entity.getUuid()) == entity) {
				return world;
			}
		}
		return null;
	}
}
