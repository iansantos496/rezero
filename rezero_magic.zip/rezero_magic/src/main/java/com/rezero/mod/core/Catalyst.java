package com.rezero.mod.core;

/**
 * Cajados catalisadores (segurados na mão PRINCIPAL). ADAPTAÇÃO de jogo: bônus em % para os feitiços.
 * Os ids e as chaves nunca devem mudar (a chave é o caminho do item registrado).
 */
public enum Catalyst {
	APPRENTICE(0, "mana_staff_apprentice", 8, 0, 0),
	CRYSTAL(1, "mana_staff_crystal", 15, 8, 0),
	PURE(2, "mana_staff_pure", 25, 12, 10),
	PRIMORDIAL(3, "mana_staff_primordial", 40, 18, 20);

	private final int id;
	private final String key;
	private final int powerPct;
	private final int costReductionPct;
	private final int castReductionPct;

	Catalyst(int id, String key, int powerPct, int costReductionPct, int castReductionPct) {
		this.id = id;
		this.key = key;
		this.powerPct = powerPct;
		this.costReductionPct = costReductionPct;
		this.castReductionPct = castReductionPct;
	}

	public int id() {
		return id;
	}

	public String key() {
		return key;
	}

	/** Aumento de potência dos feitiços, em %. */
	public int powerPct() {
		return powerPct;
	}

	/** Redução do custo de mana, em %. */
	public int costReductionPct() {
		return costReductionPct;
	}

	/** Redução do tempo de conjuração, em %. */
	public int castReductionPct() {
		return castReductionPct;
	}
}
