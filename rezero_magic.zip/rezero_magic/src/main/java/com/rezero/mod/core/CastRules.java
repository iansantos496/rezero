package com.rezero.mod.core;

/**
 * Regra única de "posso conjurar agora?", em código puro. O servidor chama isto através do MagicGate;
 * o cliente nunca decide. A ordem das verificações é fixa e testada.
 */
public final class CastRules {
	/** Os nomes (em minúsculas) viram chaves de tradução: message.rezero_magic.cast.<nome>. */
	public enum Result {
		OK,
		UNKNOWN_SPELL,
		NO_AFFINITY,
		WRONG_AFFINITY,
		LOCKED,
		ALREADY_CASTING,
		EXHAUSTED,
		ON_COOLDOWN,
		NO_MANA
	}

	private CastRules() {}

	public static Result check(Affinity playerAffinity, int channelLevel, int mana, int cooldownTicksLeft,
			boolean exhausted, boolean casting, SpellDef spell) {
		return check(playerAffinity, channelLevel, mana, cooldownTicksLeft, exhausted, casting, spell, 1.0);
	}

	/** {@code equipmentCost}: multiplicador de custo do equipamento (CastModifiers.cost). */
	public static Result check(Affinity playerAffinity, int channelLevel, int mana, int cooldownTicksLeft,
			boolean exhausted, boolean casting, SpellDef spell, double equipmentCost) {
		if (spell == null) {
			return Result.UNKNOWN_SPELL;
		}
		if (playerAffinity == null) {
			return Result.NO_AFFINITY;
		}
		if (!AffinityRules.canUse(playerAffinity, spell.affinity())) {
			return Result.WRONG_AFFINITY;
		}
		if (ChannelModel.clampLevel(channelLevel) < spell.unlockLevel()) {
			return Result.LOCKED;
		}
		if (casting) {
			return Result.ALREADY_CASTING;
		}
		if (exhausted) {
			return Result.EXHAUSTED;
		}
		if (cooldownTicksLeft > 0) {
			return Result.ON_COOLDOWN;
		}
		if (mana < ChannelModel.effectiveCost(spell.baseCost(), channelLevel, equipmentCost)) {
			return Result.NO_MANA;
		}
		return Result.OK;
	}
}
