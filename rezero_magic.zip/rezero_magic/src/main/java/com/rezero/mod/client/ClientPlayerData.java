package com.rezero.mod.client;

import java.util.ArrayList;
import java.util.List;

import com.rezero.mod.core.Affinity;
import com.rezero.mod.core.ChannelModel;
import com.rezero.mod.core.Inscription;
import com.rezero.mod.core.InscriptionRules;
import com.rezero.mod.core.SpellDef;
import com.rezero.mod.core.Spells;

/**
 * Cópia, no cliente, do último retrato enviado pelo servidor. SÓ para exibir informação.
 * Nunca use isto para decidir se um poder pode ser usado: quem decide é o servidor.
 */
public final class ClientPlayerData {
	private static volatile int affinityId = -1;
	private static volatile boolean affinityScreenRequested = false;
	private static volatile int channelLevel = 1;
	private static volatile int channelXp = 0;
	private static volatile int mana = 0;
	private static volatile boolean exhausted = false;
	private static volatile int marksMask = 0;
	private static volatile int pendingHubTab = -1;

	private static int selectedSpellId = -1;
	/** Contador de ticks do cliente, usado para a recarga e a barra de conjuração na tela. */
	private static long clientTick = 0;
	private static int castingSpellId = -1;
	private static long castStart = 0;
	private static int castTotal = 0;
	private static final long[] COOLDOWN_END = new long[32];

	private ClientPlayerData() {}

	public static void update(int newAffinityId, int level, int xp, int newMarksMask) {
		affinityId = newAffinityId;
		marksMask = newMarksMask;
		channelLevel = ChannelModel.clampLevel(level);
		channelXp = Math.max(0, xp);
	}

	public static void updateMana(int newMana, boolean isExhausted) {
		mana = Math.max(0, newMana);
		exhausted = isExhausted;
	}

	public static void clear() {
		affinityId = -1;
		affinityScreenRequested = false;
		channelLevel = 1;
		channelXp = 0;
		mana = 0;
		exhausted = false;
		marksMask = 0;
		pendingHubTab = -1;
		selectedSpellId = -1;
		castingSpellId = -1;
		java.util.Arrays.fill(COOLDOWN_END, 0L);
	}

	public static void tick() {
		clientTick++;
		if (castingSpellId >= 0 && clientTick - castStart > castTotal + 20L) {
			castingSpellId = -1; // segurança: o servidor não avisou o fim
		}
	}

	/** @return a afinidade conhecida pelo cliente, ou null se o jogador ainda não escolheu. */
	public static Affinity affinity() {
		return Affinity.fromId(affinityId);
	}

	/** Marcas gravadas conhecidas pelo cliente (só para exibição). */
	public static List<Inscription> marks() {
		return InscriptionRules.fromMask(marksMask);
	}

	/** O servidor pediu para abrir o Hub numa aba (Mesa de Inscrição). */
	public static void requestHubTab(int tab) {
		pendingHubTab = tab;
	}

	/** @return a aba pedida (e limpa o pedido), ou -1. */
	public static int takeHubTabRequest() {
		int t = pendingHubTab;
		pendingHubTab = -1;
		return t;
	}

	public static int channelLevel() {
		return channelLevel;
	}

	public static int channelXp() {
		return channelXp;
	}

	public static int mana() {
		return mana;
	}

	public static int maxMana() {
		return ChannelModel.maxMana(channelLevel);
	}

	public static boolean exhausted() {
		return exhausted;
	}

	// ---- feitiços (somente exibição e escolha do que pedir ao servidor) ----

	/** Feitiços da afinidade já liberados pelo nível dos canais. */
	public static List<SpellDef> unlockedSpells() {
		List<SpellDef> out = new ArrayList<>();
		Affinity a = affinity();
		if (a == null) {
			return out;
		}
		for (SpellDef s : Spells.forAffinity(a)) {
			if (s.unlockLevel() <= channelLevel) {
				out.add(s);
			}
		}
		return out;
	}

	public static SpellDef selectedSpell() {
		List<SpellDef> list = unlockedSpells();
		if (list.isEmpty()) {
			return null;
		}
		for (SpellDef s : list) {
			if (s.id() == selectedSpellId) {
				return s;
			}
		}
		return list.get(0);
	}

	public static void cycleSpell(int direction) {
		List<SpellDef> list = unlockedSpells();
		SpellDef current = selectedSpell();
		if (list.isEmpty() || current == null) {
			return;
		}
		int idx = list.indexOf(current);
		int next = Math.floorMod(idx + direction, list.size());
		selectedSpellId = list.get(next).id();
	}

	public static void selectSpell(int id) {
		selectedSpellId = id;
	}

	public static void onCastState(int spellId, int castTicks, int cooldownTicks) {
		if (castTicks > 0) {
			castingSpellId = spellId;
			castStart = clientTick;
			castTotal = castTicks;
			return;
		}
		if (spellId == castingSpellId) {
			castingSpellId = -1;
		}
		if (cooldownTicks > 0 && spellId >= 0 && spellId < COOLDOWN_END.length) {
			COOLDOWN_END[spellId] = clientTick + cooldownTicks;
		}
	}

	/** @return de 0.0 a 1.0 o progresso da conjuração, ou -1 se não está conjurando. */
	public static float castProgress() {
		if (castingSpellId < 0 || castTotal <= 0) {
			return -1.0f;
		}
		return Math.min(1.0f, (clientTick - castStart) / (float) castTotal);
	}

	public static int castingSpellId() {
		return castingSpellId;
	}

	public static int cooldownLeft(int spellId) {
		if (spellId < 0 || spellId >= COOLDOWN_END.length) {
			return 0;
		}
		return (int) Math.max(0L, COOLDOWN_END[spellId] - clientTick);
	}

	// ---- tela de afinidade ----

	/** O servidor pediu a tela de afinidade; ela abre assim que o jogo estiver livre para isso. */
	public static void requestAffinityScreen() {
		affinityScreenRequested = true;
	}

	public static boolean affinityScreenRequested() {
		return affinityScreenRequested;
	}

	public static void clearAffinityScreenRequest() {
		affinityScreenRequested = false;
	}
}
