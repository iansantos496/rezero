package com.rezero.mod.client;

import com.rezero.mod.content.CombatStyles;
import com.rezero.mod.core.CombatStyle;
import com.rezero.mod.core.TechniqueDef;
import com.rezero.mod.core.Techniques;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

/** HUD de combate: barra de estamina e as 3 técnicas do estilo da arma na mão (pronta, em recarga ou não aprendida). */
public final class CombatHud {
	private CombatHud() {}

	public static void render(DrawContext context) {
		MinecraftClient client = MinecraftClient.getInstance();
		if (client.player == null || client.options.hudHidden) {
			return;
		}
		int x = 10;
		int y = 66;
		int width = 100;
		int stamina = ClientPlayerData.stamina();
		int max = ClientPlayerData.maxStamina();
		context.fill(x - 1, y - 1, x + width + 1, y + 7, 0xAA000000);
		context.fill(x, y, x + width * Math.min(stamina, max) / Math.max(1, max), y + 6, 0xFF48C060);
		context.drawTextWithShadow(client.textRenderer, Text.translatable("hud.rezero_magic.stamina", stamina, max), x, y + 9, 0xFFFFFFFF);

		CombatStyle style = CombatStyles.styleOf(client.player.getMainHandStack());
		if (style == null) {
			return;
		}
		int line = y + 21;
		context.drawTextWithShadow(client.textRenderer,
				Text.translatable("hud.rezero_magic.style", Text.translatable("style.rezero_magic." + style.key())), x, line, 0xFFFFD34D);
		for (int slot = 0; slot < 3; slot++) {
			TechniqueDef tech = Techniques.slot(style, slot);
			if (tech == null) {
				continue;
			}
			line += 11;
			Text name = Text.translatable("technique.rezero_magic." + tech.key());
			Text key = ReZeroModClient.slotKeyName(slot);
			boolean learned = (ClientPlayerData.techniqueMask() & (1 << tech.id())) != 0;
			int cd = ClientPlayerData.techniqueCooldownLeft(tech.id());
			Text text;
			int color;
			if (!learned) {
				text = Text.translatable("hud.rezero_magic.technique_locked", key, name);
				color = 0xFF777777;
			} else if (cd > 0) {
				text = Text.translatable("hud.rezero_magic.technique_cd", key, name, String.format("%.1f", cd / 20.0));
				color = 0xFFAAAAAA;
			} else {
				text = Text.translatable("hud.rezero_magic.technique", key, name, tech.staminaCost());
				color = 0xFFFFFFFF;
			}
			context.drawTextWithShadow(client.textRenderer, text, x, line, color);
		}
	}
}
