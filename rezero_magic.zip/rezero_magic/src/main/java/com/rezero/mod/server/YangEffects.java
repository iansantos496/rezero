package com.rezero.mod.server;

import java.util.ArrayList;
import java.util.List;

import com.rezero.mod.core.Spells;

import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Box;

/**
 * Feitiços de Yang (fortalecimentos). Beneficiam o conjurador e os outros jogadores próximos (aliados).
 * Da obra: Yang é a afinidade de fortalecimentos. O que cada feitiço faz é adaptação.
 */
final class YangEffects {
	private YangEffects() {}

	static boolean execute(ServerWorld world, ServerPlayerEntity p, int spellId, int range, double power) {
		List<ServerPlayerEntity> group = group(world, p, range);
		switch (spellId) {
			case Spells.STRENGTHEN:
				for (ServerPlayerEntity t : group) {
					buff(t, StatusEffects.STRENGTH, 400, 0, power);
				}
				break;
			case Spells.AGILITY:
				for (ServerPlayerEntity t : group) {
					buff(t, StatusEffects.SPEED, 300, 1, power);
					buff(t, StatusEffects.JUMP_BOOST, 300, 1, power);
				}
				break;
			case Spells.RADIANT_SHIELD:
				for (ServerPlayerEntity t : group) {
					buff(t, StatusEffects.ABSORPTION, 600, 2, power);
					buff(t, StatusEffects.RESISTANCE, 200, 0, power);
				}
				break;
			case Spells.BLESSING:
				for (ServerPlayerEntity t : group) {
					buff(t, StatusEffects.REGENERATION, 200, 1, power);
					t.heal((float) (4.0 * power));
				}
				break;
			case Spells.ZENITH:
				for (ServerPlayerEntity t : group) {
					buff(t, StatusEffects.STRENGTH, 400, 1, power);
					buff(t, StatusEffects.SPEED, 400, 1, power);
					buff(t, StatusEffects.RESISTANCE, 400, 0, power);
					buff(t, StatusEffects.HASTE, 400, 1, power);
				}
				break;
			default:
				return false;
		}
		for (ServerPlayerEntity t : group) {
			world.spawnParticles(ParticleTypes.END_ROD, t.getX(), t.getY() + 1.0, t.getZ(), 20, 0.4, 0.8, 0.4, 0.03);
			world.spawnParticles(ParticleTypes.ENCHANT, t.getX(), t.getY() + 1.0, t.getZ(), 20, 0.5, 0.8, 0.5, 0.3);
		}
		SpellEffects.sound(world, p.getX(), p.getY(), p.getZ(), SoundEvents.ENTITY_PLAYER_LEVELUP, 0.8f, 1.6f);
		return true;
	}

	/** O conjurador mais os outros jogadores até {@code range} blocos. */
	private static List<ServerPlayerEntity> group(ServerWorld world, ServerPlayerEntity p, int range) {
		Box area = new Box(p.getX() - range, p.getY() - range, p.getZ() - range,
				p.getX() + range, p.getY() + range, p.getZ() + range);
		List<ServerPlayerEntity> list = new ArrayList<>();
		list.add(p);
		list.addAll(world.getEntitiesByClass(ServerPlayerEntity.class, area,
				x -> x != p && x.isAlive() && !x.isSpectator() && x.squaredDistanceTo(p) <= (double) range * range));
		return list;
	}

	private static void buff(ServerPlayerEntity target, RegistryEntry<StatusEffect> effect, int baseTicks, int amplifier,
			double power) {
		target.addStatusEffect(new StatusEffectInstance(effect, (int) Math.round(baseTicks * power), amplifier));
	}
}
