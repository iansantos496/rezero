package com.rezero.mod.content;

import com.rezero.mod.server.CrystalService;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.world.World;

/**
 * Receptor de Mana: guarda mana (no "dano" do item) e a devolve ao jogador ao usar.
 * Para carregar, use o Concentrador de Mana. Lógica no servidor.
 */
public class ManaReceptorItem extends Item {
	public ManaReceptorItem(Settings settings) {
		super(settings);
	}

	@Override
	public ActionResult use(World world, PlayerEntity user, Hand hand) {
		if (world instanceof ServerWorld serverWorld && user instanceof ServerPlayerEntity player) {
			ItemStack stack = user.getStackInHand(hand);
			CrystalService.useReceptor(serverWorld, player, stack);
		}
		return ActionResult.SUCCESS;
	}
}
