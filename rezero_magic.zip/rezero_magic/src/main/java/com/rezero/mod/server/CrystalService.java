package com.rezero.mod.server;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import com.rezero.mod.content.ManaCrystalItem;
import com.rezero.mod.content.ModItems;
import com.rezero.mod.core.CrystalRarity;
import com.rezero.mod.core.CrystalRules;
import com.rezero.mod.data.PlayerDataStore;
import com.rezero.mod.data.PlayerMagicData;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;

/**
 * Uso dos cristais de mana e do Receptor (servidor). Os cristais são neutros (qualquer afinidade), mas exigem que a
 * afinidade já tenha sido escolhida. "Saturação": depois de usar um cristal ou sacar do Receptor existe uma espera
 * antes de poder fazer de novo, para os cristais não substituírem a regeneração normal.
 */
public final class CrystalService {
	private static final Map<UUID, Long> LOCKED_UNTIL = new HashMap<>();

	private CrystalService() {}

	public static void init() {
		ServerLifecycleEvents.SERVER_STOPPED.register(server -> LOCKED_UNTIL.clear());
	}

	/** Usar um cristal diretamente: restaura mana. */
	public static boolean useCrystal(ServerWorld world, ServerPlayerEntity player, ItemStack stack, CrystalRarity rarity) {
		PlayerMagicData data = PlayerDataStore.get(player);
		if (!checkReady(world, player, data)) {
			return false;
		}
		int add = CrystalRules.restoreAmount(data.mana(), data.maxMana(), rarity.mana());
		if (add <= 0) {
			message(player, "mana_full");
			return false;
		}
		data.setMana(data.mana() + add);
		PlayerDataStore.save(player, data);
		SpellService.sendMana(player, true);
		consume(player, stack);
		lock(world, player, CrystalRules.DIRECT_LOCK_TICKS);
		effects(world, player);
		player.sendMessage(Text.translatable("message.rezero_magic.crystal.used", add), true);
		return true;
	}

	/** Usar o Receptor: devolve ao jogador a mana guardada (o que couber). */
	public static boolean useReceptor(ServerWorld world, ServerPlayerEntity player, ItemStack stack) {
		PlayerMagicData data = PlayerDataStore.get(player);
		if (!checkReady(world, player, data)) {
			return false;
		}
		int stored = CrystalRules.storedFromDamage(stack.getDamage());
		if (stored <= 0) {
			message(player, "receptor_empty");
			return false;
		}
		int moved = CrystalRules.withdraw(stored, data.mana(), data.maxMana());
		if (moved <= 0) {
			message(player, "mana_full");
			return false;
		}
		data.setMana(data.mana() + moved);
		PlayerDataStore.save(player, data);
		SpellService.sendMana(player, true);
		stack.setDamage(CrystalRules.damageFromStored(stored - moved));
		lock(world, player, CrystalRules.RECEPTOR_LOCK_TICKS);
		effects(world, player);
		player.sendMessage(Text.translatable("message.rezero_magic.crystal.receptor_drawn", moved,
				stored - moved, CrystalRules.RECEPTOR_CAPACITY), true);
		return true;
	}

	/** Concentrador: cristal na mão principal + Receptor na outra mão = Receptor carregado com +25%. */
	public static boolean useConcentrator(ServerWorld world, ServerPlayerEntity player, BlockPos pos) {
		PlayerMagicData data = PlayerDataStore.get(player);
		if (data.affinity() == null) {
			message(player, "no_affinity");
			return false;
		}
		ItemStack crystalStack = player.getMainHandStack();
		ItemStack receptorStack = player.getOffHandStack();
		if (!(crystalStack.getItem() instanceof ManaCrystalItem crystal) || receptorStack.getItem() != ModItems.MANA_RECEPTOR) {
			message(player, "concentrator_help");
			return false;
		}
		int stored = CrystalRules.storedFromDamage(receptorStack.getDamage());
		int charge = CrystalRules.concentratedCharge(crystal.rarity());
		int now = CrystalRules.load(stored, charge);
		if (now < 0) {
			message(player, "receptor_full");
			return false;
		}
		receptorStack.setDamage(CrystalRules.damageFromStored(now));
		consume(player, crystalStack);
		world.spawnParticles(ParticleTypes.ENCHANT, pos.getX() + 0.5, pos.getY() + 1.2, pos.getZ() + 0.5, 25, 0.4, 0.3, 0.4, 0.4);
		world.playSound(null, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5,
				SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME, SoundCategory.BLOCKS, 1.0f, 1.0f);
		player.sendMessage(Text.translatable("message.rezero_magic.crystal.concentrated", now - stored, now,
				CrystalRules.RECEPTOR_CAPACITY), true);
		return true;
	}

	private static boolean checkReady(ServerWorld world, ServerPlayerEntity player, PlayerMagicData data) {
		if (data.affinity() == null) {
			message(player, "no_affinity");
			return false;
		}
		Long until = LOCKED_UNTIL.get(player.getUuid());
		if (until != null) {
			int left = CrystalRules.lockRemaining(world.getTime(), until);
			if (left > 0) {
				player.sendMessage(Text.translatable("message.rezero_magic.crystal.saturated",
						String.format("%.1f", left / 20.0)), true);
				return false;
			}
		}
		return true;
	}

	private static void lock(ServerWorld world, ServerPlayerEntity player, int ticks) {
		LOCKED_UNTIL.put(player.getUuid(), world.getTime() + ticks);
	}

	private static void consume(ServerPlayerEntity player, ItemStack stack) {
		if (!player.isCreative()) {
			stack.decrement(1);
		}
	}

	private static void effects(ServerWorld world, ServerPlayerEntity player) {
		world.spawnParticles(ParticleTypes.ENCHANT, player.getX(), player.getY() + 1.0, player.getZ(), 30, 0.5, 0.8, 0.5, 0.4);
		world.playSound(null, player.getX(), player.getY(), player.getZ(),
				SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME, SoundCategory.PLAYERS, 1.0f, 1.4f);
	}

	private static void message(ServerPlayerEntity player, String key) {
		player.sendMessage(Text.translatable("message.rezero_magic.crystal." + key), true);
	}
}
