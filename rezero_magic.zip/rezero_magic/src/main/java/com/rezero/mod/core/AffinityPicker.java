package com.rezero.mod.core;

/**
 * Fluxo da tela de afinidade, em código puro (testável fora do jogo):
 * escolher um cartão -> pedir confirmação -> só então existe algo a enviar ao servidor.
 * Imutável: cada ação devolve um novo estado.
 */
public final class AffinityPicker {
	private final Affinity selected;
	private final boolean confirming;

	public AffinityPicker() {
		this(null, false);
	}

	private AffinityPicker(Affinity selected, boolean confirming) {
		this.selected = selected;
		this.confirming = confirming;
	}

	public Affinity selected() {
		return selected;
	}

	public boolean confirming() {
		return confirming;
	}

	/** Escolher (ou trocar) o cartão. Trocar de cartão cancela uma confirmação pendente. */
	public AffinityPicker select(Affinity affinity) {
		return affinity == null ? this : new AffinityPicker(affinity, false);
	}

	/** Passar para a etapa "Tem certeza?". Sem cartão escolhido, nada acontece. */
	public AffinityPicker requestConfirm() {
		return selected == null ? this : new AffinityPicker(selected, true);
	}

	/** Voltar da confirmação para a escolha, mantendo o cartão. */
	public AffinityPicker back() {
		return new AffinityPicker(selected, false);
	}

	/** @return a afinidade a enviar ao servidor: só existe depois de confirmar; senão, null. */
	public Affinity choiceToSend() {
		return confirming ? selected : null;
	}
}
