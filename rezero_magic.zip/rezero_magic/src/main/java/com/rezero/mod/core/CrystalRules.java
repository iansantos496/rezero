package com.rezero.mod.core;

/**
 * Regras puras dos cristais e do Receptor de Mana (testáveis fora do jogo).
 * O Receptor guarda mana no "dano" do item: guardado = capacidade - dano. O item novo nasce VAZIO.
 */
public final class CrystalRules {
	public static final int RECEPTOR_CAPACITY = 300;
	/** Durabilidade máxima do item (um a mais que a capacidade, para o item nunca quebrar quando vazio). */
	public static final int RECEPTOR_MAX_DAMAGE = RECEPTOR_CAPACITY + 1;
	/** Saturação: depois de usar um cristal direto, não se pode usar outro por 5 s. */
	public static final int DIRECT_LOCK_TICKS = 100;
	/** Depois de sacar mana do Receptor, 3 s de espera. */
	public static final int RECEPTOR_LOCK_TICKS = 60;
	/** O Concentrador carrega o Receptor com +25% de eficiência. */
	public static final double CONCENTRATOR_BONUS = 1.25;

	private CrystalRules() {}

	/** Mana realmente adicionada ao usar um cristal diretamente (nunca passa do máximo). */
	public static int restoreAmount(int mana, int maxMana, int restore) {
		return Math.max(0, Math.min(Math.max(0, restore), maxMana - Math.max(0, mana)));
	}

	public static int storedFromDamage(int damage) {
		return Math.max(0, Math.min(RECEPTOR_CAPACITY, RECEPTOR_CAPACITY - damage));
	}

	public static int damageFromStored(int stored) {
		return RECEPTOR_CAPACITY - Math.max(0, Math.min(RECEPTOR_CAPACITY, stored));
	}

	/** Carga que o Concentrador coloca no Receptor para este cristal. */
	public static int concentratedCharge(CrystalRarity rarity) {
		return (int) Math.round(rarity.mana() * CONCENTRATOR_BONUS);
	}

	/** Novo valor guardado depois de carregar {@code charge}; devolve -1 se o Receptor já está cheio. */
	public static int load(int stored, int charge) {
		int s = Math.max(0, Math.min(RECEPTOR_CAPACITY, stored));
		if (s >= RECEPTOR_CAPACITY) {
			return -1;
		}
		return Math.min(RECEPTOR_CAPACITY, s + Math.max(0, charge));
	}

	/** Quanto sai do Receptor para o jogador: o que houver, limitado ao espaço livre na mana. */
	public static int withdraw(int stored, int mana, int maxMana) {
		return Math.max(0, Math.min(Math.max(0, stored), maxMana - Math.max(0, mana)));
	}

	/** Ticks que ainda faltam da trava (0 se liberada). */
	public static int lockRemaining(long now, long lockedUntil) {
		return (int) Math.max(0L, lockedUntil - now);
	}
}
