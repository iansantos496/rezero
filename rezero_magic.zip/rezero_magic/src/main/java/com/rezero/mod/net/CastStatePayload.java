package com.rezero.mod.net;

import com.rezero.mod.ReZeroMod;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/**
 * Servidor -> cliente, só para a barra de conjuração e a recarga na tela:
 * início de conjuração = (id, castTicks > 0, 0); fim = (id, 0, recarga); interrompida = (id, 0, 0).
 */
public record CastStatePayload(int spellId, int castTicks, int cooldownTicks) implements CustomPayload {
	public static final CustomPayload.Id<CastStatePayload> ID =
			new CustomPayload.Id<>(Identifier.of(ReZeroMod.MOD_ID, "cast_state"));

	public static final PacketCodec<RegistryByteBuf, CastStatePayload> CODEC = PacketCodec.tuple(
			PacketCodecs.VAR_INT, CastStatePayload::spellId,
			PacketCodecs.VAR_INT, CastStatePayload::castTicks,
			PacketCodecs.VAR_INT, CastStatePayload::cooldownTicks,
			CastStatePayload::new);

	@Override
	public CustomPayload.Id<? extends CustomPayload> getId() {
		return ID;
	}
}
