# Re:Zero Magic (Fabric 1.21.11, singleplayer)

Mod com mana e três magias inspiradas em Re:Zero.

## Teclas (mudam em Opções > Controles > "Re:Zero Magia")

| Tecla | Magia | Custo | O que faz |
|-------|-------|-------|-----------|
| R | Bola de Fogo | 25 | Projétil que explode em área, causa dano e põe fogo (não destrói blocos) |
| G | Lança de Gelo | 15 | Projétil rápido; dano, lentidão forte e congelamento em pequena área |
| V | Mãos Invisíveis | 20 | Agarra o mob na mira (até 24 blocos) e o segura na sua frente por até 10 s. Aperte V de novo para arremessar |

Mana: 100 no máximo, recarrega 1 ponto a cada 0,3 s. Barra azul no canto superior esquerdo.

## Compilar

Requisitos: JDK 21 e Gradle (ou IntelliJ IDEA, que cuida disso).

Este projeto não inclui `gradlew` / `gradle-wrapper.jar`. Duas formas de resolver:

**A) Mais fácil:** gere um projeto-base em https://fabricmc.net/develop/template (Minecraft 1.21.11, mappings **Yarn**, sem "split sources", Mod ID `rezero_magic`, pacote `com.rezero.magic`). Depois copie a pasta `src/` deste projeto por cima da `src/` do template (substituindo `fabric.mod.json`).

**B) Usar este projeto direto:** dentro da pasta, rode uma vez `gradle wrapper --gradle-version 9.2.1` e depois `./gradlew build` (Windows: `gradlew.bat build`).

O mod final sai em `build/libs/rezero_magic-1.0.0.jar`. Coloque em `.minecraft/mods/` junto com o Fabric API 1.21.11 e o Fabric Loader.

Para testar sem instalar: `./gradlew runClient`.

## Se a compilação falhar

Os nomes da API do Minecraft mudam bastante entre versões. Os pontos mais prováveis:

- `ReZeroMagicClient`: `KeyBinding.Category.create(...)` e `HudRenderCallback`.
- `SpellCaster`: `setOnFireFor`, `setFrozenTicks`, `addVelocity`, `damage(world, source, amount)`.

Mande a mensagem de erro e eu corrijo.
