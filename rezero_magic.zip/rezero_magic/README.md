# Re:Zero Magia (Fabric 1.21.11)

Projeto novo, em construção por etapas. Veja `docs/PLANO.md` (plano técnico) e `docs/PROGRESSO.md` (estado atual).

## Compilar
Pelo GitHub (como antes): envie o zip ao repositório; o workflow `build.yml` já existente compila e publica o .jar em Actions > Artifacts.
Localmente: JDK 21 + `gradle build` (precisa acesso à internet para baixar o Minecraft e o Fabric).

## Verificações que não precisam do Minecraft
- `bash tools/test_core.sh`  -> compila e testa o código puro (pacote `core`).
- `python3 tools/check_static.py` -> JSON, chaves de tradução, pacotes, imports e entrypoints.
